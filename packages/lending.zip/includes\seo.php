<?php
declare(strict_types=1);

function ld_seo(): array
{
    return ld_effective_settings()['seo'] ?? ld_default_settings()['seo'];
}

function ld_seo_page_vars(string $lang, bool $is_landing, int $templateId = 1): array
{
    $seo = ld_seo();
    $business = ld_business();
    $names = ld_template_names($lang);
    $bizName = ld_pick($business['name'], $lang);
    $tagline = ld_pick($business['tagline'], $lang);

    global $t;
    $title = ld_pick($seo['title'] ?? [], $lang);
    if ($title === '') {
        $title = $is_landing
            ? (($names[$templateId] ?? 'Landing') . ' — ' . $bizName)
            : ($t['meta']['title'] ?? 'Lending CMS');
    }

    $description = ld_pick($seo['description'] ?? [], $lang);
    if ($description === '') {
        $description = $tagline !== '' ? $tagline : ($t['meta']['description'] ?? '');
    }

    $keywords = ld_pick($seo['keywords'] ?? [], $lang);
    $ogImage = trim((string) ($seo['og_image'] ?? ''));
    if ($ogImage === '') {
        $ogImage = trim((string) (ld_effective_settings()['blocks']['hero_image'] ?? ''));
    }
    if ($ogImage === '') {
        $ogImage = 'https://bilohash.com/lending/assets/img/og-default.jpg';
    }

    // Demo landings (template.php) canonicalize to the hub so Google indexes /lending/ only.
    $canonical = ld_hub_canonical_url($lang);

    return [
        'title' => $title,
        'description' => $description,
        'keywords' => $keywords,
        'og_image' => $ogImage,
        'canonical' => $canonical,
        'site_name' => $bizName !== '' ? $bizName : (LD_SITE_NAME ?? 'Lending CMS'),
    ];
}

function ld_render_seo_head(array $vars, string $lang): void
{
    $ogLocale = match ($lang) {
        'no' => 'nb_NO',
        'sv' => 'sv_SE',
        'pl' => 'pl_PL',
        'uk' => 'uk_UA',
        'ru' => 'ru_RU',
        'lt' => 'lt_LT',
        default => 'en_GB',
    };

    if (($vars['keywords'] ?? '') !== ''): ?>
    <meta name="keywords" content="<?= ld_h($vars['keywords']) ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?= ld_h($vars['canonical']) ?>">
    <?php
    $ogPath = dirname(__DIR__, 2) . '/includes/bh-open-graph.php';
    if (is_file($ogPath)) {
        require_once $ogPath;
        bh_render_open_graph([
            'title' => $vars['title'],
            'description' => $vars['description'],
            'url' => $vars['canonical'],
            'image' => $vars['og_image'],
            'site_name' => $vars['site_name'],
            'type' => 'website',
            'locale' => $ogLocale,
            'locale_alternates' => array_values(array_filter(array_map(
                static fn(string $code): ?string => $code === $lang ? null : match ($code) {
                    'no' => 'nb_NO',
                    'sv' => 'sv_SE',
                    'pl' => 'pl_PL',
                    'uk' => 'uk_UA',
                    'ru' => 'ru_RU',
                    'lt' => 'lt_LT',
                    default => 'en_GB',
                },
                array_keys(ld_langs())
            ))),
            'image_alt' => $vars['title'],
        ]);
    }
}

function ld_schema_opening_hours(): array
{
    return ['Mo-Fr 09:00-19:00', 'Sa 10:00-15:00'];
}

function ld_render_schema(string $lang): void
{
    // Demo landings (template.php) are noindex — schema only on the product hub.
    if (function_exists('ld_template_preview_active') && ld_template_preview_active()) {
        return;
    }

    global $t, $site_url;
    $pageUrl = ld_hub_canonical_url($lang);
    $hubRoot = rtrim((string) $site_url, '/') . '/';
    $productName = (string) ($t['meta']['site_name'] ?? 'Business Landing CMS');
    $seoVars = ld_seo_page_vars($lang, false);
    $description = (string) ($seoVars['description'] ?? '');
    $ogImage = (string) ($seoVars['og_image'] ?? '');

    $graph = [
        [
            '@type' => 'WebSite',
            '@id' => $hubRoot . '#website',
            'url' => $hubRoot,
            'name' => $productName,
            'description' => $description,
            'inLanguage' => [$lang === 'uk' ? 'uk' : $lang],
            'publisher' => ['@id' => 'https://bilohash.com/#organization'],
        ],
        [
            '@type' => 'SoftwareApplication',
            '@id' => $pageUrl . '#software',
            'name' => $productName,
            'description' => $description,
            'url' => $pageUrl,
            'applicationCategory' => 'BusinessApplication',
            'operatingSystem' => 'Web',
            'offers' => [
                '@type' => 'Offer',
                'price' => '0',
                'priceCurrency' => 'NOK',
                'availability' => 'https://schema.org/InStock',
                'url' => $pageUrl,
            ],
            'image' => $ogImage !== '' ? $ogImage : null,
            'provider' => [
                '@type' => 'Organization',
                'name' => 'BILOHASH',
                'url' => 'https://bilohash.com/',
            ],
        ],
        [
            '@type' => 'WebPage',
            '@id' => $pageUrl . '#webpage',
            'url' => $pageUrl,
            'name' => (string) ($seoVars['title'] ?? $productName),
            'description' => $description,
            'isPartOf' => ['@id' => $hubRoot . '#website'],
            'inLanguage' => $lang === 'uk' ? 'uk-UA' : ($lang === 'no' ? 'nb-NO' : $lang),
        ],
    ];

    echo '<script type="application/ld+json">' . json_encode(
        ['@context' => 'https://schema.org', '@graph' => array_values(array_filter($graph, static fn(array $n): bool => $n !== []))],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    ) . '</script>' . "\n";
}