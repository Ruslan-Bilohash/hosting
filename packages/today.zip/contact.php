<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/site-integrations.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';
td_boot_public_integrations();
session_start();
$current_page = 'contact';
$canonical = td_url('contact.php');
$page_title = $t['contact']['meta_title'] ?? $t['contact']['title'];
$page_desc = $t['contact']['meta_desc'] ?? '';
$feedback = '';
$feedback_type = '';
$td_recap_key = cms_recaptcha_site_key();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');
    if ($name === '' || $email === '' || $message === '') {
        $feedback = $t['contact']['error_fields'];
        $feedback_type = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $feedback = $t['contact']['error_email'];
        $feedback_type = 'error';
    } elseif (mb_strlen($message) < 10) {
        $feedback = $t['contact']['error_message'];
        $feedback_type = 'error';
    } elseif (!bh_cms_verify_recaptcha($_POST['g-recaptcha-response'] ?? '', td_site_settings())) {
        $feedback = $t['contact']['error_captcha'] ?? 'Please complete reCAPTCHA.';
        $feedback_type = 'error';
    } else {
        $feedback = $t['contact']['success'];
        $feedback_type = 'success';
    }
}

$seo_schemas = [td_seo_organization(), td_seo_webpage(td_absolute_url($canonical), $page_title, $page_desc)];
require __DIR__ . '/includes/header.php';
?>

<section class="td-page-hero">
    <div class="td-container">
        <nav class="td-crumb"><a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a> → <?= htmlspecialchars($t['contact']['breadcrumb']) ?></nav>
        <h1><?= htmlspecialchars($t['contact']['title']) ?></h1>
        <p class="td-lead"><?= htmlspecialchars($t['contact']['lead']) ?></p>
    </div>
</section>

<section class="td-section">
    <div class="td-container td-contact-grid">
        <div class="td-contact-info">
            <p><?= htmlspecialchars($t['contact']['text']) ?></p>
            <div class="td-contact-office">
                <h3><?= htmlspecialchars($t['contact']['office']) ?></h3>
                <p><?= htmlspecialchars($t['contact']['office_text']) ?></p>
            </div>
            <p class="td-demo-note"><?= htmlspecialchars($t['contact']['demo_note']) ?></p>
        </div>
        <form class="td-contact-form" method="post">
            <?php if ($feedback): ?>
            <div class="td-alert td-alert--<?= htmlspecialchars($feedback_type) ?>"><?= htmlspecialchars($feedback) ?></div>
            <?php endif; ?>
            <label><?= htmlspecialchars($t['contact']['name']) ?><input type="text" name="name" required></label>
            <label><?= htmlspecialchars($t['contact']['email']) ?><input type="email" name="email" required></label>
            <label><?= htmlspecialchars($t['contact']['subject']) ?><input type="text" name="subject" value="<?= htmlspecialchars($t['contact']['default_subject']) ?>"></label>
            <label><?= htmlspecialchars($t['contact']['message']) ?><textarea name="message" rows="6" required></textarea></label>
            <?php if ($td_recap_key !== ''): ?>
            <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($td_recap_key) ?>"></div>
            <?php endif; ?>
            <button type="submit" class="td-btn-primary"><?= htmlspecialchars($t['contact']['submit']) ?></button>
        </form>
    </div>
</section>

<?php if (!empty($td_recap_key)): ?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>