<?php
require_once __DIR__ . '/init.php';

$q = trim($_GET['q'] ?? '');
$results = $q !== '' ? td_search_articles($q) : [];
$current_page = 'search';
$canonical = td_url('search.php' . ($q ? '?q=' . urlencode($q) : ''));
$page_title = ($q ? sprintf($t['search']['results_for'] ?? 'Results for "%s"', $q) : $t['search']['meta_title']) . ' — ' . TD_SITE_NAME;
$page_desc = $t['search']['meta_title'] ?? $t['meta']['description'];
$canon_abs = td_absolute_url($canonical);
$seo_noindex = true;
$seo_schemas = [td_seo_organization(), td_seo_webpage($canon_abs, $page_title, $page_desc)];

require __DIR__ . '/includes/header.php';
?>

<section class="td-page-hero">
    <div class="td-container">
        <nav class="td-crumb"><a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a> → <?= htmlspecialchars($t['search']['breadcrumb']) ?></nav>
        <h1><?= htmlspecialchars($t['search']['title']) ?></h1>
        <form class="td-search-form" action="<?= td_url('search.php') ?>" method="get" role="search">
            <?php if ($lang !== 'no'): ?><input type="hidden" name="lang" value="<?= htmlspecialchars($lang) ?>"><?php endif; ?>
            <input type="search" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="<?= htmlspecialchars($t['search']['placeholder']) ?>" autofocus>
            <button type="submit" class="td-btn-primary"><?= htmlspecialchars($t['search']['button']) ?></button>
        </form>
    </div>
</section>

<section class="td-section">
    <div class="td-container">
        <?php if ($q === ''): ?>
        <p class="td-empty-text"><?= htmlspecialchars($t['search']['no_query']) ?></p>
        <div class="td-search-tips">
            <h3><?= htmlspecialchars($t['search']['tips_title']) ?></h3>
            <ul><?php foreach ($t['search']['tips'] ?? [] as $tip): ?><li><?= htmlspecialchars($tip) ?></li><?php endforeach; ?></ul>
        </div>
        <?php elseif (!$results): ?>
        <p class="td-empty-text"><?= htmlspecialchars($t['search']['no_results']) ?></p>
        <?php else: ?>
        <p class="td-results-count"><?= sprintf($t['search']['found'] ?? '%d articles found', count($results)) ?></p>
        <div class="td-articles-grid">
            <?php foreach ($results as $article): $size = 'medium'; require __DIR__ . '/includes/article-card.php'; endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>