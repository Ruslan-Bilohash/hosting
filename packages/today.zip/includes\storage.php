<?php

function td_data_path(string $file): string
{
    return __DIR__ . '/../data/' . $file;
}

function td_articles_file(): string
{
    return td_data_path('articles.json');
}

function td_journalists_file(): string
{
    return td_data_path('journalists.json');
}

function td_categories_file(): string
{
    return td_data_path('categories.json');
}

function td_seed_version_file(): string
{
    return td_data_path('.seed-version');
}

function td_sync_demo_seed(): void
{
    if (!defined('TD_SEED_VERSION')) {
        return;
    }

    $marker = td_seed_version_file();
    $stored = is_file($marker) ? trim((string) file_get_contents($marker)) : '';
    $target = (string) TD_SEED_VERSION;

    if ($stored === $target) {
        return;
    }

    $articles = require __DIR__ . '/../data/articles.php';
    if (is_array($articles)) {
        td_save_articles($articles);
    }

    $journalists = require __DIR__ . '/../data/journalists.php';
    if (is_array($journalists)) {
        td_save_journalists($journalists);
    }

    file_put_contents($marker, $target, LOCK_EX);
}

function td_ensure_articles_json(): void
{
    td_sync_demo_seed();

    $json = td_articles_file();
    if (!is_file($json)) {
        $defaults = require __DIR__ . '/../data/articles.php';
        td_save_articles($defaults);
    }
}

function td_ensure_journalists_json(): void
{
    td_sync_demo_seed();

    $json = td_journalists_file();
    if (!is_file($json)) {
        $defaults = require __DIR__ . '/../data/journalists.php';
        td_save_journalists($defaults);
    }
}

function td_ensure_categories_json(): void
{
    $json = td_categories_file();
    if (!is_file($json)) {
        $defaults = require __DIR__ . '/../data/categories.php';
        td_save_categories($defaults);
    }
}

function td_load_articles_raw(): array
{
    td_ensure_articles_json();
    $raw  = file_get_contents(td_articles_file());
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

function td_save_articles(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(td_articles_file(), $json, LOCK_EX) !== false;
}

function td_load_journalists_raw(): array
{
    td_ensure_journalists_json();
    $raw  = file_get_contents(td_journalists_file());
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

function td_save_journalists(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(td_journalists_file(), $json, LOCK_EX) !== false;
}

function td_load_categories_raw(): array
{
    td_ensure_categories_json();
    $raw  = file_get_contents(td_categories_file());
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

function td_save_categories(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(td_categories_file(), $json, LOCK_EX) !== false;
}

function td_settings_file(): string
{
    return td_data_path('settings.json');
}

function td_load_settings(): array
{
    require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
    $defaults = bh_cms_site_settings_defaults(bh_cms_product_accent('today'));
    $file = td_settings_file();
    if (!is_readable($file)) {
        td_save_settings($defaults);
        return $defaults;
    }
    $data = json_decode(file_get_contents($file) ?: '{}', true);
    return is_array($data) ? bh_cms_merge_site_settings($data, 'today') : $defaults;
}

function td_save_settings(array $settings): bool
{
    require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
    $merged = bh_cms_merge_site_settings($settings, 'today');
    return file_put_contents(td_settings_file(), json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) !== false;
}