<?php
require_once __DIR__ . '/init.php';
td_admin_require();
$admin_page = 'articles';

$lang_codes = ['no', 'en', 'uk', 'ru'];
$lang_labels = [
    'no' => $ta['lang_no'],
    'en' => $ta['lang_en'],
    'uk' => $ta['lang_uk'],
    'ru' => $ta['lang_ru'],
];

function td_admin_next_article_id(array $list): string
{
    $max = 0;
    foreach ($list as $item) {
        if (preg_match('/^art-(\d+)$/', $item['id'] ?? '', $m)) {
            $max = max($max, (int) $m[1]);
        }
    }
    return 'art-' . str_pad((string) ($max + 1), 2, '0', STR_PAD_LEFT);
}

// Delete
if (!empty($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $list = td_load_articles_raw();
    $list = array_values(array_filter($list, fn($a) => ($a['id'] ?? '') !== $delete_id));
    td_save_articles($list);
    header('Location: ' . td_admin_url('articles.php?deleted=1'), true, 302);
    exit;
}

$is_new  = !empty($_GET['new']);
$id      = $_GET['id'] ?? '';
$list    = td_load_articles_raw();
$idx     = null;
$article = null;

if ($is_new) {
    $article = [
        'id'            => td_admin_next_article_id($list),
        'slug'          => '',
        'category_id'   => td_categories()[0]['id'] ?? 'politics',
        'journalist_id' => td_journalists()[0]['id'] ?? '',
        'featured'      => false,
        'breaking'      => false,
        'published'     => true,
        'published_at'  => date('c'),
        'image'         => 'assets/images/articles/placeholder.svg',
        'title'         => array_fill_keys($lang_codes, ''),
        'excerpt'       => array_fill_keys($lang_codes, ''),
        'body'          => array_fill_keys($lang_codes, ''),
    ];
} else {
    foreach ($list as $i => $a) {
        if (($a['id'] ?? '') === $id) {
            $idx = $i;
            $article = $a;
            break;
        }
    }
    if ($article === null) {
        header('Location: ' . td_admin_url('articles.php'), true, 302);
        exit;
    }
}

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $record = [
        'id'            => $is_new ? td_admin_next_article_id($list) : $article['id'],
        'slug'          => trim($_POST['slug'] ?? ''),
        'category_id'   => $_POST['category_id'] ?? $article['category_id'],
        'journalist_id' => $_POST['journalist_id'] ?? $article['journalist_id'],
        'featured'      => !empty($_POST['featured']),
        'breaking'      => !empty($_POST['breaking']),
        'published'     => !empty($_POST['published']),
        'published_at'  => trim($_POST['published_at'] ?? $article['published_at'] ?? date('c')),
        'image'         => trim($_POST['image'] ?? ''),
        'title'         => [],
        'excerpt'       => [],
        'body'          => [],
    ];

    foreach ($lang_codes as $lc) {
        $record['title'][$lc]   = trim($_POST['title_' . $lc] ?? '');
        $record['excerpt'][$lc] = trim($_POST['excerpt_' . $lc] ?? '');
        $record['body'][$lc]    = trim($_POST['body_' . $lc] ?? '');
    }

    if ($record['slug'] === '' && $record['title']['en'] !== '') {
        $record['slug'] = strtolower(preg_replace('/[^a-z0-9]+/', '-', $record['title']['en']) ?? '');
        $record['slug'] = trim($record['slug'], '-');
    }

    $cat_ids = array_column(td_categories(), 'id');
    if (!in_array($record['category_id'], $cat_ids, true)) {
        $record['category_id'] = $article['category_id'] ?? ($cat_ids[0] ?? '');
    }

    $jour_ids = array_column(td_journalists(), 'id');
    if (!in_array($record['journalist_id'], $jour_ids, true)) {
        $record['journalist_id'] = $article['journalist_id'] ?? ($jour_ids[0] ?? '');
    }

    if ($is_new) {
        $list[] = $record;
    } else {
        $list[$idx] = $record;
    }

    if (td_save_articles($list)) {
        if ($is_new) {
            header('Location: ' . td_admin_url('article.php?id=' . urlencode($record['id']) . '&saved=1'), true, 302);
            exit;
        }
        $flash = 'success';
        $article = $record;
        $is_new = false;
        $id = $record['id'];
        foreach ($list as $i => $a) {
            if (($a['id'] ?? '') === $id) {
                $idx = $i;
                break;
            }
        }
    } else {
        $flash = 'error';
    }
}

if (!empty($_GET['saved'])) {
    $flash = 'success';
}

$page_title = $is_new
    ? ($ta['add_article'] ?? 'Add article')
    : (($ta['edit_article'] ?? 'Edit article') . ': ' . td_localized($article, 'title', 'en'));

require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['saved']) ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($page_title) ?></h2>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <?php if (!$is_new && ($article['slug'] ?? '') !== ''): ?>
            <a href="<?= td_url('article.php?slug=' . urlencode($article['slug'])) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                <i class="fas fa-eye"></i> <?= htmlspecialchars($ta['preview']) ?>
            </a>
            <?php endif; ?>
            <a href="<?= td_admin_url('articles.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['cancel']) ?></a>
        </div>
    </div>
    <div class="adm-card-body padded">
        <form method="post">
            <div style="display:flex;gap:20px;margin-bottom:20px;flex-wrap:wrap;align-items:flex-start">
                <img src="<?= htmlspecialchars(td_article_image($article)) ?>" alt="" style="width:200px;height:140px;object-fit:cover;border-radius:8px;border:1px solid var(--adm-border)">
                <div style="font-size:13px;color:var(--adm-muted)">
                    <strong><?= htmlspecialchars($ta['id']) ?>:</strong> <?= htmlspecialchars($article['id'] ?? '') ?>
                </div>
            </div>

            <div class="adm-form-grid">
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['slug']) ?></label>
                    <input type="text" name="slug" value="<?= htmlspecialchars($article['slug'] ?? '') ?>" placeholder="my-article-slug">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['category']) ?></label>
                    <select name="category_id">
                        <?php foreach (td_categories() as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['id']) ?>" <?= ($article['category_id'] ?? '') === ($cat['id'] ?? '') ? 'selected' : '' ?>>
                            <?= htmlspecialchars(td_localized($cat, 'name')) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['journalist']) ?></label>
                    <select name="journalist_id">
                        <?php foreach (td_journalists() as $jour): ?>
                        <option value="<?= htmlspecialchars($jour['id']) ?>" <?= ($article['journalist_id'] ?? '') === ($jour['id'] ?? '') ? 'selected' : '' ?>>
                            <?= htmlspecialchars(td_localized($jour, 'name')) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['published_at']) ?></label>
                    <input type="text" name="published_at" value="<?= htmlspecialchars($article['published_at'] ?? '') ?>" placeholder="2026-06-26T09:15:00+02:00">
                </div>
                <div class="adm-field adm-field-full">
                    <label><?= htmlspecialchars($ta['image']) ?></label>
                    <input type="text" name="image" value="<?= htmlspecialchars($article['image'] ?? '') ?>" placeholder="assets/images/articles/placeholder.svg">
                </div>
            </div>

            <div class="adm-check-row" style="margin-top:16px">
                <label><input type="checkbox" name="published" value="1" <?= ($article['published'] ?? true) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['published']) ?></label>
                <label><input type="checkbox" name="featured" value="1" <?= !empty($article['featured']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['featured']) ?></label>
                <label><input type="checkbox" name="breaking" value="1" <?= !empty($article['breaking']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['breaking']) ?></label>
            </div>

            <div class="adm-lang-tabs" style="margin-top:24px">
                <div class="adm-lang-tabs-nav">
                    <?php foreach ($lang_codes as $i => $lc): ?>
                    <button type="button" class="adm-lang-tab <?= $i === 0 ? 'active' : '' ?>" data-tab="<?= $lc ?>"><?= htmlspecialchars($lang_labels[$lc]) ?></button>
                    <?php endforeach; ?>
                </div>
                <?php foreach ($lang_codes as $i => $lc): ?>
                <div class="adm-lang-tab-panel <?= $i === 0 ? 'active' : '' ?>" data-panel="<?= $lc ?>">
                    <div class="adm-form-grid" style="margin-top:16px">
                        <div class="adm-field adm-field-full">
                            <label><?= htmlspecialchars($ta['title_label']) ?></label>
                            <input type="text" name="title_<?= $lc ?>" value="<?= htmlspecialchars($article['title'][$lc] ?? '') ?>">
                        </div>
                        <div class="adm-field adm-field-full">
                            <label><?= htmlspecialchars($ta['excerpt_label']) ?></label>
                            <textarea name="excerpt_<?= $lc ?>" rows="3"><?= htmlspecialchars($article['excerpt'][$lc] ?? '') ?></textarea>
                        </div>
                        <div class="adm-field adm-field-full">
                            <label><?= htmlspecialchars($ta['body_label']) ?></label>
                            <textarea name="body_<?= $lc ?>" rows="10"><?= htmlspecialchars($article['body'][$lc] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top:24px">
                <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($is_new ? ($ta['create'] ?? $ta['save']) : $ta['save']) ?></button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    document.querySelectorAll('.adm-lang-tab').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var tab = btn.getAttribute('data-tab');
            document.querySelectorAll('.adm-lang-tab').forEach(function (b) { b.classList.remove('active'); });
            document.querySelectorAll('.adm-lang-tab-panel').forEach(function (p) { p.classList.remove('active'); });
            btn.classList.add('active');
            document.querySelector('.adm-lang-tab-panel[data-panel="' + tab + '"]')?.classList.add('active');
        });
    });
})();
</script>

<?php require __DIR__ . '/includes/layout-end.php'; ?>