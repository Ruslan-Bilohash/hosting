<?php
require_once __DIR__ . '/init.php';

$current_page = 'home';
$featured = td_featured_articles(3);
$breaking = td_breaking_articles(3);
$latest = array_slice(td_articles(), 0, 8);
$hero = $featured[0] ?? $latest[0] ?? null;
$side_featured = array_slice($featured, 1, 2);
$journalists = array_slice(td_journalists(), 0, 4);
$categories = td_categories();
$stats = [
    'articles' => count(td_articles()),
    'journalists' => count(td_journalists()),
    'categories' => count($categories),
];

$canonical = td_url('index.php');
$page_title = $t['meta']['title'];
$page_desc = $t['meta']['description'];
$canon_abs = td_absolute_url($canonical);
$seo_schemas = [
    td_seo_organization(),
    td_seo_software_application($canon_abs),
    td_seo_website($canon_abs),
    td_seo_webpage($canon_abs, $page_title, $page_desc),
    td_seo_item_list(td_articles(), $lang, $canon_abs),
];

require __DIR__ . '/includes/header.php';
?>

<section class="td-home-hero">
    <div class="td-container">
        <div class="td-home-intro">
            <h1><?= htmlspecialchars($t['home']['title']) ?></h1>
            <p><?= htmlspecialchars($t['home']['subtitle']) ?></p>
        </div>
        <?php if ($breaking): ?>
        <div class="td-breaking-ticker" aria-label="<?= htmlspecialchars($t['home']['breaking']) ?>">
            <span class="td-breaking-label"><?= htmlspecialchars($t['home']['breaking']) ?></span>
            <?php foreach ($breaking as $b): ?>
            <a href="<?= htmlspecialchars(td_article_url($b)) ?>"><?= htmlspecialchars(td_localized($b, 'title')) ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php if ($hero): ?>
<section class="td-section td-featured-hero">
    <div class="td-container td-featured-grid">
        <div class="td-featured-main">
            <?php $article = $hero; $size = 'hero'; require __DIR__ . '/includes/article-card.php'; ?>
        </div>
        <?php if ($side_featured): ?>
        <div class="td-featured-side">
            <?php foreach ($side_featured as $article): $size = 'medium'; require __DIR__ . '/includes/article-card.php'; endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<section class="td-section">
    <div class="td-container">
        <div class="td-section-head">
            <div>
                <h2><?= htmlspecialchars($t['home']['latest']) ?></h2>
                <p><?= htmlspecialchars($t['home']['latest_sub']) ?></p>
            </div>
        </div>
        <div class="td-articles-grid">
            <?php foreach ($latest as $article): $size = 'medium'; require __DIR__ . '/includes/article-card.php'; endforeach; ?>
        </div>
    </div>
</section>

<section class="td-section td-section--paper">
    <div class="td-container">
        <div class="td-section-head">
            <h2><?= htmlspecialchars($t['home']['categories']) ?></h2>
            <p><?= htmlspecialchars($t['home']['categories_sub']) ?></p>
        </div>
        <div class="td-categories-grid">
            <?php foreach ($categories as $cat): ?>
            <a href="<?= htmlspecialchars(td_category_url($cat)) ?>" class="td-category-card" style="--cat-color: <?= htmlspecialchars($cat['color'] ?? '#111') ?>">
                <i class="<?= htmlspecialchars(td_fa_icon($cat['icon'] ?? 'folder')) ?>"></i>
                <span><?= htmlspecialchars(td_localized($cat, 'name')) ?></span>
                <small><?= sprintf($t['category']['article_count'] ?? '%d articles', count(td_articles_by_category($cat['id'] ?? ''))) ?></small>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="td-section">
    <div class="td-container td-stats-row">
        <div class="td-stat"><strong><?= $stats['articles'] ?></strong><span><?= htmlspecialchars($t['home']['stats_articles']) ?></span></div>
        <div class="td-stat"><strong><?= $stats['journalists'] ?></strong><span><?= htmlspecialchars($t['home']['stats_journalists']) ?></span></div>
        <div class="td-stat"><strong><?= $stats['categories'] ?></strong><span><?= htmlspecialchars($t['home']['stats_categories']) ?></span></div>
        <div class="td-stat"><strong>4</strong><span><?= htmlspecialchars($t['home']['stats_langs']) ?></span></div>
    </div>
</section>

<section class="td-section td-section--paper">
    <div class="td-container">
        <div class="td-section-head td-section-head--split">
            <div>
                <h2><?= htmlspecialchars($t['home']['journalists']) ?></h2>
                <p><?= htmlspecialchars($t['home']['journalists_sub']) ?></p>
            </div>
            <a href="<?= td_url('journalists.php') ?>" class="td-link-more"><?= htmlspecialchars($t['home']['view_all']) ?> →</a>
        </div>
        <div class="td-journalists-grid">
            <?php foreach ($journalists as $j): ?>
            <a href="<?= htmlspecialchars(td_journalist_url($j)) ?>" class="td-journalist-card">
                <img src="<?= htmlspecialchars(td_journalist_avatar($j)) ?>" alt="<?= htmlspecialchars(td_localized($j, 'name')) ?>" width="80" height="80" loading="lazy">
                <div>
                    <strong><?= htmlspecialchars(td_localized($j, 'name')) ?></strong>
                    <span><?= htmlspecialchars(td_localized($j, 'title')) ?></span>
                    <p><?= htmlspecialchars(mb_substr(td_localized($j, 'bio'), 0, 100)) ?>…</p>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="td-section td-cta-band">
    <div class="td-container td-cta-inner">
        <div>
            <h2><?= htmlspecialchars($t['home']['about_title']) ?></h2>
            <p><?= htmlspecialchars($t['home']['about_text']) ?></p>
        </div>
        <a href="<?= td_url('about.php') ?>" class="td-btn-primary"><?= htmlspecialchars($t['home']['about_btn']) ?></a>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>