<?php
require_once __DIR__ . '/init.php';
header('Content-Type: application/xml; charset=UTF-8');

$base = 'https://bilohash.com/today';
$langs = ['no', 'en', 'uk', 'ru'];

function td_sitemap_hreflang(string $path, array $langs): void
{
    $path = '/' . ltrim($path, '/');
    echo '        <xhtml:link rel="alternate" hreflang="x-default" href="https://bilohash.com' . htmlspecialchars($path) . '"/>' . "\n";
    foreach ($langs as $lng) {
        $href = 'https://bilohash.com' . $path;
        if ($lng !== 'no') {
            $href .= (str_contains($path, '?') ? '&' : '?') . 'lang=' . urlencode($lng);
        }
        echo '        <xhtml:link rel="alternate" hreflang="' . htmlspecialchars($lng) . '" href="' . htmlspecialchars($href) . '"/>' . "\n";
    }
}

$urls = [
    ['loc' => $base . '/', 'priority' => '1.0', 'changefreq' => 'daily', 'hreflang' => true, 'path' => '/today/'],
    ['loc' => $base . '/journalists.php', 'priority' => '0.8', 'changefreq' => 'weekly', 'hreflang' => true, 'path' => '/today/journalists.php'],
    ['loc' => $base . '/about.php', 'priority' => '0.7', 'changefreq' => 'monthly', 'hreflang' => true, 'path' => '/today/about.php'],
    ['loc' => $base . '/contact.php', 'priority' => '0.65', 'changefreq' => 'monthly', 'hreflang' => true, 'path' => '/today/contact.php'],
];

foreach (td_categories() as $cat) {
    $slug = $cat['slug'] ?? '';
    if ($slug === '') {
        continue;
    }
    $urls[] = [
        'loc'        => $base . '/category/' . rawurlencode($slug) . '/',
        'priority'   => '0.75',
        'changefreq' => 'weekly',
        'hreflang'   => true,
        'path'       => '/today/category/' . $slug . '/',
    ];
}

foreach (td_journalists() as $jour) {
    $slug = $jour['slug'] ?? '';
    if ($slug === '') {
        continue;
    }
    $urls[] = [
        'loc'        => $base . '/journalist/' . rawurlencode($slug) . '/',
        'priority'   => '0.72',
        'changefreq' => 'monthly',
        'hreflang'   => true,
        'path'       => '/today/journalist/' . $slug . '/',
    ];
}

foreach (td_articles() as $article) {
    $slug = $article['slug'] ?? '';
    if ($slug === '') {
        continue;
    }
    $urls[] = [
        'loc'        => $base . '/article/' . rawurlencode($slug) . '/',
        'priority'   => !empty($article['featured']) ? '0.9' : '0.8',
        'changefreq' => 'weekly',
        'hreflang'   => true,
        'path'       => '/today/article/' . $slug . '/',
        'lastmod'    => substr($article['published_at'] ?? '', 0, 10),
    ];
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
<?php foreach ($urls as $u): ?>
    <url>
        <loc><?= htmlspecialchars($u['loc']) ?></loc>
        <?php if (!empty($u['lastmod'])): ?>
        <lastmod><?= htmlspecialchars($u['lastmod']) ?></lastmod>
        <?php endif; ?>
        <changefreq><?= $u['changefreq'] ?? 'monthly' ?></changefreq>
        <priority><?= $u['priority'] ?? '0.5' ?></priority>
        <?php if (!empty($u['hreflang']) && !empty($u['path'])):
            td_sitemap_hreflang($u['path'], $langs);
        endif; ?>
    </url>
<?php endforeach; ?>
</urlset>