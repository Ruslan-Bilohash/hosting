<?php
define('TD_BASE_PATH', '/today');
define('TD_DOMAIN', 'bilohash.com');
define('TD_SITE_NAME', 'Today CMS');
define('TD_DEMO_MODE', true);
/** Bump when demo seed (articles.php / journalists.php) changes — refreshes JSON on server. */
define('TD_SEED_VERSION', 4);

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, TD_DOMAIN) !== false) ? TD_BASE_PATH : ($detected ?: TD_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function td_url(string $path = '', ?string $lang = null): string
{
    global $base_path;
    $base = rtrim($base_path, '/') . '/' . ltrim($path, '/');
    if ($lang !== null && $lang !== 'no') {
        $base .= (strpos($base, '?') !== false ? '&' : '?') . 'lang=' . urlencode($lang);
    }
    return $base;
}

function td_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function td_absolute_url(string $relative): string
{
    global $site_url, $protocol, $host;
    if (preg_match('#^https?://#i', $relative)) {
        return $relative;
    }
    if ($relative !== '' && $relative[0] === '/') {
        return rtrim($protocol . '://' . $host, '/') . $relative;
    }
    return rtrim($site_url, '/') . '/' . ltrim($relative, '/');
}

function td_fa_icon(string $name): string
{
    $name = trim($name);
    if ($name === '') return 'fas fa-circle';
    if (preg_match('/\b(fas|far|fab)\s+fa-/', $name)) return $name;
    $bare = ltrim($name, 'fa-');
    $brands = ['wordpress', 'twitter', 'facebook', 'instagram', 'telegram'];
    if (in_array($bare, $brands, true)) return 'fab fa-' . $bare;
    if (str_starts_with($name, 'fa-')) return 'fas ' . $name;
    return 'fas fa-' . $bare;
}