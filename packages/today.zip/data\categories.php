<?php
return [
    [
        'id'    => 'politics',
        'slug'  => 'politics',
        'color' => '#c0392b',
        'icon'  => 'landmark',
        'name'  => [
            'no' => 'Politikk',
            'en' => 'Politics',
            'uk' => 'Політика',
            'ru' => 'Политика',
        ],
    ],
    [
        'id'    => 'business',
        'slug'  => 'business',
        'color' => '#2980b9',
        'icon'  => 'chart-line',
        'name'  => [
            'no' => 'Næringsliv',
            'en' => 'Business',
            'uk' => 'Бізнес',
            'ru' => 'Бизнес',
        ],
    ],
    [
        'id'    => 'tech',
        'slug'  => 'tech',
        'color' => '#8e44ad',
        'icon'  => 'microchip',
        'name'  => [
            'no' => 'Teknologi',
            'en' => 'Technology',
            'uk' => 'Технології',
            'ru' => 'Технологии',
        ],
    ],
    [
        'id'    => 'culture',
        'slug'  => 'culture',
        'color' => '#d35400',
        'icon'  => 'palette',
        'name'  => [
            'no' => 'Kultur',
            'en' => 'Culture',
            'uk' => 'Культура',
            'ru' => 'Культура',
        ],
    ],
    [
        'id'    => 'sports',
        'slug'  => 'sports',
        'color' => '#27ae60',
        'icon'  => 'futbol',
        'name'  => [
            'no' => 'Sport',
            'en' => 'Sports',
            'uk' => 'Спорт',
            'ru' => 'Спорт',
        ],
    ],
    [
        'id'    => 'europe',
        'slug'  => 'europe',
        'color' => '#2c3e50',
        'icon'  => 'globe-europe',
        'name'  => [
            'no' => 'Europa',
            'en' => 'Europe',
            'uk' => 'Європа',
            'ru' => 'Европа',
        ],
    ],
    [
        'id'    => 'norway',
        'slug'  => 'norway',
        'color' => '#e74c3c',
        'icon'  => 'flag',
        'name'  => [
            'no' => 'Norge',
            'en' => 'Norway',
            'uk' => 'Норвегія',
            'ru' => 'Норвегия',
        ],
    ],
];