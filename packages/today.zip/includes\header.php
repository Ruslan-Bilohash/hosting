<?php
require_once __DIR__ . '/site-integrations.php';
td_boot_public_integrations();
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? td_url('index.php');
$body_class = $body_class ?? '';
$seo_schemas = $seo_schemas ?? [];
$current_page = $current_page ?? '';
$categories_nav = td_categories();
$today_date = td_format_date(date('Y-m-d'));
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php td_render_seo_head($page_title, $page_desc, $canonical, $seo_schemas, null, 'website', !empty($seo_noindex)); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;500;600;700&amp;family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&amp;family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&amp;display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;500;600;700&amp;family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&amp;family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&amp;display=swap" rel="stylesheet"></noscript>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>
    <link rel="stylesheet" href="<?= htmlspecialchars(td_asset('css/style.css')) ?>?v=3">
    <?php bh_cms_render_theme_styles('today', td_site_settings()); ?>
    <link rel="icon" href="<?= htmlspecialchars(td_asset('images/logo.svg')) ?>">
    <?php
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    ecosystem_subscription_strip_head_link();
    ?>
</head>
<body class="td-body <?= htmlspecialchars($body_class) ?>">

<a class="td-skip" href="#main"><?= htmlspecialchars($t['nav']['skip_content']) ?></a>

<div class="td-top-bar">
    <?php ecosystem_subscription_strip_render($lang); ?>
</div>

<header class="td-masthead" id="tdHeader">
    <div class="td-container td-masthead-top">
        <div class="td-masthead-meta">
            <time datetime="<?= date('Y-m-d') ?>"><?= htmlspecialchars($today_date) ?></time>
            <span class="td-masthead-region"><?= htmlspecialchars($t['meta']['masthead_note'] ?? 'Demo CMS') ?></span>
        </div>
        <div class="td-masthead-actions">
            <?php require __DIR__ . '/lang-dropdown.php'; ?>
            <a href="<?= td_url('admin/login.php') ?>" class="td-admin-link"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['nav']['admin']) ?></a>
        </div>
    </div>

    <div class="td-container td-masthead-brand">
        <a href="<?= td_url('index.php') ?>" class="td-logo">
            <img src="<?= htmlspecialchars(td_asset('images/logo.svg')) ?>" alt="<?= htmlspecialchars($t['meta']['site_name']) ?>" width="48" height="48">
            <div>
                <span class="td-logo-name">TODAY</span>
                <span class="td-logo-tag"><?= htmlspecialchars($t['meta']['tagline']) ?></span>
            </div>
        </a>
    </div>

    <div class="td-container td-masthead-nav-wrap">
        <button type="button" class="td-menu-toggle" id="tdMenuBtn" aria-expanded="false" aria-controls="tdNavPanel">
            <i class="fas fa-bars"></i> <?= htmlspecialchars($t['nav']['menu']) ?>
        </button>
        <nav class="td-nav" id="tdNavPanel" aria-label="Main">
            <a href="<?= td_url('index.php') ?>" class="<?= $current_page === 'home' ? 'active' : '' ?>"><?= htmlspecialchars($t['nav']['home']) ?></a>
            <?php foreach ($categories_nav as $cat): ?>
            <a href="<?= htmlspecialchars(td_category_url($cat)) ?>" class="<?= ($current_cat ?? '') === ($cat['slug'] ?? '') ? 'active' : '' ?>"><?= htmlspecialchars(td_localized($cat, 'name')) ?></a>
            <?php endforeach; ?>
            <a href="<?= td_url('journalists.php') ?>" class="<?= $current_page === 'journalists' ? 'active' : '' ?>"><?= htmlspecialchars($t['nav']['journalists']) ?></a>
            <a href="<?= td_url('about.php') ?>" class="<?= $current_page === 'about' ? 'active' : '' ?>"><?= htmlspecialchars($t['nav']['about']) ?></a>
            <a href="<?= td_url('contact.php') ?>" class="<?= $current_page === 'contact' ? 'active' : '' ?>"><?= htmlspecialchars($t['nav']['contact']) ?></a>
        </nav>
        <form class="td-header-search" action="<?= td_url('search.php') ?>" method="get" role="search">
            <?php if ($lang !== 'no'): ?><input type="hidden" name="lang" value="<?= htmlspecialchars($lang) ?>"><?php endif; ?>
            <input type="search" name="q" placeholder="<?= htmlspecialchars($t['home']['search_placeholder']) ?>" aria-label="<?= htmlspecialchars($t['nav']['search']) ?>">
            <button type="submit" aria-label="<?= htmlspecialchars($t['nav']['search']) ?>"><i class="fas fa-search" aria-hidden="true"></i></button>
        </form>
    </div>
</header>

<main id="main" class="td-main">