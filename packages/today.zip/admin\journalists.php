<?php
require_once __DIR__ . '/init.php';
td_admin_require();
$admin_page = 'journalists';
$page_title = $ta['journalists'];

$journalists = td_journalists();
$saved = !empty($_GET['saved']);

require __DIR__ . '/includes/layout.php';
?>

<?php if ($saved): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['saved']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['all_journalists']) ?> (<?= count($journalists) ?>)</h2>
        <a href="<?= td_url('journalists.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
            <i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['preview']) ?>
        </a>
    </div>
    <div class="adm-card-body">
        <?php if (empty($journalists)): ?>
        <p style="padding:24px;text-align:center;color:var(--adm-muted)"><?= htmlspecialchars($ta['no_journalists']) ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th></th>
                    <th><?= htmlspecialchars($ta['name_label']) ?></th>
                    <th><?= htmlspecialchars($ta['title_role_label']) ?></th>
                    <th><?= htmlspecialchars($ta['role_label']) ?></th>
                    <th><?= htmlspecialchars($ta['id']) ?></th>
                    <th><?= htmlspecialchars($ta['actions']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($journalists as $jour):
                    $article_count = count(array_filter(td_articles(true), fn($a) => ($a['journalist_id'] ?? '') === ($jour['id'] ?? '')));
                    $role_label = ($jour['role'] ?? '') === 'editor' ? ($ta['role_editor'] ?? 'Editor') : ($ta['role_journalist'] ?? 'Journalist');
                ?>
                <tr>
                    <td data-label=""><img src="<?= htmlspecialchars(td_journalist_avatar($jour)) ?>" alt="" class="adm-thumb" style="border-radius:50%;width:48px;height:48px" loading="lazy"></td>
                    <td data-label="<?= htmlspecialchars($ta['name_label']) ?>">
                        <strong><?= htmlspecialchars(td_localized($jour, 'name', 'en')) ?></strong><br>
                        <small style="color:var(--adm-muted)"><?= htmlspecialchars($jour['slug'] ?? '') ?></small>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['title_role_label']) ?>"><?= htmlspecialchars(td_localized($jour, 'title', 'en')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['role_label']) ?>"><span class="adm-badge adm-badge-pending"><?= htmlspecialchars($role_label) ?></span></td>
                    <td data-label="<?= htmlspecialchars($ta['id']) ?>"><?= (int)$article_count ?> <?= htmlspecialchars(strtolower($ta['articles'])) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['actions']) ?>">
                        <a href="<?= td_admin_url('journalist.php?id=' . urlencode($jour['id'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm">
                            <i class="fas fa-pen"></i> <?= htmlspecialchars($ta['edit']) ?>
                        </a>
                        <a href="<?= td_url('journalist.php?slug=' . urlencode($jour['slug'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>