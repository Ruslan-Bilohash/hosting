<?php

function td_localized(array $item, string $field, ?string $lang = null): string
{
    global $lang;
    $lang = $lang ?? $GLOBALS['lang'] ?? 'no';
    $val  = $item[$field] ?? '';
    if (is_array($val)) {
        return $val[$lang] ?? $val['en'] ?? $val['no'] ?? '';
    }
    return (string) $val;
}

function td_articles(bool $include_unpublished = false): array
{
    $list = td_load_articles_raw();
    if (!$include_unpublished) {
        $list = array_values(array_filter($list, fn($a) => ($a['published'] ?? true) !== false));
    }
    usort($list, fn($a, $b) => strtotime($b['published_at'] ?? '') <=> strtotime($a['published_at'] ?? ''));
    return $list;
}

function td_article_by_slug(string $slug, bool $include_unpublished = false): ?array
{
    foreach (td_articles($include_unpublished) as $article) {
        if (($article['slug'] ?? '') === $slug) {
            return $article;
        }
    }
    return null;
}

function td_featured_articles(int $limit = 5): array
{
    $list = array_values(array_filter(td_articles(), fn($a) => !empty($a['featured'])));
    return array_slice($list, 0, $limit);
}

function td_breaking_articles(int $limit = 3): array
{
    $list = array_values(array_filter(td_articles(), fn($a) => !empty($a['breaking'])));
    return array_slice($list, 0, $limit);
}

function td_articles_by_category(string $category_id, int $limit = 0): array
{
    $list = array_values(array_filter(
        td_articles(),
        fn($a) => ($a['category_id'] ?? '') === $category_id
    ));
    return $limit > 0 ? array_slice($list, 0, $limit) : $list;
}

function td_search_articles(string $query, ?string $lang = null): array
{
    global $lang;
    $lang  = $lang ?? $GLOBALS['lang'] ?? 'no';
    $query = mb_strtolower(trim($query));
    if ($query === '') {
        return [];
    }
    return array_values(array_filter(td_articles(), function ($article) use ($query, $lang) {
        $hay = mb_strtolower(
            td_localized($article, 'title', $lang) . ' '
            . td_localized($article, 'excerpt', $lang) . ' '
            . td_localized($article, 'body', $lang)
        );
        return str_contains($hay, $query);
    }));
}

function td_journalists(): array
{
    return td_load_journalists_raw();
}

function td_journalist_by_slug(string $slug): ?array
{
    foreach (td_journalists() as $journalist) {
        if (($journalist['slug'] ?? '') === $slug) {
            return $journalist;
        }
    }
    return null;
}

function td_journalist_by_id(string $id): ?array
{
    foreach (td_journalists() as $journalist) {
        if (($journalist['id'] ?? '') === $id) {
            return $journalist;
        }
    }
    return null;
}

function td_categories(): array
{
    return td_load_categories_raw();
}

function td_category_by_slug(string $slug): ?array
{
    foreach (td_categories() as $category) {
        if (($category['slug'] ?? '') === $slug) {
            return $category;
        }
    }
    return null;
}

function td_category_by_id(string $id): ?array
{
    foreach (td_categories() as $category) {
        if (($category['id'] ?? '') === $id) {
            return $category;
        }
    }
    return null;
}

function td_format_date(string $date, ?string $lang = null): string
{
    global $lang;
    $lang = $lang ?? $GLOBALS['lang'] ?? 'no';
    $ts   = strtotime($date);
    if ($ts === false) {
        return $date;
    }
    $locales = [
        'no' => 'nb_NO',
        'en' => 'en_GB',
        'uk' => 'uk_UA',
        'ru' => 'ru_RU',
    ];
    $locale = $locales[$lang] ?? 'en_GB';
    if (class_exists('IntlDateFormatter')) {
        $fmt = new IntlDateFormatter($locale, IntlDateFormatter::LONG, IntlDateFormatter::NONE);
        $formatted = $fmt->format($ts);
        if ($formatted !== false) {
            return $formatted;
        }
    }
    return date('j M Y', $ts);
}

function td_reading_time(string $text, int $wpm = 200): int
{
    $words = str_word_count(strip_tags($text));
    return max(1, (int) ceil($words / $wpm));
}

function td_excerpt(array $article, ?string $lang = null, int $max = 160): string
{
    $text = td_localized($article, 'excerpt', $lang);
    if ($text === '') {
        $text = td_localized($article, 'body', $lang);
    }
    $text = trim(preg_replace('/\s+/', ' ', strip_tags($text)) ?? '');
    if (mb_strlen($text) <= $max) {
        return $text;
    }
    return rtrim(mb_substr($text, 0, $max - 1)) . '…';
}

function td_resolve_asset(string $path, string $fallback): string
{
    $path = trim($path);
    if ($path === '') {
        return td_asset($fallback);
    }
    if (preg_match('#^https?://#i', $path) || $path[0] === '/') {
        return $path;
    }
    if (str_starts_with($path, 'assets/')) {
        return td_asset(substr($path, 7));
    }
    return td_asset($path);
}

function td_article_image(array $article): string
{
    return td_resolve_asset($article['image'] ?? '', 'images/articles/placeholder.svg');
}

function td_journalist_avatar(array $journalist): string
{
    return td_resolve_asset($journalist['avatar'] ?? '', 'images/avatar-placeholder.svg');
}

function td_lang_url(string $code, bool $for_hreflang = false): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: td_url('index.php');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);
    if ($code === 'no' && $for_hreflang) {
        unset($q['lang']);
    } else {
        $q['lang'] = $code;
    }
    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}

function td_full_lang_url(string $code): string
{
    return td_absolute_url(td_lang_url($code, true));
}

function td_category_url(array $category, ?string $lang = null): string
{
    return td_url('category/' . ($category['slug'] ?? '') . '/', $lang);
}

function td_article_url(array $article, ?string $lang = null): string
{
    return td_url('article/' . ($article['slug'] ?? '') . '/', $lang);
}

function td_journalist_url(array $journalist, ?string $lang = null): string
{
    return td_url('journalist/' . ($journalist['slug'] ?? '') . '/', $lang);
}