<?php
require_once __DIR__ . '/init.php';
$current_page = 'about';
$canonical = td_url('about.php');
$page_title = $t['about']['meta_title'] ?? $t['about']['title'];
$page_desc = $t['about']['meta_desc'] ?? '';
$seo_schemas = [td_seo_organization(), td_seo_webpage(td_absolute_url($canonical), $page_title, $page_desc)];
require __DIR__ . '/includes/header.php';
?>

<section class="td-page-hero">
    <div class="td-container">
        <nav class="td-crumb"><a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a> → <?= htmlspecialchars($t['about']['breadcrumb']) ?></nav>
        <h1><?= htmlspecialchars($t['about']['title']) ?></h1>
        <p class="td-lead"><?= htmlspecialchars($t['about']['lead']) ?></p>
    </div>
</section>

<section class="td-section">
    <div class="td-container td-about-grid">
        <div class="td-about-text">
            <p><?= htmlspecialchars($t['about']['text']) ?></p>
            <div class="td-about-demo">
                <h3><?= htmlspecialchars($t['about']['demo_title']) ?></h3>
                <p><?= htmlspecialchars($t['about']['demo_text']) ?></p>
                <div class="td-about-actions">
                    <a href="<?= td_url('index.php') ?>" class="td-btn-primary"><?= htmlspecialchars($t['about']['demo_btn']) ?></a>
                    <a href="<?= td_url('admin/login.php') ?>" class="td-btn-outline"><?= htmlspecialchars($t['about']['admin_btn']) ?></a>
                </div>
            </div>
        </div>
        <div>
            <h2><?= htmlspecialchars($t['about']['features_title']) ?></h2>
            <div class="td-features-list">
                <?php foreach ($t['about']['features'] ?? [] as $f): ?>
                <article class="td-feature-item">
                    <i class="<?= htmlspecialchars(td_fa_icon($f['icon'] ?? 'check')) ?>"></i>
                    <div>
                        <h3><?= htmlspecialchars($f['title']) ?></h3>
                        <p><?= htmlspecialchars($f['desc']) ?></p>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>