<?php
$cms_404_home = '/today/';
$cms_404_name = 'Today CMS';
require dirname(__DIR__) . '/includes/cms-404.php';