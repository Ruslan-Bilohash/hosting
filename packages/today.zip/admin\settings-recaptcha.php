<?php
require_once __DIR__ . '/init.php';
td_admin_require();
require_once dirname(__DIR__) . '/includes/storage.php';
$settings_tab = 'recaptcha';
$bh_cms_load_settings = 'td_load_settings';
$bh_cms_save_settings = 'td_save_settings';
$bh_cms_admin_url = 'td_admin_url';
$bh_cms_layout = __DIR__ . '/includes/layout.php';
$bh_cms_layout_end = __DIR__ . '/includes/layout-end.php';
require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
require dirname(__DIR__, 2) . '/includes/bh-cms-admin/complete-settings-page.php';