<?php
require_once __DIR__ . '/init.php';
td_admin_logout();
header('Location: ' . td_admin_url('login.php'), true, 302);
exit;