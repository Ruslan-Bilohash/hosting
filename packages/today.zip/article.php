<?php
require_once __DIR__ . '/init.php';

$slug = trim($_GET['slug'] ?? '');
$article = td_article_by_slug($slug);
if (!$article) {
    http_response_code(404);
    $current_page = 'article';
    $page_title = $t['article']['not_found'] . ' — ' . TD_SITE_NAME;
    $page_desc = $t['article']['not_found_text'];
    $canonical = td_url('article.php');
    require __DIR__ . '/includes/header.php';
    echo '<section class="td-container td-empty"><h1>' . htmlspecialchars($t['article']['not_found']) . '</h1><p>' . htmlspecialchars($t['article']['not_found_text']) . '</p><a class="td-btn-primary" href="' . td_url('index.php') . '">' . htmlspecialchars($t['article']['back_home']) . '</a></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$cat = td_category_by_id($article['category_id'] ?? '');
$journalist = td_journalist_by_id($article['journalist_id'] ?? '');
$related = array_slice(td_articles_by_category($article['category_id'] ?? ''), 0, 4);
$related = array_values(array_filter($related, fn($a) => ($a['slug'] ?? '') !== $slug));

$current_page = 'article';
$current_cat = $cat['slug'] ?? '';
$canonical = td_article_url($article);
$page_title = td_localized($article, 'title') . ' — ' . TD_SITE_NAME;
$page_desc = td_excerpt($article, null, 180);
$canon_abs = td_absolute_url($canonical);
$seo_schemas = [
    td_seo_organization(),
    td_seo_article($article, $lang, $canon_abs),
    td_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => td_absolute_url(td_url('index.php'))],
        ['name' => $cat ? td_localized($cat, 'name') : ($t['category']['title'] ?? 'Category'), 'url' => $cat ? td_absolute_url(td_category_url($cat)) : ''],
        ['name' => td_localized($article, 'title'), 'url' => $canon_abs],
    ]),
];

require __DIR__ . '/includes/header.php';
?>

<article class="td-article-page">
    <div class="td-container td-article-wrap">
        <nav class="td-crumb" aria-label="Breadcrumb">
            <a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a>
            <?php if ($cat): ?>
            <span>→</span>
            <a href="<?= htmlspecialchars(td_category_url($cat)) ?>"><?= htmlspecialchars(td_localized($cat, 'name')) ?></a>
            <?php endif; ?>
            <span>→</span>
            <span><?= htmlspecialchars(td_localized($article, 'title')) ?></span>
        </nav>

        <div class="td-article-demo-notice" role="note">
            <i class="fas fa-circle-info" aria-hidden="true"></i>
            <p><?= htmlspecialchars($t['article']['demo_notice']) ?></p>
        </div>

        <header class="td-article-header">
            <?php if ($cat): ?>
            <a href="<?= htmlspecialchars(td_category_url($cat)) ?>" class="td-article-cat" style="--cat-color: <?= htmlspecialchars($cat['color'] ?? '#c41e3a') ?>"><?= htmlspecialchars(td_localized($cat, 'name')) ?></a>
            <?php endif; ?>
            <?php if (!empty($article['breaking'])): ?>
            <span class="td-breaking-badge"><?= htmlspecialchars($t['article']['breaking_label']) ?></span>
            <?php endif; ?>
            <h1 class="article-headline"><?= htmlspecialchars(td_localized($article, 'title')) ?></h1>
            <p class="article-lead td-article-excerpt"><?= htmlspecialchars(td_localized($article, 'excerpt')) ?></p>
            <div class="td-article-meta">
                <?php if ($journalist): ?>
                <a href="<?= htmlspecialchars(td_journalist_url($journalist)) ?>" class="td-article-author">
                    <img src="<?= htmlspecialchars(td_journalist_avatar($journalist)) ?>" alt="" width="40" height="40">
                    <span><?= htmlspecialchars($t['article']['by']) ?> <strong><?= htmlspecialchars(td_localized($journalist, 'name')) ?></strong></span>
                </a>
                <?php endif; ?>
                <time datetime="<?= htmlspecialchars($article['published_at'] ?? '') ?>"><?= htmlspecialchars(td_format_date($article['published_at'] ?? '')) ?></time>
                <span><?= (int)td_reading_time(td_localized($article, 'body')) ?> <?= htmlspecialchars($t['article']['min_read']) ?></span>
            </div>
        </header>

        <figure class="td-article-figure">
            <img src="<?= htmlspecialchars(td_article_image($article)) ?>" alt="<?= htmlspecialchars(td_localized($article, 'title')) ?>" width="1200" height="675">
        </figure>

        <div class="td-article-body">
            <?php foreach (preg_split('/\n\s*\n/', td_localized($article, 'body')) as $para):
                $para = trim($para);
                if ($para === '') continue;
            ?>
            <p><?= nl2br(htmlspecialchars($para)) ?></p>
            <?php endforeach; ?>
        </div>

        <?php if ($related): ?>
        <section class="td-related">
            <h2><?= htmlspecialchars($t['article']['related']) ?></h2>
            <div class="td-articles-grid td-articles-grid--3">
                <?php foreach ($related as $article): $size = 'small'; require __DIR__ . '/includes/article-card.php'; endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
    </div>
</article>

<?php require __DIR__ . '/includes/footer.php'; ?>