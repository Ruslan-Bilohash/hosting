<?php
require_once __DIR__ . '/init.php';
td_admin_require();
$admin_page = 'dashboard';
$page_title = $ta['dashboard'];

$all_articles = td_articles(true);
$published    = array_values(array_filter($all_articles, fn($a) => ($a['published'] ?? true) !== false));
$drafts       = array_values(array_filter($all_articles, fn($a) => ($a['published'] ?? true) === false));
$featured     = array_values(array_filter($all_articles, fn($a) => !empty($a['featured'])));
$breaking     = array_values(array_filter($all_articles, fn($a) => !empty($a['breaking'])));
$journalists  = td_journalists();
$categories   = td_categories();
$recent       = array_slice($all_articles, 0, 8);

$chart = [];
$max_cat = 0;
foreach ($categories as $cat) {
    $count = count(array_filter($all_articles, fn($a) => ($a['category_id'] ?? '') === ($cat['id'] ?? '')));
    $chart[] = ['cat' => $cat, 'count' => $count];
    $max_cat = max($max_cat, $count);
}
usort($chart, fn($a, $b) => $b['count'] <=> $a['count']);
foreach ($chart as &$row) {
    $row['pct'] = $max_cat > 0 ? (int) round(($row['count'] / $max_cat) * 100) : 0;
}
unset($row);

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-alert adm-alert-info">
    <i class="fas fa-flask"></i> <?= htmlspecialchars($ta['json_note']) ?>
</div>

<div class="adm-stats">
    <div class="adm-stat">
        <div class="adm-stat-icon red"><i class="fas fa-newspaper"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($published) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_articles']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon orange"><i class="fas fa-file-alt"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($drafts) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_drafts']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon gold"><i class="fas fa-star"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($featured) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_featured']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon blue"><i class="fas fa-bolt"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($breaking) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_breaking']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon green"><i class="fas fa-users"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($journalists) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_journalists']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon indigo"><i class="fas fa-folder"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($categories) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_categories']) ?></div>
        </div>
    </div>
</div>

<div class="adm-dash-grid">
    <div class="adm-card">
        <div class="adm-card-head">
            <h2><?= htmlspecialchars($ta['categories']) ?></h2>
        </div>
        <div class="adm-card-body padded">
            <div class="adm-bar-chart">
                <?php foreach (array_slice($chart, 0, 7) as $row): ?>
                <div class="adm-bar-row">
                    <span class="adm-bar-label"><?= htmlspecialchars(td_localized($row['cat'], 'name')) ?></span>
                    <div class="adm-bar-track"><div class="adm-bar-fill" style="width:<?= (int)$row['pct'] ?>%"></div></div>
                    <span class="adm-bar-val"><?= (int)$row['count'] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="adm-card">
        <div class="adm-card-head">
            <h2><?= htmlspecialchars($ta['quick_actions']) ?></h2>
        </div>
        <div class="adm-card-body padded adm-quick-actions">
            <a href="<?= td_admin_url('article.php?new=1') ?>" class="adm-btn adm-btn-primary"><i class="fas fa-plus"></i> <?= htmlspecialchars($ta['add_article']) ?></a>
            <a href="<?= td_admin_url('articles.php') ?>" class="adm-btn adm-btn-outline"><i class="fas fa-newspaper"></i> <?= htmlspecialchars($ta['articles']) ?></a>
            <a href="<?= td_admin_url('journalists.php') ?>" class="adm-btn adm-btn-outline"><i class="fas fa-users"></i> <?= htmlspecialchars($ta['journalists']) ?></a>
            <a href="<?= td_url('index.php') ?>" class="adm-btn adm-btn-outline" target="_blank"><i class="fas fa-globe"></i> <?= htmlspecialchars($ta['view_site']) ?></a>
        </div>
    </div>
</div>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['recent_articles']) ?></h2>
        <a href="<?= td_admin_url('articles.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['all_articles']) ?> →</a>
    </div>
    <div class="adm-card-body">
        <?php if (empty($recent)): ?>
        <p style="padding:24px;text-align:center;color:var(--adm-muted)"><?= htmlspecialchars($ta['no_articles']) ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th></th>
                    <th><?= htmlspecialchars($ta['title_label']) ?></th>
                    <th><?= htmlspecialchars($ta['category']) ?></th>
                    <th><?= htmlspecialchars($ta['author']) ?></th>
                    <th><?= htmlspecialchars($ta['date']) ?></th>
                    <th><?= htmlspecialchars($ta['status']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $article):
                    $cat = td_category_by_id($article['category_id'] ?? '');
                    $jour = td_journalist_by_id($article['journalist_id'] ?? '');
                ?>
                <tr>
                    <td data-label=""><img src="<?= htmlspecialchars(td_article_image($article)) ?>" alt="" class="adm-thumb" loading="lazy"></td>
                    <td data-label="<?= htmlspecialchars($ta['title_label']) ?>">
                        <a href="<?= td_admin_url('article.php?id=' . urlencode($article['id'] ?? '')) ?>"><strong><?= htmlspecialchars(td_localized($article, 'title', 'en')) ?></strong></a>
                        <?php if (!empty($article['featured'])): ?><span class="adm-badge adm-badge-pending" style="margin-left:6px"><i class="fas fa-star"></i></span><?php endif; ?>
                        <?php if (!empty($article['breaking'])): ?><span class="adm-badge adm-badge-breaking"><i class="fas fa-bolt"></i></span><?php endif; ?>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['category']) ?>"><?= htmlspecialchars($cat ? td_localized($cat, 'name') : ($article['category_id'] ?? '')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['author']) ?>"><?= htmlspecialchars($jour ? td_localized($jour, 'name') : ($article['journalist_id'] ?? '')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['date']) ?>"><?= htmlspecialchars(td_format_date($article['published_at'] ?? '')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['status']) ?>">
                        <?php if (($article['published'] ?? true) !== false): ?>
                        <span class="adm-badge adm-badge-active"><?= htmlspecialchars($ta['active']) ?></span>
                        <?php else: ?>
                        <span class="adm-badge adm-badge-hidden"><?= htmlspecialchars($ta['inactive']) ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>