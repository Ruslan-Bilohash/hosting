<?php

function td_seo_og_image(): string
{
    return td_absolute_url(td_asset('images/og-default.svg'));
}

function td_seo_software_application(string $canonical): array
{
    global $site_url, $t;
    return [
        '@type'               => 'SoftwareApplication',
        '@id'                 => rtrim($site_url, '/') . '/#software',
        'name'                => 'Today CMS',
        'alternateName'       => TD_SITE_NAME,
        'url'                 => rtrim($site_url, '/') . '/',
        'applicationCategory' => 'BusinessApplication',
        'applicationSubCategory' => 'News CMS',
        'operatingSystem'     => 'Web',
        'description'         => $t['meta']['description'] ?? '',
        'inLanguage'          => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'offers'              => [
            '@type'         => 'Offer',
            'availability'  => 'https://schema.org/InStock',
            'areaServed'    => [
                ['@type' => 'Country', 'name' => 'Norway'],
                ['@type' => 'Place', 'name' => 'Europe'],
            ],
            'seller'        => [
                '@type' => 'Organization',
                'name'  => 'BILOHASH',
                'url'   => 'https://bilohash.com/',
            ],
        ],
        'featureList'         => [
            'Multilingual articles (NO, EN, UK, RU)',
            'Journalist profiles',
            'Category pages and search',
            'JSON admin panel',
            'Schema.org NewsArticle SEO',
        ],
        'screenshot'          => td_absolute_url(td_asset('images/og-default.svg')),
        'mainEntityOfPage'    => $canonical,
    ];
}

function td_seo_organization(): array
{
    global $site_url;
    return [
        '@type'      => 'NewsMediaOrganization',
        '@id'        => rtrim($site_url, '/') . '/#organization',
        'name'       => TD_SITE_NAME,
        'url'        => rtrim($site_url, '/') . '/',
        'logo'       => td_absolute_url(td_asset('images/logo.svg')),
        'areaServed' => ['NO', 'UA', 'RU', 'EU'],
        'knowsAbout' => [
            'PHP news CMS software',
            'Multilingual news website development',
            'Schema.org NewsArticle SEO',
            'JSON-backed news admin panel',
            'Newspaper-style responsive design',
        ],
    ];
}

function td_seo_website(string $canonical): array
{
    global $site_url, $t;
    return [
        '@type'            => 'WebSite',
        '@id'              => rtrim($site_url, '/') . '/#website',
        'name'             => TD_SITE_NAME,
        'url'              => rtrim($site_url, '/') . '/',
        'inLanguage'       => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'publisher'        => ['@id' => rtrim($site_url, '/') . '/#organization'],
        'potentialAction'  => [
            '@type'       => 'SearchAction',
            'target'      => [
                '@type'       => 'EntryPoint',
                'urlTemplate' => rtrim($site_url, '/') . '/search.php?q={search_term_string}',
            ],
            'query-input' => 'required name=search_term_string',
        ],
        'description'      => $t['meta']['description'] ?? '',
    ];
}

function td_seo_webpage(string $canonical, string $title, string $description): array
{
    global $lang, $site_url;
    return [
        '@type'       => 'WebPage',
        '@id'         => $canonical . '#webpage',
        'url'         => $canonical,
        'name'        => $title,
        'description' => $description,
        'isPartOf'    => ['@id' => rtrim($site_url, '/') . '/#website'],
        'inLanguage'  => td_langs()[$lang]['locale'] ?? 'nb-NO',
    ];
}

function td_seo_article(array $article, string $lang, string $canonical): array
{
    $journalist = td_journalist_by_id($article['journalist_id'] ?? '');
    $category   = td_category_by_id($article['category_id'] ?? '');
    $title      = td_localized($article, 'title', $lang);
    $body       = td_localized($article, 'body', $lang);
    $excerpt    = td_excerpt($article, $lang, 300);
    $published  = $article['published_at'] ?? date('c');

    $schema = [
        '@type'            => 'NewsArticle',
        '@id'              => $canonical . '#article',
        'headline'         => $title,
        'description'      => $excerpt,
        'url'              => $canonical,
        'mainEntityOfPage' => $canonical,
        'datePublished'    => date('c', strtotime($published)),
        'dateModified'     => date('c', strtotime($article['updated_at'] ?? $published)),
        'inLanguage'       => td_langs()[$lang]['locale'] ?? 'nb-NO',
        'image'            => td_article_image($article),
        'author'           => [
            '@type' => 'Person',
            'name'  => $journalist ? td_localized($journalist, 'name', $lang) : TD_SITE_NAME,
            'url'   => $journalist ? td_absolute_url(td_journalist_url($journalist, $lang)) : rtrim($GLOBALS['site_url'], '/') . '/',
        ],
        'publisher'        => ['@id' => rtrim($GLOBALS['site_url'], '/') . '/#organization'],
        'articleBody'      => strip_tags($body),
        'wordCount'        => str_word_count(strip_tags($body)),
        'isAccessibleForFree' => true,
    ];

    if ($category) {
        $schema['articleSection'] = td_localized($category, 'name', $lang);
    }
    if (!empty($article['breaking'])) {
        $schema['speakable'] = [
            '@type'       => 'SpeakableSpecification',
            'cssSelector' => ['.article-headline', '.article-lead'],
        ];
    }

    return $schema;
}

function td_seo_breadcrumbs(array $items): array
{
    $list = [];
    $pos  = 1;
    foreach ($items as $item) {
        $entry = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => $item['name'],
        ];
        if (!empty($item['url'])) {
            $entry['item'] = $item['url'];
        }
        $list[] = $entry;
    }
    return [
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $list,
    ];
}

function td_seo_item_list(array $articles, string $lang, string $listUrl): array
{
    $elements = [];
    $pos      = 1;
    foreach (array_slice($articles, 0, 20) as $article) {
        $elements[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'url'      => td_absolute_url(td_article_url($article, $lang)),
            'name'     => td_localized($article, 'title', $lang),
        ];
    }
    return [
        '@type'           => 'ItemList',
        'url'             => $listUrl,
        'numberOfItems'   => count($articles),
        'itemListElement' => $elements,
    ];
}

function td_seo_json(array $graphs): string
{
    $graphs = array_values(array_filter($graphs));
    if (count($graphs) === 1) {
        $data = array_merge(['@context' => 'https://schema.org'], $graphs[0]);
    } else {
        $data = [
            '@context' => 'https://schema.org',
            '@graph'   => $graphs,
        ];
    }
    return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function td_render_seo_head(
    string $page_title,
    string $page_desc,
    string $canonical,
    array $schema_graphs = [],
    ?string $og_image = null,
    ?string $og_type = 'website',
    bool $noindex = false
): void {
    global $lang_meta, $lang, $t;
    $og_image      = $og_image ?: td_seo_og_image();
    $canonical_abs = td_absolute_url($canonical);
    $keywords      = $t['meta']['keywords'] ?? '';
    $robots        = $noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="<?= $robots ?>">
    <meta name="author" content="<?= htmlspecialchars(TD_SITE_NAME) ?>">
    <meta name="geo.region" content="NO">
    <meta name="geo.placename" content="Norway">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(td_full_lang_url('no')) ?>">
    <?php foreach (td_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= $code === 'uk' ? 'uk' : $code ?>" href="<?= htmlspecialchars(td_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <meta property="og:type" content="<?= htmlspecialchars($og_type) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars(TD_SITE_NAME) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <?php foreach (td_langs() as $code => $info):
        if ($code === $lang) {
            continue;
        } ?>
    <meta property="og:locale:alternate" content="<?= htmlspecialchars(str_replace('-', '_', $info['locale'])) ?>">
    <?php endforeach; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">

    <?php if (!empty($schema_graphs)): ?>
    <script type="application/ld+json"><?= td_seo_json(array_values(array_filter($schema_graphs))) ?></script>
    <?php endif;
}