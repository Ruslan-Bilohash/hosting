<?php
require_once __DIR__ . '/init.php';

$slug = trim($_GET['slug'] ?? '');
$journalist = td_journalist_by_slug($slug);
if (!$journalist) {
    http_response_code(404);
    require __DIR__ . '/includes/header.php';
    echo '<section class="td-container td-empty"><h1>' . htmlspecialchars($t['journalist']['not_found']) . '</h1></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$articles = array_values(array_filter(td_articles(), fn($a) => ($a['journalist_id'] ?? '') === ($journalist['id'] ?? '')));
$current_page = 'journalists';
$name = td_localized($journalist, 'name');
$canonical = td_journalist_url($journalist);
$page_title = sprintf($t['journalist']['articles_by'] ?? 'Articles by %s', $name) . ' — ' . TD_SITE_NAME;
$page_desc = td_localized($journalist, 'bio');
$canon_abs = td_absolute_url($canonical);
$seo_schemas = [
    td_seo_organization(),
    td_seo_webpage($canon_abs, $page_title, $page_desc),
    [
        '@type' => 'Person',
        'name' => $name,
        'jobTitle' => td_localized($journalist, 'title'),
        'description' => td_localized($journalist, 'bio'),
        'url' => $canon_abs,
        'image' => td_absolute_url(td_journalist_avatar($journalist)),
    ],
];

require __DIR__ . '/includes/header.php';
?>

<section class="td-page-hero td-journalist-hero">
    <div class="td-container td-journalist-hero-inner">
        <img src="<?= htmlspecialchars(td_journalist_avatar($journalist)) ?>" alt="<?= htmlspecialchars($name) ?>" width="140" height="140">
        <div>
            <nav class="td-crumb"><a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a> → <a href="<?= td_url('journalists.php') ?>"><?= htmlspecialchars($t['journalists']['breadcrumb']) ?></a> → <?= htmlspecialchars($name) ?></nav>
            <h1><?= htmlspecialchars($name) ?></h1>
            <p class="td-j-title"><?= htmlspecialchars(td_localized($journalist, 'title')) ?></p>
            <p><?= htmlspecialchars(td_localized($journalist, 'bio')) ?></p>
            <p class="td-demo-note"><?= htmlspecialchars($t['journalist']['contact_note']) ?></p>
        </div>
    </div>
</section>

<section class="td-section">
    <div class="td-container">
        <h2><?= sprintf($t['journalist']['articles_by'] ?? 'Articles by %s', $name) ?></h2>
        <?php if ($articles): ?>
        <div class="td-articles-grid">
            <?php foreach ($articles as $article): $size = 'medium'; require __DIR__ . '/includes/article-card.php'; endforeach; ?>
        </div>
        <?php else: ?>
        <p class="td-empty-text"><?= htmlspecialchars($t['journalist']['no_articles']) ?></p>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>