<?php
/**
 * Demo admin auth — session based
 * Login: demo / pilotoday2026
 */
define('TD_ADMIN_USER', 'demo');
define('TD_ADMIN_PASS', 'pilotoday2026');
define('TD_ADMIN_SESSION_KEY', 'td_admin_logged');

function td_admin_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function td_admin_logged(): bool
{
    td_admin_start();
    return !empty($_SESSION[TD_ADMIN_SESSION_KEY]);
}

function td_admin_login(string $user, string $pass): bool
{
    if ($user === TD_ADMIN_USER && $pass === TD_ADMIN_PASS) {
        td_admin_start();
        $_SESSION[TD_ADMIN_SESSION_KEY] = true;
        $_SESSION['td_admin_user']    = $user;
        return true;
    }
    return false;
}

function td_admin_logout(): void
{
    td_admin_start();
    unset($_SESSION[TD_ADMIN_SESSION_KEY], $_SESSION['td_admin_user']);
}

function td_admin_require(): void
{
    if (!td_admin_logged()) {
        header('Location: ' . td_admin_url('login.php'), true, 302);
        exit;
    }
}

function td_admin_url(string $path = ''): string
{
    return td_url('admin/' . ltrim($path, '/'));
}