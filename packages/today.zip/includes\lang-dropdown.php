<?php /** Language dropdown — expects $lang, td_langs() */ ?>
<div class="td-lang" id="tdLang">
    <button type="button" class="td-lang-btn" id="tdLangBtn" aria-expanded="false">
        <?= $lang_meta['flag'] ?? '' ?> <?= htmlspecialchars($lang_meta['label'] ?? strtoupper($lang)) ?>
        <i class="fas fa-chevron-down" aria-hidden="true"></i>
    </button>
    <ul class="td-lang-menu" id="tdLangMenu" hidden>
        <?php foreach (td_langs() as $code => $info): ?>
        <li><a href="<?= htmlspecialchars(td_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['flag'] ?> <?= htmlspecialchars($info['name']) ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>