<?php
require_once __DIR__ . '/init.php';
td_admin_require();
$admin_page = 'categories';
$page_title = $ta['categories'];

$categories = td_categories();
$all_articles = td_articles(true);

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-alert adm-alert-info">
    <i class="fas fa-info-circle"></i> <?= htmlspecialchars($ta['categories_note']) ?>
</div>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['categories']) ?> (<?= count($categories) ?>)</h2>
        <a href="<?= td_url('index.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
            <i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['view_site']) ?>
        </a>
    </div>
    <div class="adm-card-body">
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th><?= htmlspecialchars($ta['id']) ?></th>
                    <th><?= htmlspecialchars($ta['slug']) ?></th>
                    <th><?= htmlspecialchars($ta['cat_name']) ?></th>
                    <th><?= htmlspecialchars($ta['color']) ?></th>
                    <th><?= htmlspecialchars($ta['icon']) ?></th>
                    <th><?= htmlspecialchars($ta['articles']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat):
                    $count = count(array_filter($all_articles, fn($a) => ($a['category_id'] ?? '') === ($cat['id'] ?? '')));
                ?>
                <tr>
                    <td data-label="<?= htmlspecialchars($ta['id']) ?>"><code><?= htmlspecialchars($cat['id'] ?? '') ?></code></td>
                    <td data-label="<?= htmlspecialchars($ta['slug']) ?>"><?= htmlspecialchars($cat['slug'] ?? '') ?></td>
                    <td data-label="<?= htmlspecialchars($ta['cat_name']) ?>">
                        <strong><?= htmlspecialchars(td_localized($cat, 'name', 'en')) ?></strong><br>
                        <small style="color:var(--adm-muted)">
                            <?= htmlspecialchars(td_localized($cat, 'name', 'no')) ?> ·
                            <?= htmlspecialchars(td_localized($cat, 'name', 'uk')) ?> ·
                            <?= htmlspecialchars(td_localized($cat, 'name', 'ru')) ?>
                        </small>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['color']) ?>">
                        <span class="adm-color-swatch" style="background:<?= htmlspecialchars($cat['color'] ?? '#ccc') ?>"></span>
                        <?= htmlspecialchars($cat['color'] ?? '') ?>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['icon']) ?>">
                        <i class="<?= htmlspecialchars(td_fa_icon($cat['icon'] ?? '')) ?>"></i>
                        <?= htmlspecialchars($cat['icon'] ?? '') ?>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['articles']) ?>"><?= (int)$count ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>