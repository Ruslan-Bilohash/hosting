<?php
require_once __DIR__ . '/init.php';
td_admin_require();
$admin_page = 'articles';
$page_title = $ta['articles'];

$filter = $_GET['filter'] ?? 'all';
$articles = td_articles(true);

if ($filter === 'published') {
    $articles = array_values(array_filter($articles, fn($a) => ($a['published'] ?? true) !== false));
} elseif ($filter === 'draft') {
    $articles = array_values(array_filter($articles, fn($a) => ($a['published'] ?? true) === false));
} elseif ($filter === 'featured') {
    $articles = array_values(array_filter($articles, fn($a) => !empty($a['featured'])));
} elseif ($filter === 'breaking') {
    $articles = array_values(array_filter($articles, fn($a) => !empty($a['breaking'])));
}

$base = td_admin_url('articles.php');
$deleted = !empty($_GET['deleted']);

require __DIR__ . '/includes/layout.php';
?>

<?php if ($deleted): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['deleted']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['all_articles']) ?> (<?= count($articles) ?>)</h2>
        <a href="<?= td_admin_url('article.php?new=1') ?>" class="adm-btn adm-btn-primary adm-btn-sm">
            <i class="fas fa-plus"></i> <?= htmlspecialchars($ta['add_article']) ?>
        </a>
    </div>
    <div class="adm-filter-bar">
        <a href="<?= htmlspecialchars($base) ?>" class="<?= $filter === 'all' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_all']) ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=published') ?>" class="<?= $filter === 'published' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_published']) ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=draft') ?>" class="<?= $filter === 'draft' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_draft']) ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=featured') ?>" class="<?= $filter === 'featured' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_featured']) ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=breaking') ?>" class="<?= $filter === 'breaking' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_breaking']) ?></a>
    </div>
    <div class="adm-card-body">
        <?php if (empty($articles)): ?>
        <p style="padding:24px;text-align:center;color:var(--adm-muted)"><?= htmlspecialchars($ta['no_articles']) ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th></th>
                    <th><?= htmlspecialchars($ta['title_label']) ?></th>
                    <th><?= htmlspecialchars($ta['category']) ?></th>
                    <th><?= htmlspecialchars($ta['author']) ?></th>
                    <th><?= htmlspecialchars($ta['date']) ?></th>
                    <th><?= htmlspecialchars($ta['status']) ?></th>
                    <th><?= htmlspecialchars($ta['actions']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($articles as $article):
                    $cat = td_category_by_id($article['category_id'] ?? '');
                    $jour = td_journalist_by_id($article['journalist_id'] ?? '');
                ?>
                <tr>
                    <td data-label=""><img src="<?= htmlspecialchars(td_article_image($article)) ?>" alt="" class="adm-thumb" loading="lazy"></td>
                    <td data-label="<?= htmlspecialchars($ta['title_label']) ?>">
                        <strong><?= htmlspecialchars(td_localized($article, 'title', 'en')) ?></strong><br>
                        <small style="color:var(--adm-muted)"><?= htmlspecialchars($article['slug'] ?? '') ?></small>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['category']) ?>"><?= htmlspecialchars($cat ? td_localized($cat, 'name') : ($article['category_id'] ?? '')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['author']) ?>"><?= htmlspecialchars($jour ? td_localized($jour, 'name') : ($article['journalist_id'] ?? '')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['date']) ?>"><?= htmlspecialchars(td_format_date($article['published_at'] ?? '')) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['status']) ?>">
                        <?php if (($article['published'] ?? true) !== false): ?>
                        <span class="adm-badge adm-badge-active"><?= htmlspecialchars($ta['active']) ?></span>
                        <?php else: ?>
                        <span class="adm-badge adm-badge-hidden"><?= htmlspecialchars($ta['inactive']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['actions']) ?>">
                        <a href="<?= td_admin_url('article.php?id=' . urlencode($article['id'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm">
                            <i class="fas fa-pen"></i> <?= htmlspecialchars($ta['edit']) ?>
                        </a>
                        <a href="<?= td_url('article.php?slug=' . urlencode($article['slug'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="<?= td_admin_url('article.php?delete=' . urlencode($article['id'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm adm-btn-danger"
                           onclick="return confirm('<?= htmlspecialchars($ta['confirm_delete'], ENT_QUOTES) ?>')">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>