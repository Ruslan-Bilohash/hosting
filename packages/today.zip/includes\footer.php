</main>

<footer class="td-footer">
    <div class="td-container td-footer-grid">
        <div class="td-footer-brand">
            <a href="<?= td_url('index.php') ?>" class="td-footer-logo">TODAY <span>CMS</span></a>
            <p><?= htmlspecialchars($t['footer']['about_text'] ?? $t['meta']['tagline']) ?></p>
        </div>
        <div>
            <h4><?= htmlspecialchars($t['footer']['sections']) ?></h4>
            <ul>
                <?php foreach (td_categories() as $cat): ?>
                <li><a href="<?= htmlspecialchars(td_category_url($cat)) ?>"><?= htmlspecialchars(td_localized($cat, 'name')) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div>
            <h4><?= htmlspecialchars($t['footer']['site'] ?? 'Site') ?></h4>
            <ul>
                <li><a href="<?= td_url('journalists.php') ?>"><?= htmlspecialchars($t['nav']['journalists']) ?></a></li>
                <li><a href="<?= td_url('about.php') ?>"><?= htmlspecialchars($t['nav']['about']) ?></a></li>
                <li><a href="<?= td_url('contact.php') ?>"><?= htmlspecialchars($t['nav']['contact']) ?></a></li>
                <li><a href="<?= td_url('admin/login.php') ?>"><?= htmlspecialchars($t['nav']['admin']) ?></a></li>
            </ul>
        </div>
        <?php require dirname(__DIR__, 2) . '/includes/ecosystem-footer-column.php'; ?>
    </div>
    <div class="td-container">
        <?php require dirname(__DIR__, 2) . '/includes/ecosystem-footer-pills.php'; ?>
    </div>
    <div class="td-container td-footer-bottom">
        <p><?= sprintf(htmlspecialchars($t['footer']['copyright'] ?? '© %s Today CMS'), date('Y')) ?></p>
        <p class="td-footer-credit"><a href="https://bilohash.com/">bilohash.com</a> · <a href="https://bilohash.com/contact.php">Contact</a> · Norway</p>
    </div>
</footer>

<script src="<?= htmlspecialchars(td_asset('js/main.js')) ?>?v=1" defer></script>
<?php bh_cms_render_chat_widget('Today CMS', td_site_settings(), $lang ?? 'no'); ?>
</body>
</html>