<?php
/** Demo journalist profiles — fictional authors for Today CMS showcase. */
return [
    [
        'id'     => 'j-01',
        'slug'   => 'ingrid-solberg',
        'role'   => 'editor',
        'avatar' => 'assets/images/journalists/ingrid-solberg.svg',
        'name'   => [
            'no' => 'Ingrid Solberg',
            'en' => 'Ingrid Solberg',
            'uk' => 'Інгрід Сольберг',
            'ru' => 'Ингрид Сольберг',
        ],
        'title' => [
            'no' => 'Demo sjefredaktør',
            'en' => 'Demo Editor-in-Chief',
            'uk' => 'Демо головний редактор',
            'ru' => 'Демо главный редактор',
        ],
        'bio' => [
            'no' => 'Fiktiv demo-profil i Today CMS. Ingrid «forfatter» artikler om flerspråklighet, journalistprofiler og bestilling av nyhets-CMS — ikke ekte nyheter.',
            'en' => 'Fictional demo profile in Today CMS. Ingrid «authors» articles about multilingual editing, journalist profiles and ordering a news CMS — not real news.',
            'uk' => 'Вигаданий демо-профіль у Today CMS. Інгрід «авторка» статей про багатомовність, профілі журналістів і замовлення новинного CMS — не справжні новини.',
            'ru' => 'Вымышленный демо-профиль в Today CMS. Ингрид «автор» статей о многоязычности, профилях журналистов и заказе новостного CMS — не настоящие новости.',
        ],
    ],
    [
        'id'     => 'j-02',
        'slug'   => 'lars-moen',
        'role'   => 'journalist',
        'avatar' => 'assets/images/journalists/lars-moen.svg',
        'name'   => [
            'no' => 'Lars Moen',
            'en' => 'Lars Moen',
            'uk' => 'Ларс Моен',
            'ru' => 'Ларс Моен',
        ],
        'title' => [
            'no' => 'Demo innholdsredaktør',
            'en' => 'Demo Content Editor',
            'uk' => 'Демо редактор контенту',
            'ru' => 'Демо редактор контента',
        ],
        'bio' => [
            'no' => 'Plassholder-forfatter for adminpanel-, kategori- og publiseringsdemoer. Alle saker er testinnhold som viser Today CMS for potensielle kunder.',
            'en' => 'Placeholder author for admin panel, category and publishing demos. All stories are test content showcasing Today CMS to prospective clients.',
            'uk' => 'Плейсхолдер-автор для демо адмінпанелі, категорій і публікації. Усі матеріали — тестовий контент для показу Today CMS клієнтам.',
            'ru' => 'Плейсхолдер-автор для демо админпанели, категорий и публикации. Все материалы — тестовый контент для показа Today CMS клиентам.',
        ],
    ],
    [
        'id'     => 'j-03',
        'slug'   => 'elena-kovalenko',
        'role'   => 'journalist',
        'avatar' => 'assets/images/journalists/elena-kovalenko.svg',
        'name'   => [
            'no' => 'Elena Kovalenko',
            'en' => 'Elena Kovalenko',
            'uk' => 'Олена Коваленко',
            'ru' => 'Елена Коваленко',
        ],
        'title' => [
            'no' => 'Demo teknisk skribent',
            'en' => 'Demo Technical Writer',
            'uk' => 'Демо технічний автор',
            'ru' => 'Демо технический автор',
        ],
        'bio' => [
            'no' => 'Skriver demotekster om Schema.org SEO, JSON-lagring og søk. Ingen tilknytning til ekte medier — kun produktdokumentasjon i nyhetsformat.',
            'en' => 'Writes demo copy about Schema.org SEO, JSON storage and search. No affiliation with real media — product documentation in news article format.',
            'uk' => 'Пише демо-тексти про Schema.org SEO, JSON-сховище та пошук. Без зв\'язку з реальними медіа — документація продукту у форматі новин.',
            'ru' => 'Пишет демо-тексты о Schema.org SEO, JSON-хранилище и поиске. Без связи с реальными медиа — документация продукта в формате новостей.',
        ],
    ],
    [
        'id'     => 'j-04',
        'slug'   => 'mariam-olsen',
        'role'   => 'journalist',
        'avatar' => 'assets/images/journalists/mariam-olsen.svg',
        'name'   => [
            'no' => 'Mariam Olsen',
            'en' => 'Mariam Olsen',
            'uk' => 'Маріам Олсен',
            'ru' => 'Мариам Олсен',
        ],
        'title' => [
            'no' => 'Demo UX-skribent',
            'en' => 'Demo UX Writer',
            'uk' => 'Демо UX-автор',
            'ru' => 'Демо UX-автор',
        ],
        'bio' => [
            'no' => 'Forfatter av demotekster om avisdesign, typografi og responsivt layout. Hjelper besøkende å vurdere frontend før de bestiller Today CMS.',
            'en' => 'Author of demo texts about newspaper design, typography and responsive layout. Helps visitors evaluate the frontend before ordering Today CMS.',
            'uk' => 'Авторка демо-текстів про газетний дизайн, типографіку та адаптивну верстку. Допомагає оцінити фронтенд перед замовленням Today CMS.',
            'ru' => 'Автор демо-текстов о газетном дизайне, типографике и адаптивной вёрстке. Помогает оценить фронтенд перед заказом Today CMS.',
        ],
    ],
    [
        'id'     => 'j-05',
        'slug'   => 'ole-brekke',
        'role'   => 'journalist',
        'avatar' => 'assets/images/journalists/ole-brekke.svg',
        'name'   => [
            'no' => 'Ole Brekke',
            'en' => 'Ole Brekke',
            'uk' => 'Оле Брекке',
            'ru' => 'Оле Брекке',
        ],
        'title' => [
            'no' => 'Demo funksjonsskribent',
            'en' => 'Demo Features Writer',
            'uk' => 'Демо автор функцій',
            'ru' => 'Демо автор функций',
        ],
        'bio' => [
            'no' => 'Viser breaking-ticker, featured-merker og andre frontend-funksjoner gjennom fiktive artikler. Sport-kategorien brukes kun som layout-demo.',
            'en' => 'Showcases breaking ticker, featured badges and other frontend features through fictional articles. The sports category is used only as a layout demo.',
            'uk' => 'Демонструє breaking-тікер, мітки featured та інші функції фронтенду через вигадані статті. Категорія спорту — лише демо верстки.',
            'ru' => 'Демонстрирует breaking-тикер, метки featured и другие функции фронтенда через вымышленные статьи. Категория спорта — лишь демо вёрстки.',
        ],
    ],
];