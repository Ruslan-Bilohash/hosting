(function () {
    var menuBtn = document.getElementById('tdMenuBtn');
    var nav = document.getElementById('tdNavPanel');
    if (menuBtn && nav) {
        menuBtn.addEventListener('click', function () {
            var open = nav.classList.toggle('is-open');
            menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    var langBtn = document.getElementById('tdLangBtn');
    var langMenu = document.getElementById('tdLangMenu');
    if (langBtn && langMenu) {
        langBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var hidden = langMenu.hasAttribute('hidden');
            if (hidden) {
                langMenu.removeAttribute('hidden');
                langBtn.setAttribute('aria-expanded', 'true');
            } else {
                langMenu.setAttribute('hidden', '');
                langBtn.setAttribute('aria-expanded', 'false');
            }
        });
        document.addEventListener('click', function () {
            langMenu.setAttribute('hidden', '');
            langBtn.setAttribute('aria-expanded', 'false');
        });
    }
})();