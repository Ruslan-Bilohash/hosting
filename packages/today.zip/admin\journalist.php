<?php
require_once __DIR__ . '/init.php';
td_admin_require();
$admin_page = 'journalists';

$lang_codes = ['no', 'en', 'uk', 'ru'];
$lang_labels = [
    'no' => $ta['lang_no'],
    'en' => $ta['lang_en'],
    'uk' => $ta['lang_uk'],
    'ru' => $ta['lang_ru'],
];

$id   = $_GET['id'] ?? '';
$list = td_load_journalists_raw();
$idx  = null;
$journalist = null;

foreach ($list as $i => $j) {
    if (($j['id'] ?? '') === $id) {
        $idx = $i;
        $journalist = $j;
        break;
    }
}

if ($journalist === null) {
    header('Location: ' . td_admin_url('journalists.php'), true, 302);
    exit;
}

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $record = [
        'id'     => $journalist['id'],
        'slug'   => trim($_POST['slug'] ?? ''),
        'role'   => ($_POST['role'] ?? '') === 'editor' ? 'editor' : 'journalist',
        'avatar' => trim($_POST['avatar'] ?? ''),
        'name'   => [],
        'title'  => [],
        'bio'    => [],
    ];

    foreach ($lang_codes as $lc) {
        $record['name'][$lc]  = trim($_POST['name_' . $lc] ?? '');
        $record['title'][$lc] = trim($_POST['title_' . $lc] ?? '');
        $record['bio'][$lc]   = trim($_POST['bio_' . $lc] ?? '');
    }

    if ($record['slug'] === '' && $record['name']['en'] !== '') {
        $record['slug'] = strtolower(preg_replace('/[^a-z0-9]+/', '-', $record['name']['en']) ?? '');
        $record['slug'] = trim($record['slug'], '-');
    }

    $list[$idx] = $record;

    if (td_save_journalists($list)) {
        $flash = 'success';
        $journalist = $record;
    } else {
        $flash = 'error';
    }
}

$page_title = ($ta['edit_journalist'] ?? 'Edit journalist') . ': ' . td_localized($journalist, 'name', 'en');

require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['saved']) ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($page_title) ?></h2>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a href="<?= td_url('journalist.php?slug=' . urlencode($journalist['slug'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                <i class="fas fa-eye"></i> <?= htmlspecialchars($ta['preview']) ?>
            </a>
            <a href="<?= td_admin_url('journalists.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['cancel']) ?></a>
        </div>
    </div>
    <div class="adm-card-body padded">
        <form method="post">
            <div style="display:flex;gap:20px;margin-bottom:20px;flex-wrap:wrap;align-items:flex-start">
                <img src="<?= htmlspecialchars(td_journalist_avatar($journalist)) ?>" alt="" style="width:96px;height:96px;object-fit:cover;border-radius:50%;border:1px solid var(--adm-border)">
                <div style="font-size:13px;color:var(--adm-muted)">
                    <strong><?= htmlspecialchars($ta['id']) ?>:</strong> <?= htmlspecialchars($journalist['id'] ?? '') ?>
                </div>
            </div>

            <div class="adm-form-grid">
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['slug']) ?></label>
                    <input type="text" name="slug" value="<?= htmlspecialchars($journalist['slug'] ?? '') ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['role_label']) ?></label>
                    <select name="role">
                        <option value="editor" <?= ($journalist['role'] ?? '') === 'editor' ? 'selected' : '' ?>><?= htmlspecialchars($ta['role_editor']) ?></option>
                        <option value="journalist" <?= ($journalist['role'] ?? '') === 'journalist' ? 'selected' : '' ?>><?= htmlspecialchars($ta['role_journalist']) ?></option>
                    </select>
                </div>
                <div class="adm-field adm-field-full">
                    <label><?= htmlspecialchars($ta['avatar_label']) ?></label>
                    <input type="text" name="avatar" value="<?= htmlspecialchars($journalist['avatar'] ?? '') ?>" placeholder="assets/images/journalists/name.svg">
                </div>
            </div>

            <div class="adm-lang-tabs" style="margin-top:24px">
                <div class="adm-lang-tabs-nav">
                    <?php foreach ($lang_codes as $i => $lc): ?>
                    <button type="button" class="adm-lang-tab <?= $i === 0 ? 'active' : '' ?>" data-tab="<?= $lc ?>"><?= htmlspecialchars($lang_labels[$lc]) ?></button>
                    <?php endforeach; ?>
                </div>
                <?php foreach ($lang_codes as $i => $lc): ?>
                <div class="adm-lang-tab-panel <?= $i === 0 ? 'active' : '' ?>" data-panel="<?= $lc ?>">
                    <div class="adm-form-grid" style="margin-top:16px">
                        <div class="adm-field">
                            <label><?= htmlspecialchars($ta['name_label']) ?></label>
                            <input type="text" name="name_<?= $lc ?>" value="<?= htmlspecialchars($journalist['name'][$lc] ?? '') ?>">
                        </div>
                        <div class="adm-field">
                            <label><?= htmlspecialchars($ta['title_role_label']) ?></label>
                            <input type="text" name="title_<?= $lc ?>" value="<?= htmlspecialchars($journalist['title'][$lc] ?? '') ?>">
                        </div>
                        <div class="adm-field adm-field-full">
                            <label><?= htmlspecialchars($ta['bio_label']) ?></label>
                            <textarea name="bio_<?= $lc ?>" rows="5"><?= htmlspecialchars($journalist['bio'][$lc] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top:24px">
                <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save']) ?></button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    document.querySelectorAll('.adm-lang-tab').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var tab = btn.getAttribute('data-tab');
            document.querySelectorAll('.adm-lang-tab').forEach(function (b) { b.classList.remove('active'); });
            document.querySelectorAll('.adm-lang-tab-panel').forEach(function (p) { p.classList.remove('active'); });
            btn.classList.add('active');
            document.querySelector('.adm-lang-tab-panel[data-panel="' + tab + '"]')?.classList.add('active');
        });
    });
})();
</script>

<?php require __DIR__ . '/includes/layout-end.php'; ?>