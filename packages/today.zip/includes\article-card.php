<?php
/** @var array $article @var string $size small|medium|large|hero */
$size = $size ?? 'medium';
$cat = td_category_by_id($article['category_id'] ?? '');
$journalist = td_journalist_by_id($article['journalist_id'] ?? '');
$cat_name = $cat ? td_localized($cat, 'name') : '';
$cat_color = $cat['color'] ?? '#c41e3a';
?>
<article class="td-card td-card--<?= htmlspecialchars($size) ?>">
    <a href="<?= htmlspecialchars(td_article_url($article)) ?>" class="td-card-link">
        <?php if ($size !== 'small'): ?>
        <div class="td-card-image">
            <img src="<?= htmlspecialchars(td_article_image($article)) ?>" alt="<?= htmlspecialchars(td_localized($article, 'title')) ?>" loading="lazy" width="640" height="400">
            <?php if (!empty($article['breaking'])): ?>
            <span class="td-breaking-badge"><?= htmlspecialchars($t['home']['breaking'] ?? 'Breaking') ?></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="td-card-body">
            <?php if ($cat_name): ?>
            <span class="td-card-cat" style="--cat-color: <?= htmlspecialchars($cat_color) ?>"><?= htmlspecialchars($cat_name) ?></span>
            <?php endif; ?>
            <h3 class="td-card-title"><?= htmlspecialchars(td_localized($article, 'title')) ?></h3>
            <?php if ($size !== 'small'): ?>
            <p class="td-card-excerpt"><?= htmlspecialchars(td_excerpt($article, null, $size === 'hero' ? 220 : 140)) ?></p>
            <?php endif; ?>
            <div class="td-card-meta">
                <?php if ($journalist): ?>
                <span class="td-card-author"><?= htmlspecialchars(td_localized($journalist, 'name')) ?></span>
                <?php endif; ?>
                <time datetime="<?= htmlspecialchars($article['published_at'] ?? '') ?>"><?= htmlspecialchars(td_format_date($article['published_at'] ?? '')) ?></time>
                <span class="td-card-read"><?= (int)td_reading_time(td_localized($article, 'body')) ?> <?= htmlspecialchars($t['article']['min_read'] ?? 'min') ?></span>
            </div>
        </div>
    </a>
</article>