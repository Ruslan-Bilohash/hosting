=== Today CMS ===

Multilingual PHP news CMS demo — newspaper design, fictional sample articles, demo authors, admin panel.
NOT a real newsroom. All articles showcase CMS features for Bilohash clients.

Languages: Norwegian (default), English, Ukrainian, Russian

URLs (after deploy)
  Frontend:     https://bilohash.com/today/
  Admin panel:  https://bilohash.com/today/admin/
  Sitemap:      https://bilohash.com/today/sitemap.xml

Admin demo login
  Username: demo
  Password: pilotoday2026

Deploy
  Upload the entire /today/ folder to the server web root.
  Ensure PHP 8+ and mod_rewrite are enabled.
  On first visit, seed data copies to /data/*.json automatically.
  Make /today/data/ writable by PHP (chmod 755 or 775).
  Delete /today/data/articles.json and journalists.json to reload new demo content.

Related
  Booking CMS:  https://bilohash.com/booking/
  Auction CMS:  https://bilohash.com/auction/
  bilohash.com: https://bilohash.com/