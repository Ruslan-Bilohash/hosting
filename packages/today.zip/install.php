<?php
if (is_file(__DIR__ . '/index.php')) { header('Location: ./'); exit; }
echo 'Installed';
