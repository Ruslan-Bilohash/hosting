<?php
require_once __DIR__ . '/init.php';

$current_page = 'journalists';
$journalists = td_journalists();
$canonical = td_url('journalists.php');
$page_title = $t['journalists']['meta_title'] ?? $t['journalists']['title'];
$page_desc = $t['journalists']['meta_desc'] ?? $t['meta']['description'];
$canon_abs = td_absolute_url($canonical);
$seo_schemas = [td_seo_organization(), td_seo_webpage($canon_abs, $page_title, $page_desc)];

require __DIR__ . '/includes/header.php';
?>

<section class="td-page-hero">
    <div class="td-container">
        <nav class="td-crumb"><a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a> → <?= htmlspecialchars($t['journalists']['breadcrumb']) ?></nav>
        <h1><?= htmlspecialchars($t['journalists']['title']) ?></h1>
        <p><?= htmlspecialchars($t['journalists']['subtitle']) ?></p>
    </div>
</section>

<section class="td-section">
    <div class="td-container td-journalists-page-grid">
        <?php foreach ($journalists as $j):
            $count = count(array_filter(td_articles(), fn($a) => ($a['journalist_id'] ?? '') === ($j['id'] ?? '')));
            $role_label = ($j['role'] ?? '') === 'editor' ? ($t['journalists']['editor'] ?? 'Editor') : ($t['journalists']['journalist'] ?? 'Journalist');
        ?>
        <article class="td-journalist-profile-card">
            <img src="<?= htmlspecialchars(td_journalist_avatar($j)) ?>" alt="<?= htmlspecialchars(td_localized($j, 'name')) ?>" width="120" height="120">
            <div>
                <span class="td-role-badge"><?= htmlspecialchars($role_label) ?></span>
                <h2><a href="<?= htmlspecialchars(td_journalist_url($j)) ?>"><?= htmlspecialchars(td_localized($j, 'name')) ?></a></h2>
                <p class="td-j-title"><?= htmlspecialchars(td_localized($j, 'title')) ?></p>
                <p><?= htmlspecialchars(td_localized($j, 'bio')) ?></p>
                <p class="td-j-count"><?= sprintf($t['journalists']['article_count'] ?? '%d articles', $count) ?></p>
                <a href="<?= htmlspecialchars(td_journalist_url($j)) ?>" class="td-link-more"><?= htmlspecialchars($t['journalists']['view_profile']) ?> →</a>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>