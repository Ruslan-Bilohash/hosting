<?php
require_once __DIR__ . '/init.php';

$slug = trim($_GET['slug'] ?? '');
$category = td_category_by_slug($slug);
if (!$category) {
    http_response_code(404);
    $current_page = 'category';
    $page_title = $t['category']['not_found'] . ' — ' . TD_SITE_NAME;
    require __DIR__ . '/includes/header.php';
    echo '<section class="td-container td-empty"><h1>' . htmlspecialchars($t['category']['not_found']) . '</h1><p>' . htmlspecialchars($t['category']['not_found_text']) . '</p></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$articles = td_articles_by_category($category['id'] ?? '');
$current_page = 'category';
$current_cat = $slug;
$cat_name = td_localized($category, 'name');
$canonical = td_category_url($category);
$page_title = sprintf($t['category']['articles_in'] ?? 'Articles in %s', $cat_name) . ' — ' . TD_SITE_NAME;
$page_desc = $cat_name . ' — ' . ($t['meta']['description'] ?? '');
$canon_abs = td_absolute_url($canonical);
$seo_schemas = [
    td_seo_organization(),
    td_seo_webpage($canon_abs, $page_title, $page_desc),
    td_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => td_absolute_url(td_url('index.php'))],
        ['name' => $cat_name, 'url' => $canon_abs],
    ]),
    td_seo_item_list($articles, $lang, $canon_abs),
];

require __DIR__ . '/includes/header.php';
?>

<section class="td-page-hero td-page-hero--cat" style="--cat-color: <?= htmlspecialchars($category['color'] ?? '#111') ?>">
    <div class="td-container">
        <nav class="td-crumb"><a href="<?= td_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a> → <?= htmlspecialchars($cat_name) ?></nav>
        <h1><i class="<?= htmlspecialchars(td_fa_icon($category['icon'] ?? 'folder')) ?>"></i> <?= htmlspecialchars($cat_name) ?></h1>
        <p><?= sprintf($t['category']['article_count'] ?? '%d articles', count($articles)) ?></p>
    </div>
</section>

<section class="td-section">
    <div class="td-container">
        <?php if ($articles): ?>
        <div class="td-articles-grid">
            <?php foreach ($articles as $article): $size = 'medium'; require __DIR__ . '/includes/article-card.php'; endforeach; ?>
        </div>
        <?php else: ?>
        <p class="td-empty-text"><?= htmlspecialchars($t['category']['no_articles']) ?></p>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>