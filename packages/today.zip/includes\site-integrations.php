<?php

require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
require_once __DIR__ . '/storage.php';

function td_site_settings(): array
{
    static $s = null;
    if ($s === null) {
        $s = td_load_settings();
        $GLOBALS['bh_cms_site_settings'] = $s;
        bh_cms_bind_recaptcha_settings($s);
    }
    return $s;
}

function td_boot_public_integrations(): void
{
    td_site_settings();
}