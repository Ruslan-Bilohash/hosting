<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/vertical-lib.php';
header('Content-Type: application/xml; charset=UTF-8');

$base = 'https://bilohash.com/auction';
$site_langs = ['en', 'uk', 'ru'];

$urls = [
    [
        'loc' => $base . '/',
        'priority' => '1.0',
        'changefreq' => 'weekly',
        'hreflang' => true,
        'path' => '/auction/',
    ],
    [
        'loc' => $base . '/site/',
        'priority' => '0.95',
        'changefreq' => 'weekly',
        'hreflang' => true,
        'path' => '/auction/site/',
    ],
    [
        'loc' => $base . '/solutions.php',
        'priority' => '0.92',
        'changefreq' => 'weekly',
        'hreflang' => true,
        'path' => '/auction/solutions.php',
    ],
    [
        'loc' => $base . '/contact.php',
        'priority' => '0.88',
        'changefreq' => 'monthly',
        'hreflang' => true,
        'path' => '/auction/contact.php',
    ],
    [
        'loc' => $base . '/site/contact.php',
        'priority' => '0.87',
        'changefreq' => 'monthly',
    ],
    [
        'loc' => $base . '/llms.txt',
        'priority' => '0.5',
        'changefreq' => 'monthly',
    ],
];

foreach ($site_langs as $lng) {
    $urls[] = [
        'loc' => $base . '/site/?lang=' . $lng,
        'priority' => '0.85',
        'changefreq' => 'weekly',
    ];
    $urls[] = [
        'loc' => $base . '/?lang=' . $lng,
        'priority' => '0.85',
        'changefreq' => 'weekly',
    ];
    $urls[] = [
        'loc' => $base . '/solutions.php?lang=' . $lng,
        'priority' => '0.85',
        'changefreq' => 'weekly',
    ];
    $urls[] = [
        'loc' => $base . '/contact.php?lang=' . $lng,
        'priority' => '0.84',
        'changefreq' => 'monthly',
    ];
    $urls[] = [
        'loc' => $base . '/site/contact.php?lang=' . $lng,
        'priority' => '0.83',
        'changefreq' => 'monthly',
    ];
}

foreach (au_vertical_slugs() as $slug) {
    $urls[] = [
        'loc' => $base . '/' . $slug . '/',
        'priority' => '0.88',
        'changefreq' => 'monthly',
        'hreflang' => true,
        'path' => '/auction/' . $slug . '/',
    ];
    foreach ($site_langs as $lng) {
        $urls[] = [
            'loc' => $base . '/' . $slug . '/?lang=' . $lng,
            'priority' => '0.86',
            'changefreq' => 'monthly',
        ];
    }
}

foreach (au_active_lots() as $lot) {
    $lot_id = $lot['id'];
    $urls[] = [
        'loc' => $base . '/lot.php?id=' . urlencode($lot_id),
        'priority' => '0.8',
        'changefreq' => 'daily',
        'lot_hreflang' => $lot_id,
    ];
    foreach ($site_langs as $lng) {
        $urls[] = [
            'loc' => $base . '/lot.php?id=' . urlencode($lot_id) . '&lang=' . $lng,
            'priority' => '0.75',
            'changefreq' => 'daily',
        ];
    }
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
<?php foreach ($urls as $u): ?>
    <url>
        <loc><?= htmlspecialchars($u['loc']) ?></loc>
        <changefreq><?= $u['changefreq'] ?? 'monthly' ?></changefreq>
        <priority><?= $u['priority'] ?? '0.5' ?></priority>
        <?php if (!empty($u['hreflang']) && !empty($u['path'])):
            $path = $u['path'];
        ?>
        <xhtml:link rel="alternate" hreflang="x-default" href="https://bilohash.com<?= htmlspecialchars($path) ?>"/>
        <xhtml:link rel="alternate" hreflang="nb-NO" href="https://bilohash.com<?= htmlspecialchars($path) ?>"/>
        <xhtml:link rel="alternate" hreflang="en-GB" href="https://bilohash.com<?= htmlspecialchars($path) ?>?lang=en"/>
        <xhtml:link rel="alternate" hreflang="uk-UA" href="https://bilohash.com<?= htmlspecialchars($path) ?>?lang=uk"/>
        <xhtml:link rel="alternate" hreflang="ru-RU" href="https://bilohash.com<?= htmlspecialchars($path) ?>?lang=ru"/>
        <?php elseif (!empty($u['lot_hreflang'])):
            $id = urlencode($u['lot_hreflang']);
        ?>
        <xhtml:link rel="alternate" hreflang="x-default" href="https://bilohash.com/auction/lot.php?id=<?= $id ?>"/>
        <xhtml:link rel="alternate" hreflang="nb-NO" href="https://bilohash.com/auction/lot.php?id=<?= $id ?>"/>
        <xhtml:link rel="alternate" hreflang="en-GB" href="https://bilohash.com/auction/lot.php?id=<?= $id ?>&amp;lang=en"/>
        <xhtml:link rel="alternate" hreflang="uk-UA" href="https://bilohash.com/auction/lot.php?id=<?= $id ?>&amp;lang=uk"/>
        <xhtml:link rel="alternate" hreflang="ru-RU" href="https://bilohash.com/auction/lot.php?id=<?= $id ?>&amp;lang=ru"/>
        <?php endif; ?>
    </url>
<?php endforeach; ?>
</urlset>