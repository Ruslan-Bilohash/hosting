<?php
$cms_404_home = '/auction/';
$cms_404_name = 'Auction CMS';
require dirname(__DIR__) . '/includes/cms-404.php';