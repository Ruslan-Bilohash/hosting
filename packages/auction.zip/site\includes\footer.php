<?php require_once dirname(__DIR__, 3) . '/includes/cms-contact.php'; ?>
<footer class="aus-footer">
    <div class="aus-footer-inner">
        <div class="aus-footer-grid">
            <div class="aus-footer-brand">
                <a href="<?= aus_url('index.php') ?>" class="aus-logo">
                    <span class="aus-logo-icon">A</span>
                    <span class="aus-logo-text">Auction <em>CMS</em></span>
                </a>
                <p><?= htmlspecialchars($t['intro']['text']) ?></p>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['product']) ?></h4>
                <ul>
                    <li><a href="<?= aus_url('index.php#features') ?>" rel="bookmark"><?= htmlspecialchars($t['nav']['features']) ?></a></li>
                    <li><a href="<?= aus_url('index.php#tech') ?>"><?= htmlspecialchars($t['nav']['tech']) ?></a></li>
                    <li><a href="<?= aus_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a></li>
                </ul>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['links']) ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/" rel="author"><?= htmlspecialchars($t['footer']['bilohash']) ?></a></li>
                    <li><a href="<?= aus_demo_url() ?>" rel="related"><?= htmlspecialchars($t['footer']['demo_link']) ?></a></li>
                    <li><a href="<?= aus_demo_url('admin/login.php') ?>"><?= htmlspecialchars($t['demo']['admin']) ?></a></li>
                    <li><a href="https://bilohash.com/auction/llms.txt"><?= htmlspecialchars($t['footer']['llms']) ?></a></li>
                    <li><a href="<?= aus_url('contact.php') ?>"><?= htmlspecialchars(cms_contact_texts('auction', $lang)['nav_discuss']) ?></a></li>
                    <li><a href="https://bilohash.com/" rel="author"><?= htmlspecialchars($t['footer']['order']) ?></a></li>
                </ul>
            </div>
            <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-column.php'; ?>
            <div>
                <h4><?= htmlspecialchars($t['footer']['author']) ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/auction/sitemap.php">Sitemap</a></li>
                    <li><a href="https://bilohash.com/auction/llms.txt"><?= htmlspecialchars($t['footer']['llms']) ?></a></li>
                    <li><a href="<?= aus_demo_url() ?>" rel="related"><?= htmlspecialchars($t['footer']['demo_link']) ?></a></li>
                </ul>
            </div>
        </div>
        <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-pills.php'; ?>
        <div class="aus-footer-bottom">
            <?= sprintf(htmlspecialchars($t['footer']['copyright']), date('Y')) ?>
        </div>
    </div>
</footer>
<script src="<?= htmlspecialchars(aus_asset('js/site.js')) ?>?v=1" defer></script>
</body>
</html>