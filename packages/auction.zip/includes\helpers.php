<?php

if (!function_exists('bh_str_lower')) {
    function bh_str_lower(string $str): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($str) : strtolower($str);
    }
}

if (!function_exists('bh_str_sub')) {
    function bh_str_sub(string $str, int $start, ?int $length = null): string
    {
        if (function_exists('mb_substr')) {
            return $length === null ? mb_substr($str, $start) : mb_substr($str, $start, $length);
        }
        return $length === null ? substr($str, $start) : substr($str, $start, $length);
    }
}

function au_active_lots(): array
{
    return au_lots(false);
}

function au_lots(bool $include_inactive = false): array
{
    require_once __DIR__ . '/storage.php';
    $list = au_load_lots_raw();
    if (!$include_inactive) {
        $list = array_values(array_filter($list, fn($l) => ($l['active'] ?? true) !== false));
    }
    return $list;
}

function au_lots_all(): array
{
    return au_lots(true);
}

function au_lot_by_id(string $id, bool $include_inactive = false): ?array
{
    foreach (au_lots($include_inactive) as $l) {
        if ($l['id'] === $id) {
            return $l;
        }
    }
    return null;
}

function au_localized(array $item, string $field, string $lang): string
{
    $val = $item[$field] ?? '';
    if (is_array($val)) {
        return $val[$lang] ?? $val['ru'] ?? $val['uk'] ?? $val['en'] ?? $val['no'] ?? '';
    }
    return (string) $val;
}

function au_categories(): array
{
    return ['art', 'antiques', 'vehicles', 'collectibles', 'jewelry', 'real_estate'];
}

function au_search_params(): array
{
    return [
        'q'         => trim($_GET['q'] ?? ''),
        'category'  => $_GET['category'] ?? '',
        'status'    => $_GET['status'] ?? '',
        'sort'      => $_GET['sort'] ?? 'ending',
        'min_bid'   => (int)($_GET['min_bid'] ?? 0),
        'max_bid'   => (int)($_GET['max_bid'] ?? 0),
    ];
}

function au_lot_ends_at(array $lot): int
{
    $raw = $lot['ends_at'] ?? '';
    $ts = strtotime($raw);
    return $ts !== false ? $ts : time() + 86400;
}

function au_lot_is_live(array $lot): bool
{
    return au_lot_ends_at($lot) > time() && ($lot['status'] ?? 'live') !== 'ended';
}

function au_filter_lots(array $params, string $lang): array
{
    $items = au_lots();
    $q = bh_str_lower($params['q']);

    if ($q !== '') {
        $items = array_filter($items, function ($l) use ($q, $lang) {
            $hay = bh_str_lower(
                au_localized($l, 'name', $lang) . ' '
                . au_localized($l, 'desc', $lang) . ' '
                . au_localized($l, 'city', $lang) . ' '
                . au_localized($l, 'country', $lang)
            );
            return str_contains($hay, $q);
        });
    }

    if ($params['category'] !== '' && in_array($params['category'], au_categories(), true)) {
        $items = array_filter($items, fn($l) => ($l['category'] ?? '') === $params['category']);
    }

    if ($params['status'] === 'live') {
        $items = array_filter($items, fn($l) => au_lot_is_live($l));
    } elseif ($params['status'] === 'ending') {
        $items = array_filter($items, function ($l) {
            $left = au_lot_ends_at($l) - time();
            return au_lot_is_live($l) && $left > 0 && $left <= 48 * 3600;
        });
    }

    if ($params['min_bid'] > 0) {
        $items = array_filter($items, fn($l) => (int)($l['current_bid'] ?? 0) >= $params['min_bid']);
    }
    if ($params['max_bid'] > 0) {
        $items = array_filter($items, fn($l) => (int)($l['current_bid'] ?? 0) <= $params['max_bid']);
    }

    $items = array_values($items);

    usort($items, function ($a, $b) use ($params) {
        return match ($params['sort']) {
            'bid_low'  => ($a['current_bid'] ?? 0) <=> ($b['current_bid'] ?? 0),
            'bid_high' => ($b['current_bid'] ?? 0) <=> ($a['current_bid'] ?? 0),
            'newest'   => au_lot_ends_at($b) <=> au_lot_ends_at($a),
            default    => au_lot_ends_at($a) <=> au_lot_ends_at($b),
        };
    });

    return $items;
}

function au_live_lots(): array
{
    return array_values(array_filter(au_lots(), fn($l) => au_lot_is_live($l)));
}

function au_ending_soon_lots(int $limit = 4): array
{
    $live = au_live_lots();
    usort($live, fn($a, $b) => au_lot_ends_at($a) <=> au_lot_ends_at($b));
    return array_slice($live, 0, $limit);
}

function au_featured_lots(int $limit = 4): array
{
    $featured = array_values(array_filter(au_lots(), fn($l) => !empty($l['featured']) && au_lot_is_live($l)));
    return array_slice($featured, 0, $limit);
}

function au_min_bid(array $lot): int
{
    $current = (int)($lot['current_bid'] ?? $lot['start_price'] ?? 0);
    $increment = max(50, (int)($lot['bid_increment'] ?? 100));
    return $current + $increment;
}

function au_lang_url(string $code, bool $for_hreflang = false): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: au_url('index.php');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);
    if ($code === 'no' && $for_hreflang) {
        unset($q['lang']);
    } else {
        $q['lang'] = $code;
    }
    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}

function au_placeholder_image(): string
{
    return au_asset('images/placeholder.svg');
}

function au_lot_image(array $lot): string
{
    return trim($lot['image'] ?? '') ?: au_placeholder_image();
}

function au_category_counts(): array
{
    $counts = array_fill_keys(au_categories(), 0);
    foreach (au_lots() as $l) {
        $cat = $l['category'] ?? '';
        if (isset($counts[$cat])) {
            $counts[$cat]++;
        }
    }
    return $counts;
}

function au_lot_long_desc(array $lot, string $lang): string
{
    $long = au_localized($lot, 'long_desc', $lang);
    if ($long !== '') {
        return $long;
    }
    return au_localized($lot, 'desc', $lang);
}

function au_lot_condition(array $lot, string $lang): string
{
    return au_localized($lot, 'condition', $lang);
}

function au_lot_seller(array $lot, string $lang): string
{
    $seller = au_localized($lot, 'seller', $lang);
    return $seller !== '' ? $seller : match ($lang) {
        'no' => 'Verifisert selger (demo)',
        'uk' => 'Верифікований продавець (демо)',
        default => 'Verified seller (demo)',
    };
}

function au_lot_estimate(array $lot): array
{
    $low = (int)($lot['estimate_low'] ?? $lot['start_price'] ?? 0);
    $high = (int)($lot['estimate_high'] ?? max($low, (int)($lot['current_bid'] ?? 0) + (int)($lot['bid_increment'] ?? 100) * 3));
    return ['low' => $low, 'high' => $high];
}

function au_lot_highlights(array $lot, string $lang): array
{
    if (!empty($lot['highlights'][$lang]) && is_array($lot['highlights'][$lang])) {
        return $lot['highlights'][$lang];
    }
    if (!empty($lot['highlights']['en']) && is_array($lot['highlights']['en'])) {
        return $lot['highlights']['en'];
    }
    $cat = $lot['category'] ?? '';
    return match ($lang) {
        'no' => match ($cat) {
            'art' => ['Autentisert proveniens', 'Profesjonell innramming', 'EU-frakt tilgjengelig'],
            'vehicles' => ['Full servicehistorikk', 'Visning etter avtale', 'Eksportdokumentasjon'],
            'real_estate' => ['Byggeklar tomt', 'Veiadkomst', 'Kommunal vann'],
            default => ['Inspeksjon på forespørsel', 'Sikker demobudgivning', 'NOK-priser'],
        },
        'uk' => match ($cat) {
            'art' => ['Автентифіковане походження', 'Професійне обрамлення', 'Доставка по ЄС'],
            'vehicles' => ['Повна історія сервісу', 'Огляд за домовленістю', 'Експортні документи'],
            'real_estate' => ['Ділянка під забудову', 'Під\'їзд', 'Комунальна вода'],
            default => ['Огляд на запит', 'Безпечне демо-ставлення', 'Ціни в NOK'],
        },
        default => match ($cat) {
            'art' => ['Authenticated provenance', 'Professional framing', 'EU shipping available'],
            'vehicles' => ['Full service history', 'Viewing by appointment', 'Export documentation'],
            'real_estate' => ['Building-ready parcel', 'Road access', 'Municipal utilities'],
            default => ['Inspection on request', 'Secure demo bidding', 'NOK pricing'],
        },
    };
}

function au_related_lots(array $lot, int $limit = 4): array
{
    $cat = $lot['category'] ?? '';
    $related = array_values(array_filter(au_lots(), fn($l) => ($l['id'] ?? '') !== ($lot['id'] ?? '') && ($l['category'] ?? '') === $cat && au_lot_is_live($l)));
    if (count($related) < $limit) {
        $extra = array_values(array_filter(au_lots(), fn($l) => ($l['id'] ?? '') !== ($lot['id'] ?? '') && au_lot_is_live($l)));
        $related = array_merge($related, $extra);
    }
    return array_slice($related, 0, $limit);
}

function au_platform_stats(): array
{
    require_once __DIR__ . '/storage.php';
    $lots = au_lots();
    $bids = au_load_bids();
    return [
        'lots'    => count($lots),
        'live'    => count(au_live_lots()),
        'bids'    => count($bids),
        'volume'  => array_sum(array_map(fn($b) => (int)($b['amount'] ?? 0), $bids)),
        'featured'=> count(array_filter($lots, fn($l) => !empty($l['featured']))),
    ];
}

function au_admin_category_chart(): array
{
    $counts = au_category_counts();
    $max = max(1, max($counts));
    $chart = [];
    foreach ($counts as $cat => $n) {
        $chart[] = ['cat' => $cat, 'count' => $n, 'pct' => round(($n / $max) * 100)];
    }
    usort($chart, fn($a, $b) => $b['count'] <=> $a['count']);
    return $chart;
}

function au_demo_bid_history(array $lot): array
{
    $count = min(8, max(3, (int)($lot['bids_count'] ?? 5)));
    $current = (int)($lot['current_bid'] ?? 1000);
    $increment = max(50, (int)($lot['bid_increment'] ?? 100));
    $history = [];
    $amount = $current;
    $names = ['Ole N.', 'Anna H.', 'Maria K.', 'Erik S.', 'Lars B.', 'Ingrid T.', 'Demo Bidder', 'Collector NO'];
    for ($i = 0; $i < $count; $i++) {
        $history[] = [
            'bidder' => $names[$i % count($names)],
            'amount' => $amount,
            'time'   => date('c', time() - ($i * 3600 + rand(120, 900))),
        ];
        $amount = max((int)($lot['start_price'] ?? 0), $amount - $increment);
    }
    return $history;
}