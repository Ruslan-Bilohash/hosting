<?php

function aus_protocol(): string
{
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    ) ? 'https' : 'http';
}

function aus_absolute_url(string $path): string
{
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    $host = $_SERVER['HTTP_HOST'] ?? AU_DOMAIN;
    return aus_protocol() . '://' . $host . (str_starts_with($path, '/') ? $path : '/' . $path);
}

function aus_full_lang_url(string $code): string
{
    return aus_absolute_url(aus_lang_url($code, true));
}

function aus_demo_absolute(string $path = ''): string
{
    return 'https://bilohash.com/auction/' . ltrim($path, '/');
}

function aus_seo_og_image(): string
{
    return 'https://bilohash.com/ruslan_cub.jpg';
}

function aus_seo_hreflang(string $code): string
{
    $info = aus_langs()[$code] ?? null;
    return $info['locale'] ?? $code;
}

function aus_seo_contact(): array
{
    return [
        'telephone' => '+4746255885',
        'email'     => 'rbilohash@gmail.com',
        'locality'  => 'Drammen',
        'region'    => 'Viken',
        'country'   => 'NO',
        'lat'       => 59.7439,
        'lng'       => 10.2045,
    ];
}

function aus_seo_json(array $graphs): string
{
    $graphs = array_values(array_filter($graphs));
    $data = count($graphs) === 1
        ? array_merge(['@context' => 'https://schema.org'], $graphs[0])
        : ['@context' => 'https://schema.org', '@graph' => $graphs];
    return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function aus_render_seo_head(string $page_title, string $page_desc, string $canonical, array $schema_graphs = []): void
{
    global $lang_meta, $lang;
    $canonical_abs = aus_absolute_url($canonical);
    $keywords = $GLOBALS['t']['meta']['keywords'] ?? '';
    $og_image = aus_seo_og_image();
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="author" content="Ruslan Bilohash / Bilohash">
    <meta name="geo.region" content="NO">
    <meta name="geo.placename" content="Drammen, Norway">
    <meta name="geo.position" content="59.7439;10.2045">
    <meta name="ICBM" content="59.7439, 10.2045">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(aus_full_lang_url('no')) ?>">
    <?php foreach (aus_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= htmlspecialchars(aus_seo_hreflang($code)) ?>" href="<?= htmlspecialchars(aus_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <link rel="alternate" type="text/plain" href="https://bilohash.com/auction/llms.txt" title="LLM context">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars($GLOBALS['t']['meta']['site_name'] ?? 'Auction CMS') ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:secure_url" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="1200">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <?php foreach (aus_langs() as $code => $info):
        if ($code === $lang) continue; ?>
    <meta property="og:locale:alternate" content="<?= htmlspecialchars(str_replace('-', '_', $info['locale'])) ?>">
    <?php endforeach; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@bilohash">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta name="twitter:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <?php if (!empty($schema_graphs)): ?>
    <script type="application/ld+json"><?= aus_seo_json($schema_graphs) ?></script>
    <?php endif;
}

function aus_seo_local_business(): array
{
    $contact = aus_seo_contact();
    return [
        '@type' => 'LocalBusiness',
        '@id'   => 'https://bilohash.com/auction/#localbusiness',
        'name'  => 'Bilohash — Auction CMS',
        'url'   => 'https://bilohash.com/auction/site/',
        'image' => aus_seo_og_image(),
        'telephone' => $contact['telephone'],
        'email' => $contact['email'],
        'address' => [
            '@type' => 'PostalAddress',
            'addressLocality' => $contact['locality'],
            'addressRegion'   => $contact['region'],
            'addressCountry'  => $contact['country'],
        ],
        'geo' => [
            '@type' => 'GeoCoordinates',
            'latitude'  => $contact['lat'],
            'longitude' => $contact['lng'],
        ],
        'areaServed' => [
            ['@type' => 'Country', 'name' => 'Norway'],
            ['@type' => 'Country', 'name' => 'Ukraine'],
            ['@type' => 'Place', 'name' => 'Europe'],
        ],
        'knowsLanguage' => ['nb-NO', 'en-GB', 'uk-UA'],
        'priceRange' => '$$',
    ];
}

function aus_seo_schemas(string $canonical, string $title, string $desc): array
{
    global $lang;
    $contact = aus_seo_contact();
    return [
        [
            '@type' => 'Organization',
            '@id'   => 'https://bilohash.com/auction/#organization',
            'name'  => 'Auction CMS',
            'url'   => 'https://bilohash.com/auction/site/',
            'email' => $contact['email'],
            'telephone' => $contact['telephone'],
            'address' => [
                '@type' => 'PostalAddress',
                'addressLocality' => $contact['locality'],
                'addressRegion'   => $contact['region'],
                'addressCountry'  => $contact['country'],
            ],
        ],
        aus_seo_local_business(),
        [
            '@type'               => 'SoftwareApplication',
            '@id'                 => $canonical . '#software',
            'name'                => 'Auction CMS',
            'applicationCategory' => 'BusinessApplication',
            'operatingSystem'     => 'Web',
            'description'         => $desc,
            'url'                 => $canonical,
            'image'               => aus_seo_og_image(),
            'inLanguage'          => ['nb-NO', 'en-GB', 'uk-UA'],
            'offers'              => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'NOK'],
            'author'              => ['@type' => 'Organization', 'name' => 'Auction CMS', 'url' => 'https://bilohash.com/auction/site/'],
            'downloadUrl'         => aus_demo_absolute(),
        ],
        [
            '@type' => 'ProfessionalService',
            '@id'   => $canonical . '#service',
            'name'  => 'Order auction website development — Norway & Europe',
            'url'   => $canonical,
            'telephone' => $contact['telephone'],
            'email' => $contact['email'],
            'description' => 'Custom PHP online auction platforms for charities, marketplaces, estate sales, art galleries and B2B tenders. Norway and Europe.',
            'areaServed' => [
                ['@type' => 'Country', 'name' => 'Norway'],
                ['@type' => 'Continent', 'name' => 'Europe'],
            ],
            'provider' => ['@id' => 'https://bilohash.com/auction/#organization'],
        ],
        [
            '@type' => 'WebPage',
            '@id'   => $canonical . '#webpage',
            'url'   => $canonical,
            'name'  => $title,
            'description' => $desc,
            'inLanguage' => aus_langs()[$lang]['locale'] ?? 'nb-NO',
            'isPartOf' => ['@type' => 'WebSite', 'name' => 'Auction CMS', 'url' => 'https://bilohash.com/auction/site/'],
        ],
    ];
}