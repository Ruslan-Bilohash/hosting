<?php
/** @var string $admin_page @var array $ta @var string $page_title */
$layout_title = $page_title ?? ($ta['dashboard'] ?? 'Admin');
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= htmlspecialchars($layout_title) ?> — Auction CMS Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(au_asset('css/admin.css')) ?>?v=3">
    <link rel="stylesheet" href="<?= htmlspecialchars(bh_cms_admin_settings_css_href()) ?>">
</head>
<body class="adm-body">
<div class="adm-sidebar-overlay" id="admOverlay" hidden></div>
<div class="adm-layout">
    <aside class="adm-sidebar" id="admSidebar">
        <a href="<?= au_admin_url('index.php') ?>" class="adm-sidebar-brand">
            <div class="icon">A</div>
            <div>
                <span>Auction CMS</span>
                <small><?= htmlspecialchars($ta['title'] ?? 'Admin') ?></small>
            </div>
        </a>
        <nav class="adm-nav">
            <a href="<?= au_admin_url('index.php') ?>" class="<?= $admin_page === 'dashboard' ? 'active' : '' ?>">
                <i class="fas fa-chart-pie"></i> <?= htmlspecialchars($ta['dashboard']) ?>
            </a>
            <a href="<?= au_admin_url('lots.php') ?>" class="<?= $admin_page === 'lots' ? 'active' : '' ?>">
                <i class="fas fa-gavel"></i> <?= htmlspecialchars($ta['lots']) ?>
            </a>
            <a href="<?= au_admin_url('bids.php') ?>" class="<?= $admin_page === 'bids' ? 'active' : '' ?>">
                <i class="fas fa-hand-holding-dollar"></i> <?= htmlspecialchars($ta['bids']) ?>
            </a>
            <a href="<?= au_admin_url('categories.php') ?>" class="<?= $admin_page === 'categories' ? 'active' : '' ?>">
                <i class="fas fa-layer-group"></i> <?= htmlspecialchars($ta['categories'] ?? 'Categories') ?>
            </a>
            <a href="<?= au_admin_url('settings.php') ?>" class="<?= ($admin_page ?? '') === 'auction_settings' ? 'active' : '' ?>">
                <i class="fas fa-sliders-h"></i> <?= htmlspecialchars($ta['auction_settings'] ?? ($ta['settings'] ?? 'Auction')) ?>
            </a>
            <a href="<?= au_admin_url('settings-appearance.php') ?>" class="<?= ($admin_page ?? '') === 'settings' ? 'active' : '' ?>">
                <i class="fas fa-palette"></i> <?= htmlspecialchars($ta['site_settings'] ?? 'Site & chat') ?>
            </a>
            <a href="<?= au_admin_url('export.php') ?>" class="<?= $admin_page === 'export' ? 'active' : '' ?>">
                <i class="fas fa-file-export"></i> <?= htmlspecialchars($ta['export'] ?? 'Export') ?>
            </a>
            <a href="<?= au_url('index.php') ?>" target="_blank">
                <i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['view_site']) ?>
            </a>
        </nav>
        <div class="adm-sidebar-foot">
            <div class="adm-lang-mini">
                <?php foreach (au_langs() as $code => $info): ?>
                <a href="<?= htmlspecialchars(au_admin_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['label'] ?></a>
                <?php endforeach; ?>
            </div>
            <a href="<?= au_admin_url('logout.php') ?>" style="color:rgba(255,255,255,.7);font-size:12px;text-decoration:none">
                <i class="fas fa-sign-out-alt"></i> <?= htmlspecialchars($ta['logout']) ?>
            </a>
        </div>
    </aside>

    <div class="adm-main">
        <header class="adm-topbar">
            <div style="display:flex;align-items:center;gap:12px">
                <button type="button" class="adm-menu-toggle" id="admMenuBtn" aria-label="Menu"><i class="fas fa-bars"></i></button>
                <h1><?= htmlspecialchars($layout_title) ?></h1>
            </div>
            <div class="adm-topbar-actions">
                <span class="adm-topbar-welcome" style="font-size:13px;color:var(--adm-muted)"><?= htmlspecialchars($ta['welcome']) ?>, <strong>demo</strong></span>
                <a href="<?= au_url('index.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                    <i class="fas fa-globe"></i> <span><?= htmlspecialchars($ta['view_site']) ?></span>
                </a>
            </div>
        </header>
        <main class="adm-content">