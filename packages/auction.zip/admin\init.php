<?php
require_once dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/admin-auth.php';
require_once dirname(__DIR__) . '/includes/storage.php';
require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';

$ta = $t['admin'] ?? [];
$admin_page = $admin_page ?? 'dashboard';

function au_admin_lang_url(string $code): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: au_admin_url('index.php');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);
    $q['lang'] = $code;
    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}