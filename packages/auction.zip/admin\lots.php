<?php
require_once __DIR__ . '/init.php';
au_admin_require();
$admin_page = 'lots';
$page_title = $ta['lots'];

$filter = $_GET['filter'] ?? 'all';
$lots   = au_lots_all();

if ($filter === 'live') {
    $lots = array_values(array_filter($lots, fn($l) => ($l['active'] ?? true) !== false && au_lot_is_live($l)));
} elseif ($filter === 'featured') {
    $lots = array_values(array_filter($lots, fn($l) => !empty($l['featured'])));
}

$base = au_admin_url('lots.php');

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['lots']) ?> (<?= count($lots) ?>)</h2>
        <a href="<?= au_url('search.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
            <i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['preview'] ?? 'Preview') ?>
        </a>
    </div>
    <div class="adm-filter-bar">
        <a href="<?= htmlspecialchars($base) ?>" class="<?= $filter === 'all' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_all'] ?? 'All') ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=live') ?>" class="<?= $filter === 'live' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_live'] ?? 'Live only') ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=featured') ?>" class="<?= $filter === 'featured' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_featured'] ?? 'Featured') ?></a>
    </div>
    <div class="adm-card-body">
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th></th>
                    <th><?= htmlspecialchars($ta['name_en']) ?></th>
                    <th><?= htmlspecialchars($ta['category']) ?></th>
                    <th><?= htmlspecialchars($ta['current_bid']) ?></th>
                    <th><?= htmlspecialchars($ta['bids_count']) ?></th>
                    <th><?= htmlspecialchars($ta['ends'] ?? 'Ends') ?></th>
                    <th><?= htmlspecialchars($ta['status']) ?></th>
                    <th><?= htmlspecialchars($ta['actions']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lots as $l): ?>
                <tr>
                    <td data-label=""><img src="<?= htmlspecialchars(au_lot_image($l)) ?>" alt="" class="adm-thumb" loading="lazy" onerror="this.onerror=null;this.src='<?= htmlspecialchars(au_placeholder_image()) ?>';"></td>
                    <td data-label="<?= htmlspecialchars($ta['name_en']) ?>">
                        <strong><?= htmlspecialchars($l['name']['en'] ?? $l['id']) ?></strong><br>
                        <small style="color:var(--adm-muted)"><?= htmlspecialchars($l['city']['en'] ?? '') ?>, <?= htmlspecialchars($l['country']['en'] ?? '') ?></small>
                        <?php if (!empty($l['featured'])): ?>
                        <span class="adm-badge adm-badge-pending" style="margin-top:4px"><i class="fas fa-star"></i></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['category']) ?>"><?= htmlspecialchars($t['categories'][$l['category'] ?? ''] ?? $l['category']) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['current_bid']) ?>"><strong><?= au_price((int)($l['current_bid'] ?? 0)) ?></strong></td>
                    <td data-label="<?= htmlspecialchars($ta['bids_count']) ?>"><?= (int)($l['bids_count'] ?? 0) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['ends'] ?? 'Ends') ?>"><?= date('d.m.Y H:i', au_lot_ends_at($l)) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['status']) ?>">
                        <?php if (($l['active'] ?? true) !== false): ?>
                        <span class="adm-badge adm-badge-active"><?= htmlspecialchars($ta['active']) ?></span>
                        <?php else: ?>
                        <span class="adm-badge adm-badge-hidden"><?= htmlspecialchars($ta['inactive']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?= htmlspecialchars($ta['actions']) ?>">
                        <a href="<?= au_admin_url('lot.php?id=' . urlencode($l['id'])) ?>" class="adm-btn adm-btn-outline adm-btn-sm">
                            <i class="fas fa-pen"></i> <?= htmlspecialchars($ta['edit']) ?>
                        </a>
                        <a href="<?= au_url('lot.php?id=' . urlencode($l['id'])) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>