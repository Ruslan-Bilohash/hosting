<?php

function au_data_path(string $file): string
{
    return __DIR__ . '/../data/' . $file;
}

function au_lots_file(): string
{
    return au_data_path('lots.json');
}

function au_bids_file(): string
{
    return au_data_path('bids.json');
}

function au_settings_file(): string
{
    return au_data_path('settings.json');
}

function au_default_settings(): array
{
    require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
    return array_merge([
        'currency'         => 'NOK',
        'default_increment'=> 100,
        'anti_sniping_mins' => 5,
        'buyer_premium_pct' => 15,
        'notify_outbid'    => true,
        'notify_ending'    => true,
        'site_tagline'     => 'Auction CMS Demo',
    ], bh_cms_site_settings_defaults(bh_cms_product_accent('auction')));
}

function au_load_settings(): array
{
    $file = au_settings_file();
    if (!is_file($file)) {
        $defaults = au_default_settings();
        au_save_settings($defaults);
        return $defaults;
    }
    $data = json_decode(file_get_contents($file) ?: '{}', true);
    return is_array($data) ? array_merge(au_default_settings(), $data) : au_default_settings();
}

function au_save_settings(array $settings): bool
{
    $json = json_encode(array_merge(au_default_settings(), $settings), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(au_settings_file(), $json, LOCK_EX) !== false;
}

function au_default_lots_from_seed(): ?array
{
    $seedFile = __DIR__ . '/../data/lots.php';
    if (!is_readable($seedFile)) {
        return null;
    }
    $defaults = require $seedFile;
    if (!is_array($defaults)) {
        return null;
    }
    foreach ($defaults as &$lot) {
        $lot['active'] = $lot['active'] ?? true;
    }
    unset($lot);
    return $defaults;
}

function au_fallback_lots(): array
{
    return [
        [
            'id' => 'demo-charity-art',
            'category' => 'art',
            'status' => 'live',
            'featured' => true,
            'active' => true,
            'ends_at' => '2026-07-15T18:00:00+02:00',
            'start_price' => 500,
            'current_bid' => 4200,
            'bid_increment' => 100,
            'bids_count' => 12,
            'reserve_met' => true,
            'city' => ['en' => 'Oslo', 'no' => 'Oslo', 'uk' => 'Осло', 'ru' => 'Осло'],
            'country' => ['en' => 'Norway', 'no' => 'Norge', 'uk' => 'Норвегія', 'ru' => 'Норвегия'],
            'name' => [
                'en' => 'Charity art bundle — NGO demo lot',
                'no' => 'Veldedighets kunstpakke — NGO-demo',
                'uk' => 'Благодійний арт-набір — NGO демо',
                'ru' => 'Благотворительный арт-набор — NGO демо',
            ],
            'desc' => [
                'en' => 'Demo lot for charity auction workflows on Auction CMS.',
                'no' => 'Demolot for veldedighetsauksjoner i Auction CMS.',
                'uk' => 'Демо-лот для благодійних аукціонів у Auction CMS.',
                'ru' => 'Демо-лот для благотворительных аукционов в Auction CMS.',
            ],
            'image' => 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800&q=80',
        ],
    ];
}

function au_ensure_lots_json(): void
{
    $json = au_lots_file();

    if (!is_file($json)) {
        $defaults = au_default_lots_from_seed();
        if ($defaults !== null) {
            au_save_lots($defaults);
        }
        return;
    }

    $defaults = au_default_lots_from_seed();
    if ($defaults === null) {
        return;
    }

    $existing = json_decode(file_get_contents($json) ?: '[]', true);
    if (!is_array($existing)) {
        au_save_lots($defaults);
        return;
    }

    $ids = array_column($existing, 'id');
    $merged = $existing;
    $changed = false;
    foreach ($defaults as $lot) {
        if (!in_array($lot['id'] ?? '', $ids, true)) {
            $merged[] = $lot;
            $changed = true;
        }
    }
    if ($changed) {
        au_save_lots($merged);
    }
}

function au_load_lots_raw(): array
{
    $file = au_lots_file();
    if (is_readable($file)) {
        $data = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($data) && $data !== []) {
            return $data;
        }
    }

    au_ensure_lots_json();
    if (is_readable($file)) {
        $data = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($data) && $data !== []) {
            return $data;
        }
    }

    $seed = au_default_lots_from_seed();
    if ($seed !== null) {
        return $seed;
    }

    return au_fallback_lots();
}

function au_save_lots(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(au_lots_file(), $json, LOCK_EX) !== false;
}

function au_load_bids(): array
{
    $file = au_bids_file();
    if (!is_file($file)) {
        au_seed_demo_bids();
    }
    $raw = file_get_contents($file);
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

function au_save_bids(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(au_bids_file(), $json, LOCK_EX) !== false;
}

function au_add_bid(array $bid): string
{
    $list = au_load_bids();
    $bid['id']         = $bid['id'] ?? ('au-' . bin2hex(random_bytes(4)));
    $bid['created_at'] = $bid['created_at'] ?? date('c');
    $bid['status']     = $bid['status'] ?? 'active';
    array_unshift($list, $bid);

    $lots = au_load_lots_raw();
    foreach ($lots as &$l) {
        if (($l['id'] ?? '') === ($bid['lot_id'] ?? '')) {
            $l['current_bid'] = max((int)($l['current_bid'] ?? 0), (int)($bid['amount'] ?? 0));
            $l['bids_count']  = (int)($l['bids_count'] ?? 0) + 1;
            break;
        }
    }
    unset($l);
    au_save_lots($lots);
    au_save_bids($list);
    return $bid['ref'] ?? $bid['id'];
}

function au_seed_demo_bids(): void
{
    $lots = au_load_lots_raw();
    $samples = [];
    if (count($lots) >= 2) {
        $samples = [
            [
                'id' => 'demo-001', 'ref' => 'AU-DEMO-7F3A9B2C', 'status' => 'active',
                'lot_id' => $lots[0]['id'], 'lot_name' => $lots[0]['name']['en'] ?? 'Lot',
                'bidder' => 'Anna Hansen', 'email' => 'anna@demo.no', 'phone' => '+4798765432',
                'amount' => (int)($lots[0]['current_bid'] ?? 5000), 'created_at' => date('c', strtotime('-2 hours')),
            ],
            [
                'id' => 'demo-002', 'ref' => 'AU-DEMO-4E8D1A0F', 'status' => 'outbid',
                'lot_id' => $lots[1]['id'], 'lot_name' => $lots[1]['name']['en'] ?? 'Lot',
                'bidder' => 'Ole Nordmann', 'email' => 'ole@demo.no', 'phone' => '+4744455566',
                'amount' => (int)($lots[1]['current_bid'] ?? 3000) - 500, 'created_at' => date('c', strtotime('-5 hours')),
            ],
            [
                'id' => 'demo-003', 'ref' => 'AU-DEMO-9C2B5E7D', 'status' => 'won',
                'lot_id' => $lots[2]['id'] ?? $lots[0]['id'], 'lot_name' => $lots[2]['name']['en'] ?? 'Lot',
                'bidder' => 'Maria Kowalska', 'email' => 'maria@demo.pl', 'phone' => '+48123456789',
                'amount' => (int)($lots[2]['current_bid'] ?? 8000), 'created_at' => date('c', strtotime('-1 day')),
            ],
        ];
    }
    au_save_bids($samples);
}