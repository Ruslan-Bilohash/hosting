<?php
require_once dirname(__DIR__, 2) . '/includes/cms-contact.php';
/** @var string $slug @var array $vertical @var array $v @var string $canonical */
$current_page = 'vertical';
$vertical_seo_mode = true;
$vertical_keywords = $v['keywords'] ?? null;
$body_class = 'au-vertical-page';
$hub_label = au_vertical_hub_label($lang);
$demo_btn = ['no' => 'Live demo', 'en' => 'Live demo', 'uk' => 'Live demo', 'ru' => 'Live demo'][$lang] ?? 'Live demo';
$product_btn = ['no' => 'Produktside', 'en' => 'Product page', 'uk' => 'Сторінка продукту', 'ru' => 'Страница продукта'][$lang] ?? 'Product page';
$benefits_title = ['no' => 'Fordeler', 'en' => 'Benefits', 'uk' => 'Переваги', 'ru' => 'Преимущества'][$lang] ?? 'Benefits';
$features_title = ['no' => 'Funksjoner i Auction CMS', 'en' => 'Auction CMS features', 'uk' => 'Можливості Auction CMS', 'ru' => 'Возможности Auction CMS'][$lang] ?? 'Auction CMS features';
$faq_title = ['no' => 'Ofte stilte spørsmål', 'en' => 'FAQ', 'uk' => 'Часті питання', 'ru' => 'Частые вопросы'][$lang] ?? 'FAQ';
$related_title = ['no' => 'Andre auksjonstyper', 'en' => 'More auction types', 'uk' => 'Інші типи аукціонів', 'ru' => 'Другие типы аукционов'][$lang] ?? 'More auction types';
$region_note = ['no' => 'Norge · Europa · Ukraina', 'en' => 'Norway · Europe · Ukraine', 'uk' => 'Норвегія · Європа · Україна', 'ru' => 'Норвегия · Европа · Украина'][$lang] ?? 'Norway · Europe · Ukraine';
$all = au_verticals_all();
$cat = trim($vertical['demo_category'] ?? '');
$demo_url = au_url('search.php' . ($cat ? '?category=' . urlencode($cat) : ''));
require __DIR__ . '/header.php';
?>

<main class="au-container au-vertical-main">
    <nav class="au-breadcrumb au-vertical-crumb">
        <a href="<?= au_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
        → <a href="<?= au_url('solutions.php') ?>"><?= htmlspecialchars($hub_label) ?></a>
        → <?= htmlspecialchars($v['h1']) ?>
    </nav>

    <section class="au-vertical-hero">
        <div class="au-vertical-hero-icon"><i class="fas fa-<?= htmlspecialchars($vertical['icon'] ?? 'gavel') ?>"></i></div>
        <h1><?= htmlspecialchars($v['h1']) ?></h1>
        <p class="au-vertical-subtitle"><?= htmlspecialchars($v['subtitle']) ?></p>
        <p class="au-detail-desc au-vertical-intro"><?= htmlspecialchars($v['intro']) ?></p>
        <p class="au-vertical-region"><i class="fas fa-globe-europe" aria-hidden="true"></i> <?= htmlspecialchars($region_note) ?></p>
        <div class="au-vertical-cta-row">
            <a href="<?= htmlspecialchars($demo_url) ?>" class="au-btn-gold"><i class="fas fa-play-circle"></i> <?= htmlspecialchars($demo_btn) ?></a>
            <a href="https://bilohash.com/auction/site/" class="au-btn-outline-dark"><i class="fas fa-book"></i> <?= htmlspecialchars($product_btn) ?></a>
            <a href="<?= au_url('contact.php') ?>" class="au-btn-outline-dark"><i class="fas fa-comments"></i> <?= htmlspecialchars(cms_contact_texts('auction', $lang)['nav_discuss']) ?></a>
        </div>
    </section>

    <section class="au-vertical-section">
        <h2 class="au-section-title"><?= htmlspecialchars($benefits_title) ?></h2>
        <div class="au-vertical-benefits">
            <?php foreach ($v['benefits'] ?? [] as $b): ?>
            <article class="au-step-card">
                <h3><?= htmlspecialchars($b['title']) ?></h3>
                <p><?= htmlspecialchars($b['text']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="au-vertical-section">
        <h2 class="au-section-title"><?= htmlspecialchars($features_title) ?></h2>
        <ul class="au-highlight-list">
            <?php foreach ($v['features'] ?? [] as $f): ?>
            <li><i class="fas fa-check"></i> <?= htmlspecialchars($f) ?></li>
            <?php endforeach; ?>
        </ul>
    </section>

    <?php if (!empty($v['faq'])): ?>
    <section class="au-vertical-section au-faq-section">
        <h2 class="au-section-title"><?= htmlspecialchars($faq_title) ?></h2>
        <div class="au-faq-list">
            <?php foreach ($v['faq'] as $i => $item): ?>
            <details class="au-faq-item"<?= $i === 0 ? ' open' : '' ?>>
                <summary><?= htmlspecialchars($item['q']) ?></summary>
                <p><?= htmlspecialchars($item['a']) ?></p>
            </details>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <section class="au-vertical-section au-related">
        <h2 class="au-section-title"><?= htmlspecialchars($related_title) ?></h2>
        <div class="au-vertical-links">
            <?php
            $vdefs = au_vertical_defs();
            foreach ($all as $s => $item):
                if ($s === $slug) continue;
                $short = $vdefs[$s][$lang] ?? $vdefs[$s]['en'] ?? $s;
            ?>
            <a href="<?= htmlspecialchars(au_vertical_url($s)) ?>" class="au-vertical-link-card">
                <i class="fas fa-<?= htmlspecialchars($item['icon'] ?? 'tag') ?>"></i>
                <strong><?= htmlspecialchars($short) ?></strong>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="au-vertical-cta-band">
        <h2 class="au-section-title"><?= htmlspecialchars($v['cta'] ?? '') ?></h2>
        <a href="<?= au_url('contact.php') ?>" class="au-btn-gold au-btn-block"><?= htmlspecialchars(cms_contact_texts('auction', $lang)['nav_discuss']) ?></a>
    </section>
</main>

<?php require __DIR__ . '/footer.php'; ?>