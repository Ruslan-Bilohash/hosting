<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';
require_once __DIR__ . '/includes/site-integrations.php';
au_boot_public_integrations();

$current_page = 'contact';
$product = 'auction';
$cms_t = cms_contact_texts($product, $lang);
$cms_alert = '';
$cms_alert_type = '';
$cms_values = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = cms_contact_handle_post($product, $lang, 'https://bilohash.com/auction/contact.php');
    $cms_alert = $result['alert'];
    $cms_alert_type = $result['alert_type'];
    $cms_values = $result['values'];
}

$cms_csrf = cms_contact_ensure_csrf();
$page_title = $cms_t['page_title'];
$page_desc  = $cms_t['meta_description'];
$canonical  = $site_url . '/contact.php' . ($lang !== 'no' ? '?lang=' . $lang : '');
$canon_abs  = au_absolute_url($canonical);
$seo_schemas = [
    au_seo_organization(),
    au_seo_webpage($canon_abs, $page_title, $page_desc),
    au_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => au_absolute_url(au_url('index.php'))],
        ['name' => $cms_t['h1'], 'url' => $canon_abs],
    ]),
];

$cms_prefix = 'au';
$body_class = 'au-page-contact';
$cms_action = au_url('contact.php') . ($lang !== 'no' ? '?lang=' . urlencode($lang) : '');

require __DIR__ . '/includes/header.php';
require dirname(__DIR__) . '/includes/cms-contact-form.php';
require __DIR__ . '/includes/footer.php';