<?php
if (empty($t['ecosystem']['items'])) {
    return;
}
$eco = $t['ecosystem'];
?>
<section class="au-ecosystem-section" id="ecosystem">
    <div class="au-container">
        <div class="au-section-head au-section-head-center">
            <div>
                <h2 class="au-section-title"><?= htmlspecialchars($eco['title']) ?></h2>
                <p class="au-section-sub"><?= htmlspecialchars($eco['subtitle']) ?></p>
            </div>
        </div>
        <div class="au-ecosystem-grid">
            <?php foreach ($eco['items'] as $item): ?>
            <article class="au-ecosystem-card">
                <div class="au-ecosystem-icon">
                    <?php if (($item['icon'] ?? '') === 'wordpress'): ?>
                    <i class="fab fa-wordpress" aria-hidden="true"></i>
                    <?php else: ?>
                    <i class="fas fa-<?= htmlspecialchars($item['icon']) ?>" aria-hidden="true"></i>
                    <?php endif; ?>
                </div>
                <h3><?= htmlspecialchars($item['name']) ?></h3>
                <p><?= htmlspecialchars($item['desc']) ?></p>
                <div class="au-ecosystem-links">
                    <a href="<?= htmlspecialchars($item['url']) ?>" class="au-btn-outline-dark au-btn-sm" rel="related"><?= htmlspecialchars($eco['product_btn']) ?></a>
                    <a href="<?= htmlspecialchars($item['demo']) ?>" class="au-btn-outline au-btn-sm" rel="related"><?= htmlspecialchars($eco['demo_btn']) ?></a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>