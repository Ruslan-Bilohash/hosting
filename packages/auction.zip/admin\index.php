<?php
require_once __DIR__ . '/init.php';
au_admin_require();
$admin_page = 'dashboard';
$page_title = $ta['dashboard'];

$lots    = au_lots_all();
$bids    = au_load_bids();
$stats   = au_platform_stats();
$chart   = au_admin_category_chart();
$active  = count(array_filter($lots, fn($l) => ($l['active'] ?? true) !== false));
$ending  = array_values(array_filter($lots, function ($l) {
    if (($l['active'] ?? true) === false || !au_lot_is_live($l)) return false;
    $left = au_lot_ends_at($l) - time();
    return $left > 0 && $left <= 48 * 3600;
}));
usort($ending, fn($a, $b) => au_lot_ends_at($a) <=> au_lot_ends_at($b));
$ending = array_slice($ending, 0, 6);
$recent  = array_slice($bids, 0, 8);

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-alert adm-alert-info">
    <i class="fas fa-flask"></i> <?= htmlspecialchars($ta['add_note']) ?>
</div>

<div class="adm-stats">
    <div class="adm-stat">
        <div class="adm-stat-icon gold"><i class="fas fa-gavel"></i></div>
        <div>
            <div class="adm-stat-val"><?= $active ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_lots']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon green"><i class="fas fa-hand-holding-dollar"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($bids) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_bids']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon blue"><i class="fas fa-coins"></i></div>
        <div>
            <div class="adm-stat-val"><?= au_price((int)$stats['volume']) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_vol']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon orange"><i class="fas fa-bolt"></i></div>
        <div>
            <div class="adm-stat-val"><?= (int)$stats['live'] ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_live']) ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon gold"><i class="fas fa-star"></i></div>
        <div>
            <div class="adm-stat-val"><?= (int)$stats['featured'] ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['featured_count'] ?? 'Featured') ?></div>
        </div>
    </div>
</div>

<div class="adm-dash-grid">
    <div class="adm-card">
        <div class="adm-card-head">
            <h2><?= htmlspecialchars($ta['by_category'] ?? 'By category') ?></h2>
            <a href="<?= au_admin_url('categories.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm">→</a>
        </div>
        <div class="adm-card-body padded">
            <div class="adm-bar-chart">
                <?php foreach (array_slice($chart, 0, 6) as $row): ?>
                <div class="adm-bar-row">
                    <span class="adm-bar-label"><?= htmlspecialchars($t['categories'][$row['cat']] ?? $row['cat']) ?></span>
                    <div class="adm-bar-track"><div class="adm-bar-fill" style="width:<?= (int)$row['pct'] ?>%"></div></div>
                    <span class="adm-bar-val"><?= (int)$row['count'] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="adm-card">
        <div class="adm-card-head">
            <h2><?= htmlspecialchars($ta['ending_soon'] ?? 'Ending soon') ?></h2>
            <a href="<?= au_url('search.php?status=ending') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank"><?= htmlspecialchars($ta['view_site']) ?></a>
        </div>
        <div class="adm-card-body padded adm-ending-list">
            <?php if (empty($ending)): ?>
            <p style="color:var(--adm-muted);margin:0"><?= htmlspecialchars($ta['no_lots_cat'] ?? 'No lots ending soon.') ?></p>
            <?php else: foreach ($ending as $el): ?>
            <a href="<?= au_admin_url('lot.php?id=' . urlencode($el['id'])) ?>" class="adm-ending-item">
                <img src="<?= htmlspecialchars(au_lot_image($el)) ?>" alt="" loading="lazy" onerror="this.onerror=null;this.src='<?= htmlspecialchars(au_placeholder_image()) ?>';">
                <div>
                    <strong><?= htmlspecialchars($el['name']['en'] ?? $el['id']) ?></strong>
                    <span><?= au_price((int)($el['current_bid'] ?? 0)) ?> · <?= date('d.m H:i', au_lot_ends_at($el)) ?></span>
                </div>
            </a>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['recent_bids']) ?></h2>
        <a href="<?= au_admin_url('bids.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['all_bids']) ?> →</a>
    </div>
    <div class="adm-card-body">
        <?php if (empty($recent)): ?>
        <p style="padding:24px;text-align:center;color:var(--adm-muted)"><?= htmlspecialchars($ta['no_bids']) ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th><?= htmlspecialchars($ta['ref']) ?></th>
                    <th><?= htmlspecialchars($ta['bidder']) ?></th>
                    <th><?= htmlspecialchars($ta['lot']) ?></th>
                    <th><?= htmlspecialchars($ta['amount']) ?></th>
                    <th><?= htmlspecialchars($ta['status']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $b): ?>
                <tr>
                    <td data-label="<?= htmlspecialchars($ta['ref']) ?>"><code style="font-size:11px"><?= htmlspecialchars($b['ref'] ?? '') ?></code></td>
                    <td data-label="<?= htmlspecialchars($ta['bidder']) ?>"><?= htmlspecialchars($b['bidder'] ?? '') ?></td>
                    <td data-label="<?= htmlspecialchars($ta['lot']) ?>"><?= htmlspecialchars($b['lot_name'] ?? '') ?></td>
                    <td data-label="<?= htmlspecialchars($ta['amount']) ?>"><strong><?= au_price((int)($b['amount'] ?? 0)) ?></strong></td>
                    <td data-label="<?= htmlspecialchars($ta['status']) ?>"><span class="adm-badge adm-badge-<?= htmlspecialchars($b['status'] ?? 'active') ?>"><?= htmlspecialchars($ta['status_' . ($b['status'] ?? 'active')] ?? $b['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['quick_actions']) ?></h2></div>
    <div class="adm-card-body padded adm-quick-actions">
        <a href="<?= au_admin_url('lots.php') ?>" class="adm-btn adm-btn-primary"><i class="fas fa-gavel"></i> <?= htmlspecialchars($ta['lots']) ?></a>
        <a href="<?= au_admin_url('bids.php') ?>" class="adm-btn adm-btn-outline"><i class="fas fa-list"></i> <?= htmlspecialchars($ta['bids']) ?></a>
        <a href="<?= au_admin_url('settings.php') ?>" class="adm-btn adm-btn-outline"><i class="fas fa-cog"></i> <?= htmlspecialchars($ta['settings'] ?? 'Settings') ?></a>
        <a href="<?= au_admin_url('export.php?download=csv') ?>" class="adm-btn adm-btn-outline"><i class="fas fa-download"></i> CSV</a>
        <a href="<?= au_url('index.php') ?>" class="adm-btn adm-btn-outline" target="_blank"><i class="fas fa-globe"></i> <?= htmlspecialchars($ta['view_site']) ?></a>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>