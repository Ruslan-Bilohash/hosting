<?php
/**
 * Bilohash Auction — universal demo platform
 * /auction
 */
define('AU_BASE_PATH', '/auction');
define('AU_DOMAIN', 'bilohash.com');
define('AU_SITE_NAME', 'Auction CMS');
define('AU_CURRENCY', 'NOK');
define('AU_DEMO_MODE', true);

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, AU_DOMAIN) !== false) ? AU_BASE_PATH : ($detected ?: AU_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function au_url(string $path = ''): string
{
    global $base_path;
    return rtrim($base_path, '/') . '/' . ltrim($path, '/');
}

function au_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function au_price(int $amount): string
{
    return number_format($amount, 0, ',', ' ') . ' kr';
}