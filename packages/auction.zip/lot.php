<?php
require_once __DIR__ . '/init.php';
$id = $_GET['id'] ?? '';
$lot = au_lot_by_id($id);
if (!$lot) {
    header('Location: ' . au_url('search.php'), true, 302);
    exit;
}
$name       = au_localized($lot, 'name', $lang);
$city       = au_localized($lot, 'city', $lang);
$country    = au_localized($lot, 'country', $lang);
$desc       = au_localized($lot, 'desc', $lang);
$long_desc  = au_lot_long_desc($lot, $lang);
$condition  = au_lot_condition($lot, $lang);
$seller     = au_lot_seller($lot, $lang);
$highlights = au_lot_highlights($lot, $lang);
$estimate   = au_lot_estimate($lot);
$is_live    = au_lot_is_live($lot);
$ends_ts    = au_lot_ends_at($lot);
$min_bid    = au_min_bid($lot);
$history    = au_demo_bid_history($lot);
$related    = au_related_lots($lot, 4);
$bid_url    = au_url('bid.php?id=' . urlencode($lot['id']));
$page_title = $name . ' — ' . $t['meta']['site_name'];
$page_desc  = mb_substr(strip_tags($long_desc), 0, 160);
$canonical  = $site_url . '/lot.php?id=' . urlencode($lot['id']);
$canon_abs  = au_absolute_url($canonical);
$seo_og_image = au_lot_image($lot);
$seo_og_type  = 'product';
$seo_schemas = [
    au_seo_webpage($canon_abs, $page_title, $page_desc),
    au_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => au_absolute_url(au_url('index.php'))],
        ['name' => $t['categories'][$lot['category'] ?? ''] ?? 'Lots', 'url' => au_absolute_url(au_url('search.php?category=' . urlencode($lot['category'] ?? '')))],
        ['name' => $name, 'url' => $canon_abs],
    ]),
    au_seo_lot($lot, $lang, $canon_abs),
];
require __DIR__ . '/includes/header.php';
?>

<div class="au-container">
    <nav class="au-breadcrumb">
        <a href="<?= au_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
        → <a href="<?= au_url('search.php?category=' . urlencode($lot['category'] ?? '')) ?>"><?= htmlspecialchars($t['categories'][$lot['category'] ?? ''] ?? '') ?></a>
        → <?= htmlspecialchars($name) ?>
    </nav>

    <div class="au-detail-layout">
        <div class="au-detail">
            <div class="au-gallery">
                <img src="<?= htmlspecialchars(au_lot_image($lot)) ?>" alt="<?= htmlspecialchars($name) ?>" onerror="this.onerror=null;this.src='<?= htmlspecialchars(au_placeholder_image()) ?>';">
            </div>
            <div class="au-detail-head">
                <span class="au-cat-tag"><?= htmlspecialchars($t['categories'][$lot['category'] ?? ''] ?? '') ?></span>
                <span class="au-lot-id"><?= htmlspecialchars($t['lot']['lot_no']) ?>: <?= htmlspecialchars($lot['id']) ?></span>
                <?php if (!empty($lot['featured'])): ?>
                <span class="au-cat-tag au-cat-tag-gold"><i class="fas fa-star"></i> Featured</span>
                <?php endif; ?>
            </div>
            <h1><?= htmlspecialchars($name) ?></h1>
            <div class="au-location au-location-lg">
                <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($city) ?>, <?= htmlspecialchars($country) ?>
            </div>

            <div class="au-estimate-bar">
                <span><?= htmlspecialchars($t['lot']['estimate']) ?>:</span>
                <strong><?= au_price($estimate['low']) ?> – <?= au_price($estimate['high']) ?></strong>
            </div>

            <div class="au-tabs" role="tablist">
                <button type="button" class="au-tab active" data-tab="overview"><?= htmlspecialchars($t['lot']['tab_overview']) ?></button>
                <button type="button" class="au-tab" data-tab="specs"><?= htmlspecialchars($t['lot']['tab_specs']) ?></button>
                <button type="button" class="au-tab" data-tab="history"><?= htmlspecialchars($t['lot']['tab_history']) ?></button>
            </div>

            <div class="au-tab-panel active" id="tab-overview">
                <p class="au-detail-desc"><?= htmlspecialchars($desc) ?></p>
                <?php if ($long_desc !== $desc): ?>
                <p class="au-detail-desc au-detail-long"><?= htmlspecialchars($long_desc) ?></p>
                <?php endif; ?>
                <?php if (!empty($highlights)): ?>
                <h3 class="au-subhead"><?= htmlspecialchars($t['lot']['highlights']) ?></h3>
                <ul class="au-highlight-list">
                    <?php foreach ($highlights as $h): ?>
                    <li><i class="fas fa-check"></i> <?= htmlspecialchars($h) ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>

            <div class="au-tab-panel" id="tab-specs" hidden>
                <dl class="au-spec-grid">
                    <div><dt><?= htmlspecialchars($t['lot']['condition']) ?></dt><dd><?= $condition !== '' ? htmlspecialchars($condition) : '—' ?></dd></div>
                    <div><dt><?= htmlspecialchars($t['lot']['seller']) ?></dt><dd><?= htmlspecialchars($seller) ?></dd></div>
                    <div><dt><?= htmlspecialchars($t['lot']['category']) ?></dt><dd><?= htmlspecialchars($t['categories'][$lot['category'] ?? ''] ?? '') ?></dd></div>
                    <div><dt><?= htmlspecialchars($t['lot']['increment']) ?></dt><dd><?= au_price((int)($lot['bid_increment'] ?? 100)) ?></dd></div>
                    <div><dt><?= htmlspecialchars($t['lot']['shipping']) ?></dt><dd><?= htmlspecialchars($t['lot']['shipping_note']) ?></dd></div>
                    <div><dt><?= htmlspecialchars($t['lot']['ends']) ?></dt><dd><?= date('d.m.Y H:i', $ends_ts) ?></dd></div>
                </dl>
            </div>

            <div class="au-tab-panel" id="tab-history" hidden>
                <p class="au-demo-hint"><?= htmlspecialchars($t['lot']['demo_history']) ?></p>
                <div class="au-bid-history">
                    <table>
                        <thead>
                            <tr>
                                <th><?= htmlspecialchars($t['lot']['bidder']) ?></th>
                                <th><?= htmlspecialchars($t['lot']['amount']) ?></th>
                                <th><?= htmlspecialchars($t['lot']['time']) ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $h): ?>
                            <tr>
                                <td><?= htmlspecialchars($h['bidder']) ?></td>
                                <td><strong><?= au_price((int)$h['amount']) ?></strong></td>
                                <td><?= date('d.m.Y H:i', strtotime($h['time'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <aside class="au-bid-box">
            <?php if ($is_live): ?>
            <div class="au-countdown-lg" data-countdown="<?= (int)$ends_ts ?>">
                <span class="au-countdown-label"><?= htmlspecialchars($t['card']['ends_in']) ?></span>
                <div class="au-countdown-blocks">
                    <span><b class="cd-d">--</b><small><?= htmlspecialchars($t['countdown']['days']) ?></small></span>
                    <span><b class="cd-h">--</b><small><?= htmlspecialchars($t['countdown']['hours']) ?></small></span>
                    <span><b class="cd-m">--</b><small><?= htmlspecialchars($t['countdown']['minutes']) ?></small></span>
                    <span><b class="cd-s">--</b><small><?= htmlspecialchars($t['countdown']['seconds']) ?></small></span>
                </div>
            </div>
            <?php else: ?>
            <div class="au-ended-banner"><?= htmlspecialchars($t['card']['ended']) ?></div>
            <?php endif; ?>

            <div class="au-bid-current">
                <div class="au-bid-label"><?= htmlspecialchars($t['lot']['current_bid']) ?></div>
                <div class="au-bid-price-lg"><?= au_price((int)($lot['current_bid'] ?? 0)) ?></div>
                <div class="au-bid-note"><?= sprintf($t['lot']['bids_count'], (int)($lot['bids_count'] ?? 0)) ?></div>
            </div>

            <dl class="au-bid-details">
                <div><dt><?= htmlspecialchars($t['lot']['min_bid']) ?></dt><dd><?= au_price($min_bid) ?></dd></div>
                <div><dt><?= htmlspecialchars($t['lot']['estimate']) ?></dt><dd><?= au_price($estimate['low']) ?> – <?= au_price($estimate['high']) ?></dd></div>
                <div><dt><?= htmlspecialchars($t['lot']['increment']) ?></dt><dd><?= au_price((int)($lot['bid_increment'] ?? 100)) ?></dd></div>
            </dl>

            <?php if ($is_live): ?>
            <a href="<?= htmlspecialchars($bid_url) ?>" class="au-btn-gold au-btn-block">
                <i class="fas fa-gavel"></i> <?= htmlspecialchars($t['lot']['place_bid']) ?>
            </a>
            <?php endif; ?>
            <div class="au-demo-alert"><?= htmlspecialchars($t['lot']['demo_note']) ?></div>
        </aside>
    </div>

    <?php if (!empty($related)): ?>
    <section class="au-related">
        <h2 class="au-section-title"><?= htmlspecialchars($t['lot']['related']) ?></h2>
        <div class="au-lot-grid au-lot-grid-compact">
            <?php foreach ($related as $rlot):
                $lot = $rlot;
                require __DIR__ . '/includes/lot-card.php';
            endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>