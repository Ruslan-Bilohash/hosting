<?php
require_once __DIR__ . '/init.php';
au_admin_require();
$admin_page = 'auction_settings';
$page_title = $ta['settings'] ?? 'Settings';
$settings = au_load_settings();
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings['currency']          = strtoupper(substr(trim($_POST['currency'] ?? 'NOK'), 0, 3)) ?: 'NOK';
    $settings['default_increment'] = max(50, (int)($_POST['default_increment'] ?? 100));
    $settings['anti_sniping_mins']   = max(0, (int)($_POST['anti_sniping_mins'] ?? 5));
    $settings['buyer_premium_pct']   = max(0, min(50, (int)($_POST['buyer_premium_pct'] ?? 15)));
    $settings['notify_outbid']       = !empty($_POST['notify_outbid']);
    $settings['notify_ending']       = !empty($_POST['notify_ending']);
    $settings['site_tagline']      = trim($_POST['site_tagline'] ?? 'Auction CMS Demo');
    $flash = au_save_settings($settings) ? 'success' : 'error';
    $settings = au_load_settings();
}

require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['settings_saved'] ?? 'Settings saved.') ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['settings_title'] ?? 'Auction settings') ?></h2></div>
    <div class="adm-card-body padded">
        <form method="post" class="adm-form-grid">
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['currency'] ?? 'Currency') ?></label>
                <input type="text" name="currency" value="<?= htmlspecialchars($settings['currency']) ?>" maxlength="3">
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['increment']) ?></label>
                <input type="number" name="default_increment" min="50" step="50" value="<?= (int)$settings['default_increment'] ?>">
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['anti_sniping'] ?? 'Anti-sniping (min)') ?></label>
                <input type="number" name="anti_sniping_mins" min="0" max="30" value="<?= (int)$settings['anti_sniping_mins'] ?>">
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['buyer_premium'] ?? 'Buyer premium %') ?></label>
                <input type="number" name="buyer_premium_pct" min="0" max="50" value="<?= (int)$settings['buyer_premium_pct'] ?>">
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['site_tagline'] ?? 'Site tagline') ?></label>
                <input type="text" name="site_tagline" value="<?= htmlspecialchars($settings['site_tagline']) ?>">
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="notify_outbid" value="1" <?= !empty($settings['notify_outbid']) ? 'checked' : '' ?>> Outbid email alerts (demo)</label>
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="notify_ending" value="1" <?= !empty($settings['notify_ending']) ? 'checked' : '' ?>> Ending-soon reminders (demo)</label>
            </div>
            <div class="adm-field adm-field-full">
                <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save']) ?></button>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>