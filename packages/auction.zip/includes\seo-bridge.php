<?php
/**
 * Auction CMS → seo-master bridge.
 */

function au_seo_master_path_from_canonical(string $canonical): string
{
    $path = parse_url($canonical, PHP_URL_PATH) ?: '/auction/';
    return $path;
}

function au_seo_master_render_page(): void
{
    global $lang, $page_title, $page_desc, $canonical, $seo_og_image, $seo_og_type;
    global $seo_noindex, $seo_schemas, $current_page, $t;

    $master = dirname(__DIR__, 2) . '/includes/seo-master.php';
    if (is_file($master)) {
        require_once $master;
    }

    $canon_abs = au_absolute_url($canonical);
    $path = au_seo_master_path_from_canonical($canon_abs);
    $og = $seo_og_image ?? au_seo_og_image();

    $opts = [
        'page_title'       => $page_title,
        'meta_description' => $page_desc,
        'canonical'        => $canon_abs,
        'path'             => $path,
        'lang'             => $lang,
        'default_lang'     => 'no',
        'languages'        => ['no', 'en', 'uk', 'ru'],
        'schema_id_base'   => 'https://bilohash.com/auction',
        'site_name'        => AU_SITE_NAME,
        'og_image'         => $og,
        'og_image_alt'     => $page_title,
        'og_type'          => $seo_og_type ?? 'website',
        'noindex'          => !empty($seo_noindex),
        'render_viewport'  => false,
        'keywords'         => $t['meta']['keywords'] ?? '',
    ];

    if (($current_page ?? '') === 'home' && empty($seo_schemas)) {
        $opts['schema_type'] = 'cms';
        $opts['software'] = [
            'name'                 => AU_SITE_NAME,
            'description'          => $page_desc,
            'url'                  => $canon_abs,
            'download_url'         => 'https://bilohash.com/auction/',
            'version'              => '2.0',
            'price'                => '0',
            'price_currency'       => 'NOK',
            'application_category' => 'BusinessApplication',
            'feature_list'         => 'Multilingual auction demo, live bidding, admin panel, Schema.org Product/Offer, CSV export',
            'service_type'         => 'Custom auction website development — Norway & Europe',
        ];
        $opts['breadcrumb'] = [
            ['name' => 'BILOHASH', 'url' => 'https://bilohash.com/'],
            ['name' => AU_SITE_NAME, 'url' => $canon_abs],
        ];
    } elseif (!empty($seo_schemas)) {
        $opts['schema_mode'] = 'extend';
        $opts['extra_schema'] = $seo_schemas;
    } else {
        $opts['schema_type'] = 'cms';
        $opts['software'] = [
            'name'        => AU_SITE_NAME,
            'description' => $page_desc,
            'url'         => $canon_abs,
            'download_url'=> 'https://bilohash.com/auction/',
        ];
    }

    $master = dirname(__DIR__, 2) . '/includes/seo-master.php';
    if (!is_file($master) || !function_exists('bh_seo_master_render')) {
        require_once __DIR__ . '/seo.php';
        au_render_seo_head(
            $page_title,
            $page_desc,
            $canonical,
            $seo_schemas ?? [],
            $seo_og_image ?? null,
            $seo_og_type ?? 'website',
            !empty($seo_noindex)
        );
        return;
    }

    try {
        bh_seo_master_render($opts);
    } catch (Throwable $e) {
        require_once __DIR__ . '/seo.php';
        au_render_seo_head(
            $page_title,
            $page_desc,
            $canonical,
            $seo_schemas ?? [],
            $seo_og_image ?? null,
            $seo_og_type ?? 'website',
            !empty($seo_noindex)
        );
    }
}