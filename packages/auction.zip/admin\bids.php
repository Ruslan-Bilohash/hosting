<?php
require_once __DIR__ . '/init.php';
au_admin_require();
$admin_page = 'bids';
$page_title = $ta['bids'];

$bids = au_load_bids();
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['bid_id']) && !empty($_POST['status'])) {
    $bidId = $_POST['bid_id'];
    $newStatus = $_POST['status'];
    if (in_array($newStatus, ['active', 'outbid', 'won'], true)) {
        foreach ($bids as &$b) {
            if (($b['id'] ?? '') === $bidId) {
                $b['status'] = $newStatus;
                break;
            }
        }
        unset($b);
        if (au_save_bids($bids)) {
            $flash = 'success';
        } else {
            $flash = 'error';
        }
    }
}

require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['saved']) ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['all_bids']) ?> (<?= count($bids) ?>)</h2>
    </div>
    <div class="adm-card-body">
        <?php if (empty($bids)): ?>
        <p style="padding:32px;text-align:center;color:var(--adm-muted)"><?= htmlspecialchars($ta['no_bids']) ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
        <table class="adm-table">
            <thead>
                <tr>
                    <th><?= htmlspecialchars($ta['ref']) ?></th>
                    <th><?= htmlspecialchars($ta['bidder']) ?></th>
                    <th><?= htmlspecialchars($ta['lot']) ?></th>
                    <th><?= htmlspecialchars($ta['amount']) ?></th>
                    <th><?= htmlspecialchars($ta['status']) ?></th>
                    <th><?= htmlspecialchars($ta['created']) ?></th>
                    <th><?= htmlspecialchars($ta['actions']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bids as $b):
                    $st = $b['status'] ?? 'active';
                ?>
                <tr>
                    <td><code style="font-size:11px"><?= htmlspecialchars($b['ref'] ?? $b['id'] ?? '') ?></code></td>
                    <td>
                        <strong><?= htmlspecialchars($b['bidder'] ?? '') ?></strong><br>
                        <small style="color:var(--adm-muted)"><?= htmlspecialchars($b['email'] ?? '') ?></small>
                    </td>
                    <td><?= htmlspecialchars($b['lot_name'] ?? '') ?></td>
                    <td><strong><?= au_price((int)($b['amount'] ?? 0)) ?></strong></td>
                    <td><span class="adm-badge adm-badge-<?= htmlspecialchars($st) ?>"><?= htmlspecialchars($ta['status_' . $st] ?? $st) ?></span></td>
                    <td style="font-size:12px;color:var(--adm-muted)"><?= isset($b['created_at']) ? date('d.m.Y H:i', strtotime($b['created_at'])) : '—' ?></td>
                    <td>
                        <form method="post" style="display:flex;gap:4px;align-items:center">
                            <input type="hidden" name="bid_id" value="<?= htmlspecialchars($b['id'] ?? '') ?>">
                            <select name="status" style="padding:4px 8px;border-radius:4px;border:1px solid var(--adm-border);font-size:12px">
                                <option value="active" <?= $st === 'active' ? 'selected' : '' ?>><?= htmlspecialchars($ta['status_active']) ?></option>
                                <option value="outbid" <?= $st === 'outbid' ? 'selected' : '' ?>><?= htmlspecialchars($ta['status_outbid']) ?></option>
                                <option value="won" <?= $st === 'won' ? 'selected' : '' ?>><?= htmlspecialchars($ta['status_won']) ?></option>
                            </select>
                            <button type="submit" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['change_status']) ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>