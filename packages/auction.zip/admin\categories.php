<?php
require_once __DIR__ . '/init.php';
au_admin_require();
$admin_page = 'categories';
$page_title = $ta['categories'] ?? 'Categories';
$chart = au_admin_category_chart();
$lots = au_lots_all();

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-stats adm-stats--compact">
    <?php foreach ($chart as $row):
        $cat = $row['cat'];
    ?>
    <div class="adm-stat adm-stat--mini">
        <div class="adm-stat-icon gold"><i class="fas fa-tag"></i></div>
        <div>
            <div class="adm-stat-val"><?= (int)$row['count'] ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($t['categories'][$cat] ?? $cat) ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['by_category'] ?? 'Lots by category') ?></h2></div>
    <div class="adm-card-body padded">
        <div class="adm-bar-chart">
            <?php foreach ($chart as $row): ?>
            <div class="adm-bar-row">
                <span class="adm-bar-label"><?= htmlspecialchars($t['categories'][$row['cat']] ?? $row['cat']) ?></span>
                <div class="adm-bar-track"><div class="adm-bar-fill" style="width:<?= (int)$row['pct'] ?>%"></div></div>
                <span class="adm-bar-val"><?= (int)$row['count'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['cat_overview'] ?? 'Category overview') ?></h2></div>
    <div class="adm-card-body">
        <div class="adm-table-wrap">
        <table class="adm-table adm-table--cards">
            <thead>
                <tr>
                    <th><?= htmlspecialchars($ta['category']) ?></th>
                    <th><?= htmlspecialchars($ta['lots']) ?></th>
                    <th><?= htmlspecialchars($ta['stats_live']) ?></th>
                    <th><?= htmlspecialchars($ta['actions']) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (au_categories() as $cat):
                    $in_cat = array_filter($lots, fn($l) => ($l['category'] ?? '') === $cat && ($l['active'] ?? true) !== false);
                    $live_cat = array_filter($in_cat, fn($l) => au_lot_is_live($l));
                ?>
                <tr>
                    <td data-label="<?= htmlspecialchars($ta['category']) ?>"><strong><?= htmlspecialchars($t['categories'][$cat]) ?></strong></td>
                    <td data-label="<?= htmlspecialchars($ta['lots']) ?>"><?= count($in_cat) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['stats_live']) ?>"><?= count($live_cat) ?></td>
                    <td data-label="<?= htmlspecialchars($ta['actions']) ?>">
                        <a href="<?= au_url('search.php?category=' . urlencode($cat)) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank">
                            <i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['view_site']) ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>