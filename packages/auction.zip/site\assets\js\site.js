(function () {
    'use strict';

    var header = document.getElementById('ausHeader');
    var menuBtn = document.getElementById('ausMenuBtn');
    var panel = document.getElementById('ausMobilePanel');
    var overlay = document.getElementById('ausOverlay');

    function closeNav() {
        if (!header) return;
        header.classList.remove('nav-open');
        document.body.classList.remove('aus-nav-open');
        if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
        if (panel) panel.hidden = true;
        if (overlay) {
            overlay.hidden = true;
            overlay.classList.remove('is-open');
        }
    }

    function openNav() {
        if (!header) return;
        header.classList.add('nav-open');
        document.body.classList.add('aus-nav-open');
        if (menuBtn) menuBtn.setAttribute('aria-expanded', 'true');
        if (panel) panel.hidden = false;
        if (overlay) {
            overlay.hidden = false;
            requestAnimationFrame(function () { overlay.classList.add('is-open'); });
        }
    }

    if (menuBtn && header) {
        menuBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            closeLangDropdown();
            if (header.classList.contains('nav-open')) closeNav();
            else openNav();
        });
    }
    if (overlay) overlay.addEventListener('click', closeNav);
    if (panel) {
        panel.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', closeNav);
        });
    }
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 769) closeNav();
    });

    var langDropdown = document.getElementById('ausLangDropdown');
    var langBtn = document.getElementById('ausLangBtn');
    var langMenu = document.getElementById('ausLangMenu');

    function closeLangDropdown() {
        if (!langDropdown) return;
        langDropdown.classList.remove('is-open');
        if (langBtn) langBtn.setAttribute('aria-expanded', 'false');
        if (langMenu) langMenu.hidden = true;
    }

    if (langBtn && langMenu && langDropdown) {
        langBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = langDropdown.classList.toggle('is-open');
            langMenu.hidden = !open;
            langBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        langMenu.addEventListener('click', function (e) { e.stopPropagation(); });
    }
    document.addEventListener('click', closeLangDropdown);
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeNav();
            closeLangDropdown();
        }
    });

    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            var id = link.getAttribute('href');
            if (!id || id === '#') return;
            var target = document.querySelector(id);
            if (!target) return;
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            if (history.replaceState) {
                history.replaceState(null, '', id);
            }
        });
    });
})();