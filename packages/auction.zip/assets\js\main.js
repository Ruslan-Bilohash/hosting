(function () {
    'use strict';

    // Mobile header menu
    var header = document.getElementById('auHeader');
    var menuBtn = document.getElementById('auMenuBtn');
    var menuClose = document.getElementById('auMenuClose');
    var overlay = document.getElementById('auOverlay');
    var panel = document.getElementById('auHeaderPanel');

    function closeNav() {
        if (!header) return;
        header.classList.remove('nav-open');
        document.body.classList.remove('au-nav-open');
        if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
        if (overlay) {
            overlay.classList.remove('is-open');
            overlay.hidden = true;
        }
    }

    function openNav() {
        if (!header) return;
        header.classList.add('nav-open');
        document.body.classList.add('au-nav-open');
        if (menuBtn) menuBtn.setAttribute('aria-expanded', 'true');
        if (overlay) {
            overlay.hidden = false;
            requestAnimationFrame(function () { overlay.classList.add('is-open'); });
        }
    }

    if (menuBtn && header) {
        menuBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (header.classList.contains('nav-open')) closeNav();
            else openNav();
        });
    }
    if (menuClose) menuClose.addEventListener('click', closeNav);
    if (overlay) overlay.addEventListener('click', closeNav);
    if (panel) {
        panel.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', closeNav);
        });
    }

    // Language dropdown
    var langDropdown = document.getElementById('auLangDropdown');
    var langBtn = document.getElementById('auLangBtn');
    var langMenu = document.getElementById('auLangMenu');

    function closeLangDropdown() {
        if (!langDropdown) return;
        langDropdown.classList.remove('is-open');
        if (langBtn) langBtn.setAttribute('aria-expanded', 'false');
        if (langMenu) langMenu.hidden = true;
    }

    if (langBtn && langMenu && langDropdown) {
        langBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = langDropdown.classList.toggle('is-open');
            langMenu.hidden = !open;
            langBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        langMenu.addEventListener('click', function (e) { e.stopPropagation(); });
    }

    document.addEventListener('click', closeLangDropdown);
    // Search filters (mobile / tablet)
    var filterToggle = document.getElementById('auFilterToggle');
    var filtersPanel = document.getElementById('auFilters');

    function setFilterToggleLabel(open) {
        if (!filterToggle) return;
        var label = filterToggle.querySelector('span');
        if (!label) return;
        var openText = filterToggle.getAttribute('data-label-open');
        var closeText = filterToggle.getAttribute('data-label-close');
        if (open) {
            if (closeText) label.textContent = closeText;
        } else if (openText) {
            label.textContent = openText;
        }
    }

    function closeFilters() {
        if (!filtersPanel || !filterToggle) return;
        filtersPanel.classList.remove('is-open');
        filterToggle.setAttribute('aria-expanded', 'false');
        setFilterToggleLabel(false);
    }

    if (filterToggle && filtersPanel) {
        filterToggle.addEventListener('click', function () {
            var open = filtersPanel.classList.toggle('is-open');
            filterToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            setFilterToggleLabel(open);
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeNav();
            closeLangDropdown();
            closeFilters();
        }
    });
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 1100) {
            closeNav();
            closeLangDropdown();
            closeFilters();
        }
    });

    // Countdown timers
    function pad(n) {
        return n < 10 ? '0' + n : String(n);
    }

    function formatShort(ms) {
        if (ms <= 0) return '00:00:00';
        var s = Math.floor(ms / 1000);
        var d = Math.floor(s / 86400);
        s %= 86400;
        var h = Math.floor(s / 3600);
        s %= 3600;
        var m = Math.floor(s / 60);
        s %= 60;
        if (d > 0) return d + 'd ' + pad(h) + ':' + pad(m) + ':' + pad(s);
        return pad(h) + ':' + pad(m) + ':' + pad(s);
    }

    function updateCountdowns() {
        var now = Date.now();
        document.querySelectorAll('[data-countdown]').forEach(function (el) {
            var end = parseInt(el.getAttribute('data-countdown'), 10) * 1000;
            var left = end - now;

            if (el.classList.contains('au-countdown-lg')) {
                var dEl = el.querySelector('.cd-d');
                var hEl = el.querySelector('.cd-h');
                var mEl = el.querySelector('.cd-m');
                var sEl = el.querySelector('.cd-s');
                if (left <= 0) {
                    if (dEl) dEl.textContent = '00';
                    if (hEl) hEl.textContent = '00';
                    if (mEl) mEl.textContent = '00';
                    if (sEl) sEl.textContent = '00';
                    return;
                }
                var sec = Math.floor(left / 1000);
                var days = Math.floor(sec / 86400);
                sec %= 86400;
                var hours = Math.floor(sec / 3600);
                sec %= 3600;
                var mins = Math.floor(sec / 60);
                sec %= 60;
                if (dEl) dEl.textContent = pad(days);
                if (hEl) hEl.textContent = pad(hours);
                if (mEl) mEl.textContent = pad(mins);
                if (sEl) sEl.textContent = pad(sec);
            } else {
                var val = el.querySelector('.au-countdown-val');
                if (val) {
                    val.textContent = left <= 0 ? '00:00:00' : formatShort(left);
                }
            }
        });
    }

    updateCountdowns();
    setInterval(updateCountdowns, 1000);

    // Lot detail tabs
    document.querySelectorAll('.au-tabs').forEach(function (tablist) {
        var tabs = tablist.querySelectorAll('.au-tab[data-tab]');
        if (!tabs.length) return;

        var container = tablist.parentElement;

        function activate(tabId) {
            tabs.forEach(function (btn) {
                var on = btn.getAttribute('data-tab') === tabId;
                btn.classList.toggle('active', on);
                btn.setAttribute('aria-selected', on ? 'true' : 'false');
            });
            container.querySelectorAll('.au-tab-panel').forEach(function (panel) {
                var match = panel.id === 'tab-' + tabId;
                panel.classList.toggle('active', match);
                panel.hidden = !match;
            });
        }

        tablist.setAttribute('role', 'tablist');
        tabs.forEach(function (btn, i) {
            btn.setAttribute('role', 'tab');
            btn.setAttribute('aria-controls', 'tab-' + btn.getAttribute('data-tab'));
            if (btn.classList.contains('active')) {
                btn.setAttribute('aria-selected', 'true');
            } else {
                btn.setAttribute('aria-selected', 'false');
                btn.setAttribute('tabindex', '-1');
            }
            btn.addEventListener('click', function () {
                activate(btn.getAttribute('data-tab'));
                tabs.forEach(function (b) { b.setAttribute('tabindex', '-1'); });
                btn.setAttribute('tabindex', '0');
            });
            btn.addEventListener('keydown', function (e) {
                var idx = Array.prototype.indexOf.call(tabs, btn);
                if (e.key === 'ArrowRight') {
                    e.preventDefault();
                    tabs[(idx + 1) % tabs.length].click();
                    tabs[(idx + 1) % tabs.length].focus();
                } else if (e.key === 'ArrowLeft') {
                    e.preventDefault();
                    tabs[(idx - 1 + tabs.length) % tabs.length].click();
                    tabs[(idx - 1 + tabs.length) % tabs.length].focus();
                }
            });
        });
    });
})();