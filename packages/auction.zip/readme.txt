=== Auction CMS ===

Universal PHP online auction / bidding script for Norway and Europe.
Timed lots, live countdown, bid form, proxy bids (extensible), admin panel.

Languages: Norwegian (default), English, Ukrainian

URLs
  Frontend:     https://bilohash.com/auction/
  Admin panel:  https://bilohash.com/auction/admin/
  Product page: https://bilohash.com/auction/site/
  Sitemap:      https://bilohash.com/auction/sitemap.php
  AI context:   https://bilohash.com/auction/llms.txt

Admin demo login
  Username: demo
  Password: biloauction2026

Features
  - Public catalog with search, categories, filters and sort
  - Lot pages with countdown, bid history and Schema.org Product/Offer
  - Demo bid form (JSON storage, no real payments)
  - Admin: lots, bids, dashboard
  - SEO: hreflang (no/en/uk), dynamic sitemap, robots.txt, llms.txt
  - Amber/navy responsive UI, Font Awesome 6

Tech
  PHP 8+, JSON storage (lots.json, bids.json), modular i18n, no framework

Order custom auction website
  https://bilohash.com/

Related
  Booking CMS: https://bilohash.com/booking/site/