<?php
require_once dirname(__DIR__) . '/includes/admin-auth.php';
au_admin_logout();
header('Location: ' . au_admin_url('login.php'), true, 302);
exit;