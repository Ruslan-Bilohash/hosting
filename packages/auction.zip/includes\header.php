<?php
require_once dirname(__DIR__, 2) . '/includes/cms-contact.php';
require_once __DIR__ . '/site-integrations.php';
au_boot_public_integrations();
$cms_nav_discuss = cms_contact_texts('auction', $lang)['nav_discuss'];
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? $site_url . '/';
$body_class = $body_class ?? '';
$seo_schemas = $seo_schemas ?? [];
$seo_og_image = $seo_og_image ?? null;
$seo_og_type  = $seo_og_type ?? 'website';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    if (!empty($vertical_seo_mode)) {
        au_render_vertical_seo_head($page_title, $page_desc, $canonical, $seo_schemas, $vertical_keywords ?? null, $seo_og_image);
    } else {
        require_once __DIR__ . '/seo-bridge.php';
        au_seo_master_render_page();
    }
    ?>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>
    <link rel="stylesheet" href="<?= htmlspecialchars(au_asset('css/style.css')) ?>?v=11">
    <?php bh_cms_render_theme_styles('auction', au_site_settings()); ?>
    <?php if ((!empty($cms_prefix) && $cms_prefix !== 'fl') || ($current_page ?? '') === 'contact'): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars(cms_contact_stylesheet_href()) ?>">
    <?php endif; ?>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%230c1222' width='100' height='100' rx='12'/><text x='50' y='62' font-size='40' text-anchor='middle' fill='%23f59e0b' font-family='sans-serif' font-weight='bold'>A</text></svg>">
    <?php
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    ecosystem_subscription_strip_head_link();
    ?>
</head>
<body class="<?= htmlspecialchars($body_class) ?>">

<a class="au-skip-link" href="#auMain"><?= htmlspecialchars($t['nav']['skip'] ?? 'Skip to content') ?></a>

<div class="au-top-bar">
<?php ecosystem_subscription_strip_render($lang); ?>

<header class="au-header" id="auHeader" itemscope itemtype="https://schema.org/WPHeader">
    <div class="au-header-inner">
        <a href="<?= au_url('index.php') ?>" class="au-logo" itemprop="url">
            <span class="au-logo-icon"><i class="fas fa-gavel"></i></span>
            <span class="au-logo-text" itemprop="name"><?= htmlspecialchars($t['meta']['site_name']) ?></span>
        </a>
        <div class="au-header-panel" id="auHeaderPanel">
            <div class="au-panel-head">
                <span class="au-panel-title"><?= htmlspecialchars($t['meta']['site_name']) ?></span>
                <button type="button" class="au-menu-close" id="auMenuClose" aria-label="Close menu">
                    <i class="fas fa-times" aria-hidden="true"></i>
                </button>
            </div>
            <nav class="au-nav" aria-label="Main">
                <a href="<?= au_url('index.php') ?>" class="<?= ($current_page ?? '') === 'home' ? 'active' : '' ?>"><?= htmlspecialchars($t['nav']['live']) ?></a>
                <a href="<?= au_url('solutions.php') ?>"><?= htmlspecialchars(au_vertical_hub_label($lang)) ?></a>
                <a href="<?= au_url('search.php') ?>"><?= htmlspecialchars($t['nav']['categories']) ?></a>
                <a href="<?= au_url('search.php?status=ending') ?>"><?= htmlspecialchars($t['nav']['ending']) ?></a>
                <a href="<?= au_url('search.php') ?>"><?= htmlspecialchars($t['nav']['sell']) ?></a>
            </nav>
            <div class="au-header-actions">
                <a href="<?= au_url('contact.php') ?>" class="au-btn-gold au-btn-discuss <?= ($current_page ?? '') === 'contact' ? 'active' : '' ?>"><i class="fas fa-comments"></i> <span><?= htmlspecialchars($cms_nav_discuss) ?></span></a>

                <a href="https://bilohash.com/auction/site/" class="au-btn-outline au-btn-hide-md"><span><?= htmlspecialchars($t['demo_strip']['cms']) ?></span></a>
                <a href="<?= au_url('admin/login.php') ?>" class="au-btn-outline" title="Admin"><i class="fas fa-user-shield" aria-hidden="true"></i> <span class="au-btn-label">Admin</span></a>

            </div>
        </div>
        <div class="au-header-bar">
            <?php require __DIR__ . '/lang-dropdown.php'; ?>
            <button type="button" class="au-menu-toggle" id="auMenuBtn" aria-label="Menu" aria-expanded="false" aria-controls="auHeaderPanel">
                <i class="fas fa-bars au-menu-icon-open" aria-hidden="true"></i>
                <i class="fas fa-times au-menu-icon-close" aria-hidden="true"></i>
            </button>
        </div>
    </div>
</header>
</div>
<div class="au-overlay" id="auOverlay" hidden></div>

<main id="auMain" class="au-main">