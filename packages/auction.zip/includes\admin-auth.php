<?php
/**
 * Demo admin auth — session based
 * Login: demo / biloauction2026
 */
define('AU_ADMIN_USER', 'demo');
define('AU_ADMIN_PASS', 'biloauction2026');
define('AU_ADMIN_SESSION_KEY', 'au_admin_logged');

function au_admin_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function au_admin_logged(): bool
{
    au_admin_start();
    return !empty($_SESSION[AU_ADMIN_SESSION_KEY]);
}

function au_admin_login(string $user, string $pass): bool
{
    if ($user === AU_ADMIN_USER && $pass === AU_ADMIN_PASS) {
        au_admin_start();
        $_SESSION[AU_ADMIN_SESSION_KEY] = true;
        $_SESSION['au_admin_user'] = $user;
        return true;
    }
    return false;
}

function au_admin_logout(): void
{
    au_admin_start();
    unset($_SESSION[AU_ADMIN_SESSION_KEY], $_SESSION['au_admin_user']);
}

function au_admin_require(): void
{
    if (!au_admin_logged()) {
        header('Location: ' . au_admin_url('login.php'), true, 302);
        exit;
    }
}

function au_admin_url(string $path = ''): string
{
    return au_url('admin/' . ltrim($path, '/'));
}