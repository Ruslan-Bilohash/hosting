<?php
require_once __DIR__ . '/init.php';
$slug = trim($_GET['slug'] ?? '');
$vertical = au_vertical_by_slug($slug);
if (!$vertical) {
    header('Location: ' . au_url('solutions.php'), true, 302);
    exit;
}

$GLOBALS['vertical_slug'] = $slug;
$v = au_vertical_lang($vertical, $lang);
$page_title = $v['title'] ?? AU_SITE_NAME;
$page_desc  = $v['description'] ?? '';
$canonical  = au_vertical_canonical($slug);
$canon_abs  = au_absolute_url($canonical);

$seo_schemas = [
    au_seo_organization(),
    au_seo_webpage($canon_abs, $page_title, $page_desc),
    au_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => au_absolute_url(au_url('index.php'))],
        ['name' => au_vertical_hub_label($lang), 'url' => au_absolute_url(au_url('solutions.php'))],
        ['name' => $v['h1'] ?? $slug, 'url' => $canon_abs],
    ]),
    au_seo_vertical_service($v['h1'] ?? $slug, $page_desc, $canon_abs),
    au_seo_software_app($canon_abs, $page_desc),
];
if (!empty($v['faq'])) {
    $seo_schemas[] = au_seo_faq_page($v['faq']);
}

require __DIR__ . '/includes/vertical-template.php';