<?php
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';
$current_page = 'home';
$search_params = au_search_params();
$live_lots     = au_featured_lots(6);
$ending_soon   = au_ending_soon_lots(4);
$cat_counts    = au_category_counts();
$stats         = au_platform_stats();
$canonical     = $site_url . '/';
$page_title    = $t['meta']['title'];
$page_desc     = $t['meta']['description'];
require __DIR__ . '/includes/header.php';
?>

<section class="au-hero">
    <div class="au-hero-bg"></div>
    <div class="au-hero-inner">
        <span class="au-demo-badge"><i class="fas fa-gavel"></i> <?= htmlspecialchars($t['hero']['badge']) ?></span>
        <h1><?= htmlspecialchars($t['hero']['title']) ?></h1>
        <p><?= htmlspecialchars($t['hero']['subtitle']) ?></p>
        <?php require __DIR__ . '/includes/search-form.php'; ?>
    </div>
</section>

<section class="au-about-script">
    <div class="au-container au-about-script-inner">
        <div class="au-about-script-text">
            <h2><?= htmlspecialchars($t['about_script']['title']) ?></h2>
            <p><?= htmlspecialchars($t['about_script']['text']) ?></p>
            <?php if (au_use_case_slugs()): ?>
            <p class="au-about-use-label"><?= htmlspecialchars($t['about_script']['use_label'] ?? '') ?></p>
            <div class="au-about-usecases">
                <?php foreach (au_use_case_slugs() as $slug):
                    $vdef = au_vertical_defs()[$slug] ?? null;
                    if (!$vdef) continue;
                    $label = $vdef[$lang] ?? $vdef['en'] ?? $slug;
                ?>
                <a href="<?= htmlspecialchars(au_vertical_url($slug)) ?>" class="au-about-usecase au-about-usecase-link">
                    <i class="fas fa-<?= htmlspecialchars($vdef['icon'] ?? 'gavel') ?>" aria-hidden="true"></i>
                    <?= htmlspecialchars($label) ?>
                </a>
                <?php endforeach; ?>
            </div>
            <p class="au-about-use-more">
                <a href="<?= au_url('solutions.php') ?>"><?= htmlspecialchars(au_vertical_hub_label($lang)) ?> →</a>
            </p>
            <?php endif; ?>
            <ul class="au-about-features">
                <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($t['about_script']['f1']) ?></li>
                <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($t['about_script']['f2']) ?></li>
                <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($t['about_script']['f3']) ?></li>
            </ul>
            <div class="au-about-actions">
                <a href="<?= au_url('index.php') ?>" class="au-btn-gold"><i class="fas fa-play-circle"></i> <?= htmlspecialchars($t['about_script']['demo_btn']) ?></a>
                <a href="<?= au_url('admin/login.php') ?>" class="au-btn-outline-dark"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['about_script']['admin_btn']) ?></a>
                <a href="https://bilohash.com/auction/site/" class="au-btn-outline-dark"><i class="fas fa-book"></i> <?= htmlspecialchars($t['about_script']['product_btn']) ?></a>
                <a href="<?= au_url('contact.php') ?>" class="au-btn-gold"><i class="fas fa-comments"></i> <?= htmlspecialchars(cms_contact_texts('auction', $lang)['nav_discuss']) ?></a>
            </div>
            <p class="au-about-creds"><i class="fas fa-key"></i> <?= htmlspecialchars($t['about_script']['creds']) ?></p>
        </div>
        <div class="au-about-script-visual">
            <div class="au-about-mock">
                <div class="au-mock-header"><span></span><span></span><span></span></div>
                <div class="au-mock-body">
                    <div class="au-mock-lot"></div>
                    <div class="au-mock-lot"></div>
                    <div class="au-mock-lot"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="au-stats-strip">
    <div class="au-container au-stats-grid">
        <div class="au-stat-item">
            <i class="fas fa-gavel"></i>
            <strong><?= (int)$stats['lots'] ?></strong>
            <span><?= htmlspecialchars($t['home']['stats_lots']) ?></span>
        </div>
        <div class="au-stat-item">
            <i class="fas fa-bolt"></i>
            <strong><?= (int)$stats['live'] ?></strong>
            <span><?= htmlspecialchars($t['home']['stats_live']) ?></span>
        </div>
        <div class="au-stat-item">
            <i class="fas fa-hand-holding-dollar"></i>
            <strong><?= (int)$stats['bids'] ?></strong>
            <span><?= htmlspecialchars($t['home']['stats_bids']) ?></span>
        </div>
        <div class="au-stat-item">
            <i class="fas fa-coins"></i>
            <strong><?= au_price((int)$stats['volume']) ?></strong>
            <span><?= htmlspecialchars($t['home']['stats_vol']) ?></span>
        </div>
    </div>
</section>

<div class="au-container">
    <div class="au-section-head">
        <div>
            <h2 class="au-section-title"><?= htmlspecialchars($t['home']['live']) ?></h2>
            <p class="au-section-sub"><?= htmlspecialchars($t['home']['live_sub']) ?></p>
        </div>
        <a href="<?= au_url('search.php?status=live') ?>" class="au-link-more"><?= htmlspecialchars($t['home']['view_all']) ?> →</a>
    </div>
    <div class="au-lot-grid">
        <?php foreach ($live_lots as $lot):
            require __DIR__ . '/includes/lot-card.php';
        endforeach; ?>
    </div>
</div>

<div class="au-container au-section-tight">
    <h2 class="au-section-title"><?= htmlspecialchars($t['home']['categories']) ?></h2>
    <div class="au-cat-grid">
        <?php foreach (au_categories() as $cat):
            $icon = match ($cat) {
                'art' => 'palette',
                'antiques' => 'landmark',
                'vehicles' => 'car',
                'collectibles' => 'gem',
                'jewelry' => 'ring',
                'real_estate' => 'house',
                default => 'tag',
            };
            $url = au_url('search.php?category=' . urlencode($cat));
        ?>
        <a href="<?= htmlspecialchars($url) ?>" class="au-cat-card">
            <i class="fas fa-<?= $icon ?>"></i>
            <strong><?= htmlspecialchars($t['categories'][$cat]) ?></strong>
            <span><?= (int)($cat_counts[$cat] ?? 0) ?> <?= htmlspecialchars($t['home']['lots']) ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="au-container au-section-tight">
    <div class="au-section-head">
        <div>
            <h2 class="au-section-title"><?= htmlspecialchars($t['home']['ending']) ?></h2>
            <p class="au-section-sub"><?= htmlspecialchars($t['home']['ending_sub']) ?></p>
        </div>
        <a href="<?= au_url('search.php?status=ending') ?>" class="au-link-more"><?= htmlspecialchars($t['home']['view_all']) ?> →</a>
    </div>
    <div class="au-lot-grid">
        <?php foreach ($ending_soon as $lot):
            require __DIR__ . '/includes/lot-card.php';
        endforeach; ?>
    </div>
</div>

<div class="au-container au-section-tight">
    <div class="au-section-head au-section-head-center">
        <div>
            <h2 class="au-section-title"><?= htmlspecialchars($t['how_it_works']['title']) ?></h2>
            <p class="au-section-sub"><?= htmlspecialchars($t['how_it_works']['subtitle']) ?></p>
        </div>
    </div>
    <div class="au-steps-grid">
        <?php foreach ($t['how_it_works']['steps'] as $i => $step): ?>
        <article class="au-step-card">
            <div class="au-step-num"><?= $i + 1 ?></div>
            <div class="au-step-icon"><i class="fas fa-<?= htmlspecialchars($step['icon']) ?>"></i></div>
            <h3><?= htmlspecialchars($step['title']) ?></h3>
            <p><?= htmlspecialchars($step['desc']) ?></p>
        </article>
        <?php endforeach; ?>
    </div>
</div>

<div class="au-container au-section-tight">
    <h2 class="au-section-title"><?= htmlspecialchars($t['home']['why']) ?></h2>
    <div class="au-why-grid">
        <div class="au-why-item">
            <i class="fas fa-chart-line"></i>
            <h4><?= htmlspecialchars($t['home']['why_1_t']) ?></h4>
            <p><?= htmlspecialchars($t['home']['why_1_d']) ?></p>
        </div>
        <div class="au-why-item">
            <i class="fas fa-shield-halved"></i>
            <h4><?= htmlspecialchars($t['home']['why_2_t']) ?></h4>
            <p><?= htmlspecialchars($t['home']['why_2_d']) ?></p>
        </div>
        <div class="au-why-item">
            <i class="fas fa-globe-europe"></i>
            <h4><?= htmlspecialchars($t['home']['why_3_t']) ?></h4>
            <p><?= htmlspecialchars($t['home']['why_3_d']) ?></p>
        </div>
    </div>
</div>

<div class="au-container au-section-tight au-faq-section au-section-last">
    <h2 class="au-section-title"><?= htmlspecialchars($t['faq']['title']) ?></h2>
    <div class="au-faq-list">
        <?php foreach ($t['faq']['items'] as $i => $item): ?>
        <details class="au-faq-item"<?= $i === 0 ? ' open' : '' ?>>
            <summary><?= htmlspecialchars($item['q']) ?></summary>
            <p><?= htmlspecialchars($item['a']) ?></p>
        </details>
        <?php endforeach; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>