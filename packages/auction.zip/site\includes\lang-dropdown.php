<?php
$current = aus_langs()[$lang] ?? aus_langs()['no'];
?>
<div class="aus-lang-dropdown" id="ausLangDropdown">
    <button type="button" class="aus-lang-dropdown-btn" id="ausLangBtn" aria-expanded="false" aria-haspopup="listbox" aria-controls="ausLangMenu">
        <span><?= $current['flag'] ?> <?= htmlspecialchars($current['label']) ?></span>
        <i class="fas fa-chevron-down" aria-hidden="true"></i>
    </button>
    <ul class="aus-lang-dropdown-menu" id="ausLangMenu" role="listbox" hidden>
        <?php foreach (aus_langs() as $code => $info): ?>
        <li role="option">
            <a href="<?= htmlspecialchars(aus_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>" <?= $lang === $code ? 'aria-current="true"' : '' ?>>
                <span><?= $info['flag'] ?></span>
                <span><?= htmlspecialchars($info['name']) ?></span>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
</div>