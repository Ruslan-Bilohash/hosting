<?php
require_once __DIR__ . '/../config.php';

define('AUS_LANG_COOKIE', 'aus_lang');

$AUS_LANGS = [
    'no' => ['label' => 'NO', 'name' => 'Norsk', 'flag' => '🇳🇴', 'locale' => 'nb-NO', 'html' => 'no'],
    'en' => ['label' => 'EN', 'name' => 'English', 'flag' => '🇬🇧', 'locale' => 'en-GB', 'html' => 'en'],
    'uk' => ['label' => 'UA', 'name' => 'Українська', 'flag' => '🇺🇦', 'locale' => 'uk-UA', 'html' => 'uk'],
    'ru' => ['label' => 'RU', 'name' => 'Русский', 'flag' => '🇷🇺', 'locale' => 'ru-RU', 'html' => 'ru'],
];

function aus_langs(): array { global $AUS_LANGS; return $AUS_LANGS; }

/**
 * Detect language: site cookie (aus_lang) or ?lang= — separate from demo AU_LANG_COOKIE.
 * Falls back to parent auction lang cookie if present and valid for site.
 */
function aus_detect_lang(): string
{
    global $base_path, $AUS_LANGS;
    $codes = array_keys($AUS_LANGS);

    if (!empty($_GET['lang']) && in_array($_GET['lang'], $codes, true)) {
        $chosen = $_GET['lang'];
        setcookie(AUS_LANG_COOKIE, $chosen, [
            'expires' => time() + 365 * 86400,
            'path'    => rtrim($base_path, '/') . '/' ?: '/',
            'secure'  => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'samesite'=> 'Lax',
        ]);
        if ($chosen === 'no') {
            $uri = $_SERVER['REQUEST_URI'] ?? '/';
            $parts = parse_url($uri);
            parse_str($parts['query'] ?? '', $q);
            unset($q['lang']);
            $clean = ($parts['path'] ?? '/') . ($q ? '?' . http_build_query($q) : '');
            if ($clean !== $uri) { header('Location: ' . $clean, true, 302); exit; }
        }
        return $chosen;
    }
    if (!empty($_COOKIE[AUS_LANG_COOKIE]) && in_array($_COOKIE[AUS_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[AUS_LANG_COOKIE];
    }
    if (!empty($_COOKIE['au_lang']) && in_array($_COOKIE['au_lang'], $codes, true)) {
        return $_COOKIE['au_lang'];
    }
    return 'no';
}

$lang      = aus_detect_lang();
$lang_meta = $AUS_LANGS[$lang] ?? $AUS_LANGS['no'];
$lang_file = __DIR__ . '/../lang/' . $lang . '.php';
if (!is_file($lang_file)) $lang_file = __DIR__ . '/../lang/en.php';
$t = require $lang_file;

require_once dirname(__DIR__, 3) . '/includes/ecosystem-i18n.php';
$t = bh_apply_ecosystem_translations($t, $lang, 'auction');

require_once __DIR__ . '/helpers.php';