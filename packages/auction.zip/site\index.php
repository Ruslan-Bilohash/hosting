<?php
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/vertical-lib.php';
require_once dirname(__DIR__, 2) . '/includes/cms-contact.php';
$canonical = $site_url . '/';
require __DIR__ . '/includes/header.php';
?>

<section class="aus-hero">
    <div class="aus-hero-bg"></div>
    <div class="aus-container aus-hero-inner">
        <div class="aus-hero-content">
            <span class="aus-badge"><?= htmlspecialchars($t['hero']['badge']) ?></span>
            <h1><?= htmlspecialchars($t['hero']['title']) ?></h1>
            <p class="aus-hero-sub"><?= htmlspecialchars($t['hero']['subtitle']) ?></p>
            <div class="aus-hero-cta">
                <a href="<?= aus_demo_url() ?>" class="aus-btn-primary aus-btn-lg"><i class="fas fa-gavel"></i> <?= htmlspecialchars($t['hero']['cta_demo']) ?></a>
                <a href="<?= aus_demo_url('admin/login.php') ?>" class="aus-btn-outline aus-btn-lg"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['hero']['cta_admin']) ?></a>
                <a href="<?= aus_url('contact.php') ?>" class="aus-btn-ghost aus-btn-lg"><i class="fas fa-comments"></i> <?= htmlspecialchars(cms_contact_texts('auction', $lang)['nav_discuss']) ?></a>
            </div>
        </div>
        <div class="aus-hero-preview" aria-hidden="true">
            <div class="aus-mockup">
                <div class="aus-mockup-header">
                    <span class="aus-mockup-dot"></span>
                    <span class="aus-mockup-dot"></span>
                    <span class="aus-mockup-dot"></span>
                    <span class="aus-mockup-title">Live lots</span>
                </div>
                <div class="aus-mockup-body">
                    <article class="aus-mockup-lot">
                        <div class="aus-mockup-thumb"><i class="fas fa-clock"></i></div>
                        <div class="aus-mockup-info">
                            <strong>Vintage Omega Seamaster</strong>
                            <span class="aus-mockup-bid">12 400 kr</span>
                            <span class="aus-mockup-time"><i class="fas fa-hourglass-half"></i> 02:14:33</span>
                        </div>
                    </article>
                    <article class="aus-mockup-lot active">
                        <div class="aus-mockup-thumb"><i class="fas fa-image"></i></div>
                        <div class="aus-mockup-info">
                            <strong>Limited Edvard Munch Print</strong>
                            <span class="aus-mockup-bid">8 750 kr</span>
                            <span class="aus-mockup-time"><i class="fas fa-hourglass-half"></i> 05:42:08</span>
                        </div>
                    </article>
                    <article class="aus-mockup-lot">
                        <div class="aus-mockup-thumb"><i class="fas fa-bicycle"></i></div>
                        <div class="aus-mockup-info">
                            <strong>1982 Peugeot Road Bike</strong>
                            <span class="aus-mockup-bid">3 200 kr</span>
                            <span class="aus-mockup-time"><i class="fas fa-hourglass-half"></i> 01:08:55</span>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="aus-section aus-intro">
    <div class="aus-container">
        <h2><?= htmlspecialchars($t['intro']['title']) ?></h2>
        <p class="aus-lead"><?= htmlspecialchars($t['intro']['text']) ?></p>
        <?php if (au_use_case_slugs()): ?>
        <p class="aus-use-label"><?= htmlspecialchars($t['intro']['use_label'] ?? '') ?></p>
        <div class="aus-usecases">
            <?php foreach (au_use_case_slugs() as $slug):
                $vdef = au_vertical_defs()[$slug] ?? null;
                if (!$vdef) continue;
                $label = $vdef[$lang] ?? $vdef['en'] ?? $slug;
            ?>
            <a href="<?= htmlspecialchars(aus_vertical_url($slug)) ?>" class="aus-usecase aus-usecase-link" rel="related">
                <i class="fas fa-<?= htmlspecialchars($vdef['icon'] ?? 'gavel') ?>" aria-hidden="true"></i>
                <?= htmlspecialchars($label) ?>
            </a>
            <?php endforeach; ?>
        </div>
        <p class="aus-use-more">
            <a href="<?= htmlspecialchars(aus_demo_url('solutions.php' . ($lang !== 'no' ? '?lang=' . $lang : ''))) ?>"><?= htmlspecialchars(au_vertical_hub_label($lang)) ?> →</a>
        </p>
        <?php endif; ?>
    </div>
</section>

<section class="aus-section" id="features">
    <div class="aus-container">
        <h2 class="aus-section-title"><?= htmlspecialchars($t['features']['title']) ?></h2>
        <div class="aus-features-grid">
            <?php foreach ($t['features']['items'] as $f): ?>
            <article class="aus-feature-card">
                <div class="aus-feature-icon"><i class="fas fa-<?= htmlspecialchars($f['icon']) ?>"></i></div>
                <h3><?= htmlspecialchars($f['title']) ?></h3>
                <p><?= htmlspecialchars($f['desc']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="aus-section aus-tech-section" id="tech">
    <div class="aus-container">
        <div class="aus-tech-layout">
            <div>
                <h2 class="aus-section-title"><?= htmlspecialchars($t['tech']['title']) ?></h2>
                <ul class="aus-tech-list">
                    <?php foreach ($t['tech']['items'] as $item): ?>
                    <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($item) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="aus-tech-visual">
                <div class="aus-tech-panel">
                    <div class="aus-tech-panel-head"><i class="fas fa-server"></i> auction-cms</div>
                    <ul class="aus-tech-panel-list">
                        <li><span>lots.json</span><em>14 demo lots</em></li>
                        <li><span>settings.json</span><em>configurable</em></li>
                        <li><span>bids.json</span><em>real-time</em></li>
                        <li><span>i18n/</span><em>no · en · uk</em></li>
                        <li><span>sitemap.php</span><em>SEO</em></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="aus-section aus-demo-section" id="demo">
    <div class="aus-container">
        <h2 class="aus-section-title"><?= htmlspecialchars($t['demo']['title']) ?></h2>
        <div class="aus-demo-grid">
            <article class="aus-demo-card">
                <div class="aus-demo-icon"><i class="fas fa-gavel"></i></div>
                <h3><?= htmlspecialchars($t['demo']['frontend']) ?></h3>
                <p><?= htmlspecialchars($t['demo']['frontend_desc']) ?></p>
                <a href="<?= aus_demo_url() ?>" class="aus-btn-primary"><?= htmlspecialchars($t['demo']['open']) ?> →</a>
            </article>
            <article class="aus-demo-card">
                <div class="aus-demo-icon admin"><i class="fas fa-user-shield"></i></div>
                <h3><?= htmlspecialchars($t['demo']['admin']) ?></h3>
                <p><?= htmlspecialchars($t['demo']['admin_desc']) ?></p>
                <code class="aus-creds">demo / biloauction2026</code>
                <a href="<?= aus_demo_url('admin/login.php') ?>" class="aus-btn-outline"><?= htmlspecialchars($t['demo']['open']) ?> →</a>
            </article>
        </div>
    </div>
</section>

<section class="aus-cta-band">
    <div class="aus-container">
        <h2><?= htmlspecialchars($t['cta']['title']) ?></h2>
        <p><?= htmlspecialchars($t['cta']['text']) ?></p>
        <a href="https://bilohash.com/" class="aus-btn-primary aus-btn-lg"><?= htmlspecialchars($t['cta']['btn']) ?></a>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>