<?php
require_once __DIR__ . '/seo.php';
require_once dirname(__DIR__, 3) . '/includes/cms-contact.php';
$cms_nav_discuss = cms_contact_texts('auction', $lang)['nav_discuss'];
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? $site_url . '/';
require_once dirname(__DIR__, 3) . '/includes/seo-master.php';
$canon_abs = aus_absolute_url($canonical);
$aus_path = parse_url($canon_abs, PHP_URL_PATH) ?: '/auction/site/';
?>
<!DOCTYPE html>
<html lang="<?= bh_seo_master_html_lang($lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    bh_seo_master_render([
        'page_title'       => $page_title,
        'meta_description' => $page_desc,
        'canonical'        => $canon_abs,
        'path'             => $aus_path,
        'lang'             => $lang,
        'default_lang'     => 'no',
        'languages'        => ['no', 'en', 'uk'],
        'schema_type'      => 'cms',
        'schema_id_base'   => 'https://bilohash.com/auction/site',
        'site_name'        => $t['meta']['site_name'] ?? 'Auction CMS',
        'og_image'         => aus_seo_og_image(),
        'og_image_alt'     => $page_title,
        'keywords'         => $t['meta']['keywords'] ?? '',
        'render_viewport'  => false,
        'software'         => [
            'name'                 => 'Auction CMS',
            'description'          => $page_desc,
            'url'                  => $canon_abs,
            'download_url'         => 'https://bilohash.com/auction/',
            'version'              => '2.0',
            'price'                => '0',
            'price_currency'       => 'NOK',
            'application_category' => 'BusinessApplication',
            'service_type'         => 'Order auction website development — Norway & Europe',
        ],
        'breadcrumb'       => [
            ['name' => 'BILOHASH', 'url' => 'https://bilohash.com/'],
            ['name' => 'Auction CMS', 'url' => $canon_abs],
        ],
    ]);
    ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(aus_asset('css/site.css')) ?>?v=2">
    <?php if (!empty($cms_prefix) && $cms_prefix !== 'fl'): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars(cms_contact_stylesheet_href()) ?>">
    <?php endif; ?>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%230a1628' width='100' height='100' rx='12'/><text x='50' y='58' font-size='36' text-anchor='middle' fill='%23f59e0b' font-family='sans-serif' font-weight='bold'>A</text></svg>">
</head>
<body>
<?php require dirname(__DIR__, 3) . '/includes/ecosystem-top-bar.php'; ?>
<header class="aus-header" id="ausHeader">
    <div class="aus-header-inner">
        <a href="<?= aus_url('index.php') ?>" class="aus-logo">
            <span class="aus-logo-icon">A</span>
            <span class="aus-logo-text">Auction <em>CMS</em></span>
        </a>
        <nav class="aus-nav" aria-label="Main">
            <a href="<?= aus_url('index.php#features') ?>"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="<?= aus_url('index.php#tech') ?>"><?= htmlspecialchars($t['nav']['tech']) ?></a>
            <a href="<?= aus_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a>
        </nav>
        <div class="aus-header-tools">
            <?php require __DIR__ . '/lang-dropdown.php'; ?>
            <button class="aus-menu-toggle" id="ausMenuBtn" aria-label="Menu" type="button" aria-expanded="false" aria-controls="ausMobilePanel">
                <i class="fas fa-bars aus-menu-icon-open" aria-hidden="true"></i>
                <i class="fas fa-times aus-menu-icon-close" aria-hidden="true"></i>
            </button>
        </div>
        <div class="aus-header-actions">
            <a href="<?= aus_demo_url() ?>" class="aus-btn-ghost"><i class="fas fa-gavel"></i> <?= htmlspecialchars($t['demo']['frontend']) ?></a>
            <a href="<?= aus_demo_url('admin/login.php') ?>" class="aus-btn-ghost"><i class="fas fa-lock"></i> <?= htmlspecialchars($t['nav']['admin']) ?></a>
            <a href="<?= aus_url('contact.php') ?>" class="aus-btn-primary"><i class="fas fa-comments"></i> <?= htmlspecialchars($cms_nav_discuss) ?></a>
        </div>
    </div>
    <div class="aus-mobile-panel" id="ausMobilePanel" hidden>
        <nav class="aus-nav-mobile" aria-label="Mobile">
            <a href="<?= aus_url('index.php#features') ?>"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="<?= aus_url('index.php#tech') ?>"><?= htmlspecialchars($t['nav']['tech']) ?></a>
            <a href="<?= aus_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a>
        </nav>
        <div class="aus-mobile-actions">
            <a href="<?= aus_demo_url() ?>" class="aus-btn-primary"><?= htmlspecialchars($t['hero']['cta_demo']) ?></a>
            <a href="<?= aus_demo_url('admin/login.php') ?>" class="aus-btn-outline"><?= htmlspecialchars($t['hero']['cta_admin']) ?></a>
            <a href="<?= aus_url('contact.php') ?>" class="aus-btn-ghost"><?= htmlspecialchars($cms_nav_discuss) ?></a>
        </div>
    </div>
</header>
<div class="aus-overlay" id="ausOverlay" hidden></div>