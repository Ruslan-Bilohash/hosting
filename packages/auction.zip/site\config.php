<?php
/**
 * Auction CMS — product marketing site
 * /auction/site
 */
require_once dirname(__DIR__) . '/config.php';

define('AUS_BASE_PATH', '/auction/site');
define('AUS_PRODUCT_NAME', 'Auction CMS');
define('AUS_PARENT_PATH', '/auction');

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, AU_DOMAIN) !== false) ? AUS_BASE_PATH : ($detected ?: AUS_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';
$screen_url = AUS_PARENT_PATH . '/screen';

function aus_url(string $path = ''): string
{
    global $base_path;
    return rtrim($base_path, '/') . '/' . ltrim($path, '/');
}

function aus_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function aus_screen(string $file): string
{
    global $screen_url;
    return $screen_url . '/' . ltrim($file, '/');
}

function aus_demo_url(string $path = ''): string
{
    global $host, $protocol;
    return rtrim($protocol . '://' . $host . AUS_PARENT_PATH, '/') . '/' . ltrim($path, '/');
}