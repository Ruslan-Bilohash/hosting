<?php
require_once __DIR__ . '/init.php';
au_admin_require();
$admin_page = 'lots';

$id = $_GET['id'] ?? '';
$list = au_load_lots_raw();
$idx = null;
$lot = null;
foreach ($list as $i => $l) {
    if ($l['id'] === $id) {
        $idx = $i;
        $lot = $l;
        break;
    }
}
if ($lot === null) {
    header('Location: ' . au_admin_url('lots.php'), true, 302);
    exit;
}

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $list[$idx]['start_price']   = max(0, (int)($_POST['start_price'] ?? $lot['start_price']));
    $list[$idx]['current_bid']   = max(0, (int)($_POST['current_bid'] ?? $lot['current_bid']));
    $list[$idx]['bid_increment'] = max(50, (int)($_POST['bid_increment'] ?? $lot['bid_increment']));
    $list[$idx]['bids_count']    = max(0, (int)($_POST['bids_count'] ?? $lot['bids_count']));
    $list[$idx]['ends_at']       = trim($_POST['ends_at'] ?? $lot['ends_at']);
    $list[$idx]['active']        = !empty($_POST['active']);
    $list[$idx]['featured']      = !empty($_POST['featured']);
    $list[$idx]['category']      = in_array($_POST['category'] ?? '', au_categories(), true) ? $_POST['category'] : $lot['category'];
    foreach (['en', 'no', 'uk'] as $lc) {
        if (!empty($_POST['name_' . $lc])) {
            $list[$idx]['name'][$lc] = trim($_POST['name_' . $lc]);
        }
    }
    if (au_save_lots($list)) {
        $flash = 'success';
        $lot = $list[$idx];
    } else {
        $flash = 'error';
    }
}

$page_title = ($ta['edit'] ?? 'Edit') . ': ' . ($lot['name']['en'] ?? $id);
require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['saved']) ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error']) ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($lot['name']['en'] ?? $id) ?></h2>
        <a href="<?= au_admin_url('lots.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['cancel']) ?></a>
    </div>
    <div class="adm-card-body padded">
        <form method="post">
            <div style="display:flex;gap:20px;margin-bottom:20px;flex-wrap:wrap">
                <img src="<?= htmlspecialchars(au_lot_image($lot)) ?>" alt="" style="width:200px;height:140px;object-fit:cover;border-radius:8px;border:1px solid var(--adm-border)" onerror="this.onerror=null;this.src='<?= htmlspecialchars(au_placeholder_image()) ?>';">
                <div style="font-size:13px;color:var(--adm-muted)">
                    <strong>ID:</strong> <?= htmlspecialchars($lot['id']) ?><br>
                    <?= htmlspecialchars($lot['city']['en'] ?? '') ?>, <?= htmlspecialchars($lot['country']['en'] ?? '') ?><br>
                    <a href="<?= au_url('lot.php?id=' . urlencode($lot['id'])) ?>" target="_blank">View on site →</a>
                </div>
            </div>

            <div class="adm-form-grid">
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['name_en']) ?> (EN)</label>
                    <input type="text" name="name_en" value="<?= htmlspecialchars($lot['name']['en'] ?? '') ?>">
                </div>
                <div class="adm-field">
                    <label>Name (NO)</label>
                    <input type="text" name="name_no" value="<?= htmlspecialchars($lot['name']['no'] ?? '') ?>">
                </div>
                <div class="adm-field">
                    <label>Name (UK)</label>
                    <input type="text" name="name_uk" value="<?= htmlspecialchars($lot['name']['uk'] ?? '') ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['category']) ?></label>
                    <select name="category">
                        <?php foreach (au_categories() as $cat): ?>
                        <option value="<?= $cat ?>" <?= ($lot['category'] ?? '') === $cat ? 'selected' : '' ?>><?= htmlspecialchars($t['categories'][$cat]) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['start_price']) ?></label>
                    <input type="number" name="start_price" min="0" step="100" value="<?= (int)($lot['start_price'] ?? 0) ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['current_bid']) ?></label>
                    <input type="number" name="current_bid" min="0" step="100" value="<?= (int)($lot['current_bid'] ?? 0) ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['increment']) ?></label>
                    <input type="number" name="bid_increment" min="50" step="50" value="<?= (int)($lot['bid_increment'] ?? 100) ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['bids_count']) ?></label>
                    <input type="number" name="bids_count" min="0" value="<?= (int)($lot['bids_count'] ?? 0) ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['ends_at']) ?></label>
                    <input type="text" name="ends_at" value="<?= htmlspecialchars($lot['ends_at'] ?? '') ?>" placeholder="2026-06-28T18:00:00+02:00">
                </div>
                <div class="adm-field" style="display:flex;align-items:center;gap:8px;padding-top:24px">
                    <input type="checkbox" name="active" id="active" value="1" <?= ($lot['active'] ?? true) !== false ? 'checked' : '' ?>>
                    <label for="active" style="margin:0"><?= htmlspecialchars($ta['active']) ?></label>
                </div>
                <div class="adm-field" style="display:flex;align-items:center;gap:8px;padding-top:24px">
                    <input type="checkbox" name="featured" id="featured" value="1" <?= !empty($lot['featured']) ? 'checked' : '' ?>>
                    <label for="featured" style="margin:0"><?= htmlspecialchars($ta['featured']) ?></label>
                </div>
            </div>
            <div style="margin-top:20px">
                <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save']) ?></button>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>