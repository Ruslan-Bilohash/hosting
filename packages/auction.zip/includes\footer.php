</main>
<?php require_once dirname(__DIR__, 2) . '/includes/cms-contact.php';
$ft = $t['footer'] ?? [];
$au_discuss = cms_contact_texts('auction', $lang)['nav_discuss'];

if (empty($au_skip_ecosystem) && is_file(__DIR__ . '/ecosystem-strip.php')) {
    require __DIR__ . '/ecosystem-strip.php';
}
?>
<footer class="au-footer" itemscope itemtype="https://schema.org/WPFooter">
    <div class="au-footer-inner">
        <div class="au-footer-grid">
            <div>
                <h4><?= htmlspecialchars($ft['about'] ?? 'Auction CMS') ?></h4>
                <p class="au-footer-text"><?= htmlspecialchars($ft['demo'] ?? '') ?></p>
            </div>
            <div>
                <h4><?= htmlspecialchars($ft['crosslinks'] ?? 'Links') ?></h4>
                <ul>
                    <li><a href="<?= au_url('site/') ?>" rel="related"><?= htmlspecialchars($ft['product_page'] ?? 'Product page') ?></a></li>
                    <li><a href="<?= au_url('contact.php') ?>"><?= htmlspecialchars($au_discuss) ?></a></li>
                    <li><a href="https://bilohash.com/" rel="author"><?= htmlspecialchars($ft['order_dev'] ?? 'Order development') ?></a></li>
                    <li><a href="<?= au_url('admin/login.php') ?>"><?= htmlspecialchars($ft['admin_demo'] ?? 'Admin demo') ?></a></li>
                </ul>
            </div>
            <?php if (!empty($t['ecosystem']['items'])): ?>
            <div>
                <h4><?= htmlspecialchars($ft['ecosystem'] ?? 'Ecosystem') ?></h4>
                <ul>
                    <?php foreach ($t['ecosystem']['items'] as $eco): ?>
                    <li><a href="<?= htmlspecialchars($eco['demo']) ?>" rel="related"><?= htmlspecialchars($eco['name']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            <div>
                <h4><?= htmlspecialchars($ft['support'] ?? 'Support') ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/"><?= htmlspecialchars($t['nav']['help'] ?? 'Help') ?></a></li>
                    <li><a href="<?= au_url('search.php') ?>"><?= htmlspecialchars($t['nav']['live'] ?? 'Live') ?></a></li>
                    <li><a href="<?= au_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a></li>
                </ul>
            </div>
            <div>
                <h4><?= htmlspecialchars($ft['legal'] ?? 'Legal') ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/website/privacy-policy.php"><?= htmlspecialchars($ft['privacy'] ?? 'Privacy') ?></a></li>
                    <li><a href="https://bilohash.com/website/cookies.php"><?= htmlspecialchars($ft['terms'] ?? 'Terms') ?></a></li>
                    <li><a href="https://bilohash.com/"><?= htmlspecialchars($ft['portfolio'] ?? 'Portfolio') ?></a></li>
                    <li><a href="<?= au_url('llms.txt') ?>">llms.txt</a></li>
                    <li><a href="<?= au_url('sitemap.php') ?>">Sitemap</a></li>
                </ul>
            </div>
        </div>
        <?php if (!empty($t['ecosystem']['items'])): ?>
        <div class="au-footer-ecosystem">
            <span class="au-footer-eco-label"><?= htmlspecialchars($ft['related_products'] ?? 'Related products') ?>:</span>
            <?php foreach ($t['ecosystem']['items'] as $eco): ?>
            <a href="<?= htmlspecialchars($eco['demo']) ?>" rel="related" title="<?= htmlspecialchars($eco['name']) ?>"><?= htmlspecialchars($eco['short'] ?? $eco['name']) ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="au-footer-bottom">
            <?= sprintf(htmlspecialchars($ft['copyright'] ?? '© %s Auction CMS Demo.'), date('Y')) ?>
        </div>
    </div>
</footer>
<script src="<?= htmlspecialchars(au_asset('js/main.js')) ?>?v=6" defer></script>
<?php bh_cms_render_chat_widget('Auction CMS', au_site_settings(), $lang ?? 'en'); ?>
</body>
</html>