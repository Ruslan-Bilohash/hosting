<?php

if (!function_exists('bh_str_lower')) {
    function bh_str_lower(string $s): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
    }
}

function au_vertical_defs(): array
{
    static $defs = null;
    if ($defs === null) {
        $defs = require __DIR__ . '/../data/vertical-defs.php';
    }
    return $defs;
}

function au_use_case_slugs(): array
{
    return array_keys(au_vertical_defs());
}

function au_vertical_hub_label(string $lang): string
{
    $labels = [
        'no' => 'Auksjonstyper',
        'en' => 'Auction types',
        'uk' => 'Типи аукціонів',
        'ru' => 'Типы аукционов',
    ];
    return $labels[$lang] ?? $labels['en'];
}

function au_verticals_build(): array
{
    $defs = au_vertical_defs();
    $tpl = [
        'no' => [
            'title' => 'Bestill %s plattform Norge | Auction CMS',
            'description' => 'Auction CMS — PHP auksjonsplattform for %s i Norge og Europa. Live budgivning, adminpanel, SEO og demo. Bestill skreddersydd auksjonsløsning.',
            'keywords' => 'bestill %s Norge, PHP auksjon %s, online auksjon Europa, Auction CMS, budgivningssystem, auksjonsnettsted Norge',
            'subtitle' => 'Profesjonell PHP auksjonsplattform for %s',
            'intro' => 'Auction CMS er en modulær PHP-løsning for tidsbegrensede %s. 14 demo-lotter, nedtelling, budskjema, adminpanel med diagrammer og CSV-eksport — klar for betaling, KYC og white-label.',
            'cta' => 'Trenger du en auksjonsplattform for %s? Kontakt oss for tilbud.',
            'h1' => 'Auction CMS — %s',
        ],
        'en' => [
            'title' => 'Order %s Platform Norway | Auction CMS',
            'description' => 'Auction CMS — PHP auction platform for %s in Norway & Europe. Live bidding, admin panel, SEO and demo. Order a custom auction solution.',
            'keywords' => 'order %s Norway, PHP auction %s, online bidding Europe, Auction CMS, auction website development',
            'subtitle' => 'Professional PHP auction platform for %s',
            'intro' => 'Auction CMS is a modular PHP solution for timed %s. 14 demo lots, countdown, bid form, admin dashboard with charts and CSV export — ready for payments, KYC and white-label.',
            'cta' => 'Need an auction platform for %s? Contact us for a quote.',
            'h1' => 'Auction CMS — %s',
        ],
        'uk' => [
            'title' => 'Замовити платформу %s | Auction CMS',
            'description' => 'Auction CMS — PHP-платформа аукціонів для %s у Норвегії та Європі. Live-торги, адмін-панель, SEO та демо. Замовити індивідуальне рішення.',
            'keywords' => 'замовити %s Норвегія, PHP аукціон %s, онлайн торги Європа, Auction CMS, розробка аукціонного сайту',
            'subtitle' => 'Професійна PHP-платформа аукціонів для %s',
            'intro' => 'Auction CMS — модульне PHP-рішення для %s з таймером. 14 демо-лотів, зворотний відлік, форма ставок, адмін-дашборд і CSV-експорт — готово до оплати, KYC та white-label.',
            'cta' => 'Потрібна аукціонна платформа для %s? Зв\'яжіться для пропозиції.',
            'h1' => 'Auction CMS — %s',
        ],
        'ru' => [
            'title' => 'Заказать платформу %s | Auction CMS',
            'description' => 'Auction CMS — PHP-платформа аукционов для %s в Норвегии и Европе. Live-торги, админ-панель, SEO и демо. Закажите индивидуальное решение.',
            'keywords' => 'заказать %s Норвегия, PHP аукцион %s, онлайн торги Европа, Auction CMS, разработка аукционного сайта',
            'subtitle' => 'Профессиональная PHP-платформа аукционов для %s',
            'intro' => 'Auction CMS — модульное PHP-решение для %s с таймером. 14 демо-лотов, обратный отсчёт, форма ставок, админ-дашборд и CSV-экспорт — готово к оплате, KYC и white-label.',
            'cta' => 'Нужна аукционная платформа для %s? Свяжитесь для предложения.',
            'h1' => 'Auction CMS — %s',
        ],
    ];
    $benefits = [
        'no' => [
            ['title' => 'Live budgivning', 'text' => 'Nedtelling i sanntid, minstebud og anti-sniping — trygg opplevelse for kjøpere.'],
            ['title' => 'Rike objektsider', 'text' => 'Faner, estimater, tilstandsnotater, budhistorikk og relaterte objekter.'],
            ['title' => 'Kraftig admin', 'text' => 'Dashbord, kategorier, innstillinger, filtre og CSV-eksport av bud.'],
            ['title' => 'SEO for Norge/Europa', 'text' => 'Hreflang, Schema.org, sitemap og dedikerte landingssider per auksjonstype.'],
        ],
        'en' => [
            ['title' => 'Live bidding', 'text' => 'Real-time countdown, minimum bids and anti-sniping — trusted buyer experience.'],
            ['title' => 'Rich lot pages', 'text' => 'Tabs, estimates, condition notes, bid history and related lots.'],
            ['title' => 'Powerful admin', 'text' => 'Dashboard, categories, settings, filters and CSV bid export.'],
            ['title' => 'SEO for Norway/Europe', 'text' => 'Hreflang, Schema.org, sitemap and dedicated landing pages per auction type.'],
        ],
        'uk' => [
            ['title' => 'Live-торги', 'text' => 'Зворотний відлік у реальному часі, мінімальні ставки та anti-sniping.'],
            ['title' => 'Детальні лоти', 'text' => 'Вкладки, оцінки, стан, історія ставок і схожі лоти.'],
            ['title' => 'Потужна адмінка', 'text' => 'Дашборд, категорії, налаштування, фільтри та CSV-експорт ставок.'],
            ['title' => 'SEO для Норвегії/Європи', 'text' => 'Hreflang, Schema.org, sitemap і окремі лендінги для кожного типу аукціону.'],
        ],
        'ru' => [
            ['title' => 'Live-торги', 'text' => 'Обратный отсчёт в реальном времени, минимальные ставки и anti-sniping.'],
            ['title' => 'Детальные лоты', 'text' => 'Вкладки, оценки, состояние, история ставок и похожие лоты.'],
            ['title' => 'Мощная админка', 'text' => 'Дашборд, категории, настройки, фильтры и CSV-экспорт ставок.'],
            ['title' => 'SEO для Норвегии/Европы', 'text' => 'Hreflang, Schema.org, sitemap и лендинги на норвежском, английском, украинском и русском (NO/EN/UA/RU).'],
        ],
    ];
    $features = [
        'no' => ['14 demo-lotter med flerspråklige beskrivelser', 'Proxy-bud og budskjema', 'Mobil-først responsiv UI', 'Admin med diagrammer og ending soon', 'JSON-lagring — enkel migrering', 'Integrasjonsklar for Vipps/Stripe'],
        'en' => ['14 demo lots with multilingual descriptions', 'Proxy bids and bid form', 'Mobile-first responsive UI', 'Admin with charts and ending soon', 'JSON storage — easy migration', 'Integration-ready for Vipps/Stripe'],
        'uk' => ['14 демо-лотів з багатомовними описами', 'Proxy-ставки та форма торгів', 'Mobile-first адаптивний UI', 'Адмін з діаграмами та ending soon', 'JSON-сховище — легка міграція', 'Готово до Vipps/Stripe'],
        'ru' => ['14 демо-лотов с многоязычными описаниями', 'Proxy-ставки и форма торгов', 'Mobile-first адаптивный UI', 'Админ с диаграммами и ending soon', 'JSON-хранилище — лёгкая миграция', 'Готово к Vipps/Stripe'],
    ];
    $faq_q = [
        'no' => ['Passer Auction CMS for %s?', 'Støttes flere språk?', 'Kan jeg se en live demo?', 'Hvordan kommer jeg i gang?'],
        'en' => ['Is Auction CMS suitable for %s?', 'Are multiple languages supported?', 'Is there a live demo?', 'How do we get started?'],
        'uk' => ['Чи підходить Auction CMS для %s?', 'Чи є кілька мов?', 'Чи є live demo?', 'Як почати?'],
        'ru' => ['Подходит ли Auction CMS для %s?', 'Поддерживается ли несколько языков?', 'Есть ли live demo?', 'Как начать?'],
    ];
    $faq_a = [
        'no' => ['Ja. Plattformen tilpasses regler, kategorier, provisjon og betaling for %s i Norge og Europa.', 'Demo har norsk, engelsk og ukrainsk med korrekt hreflang og SEO per side.', 'Ja — bilohash.com/auction med admin demo / biloauction2026.', 'Kontakt bilohash.com med info om %s — vi foreslår arkitektur og pris.'],
        'en' => ['Yes. The platform adapts rules, categories, commission and payments for %s in Norway and Europe.', 'The demo includes Norwegian, English and Ukrainian with proper hreflang and per-page SEO.', 'Yes — bilohash.com/auction with admin demo / biloauction2026.', 'Contact bilohash.com with details about your %s — we propose architecture and pricing.'],
        'uk' => ['Так. Платформу налаштовують під правила, категорії, комісію та оплату для %s у Норвегії та Європі.', 'У демо — норвезька, англійська та українська з коректним hreflang і SEO.', 'Так — bilohash.com/auction, адмін demo / biloauction2026.', 'Зв\'яжіться через bilohash.com з деталями про %s — запропонуємо архітектуру та ціну.'],
        'ru' => ['Да. Платформу настраивают под правила, категории, комиссию и оплату для %s в Норвегии и Европе.', 'В демо — норвежский, английский, украинский и русский (NO/EN/UA/RU) с корректным hreflang и SEO.', 'Да — bilohash.com/auction, админ demo / biloauction2026.', 'Свяжитесь через bilohash.com с деталями о %s — предложим архитектуру и цену.'],
    ];

    $ru_overrides = is_file(__DIR__ . '/../data/vertical-seo-ru.php')
        ? require __DIR__ . '/../data/vertical-seo-ru.php'
        : [];

    $out = [];
    foreach ($defs as $slug => $def) {
        $entry = ['icon' => $def['icon'], 'demo_category' => $def['demo_category']];
        foreach (['no', 'en', 'uk', 'ru'] as $lng) {
            $name = $def[$lng];
            $lower = bh_str_lower($name);
            $t = $tpl[$lng];
            $faqs = [];
            foreach ($faq_q[$lng] as $i => $q) {
                $faqs[] = ['q' => sprintf($q, $lower), 'a' => sprintf($faq_a[$lng][$i], $lower)];
            }
            $entry[$lng] = [
                'title' => sprintf($t['title'], $name),
                'description' => sprintf($t['description'], $lower),
                'keywords' => sprintf($t['keywords'], $lower, $lower),
                'h1' => sprintf($t['h1'], $name),
                'subtitle' => sprintf($t['subtitle'], $lower),
                'intro' => sprintf($t['intro'], $lower),
                'benefits' => $benefits[$lng],
                'features' => $features[$lng],
                'faq' => $faqs,
                'cta' => sprintf($t['cta'], $lower),
            ];
            if ($lng === 'ru' && isset($ru_overrides[$slug]) && is_array($ru_overrides[$slug])) {
                $entry[$lng] = array_merge($entry[$lng], $ru_overrides[$slug]);
            }
        }
        $out[$slug] = $entry;
    }
    return $out;
}

function au_verticals_all(): array
{
    static $cache = null;
    if ($cache === null) {
        $file = __DIR__ . '/../data/verticals.php';
        $cache = is_file($file) ? require $file : au_verticals_build();
    }
    return $cache;
}

function au_vertical_slugs(): array
{
    return array_keys(au_verticals_all());
}

function au_vertical_by_slug(string $slug): ?array
{
    $all = au_verticals_all();
    return $all[$slug] ?? null;
}

function au_vertical_lang(array $vertical, string $lang): array
{
    $lang = in_array($lang, ['no', 'en', 'uk', 'ru'], true) ? $lang : 'no';
    return $vertical[$lang] ?? $vertical['no'] ?? [];
}

function au_vertical_url(string $slug, ?string $lang = null): string
{
    $path = au_url($slug . '/');
    if ($lang && $lang !== 'no') {
        return $path . '?lang=' . urlencode($lang);
    }
    return $path;
}

function au_vertical_canonical(string $slug): string
{
    global $site_url, $lang;
    $base = rtrim($site_url, '/') . '/' . $slug . '/';
    return $lang !== 'no' ? $base . '?lang=' . $lang : $base;
}

function au_vertical_lang_url_for(string $slug, string $code): string
{
    return au_vertical_url($slug, $code === 'no' ? null : $code);
}

function au_seo_faq_page(array $items): array
{
    $entities = [];
    foreach ($items as $item) {
        $entities[] = [
            '@type'          => 'Question',
            'name'           => $item['q'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text'  => $item['a'],
            ],
        ];
    }
    return [
        '@type'            => 'FAQPage',
        'mainEntity'       => $entities,
    ];
}

function au_seo_vertical_service(string $name, string $description, string $canonical): array
{
    return [
        '@type'       => 'Service',
        '@id'         => $canonical . '#service',
        'name'        => $name,
        'description' => $description,
        'url'         => $canonical,
        'provider'    => ['@id' => 'https://bilohash.com/auction/#organization'],
        'areaServed'  => [
            ['@type' => 'Country', 'name' => 'Norway'],
            ['@type' => 'Country', 'name' => 'Ukraine'],
            ['@type' => 'Place', 'name' => 'Europe'],
        ],
        'serviceType' => 'Online auction platform development',
    ];
}

function au_render_vertical_seo_head(
    string $page_title,
    string $page_desc,
    string $canonical,
    array $schema_graphs = [],
    ?string $page_keywords = null,
    ?string $og_image = null
): void {
    global $lang_meta, $lang;
    $og_image = $og_image ?: au_seo_og_image();
    $canonical_abs = au_absolute_url($canonical);
    $robots = 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    $slug = $GLOBALS['vertical_slug'] ?? '';
    $vertical_hreflang = [];
    foreach (['no', 'en', 'uk', 'ru'] as $code) {
        $info = au_langs()[$code] ?? null;
        $vertical_hreflang[] = [
            'hreflang' => $info['locale'] ?? $code,
            'href'     => au_absolute_url(au_vertical_lang_url_for($slug, $code)),
        ];
    }
    require_once dirname(__DIR__, 2) . '/includes/seo-master.php';
    bh_seo_master_render([
        'page_title'          => $page_title,
        'meta_description'    => $page_desc,
        'canonical'           => $canonical_abs,
        'path'                => parse_url($canonical_abs, PHP_URL_PATH) ?: '/auction/',
        'lang'                => $lang,
        'default_lang'        => 'no',
        'languages'           => [],
        'hreflang_alternates' => $vertical_hreflang,
        'hreflang_x_default'  => au_absolute_url(au_vertical_lang_url_for($slug, 'no')),
        'schema_id_base'      => 'https://bilohash.com/auction',
        'site_name'           => AU_SITE_NAME,
        'og_image'            => $og_image,
        'og_image_alt'        => $page_title,
        'keywords'            => $page_keywords ?? '',
        'render_viewport'     => false,
        'schema_mode'         => 'extend',
        'extra_schema'        => $schema_graphs,
    ]);
}