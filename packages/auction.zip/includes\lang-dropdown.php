<?php
/** Language dropdown — expects $lang, au_langs(), au_lang_url() */
$current = au_langs()[$lang] ?? au_langs()['no'];
?>
<div class="au-lang-dropdown" id="auLangDropdown">
    <button type="button" class="au-lang-dropdown-btn" id="auLangBtn" aria-expanded="false" aria-haspopup="listbox" aria-controls="auLangMenu">
        <span class="au-lang-dropdown-current"><?= $current['flag'] ?> <?= htmlspecialchars($current['label']) ?></span>
        <i class="fas fa-chevron-down" aria-hidden="true"></i>
    </button>
    <ul class="au-lang-dropdown-menu" id="auLangMenu" role="listbox" hidden>
        <?php foreach (au_langs() as $code => $info): ?>
        <li role="option">
            <a href="<?= htmlspecialchars(au_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>" <?= $lang === $code ? 'aria-current="true"' : '' ?>>
                <span class="au-lang-flag"><?= $info['flag'] ?></span>
                <span class="au-lang-name"><?= htmlspecialchars($info['name']) ?></span>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
</div>