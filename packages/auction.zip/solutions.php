<?php
require_once __DIR__ . '/init.php';
if (!function_exists('bh_str_sub')) {
    function bh_str_sub(string $str, int $start, ?int $length = null): string
    {
        if (function_exists('mb_substr')) {
            return $length === null ? mb_substr($str, $start) : mb_substr($str, $start, $length);
        }
        return $length === null ? substr($str, $start) : substr($str, $start, $length);
    }
}

$current_page = 'solutions';
$all = au_verticals_all();

$langCopy = [
    'page_title' => [
        'no' => 'Auksjonstyper Norge | Auction CMS',
        'en' => 'Auction Types Norway | Auction CMS',
        'uk' => 'Типи аукціонів | Auction CMS',
        'ru' => 'Типы аукционов | Auction CMS',
    ],
    'page_desc' => [
        'no' => 'PHP auksjonsplattform for veldedighet, kunst & antikviteter, dødsbo, industrielt overskudd, samleobjekter, kjøretøy, galla og B2B. Flerspråklig SEO for Norge, Europa og Ukraina.',
        'en' => 'PHP auction platform for charity, art & antiques, estate sales, industrial surplus, collectibles, vehicles, galas and B2B tenders. Multilingual SEO for Norway, Europe and Ukraine.',
        'uk' => 'PHP-платформа аукціонів для благодійності, мистецтва, спадщини, промисловості, колекцій, авто, гала та B2B. SEO для Норвегії, Європи та України.',
        'ru' => 'PHP-платформа аукционов: благотворительные аукционы, искусство и антиквариат, распродажи наследства, промышленные остатки, коллекционные предметы, автоаукционы, гала-аукционы и B2B-тендеры. SEO для Норвегии, Европы и Украины.',
    ],
    'breadcrumb' => [
        'no' => 'Auksjonstyper',
        'en' => 'Auction types',
        'uk' => 'Типи аукціонів',
        'ru' => 'Типы аукционов',
    ],
    'hub_h1' => [
        'no' => 'Auksjonstyper for Norge & Europa',
        'en' => 'Auction types for Norway & Europe',
        'uk' => 'Типи аукціонів для Норвегії та Європи',
        'ru' => 'Типы аукционов для Норвегии и Европы',
    ],
    'hub_sub' => [
        'no' => '8 dedikerte SEO-sider — veldedighet, kunst & antikviteter, dødsbo, industri, samleobjekter, kjøretøy, galla og B2B. Norsk, engelsk, ukrainsk og russisk.',
        'en' => '8 dedicated SEO pages — charity, art & antiques, estate sales, industrial surplus, collectibles, vehicles, galas and B2B. Norwegian, English, Ukrainian and Russian.',
        'uk' => '8 окремих SEO-сторінок — благодійність, мистецтво, спадщина, промисловість, колекції, авто, гала та B2B. NO, EN, UA, RU.',
        'ru' => '8 отдельных SEO-страниц — благотворительность, искусство, наследство, промышленность, коллекции, авто, гала и B2B. NO, EN, UA, RU.',
    ],
];

$page_title = $langCopy['page_title'][$lang] ?? $langCopy['page_title']['en'];
$page_desc  = $langCopy['page_desc'][$lang] ?? $langCopy['page_desc']['en'];
$canonical = $site_url . '/solutions.php' . ($lang !== 'no' ? '?lang=' . $lang : '');
$canon_abs = au_absolute_url($canonical);
$seo_schemas = [
    au_seo_organization(),
    au_seo_webpage($canon_abs, $page_title, $page_desc),
    au_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => au_absolute_url(au_url('index.php'))],
        ['name' => $langCopy['breadcrumb'][$lang] ?? $langCopy['breadcrumb']['en'], 'url' => $canon_abs],
    ]),
];
require __DIR__ . '/includes/header.php';
$hub_h1 = $langCopy['hub_h1'][$lang] ?? $langCopy['hub_h1']['en'];
$hub_sub = $langCopy['hub_sub'][$lang] ?? $langCopy['hub_sub']['en'];
?>

<div class="au-container au-solutions-hub">
    <h1 class="au-page-title"><?= htmlspecialchars($hub_h1) ?></h1>
    <p class="au-results-meta"><?= htmlspecialchars($hub_sub) ?></p>
    <div class="au-vertical-links au-solutions-grid">
        <?php
        $vdefs = au_vertical_defs();
        foreach ($all as $slug => $item):
            $lv = au_vertical_lang($item, $lang);
            $short = $vdefs[$slug][$lang] ?? $vdefs[$slug]['en'] ?? ($lv['h1'] ?? $slug);
        ?>
        <a href="<?= htmlspecialchars(au_vertical_url($slug)) ?>" class="au-vertical-link-card">
            <i class="fas fa-<?= htmlspecialchars($item['icon'] ?? 'gavel') ?>"></i>
            <strong><?= htmlspecialchars($short) ?></strong>
            <span><?= htmlspecialchars(bh_str_sub($lv['subtitle'] ?? '', 0, 90)) ?>…</span>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>