<?php
require_once __DIR__ . '/init.php';
$current_page = 'search';
$search_params = au_search_params();
$results = au_filter_lots($search_params, $lang);
$page_title = $t['search_page']['title'] . ($search_params['q'] ? ' — ' . $search_params['q'] : '');
$page_desc  = sprintf($t['search_page']['found'], count($results)) . '. ' . $t['meta']['description'];
$canonical = $site_url . '/search.php?' . http_build_query(array_filter($search_params));
$canon_abs = au_absolute_url($canonical);
$seo_noindex = true;
$seo_schemas = [
    au_seo_webpage($canon_abs, $page_title, $page_desc),
    au_seo_item_list($results, $lang, $canon_abs),
    au_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => au_absolute_url(au_url('index.php'))],
        ['name' => $t['search_page']['title'], 'url' => $canon_abs],
    ]),
];
require __DIR__ . '/includes/header.php';
?>

<section class="au-hero au-hero-compact">
    <div class="au-hero-inner">
        <?php require __DIR__ . '/includes/search-form.php'; ?>
    </div>
</section>

<div class="au-container">
    <div class="au-search-layout">
        <aside class="au-filters" id="auFilters" aria-label="<?= htmlspecialchars($t['search_page']['filter']) ?>">
            <h3><?= htmlspecialchars($t['search_page']['filter']) ?></h3>
            <form method="get" action="<?= au_url('search.php') ?>">
                <input type="hidden" name="q" value="<?= htmlspecialchars($search_params['q']) ?>">
                <div class="au-filter-group">
                    <label><?= htmlspecialchars($t['search_page']['category']) ?></label>
                    <select name="category" onchange="this.form.submit()">
                        <option value=""><?= htmlspecialchars($t['search_page']['all']) ?></option>
                        <?php foreach (au_categories() as $cat): ?>
                        <option value="<?= $cat ?>" <?= $search_params['category'] === $cat ? 'selected' : '' ?>><?= htmlspecialchars($t['categories'][$cat]) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="au-filter-group">
                    <label><?= htmlspecialchars($t['search_page']['status']) ?></label>
                    <select name="status" onchange="this.form.submit()">
                        <option value=""><?= htmlspecialchars($t['search_page']['status_all']) ?></option>
                        <option value="live" <?= $search_params['status'] === 'live' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['status_live']) ?></option>
                        <option value="ending" <?= $search_params['status'] === 'ending' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['status_end']) ?></option>
                    </select>
                </div>
                <div class="au-filter-group">
                    <label><?= htmlspecialchars($t['search_page']['sort']) ?></label>
                    <select name="sort" onchange="this.form.submit()">
                        <option value="ending" <?= $search_params['sort'] === 'ending' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_ending']) ?></option>
                        <option value="bid_low" <?= $search_params['sort'] === 'bid_low' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_bid_l']) ?></option>
                        <option value="bid_high" <?= $search_params['sort'] === 'bid_high' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_bid_h']) ?></option>
                        <option value="newest" <?= $search_params['sort'] === 'newest' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_new']) ?></option>
                    </select>
                </div>
                <div class="au-filter-group">
                    <label><?= htmlspecialchars($t['search_page']['price']) ?> (min)</label>
                    <input type="number" name="min_bid" value="<?= (int)$search_params['min_bid'] ?>" min="0" step="500" placeholder="0">
                </div>
                <div class="au-filter-group">
                    <label><?= htmlspecialchars($t['search_page']['price']) ?> (max)</label>
                    <input type="number" name="max_bid" value="<?= (int)$search_params['max_bid'] ?>" min="0" step="500" placeholder="500000">
                </div>
                <button type="submit" class="au-btn-gold" style="width:100%"><?= htmlspecialchars($t['search']['search_btn']) ?></button>
            </form>
        </aside>

        <div class="au-results-col">
            <div class="au-results-header">
                <div class="au-results-heading-wrap">
                    <h1 class="au-results-heading">
                        <span><?= htmlspecialchars($t['search_page']['title']) ?></span>
                        <span class="au-results-badge" aria-label="<?= sprintf(htmlspecialchars($t['search_page']['found']), count($results)) ?>"><?= count($results) ?></span>
                    </h1>
                    <p class="au-results-sub"><?= sprintf(htmlspecialchars($t['search_page']['found']), count($results)) ?></p>
                    <?php if ($search_params['q']): ?>
                    <p class="au-results-meta"><i class="fas fa-search" aria-hidden="true"></i> <?= htmlspecialchars($search_params['q']) ?></p>
                    <?php endif; ?>
                </div>
                <button type="button" class="au-filter-toggle" id="auFilterToggle" aria-expanded="false" aria-controls="auFilters"
                    data-label-open="<?= htmlspecialchars($t['search_page']['filter_open']) ?>"
                    data-label-close="<?= htmlspecialchars($t['search_page']['filter_close']) ?>">
                    <i class="fas fa-sliders-h" aria-hidden="true"></i>
                    <span><?= htmlspecialchars($t['search_page']['filter_open']) ?></span>
                </button>
            </div>

            <?php if (empty($results)): ?>
            <div class="au-form-card au-empty-state">
                <i class="fas fa-gavel"></i>
                <p><?= htmlspecialchars($t['search_page']['no_results']) ?></p>
                <a href="<?= au_url('index.php') ?>" class="au-btn-gold"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
            </div>
            <?php else: ?>
            <div class="au-lot-grid au-lot-grid-list">
                <?php
                $lot_card_layout = 'list';
                foreach ($results as $lot):
                    require __DIR__ . '/includes/lot-card.php';
                endforeach;
                unset($lot_card_layout);
                ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>