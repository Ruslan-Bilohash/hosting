<?php
/** One-time builder — run: php data/_build_verticals.php */
require_once dirname(__DIR__) . '/includes/vertical-lib.php';

$out = au_verticals_build();
$export = "<?php\nreturn " . var_export($out, true) . ";\n";
file_put_contents(__DIR__ . '/verticals.php', $export);
echo "Written verticals.php with " . count($out) . " verticals\n";