<?php
/** @var array $lot */
/** @var array $t */
/** @var string $lang */
$detail_url = au_url('lot.php?id=' . urlencode($lot['id']));
$bid_url    = au_url('bid.php?id=' . urlencode($lot['id']));
$name       = au_localized($lot, 'name', $lang);
$city       = au_localized($lot, 'city', $lang);
$country    = au_localized($lot, 'country', $lang);
$desc       = au_localized($lot, 'desc', $lang);
$is_live    = au_lot_is_live($lot);
$ends_ts    = au_lot_ends_at($lot);
$cat        = $lot['category'] ?? '';
$layout     = $lot_card_layout ?? 'grid';
$card_class = 'au-lot-card' . ($layout === 'list' ? ' au-lot-card--list' : '');
?>
<article class="<?= $card_class ?>" data-ends="<?= (int)$ends_ts ?>">
    <div class="au-lot-img">
        <a href="<?= htmlspecialchars($detail_url) ?>">
            <img src="<?= htmlspecialchars(au_lot_image($lot)) ?>" alt="<?= htmlspecialchars($name) ?>" loading="lazy" width="320" height="220" onerror="this.onerror=null;this.src='<?= htmlspecialchars(au_placeholder_image()) ?>';">
        </a>
        <?php if ($is_live): ?>
        <span class="au-live-badge"><i class="fas fa-circle"></i> <?= htmlspecialchars($t['card']['live']) ?></span>
        <?php endif; ?>
        <?php if (!empty($lot['featured'])): ?>
        <span class="au-featured-badge"><i class="fas fa-star"></i></span>
        <?php endif; ?>
    </div>
    <div class="au-lot-body">
        <div class="au-lot-meta">
            <span class="au-cat-tag"><?= htmlspecialchars($t['categories'][$cat] ?? $cat) ?></span>
            <?php if ($is_live): ?>
            <span class="au-countdown" data-countdown="<?= (int)$ends_ts ?>">
                <i class="fas fa-clock"></i> <span class="au-countdown-val">--</span>
            </span>
            <?php else: ?>
            <span class="au-ended-tag"><?= htmlspecialchars($t['card']['ended']) ?></span>
            <?php endif; ?>
        </div>
        <h3><a href="<?= htmlspecialchars($detail_url) ?>"><?= htmlspecialchars($name) ?></a></h3>
        <div class="au-location"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($city) ?>, <?= htmlspecialchars($country) ?></div>
        <p class="au-desc-snippet"><?= htmlspecialchars(bh_str_sub($desc, 0, 100)) ?>…</p>
    </div>
    <div class="au-lot-side">
        <div class="au-bid-block">
            <div class="au-bid-label"><?= htmlspecialchars($t['card']['current_bid']) ?></div>
            <div class="au-bid-price"><?= au_price((int)($lot['current_bid'] ?? 0)) ?></div>
            <div class="au-bid-note">
                <?= (int)($lot['bids_count'] ?? 0) ?> <?= htmlspecialchars($t['card']['bids']) ?>
                · <?= !empty($lot['reserve_met']) ? htmlspecialchars($t['card']['reserve_met']) : htmlspecialchars($t['card']['reserve_not']) ?>
            </div>
            <a href="<?= htmlspecialchars($bid_url) ?>" class="au-btn-gold"><?= htmlspecialchars($t['card']['place_bid']) ?></a>
            <a href="<?= htmlspecialchars($detail_url) ?>" class="au-btn-ghost"><?= htmlspecialchars($t['card']['view_lot']) ?></a>
        </div>
    </div>
</article>