<?php

function au_protocol(): string
{
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    ) ? 'https' : 'http';
}

function au_host(): string
{
    return $_SERVER['HTTP_HOST'] ?? AU_DOMAIN;
}

function au_absolute_url(string $path): string
{
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return au_protocol() . '://' . au_host() . (str_starts_with($path, '/') ? $path : '/' . $path);
}

function au_full_lang_url(string $code): string
{
    return au_absolute_url(au_lang_url($code, true));
}

function au_seo_og_image(): string
{
    $local = __DIR__ . '/../assets/images/og-auction.jpg';
    if (is_file($local)) {
        return au_absolute_url(au_asset('images/og-auction.jpg'));
    }
    return 'https://bilohash.com/ruslan_cub.jpg';
}

function au_seo_hreflang(string $code): string
{
    $info = au_langs()[$code] ?? null;
    return $info['locale'] ?? $code;
}

function au_seo_contact(): array
{
    return [
        'telephone' => '+4746255885',
        'email'     => 'rbilohash@gmail.com',
        'locality'  => 'Drammen',
        'region'    => 'Viken',
        'country'   => 'NO',
        'lat'       => 59.7439,
        'lng'       => 10.2045,
    ];
}

function au_seo_author(): array
{
    return [
        '@type' => 'Organization',
        'name'  => AU_SITE_NAME,
        'url'   => 'https://bilohash.com/auction/',
    ];
}

function au_seo_organization(): array
{
    $contact = au_seo_contact();
    return [
        '@type' => 'Organization',
        '@id'   => 'https://bilohash.com/auction/#organization',
        'name'  => AU_SITE_NAME,
        'url'   => 'https://bilohash.com/auction/',
        'logo'  => 'https://bilohash.com/favicon.ico',
        'email' => $contact['email'],
        'telephone' => $contact['telephone'],
        'address' => [
            '@type' => 'PostalAddress',
            'addressLocality' => $contact['locality'],
            'addressRegion'   => $contact['region'],
            'addressCountry'  => $contact['country'],
        ],
        'areaServed' => ['NO', 'UA', 'EU'],
        'knowsAbout' => [
            'PHP auction scripts',
            'Online bidding platforms',
            'Auction website development Norway',
            'Multilingual SEO',
            'Schema.org structured data',
        ],
    ];
}

function au_seo_local_business(): array
{
    $contact = au_seo_contact();
    return [
        '@type' => 'LocalBusiness',
        '@id'   => 'https://bilohash.com/auction/#localbusiness',
        'name'  => 'Bilohash — Auction CMS',
        'url'   => 'https://bilohash.com/auction/',
        'image' => au_seo_og_image(),
        'telephone' => $contact['telephone'],
        'email' => $contact['email'],
        'address' => [
            '@type' => 'PostalAddress',
            'addressLocality' => $contact['locality'],
            'addressRegion'   => $contact['region'],
            'addressCountry'  => $contact['country'],
        ],
        'geo' => [
            '@type' => 'GeoCoordinates',
            'latitude'  => $contact['lat'],
            'longitude' => $contact['lng'],
        ],
        'areaServed' => [
            ['@type' => 'Country', 'name' => 'Norway'],
            ['@type' => 'Country', 'name' => 'Ukraine'],
            ['@type' => 'Place', 'name' => 'Europe'],
        ],
        'knowsLanguage' => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'priceRange' => '$$',
    ];
}

function au_seo_software_app(string $canonical, string $description): array
{
    return [
        '@type'               => 'SoftwareApplication',
        '@id'                 => $canonical . '#software',
        'name'                => AU_SITE_NAME,
        'applicationCategory' => 'BusinessApplication',
        'applicationSubCategory' => 'Online auction and bidding software',
        'operatingSystem'     => 'Web',
        'description'         => $description,
        'url'                 => $canonical,
        'image'               => au_seo_og_image(),
        'inLanguage'          => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'offers'              => [
            '@type'         => 'Offer',
            'price'         => '0',
            'priceCurrency' => 'NOK',
            'availability'  => 'https://schema.org/InStock',
            'url'           => 'https://bilohash.com/auction/',
        ],
        'author'    => au_seo_author(),
        'publisher' => au_seo_organization(),
        'featureList' => 'Multilingual frontend, lot search, live countdown, bid form, admin panel, JSON storage, Schema.org SEO, responsive UI',
    ];
}

function au_seo_website(string $canonical): array
{
    global $site_url;
    return [
        '@type' => 'WebSite',
        '@id'   => rtrim($site_url, '/') . '/#website',
        'name'  => AU_SITE_NAME,
        'url'   => rtrim($site_url, '/') . '/',
        'inLanguage' => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'publisher' => ['@id' => 'https://bilohash.com/auction/#organization'],
        'potentialAction' => [
            '@type'       => 'SearchAction',
            'target'      => [
                '@type'       => 'EntryPoint',
                'urlTemplate' => rtrim($site_url, '/') . '/search.php?q={search_term_string}',
            ],
            'query-input' => 'required name=search_term_string',
        ],
    ];
}

function au_seo_webpage(string $canonical, string $title, string $description): array
{
    global $lang;
    return [
        '@type'       => 'WebPage',
        '@id'         => $canonical . '#webpage',
        'url'         => $canonical,
        'name'        => $title,
        'description' => $description,
        'isPartOf'    => ['@id' => rtrim($GLOBALS['site_url'], '/') . '/#website'],
        'about'       => ['@id' => rtrim($GLOBALS['site_url'], '/') . '/#software'],
        'inLanguage'  => au_langs()[$lang]['locale'] ?? 'en-GB',
    ];
}

function au_seo_breadcrumbs(array $items): array
{
    $list = [];
    $pos = 1;
    foreach ($items as $item) {
        $entry = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => $item['name'],
        ];
        if (!empty($item['url'])) {
            $entry['item'] = $item['url'];
        }
        $list[] = $entry;
    }
    return [
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $list,
    ];
}

function au_seo_lot(array $lot, string $lang, string $canonical): array
{
    $name = au_localized($lot, 'name', $lang);
    $desc = au_localized($lot, 'desc', $lang);
    $city = au_localized($lot, 'city', $lang);
    $country = au_localized($lot, 'country', $lang);
    $current = (int)($lot['current_bid'] ?? $lot['start_price'] ?? 0);
    $ends = au_lot_ends_at($lot);

    return [
        '@type' => 'Product',
        '@id'   => $canonical . '#product',
        'name'  => $name,
        'description' => $desc,
        'url'   => $canonical,
        'image' => au_lot_image($lot),
        'category' => $lot['category'] ?? 'Auction lot',
        'brand' => [
            '@type' => 'Organization',
            'name'  => AU_SITE_NAME,
        ],
        'offers' => [
            '@type'           => 'Offer',
            '@id'             => $canonical . '#offer',
            'url'             => $canonical,
            'price'           => (string) $current,
            'priceCurrency'   => AU_CURRENCY,
            'availability'    => au_lot_is_live($lot)
                ? 'https://schema.org/InStock'
                : 'https://schema.org/SoldOut',
            'priceValidUntil' => date('c', $ends),
            'itemCondition'   => 'https://schema.org/UsedCondition',
            'seller'          => au_seo_organization(),
            'eligibleRegion'  => ['NO', 'EU'],
        ],
        'additionalProperty' => [
            [
                '@type' => 'PropertyValue',
                'name'  => 'Location',
                'value' => $city . ', ' . $country,
            ],
            [
                '@type' => 'PropertyValue',
                'name'  => 'Bid count',
                'value' => (string) ($lot['bids_count'] ?? 0),
            ],
        ],
    ];
}

function au_seo_item_list(array $lots, string $lang, string $listUrl): array
{
    $elements = [];
    $pos = 1;
    foreach (array_slice($lots, 0, 20) as $l) {
        $url = au_absolute_url(au_url('lot.php?id=' . urlencode($l['id'])));
        $elements[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'url'      => $url,
            'name'     => au_localized($l, 'name', $lang),
        ];
    }
    return [
        '@type'           => 'ItemList',
        'url'             => $listUrl,
        'numberOfItems'   => count($lots),
        'itemListElement' => $elements,
    ];
}

function au_seo_professional_service(): array
{
    return [
        '@type' => 'ProfessionalService',
        '@id'   => 'https://bilohash.com/auction/#service',
        'name'  => 'Custom auction website development — Norway & Europe',
        'url'   => 'https://bilohash.com/auction/',
        'description' => 'Order development of online auction websites and PHP bidding scripts. Art, antiques, vehicles, charity, real estate. Norway and Europe.',
        'areaServed' => ['Norway', 'Ukraine', 'Lithuania', 'Europe'],
        'provider' => au_seo_organization(),
    ];
}

function au_seo_json(array $graphs): string
{
    $graphs = array_values(array_filter($graphs));
    if (count($graphs) === 1) {
        $data = array_merge(['@context' => 'https://schema.org'], $graphs[0]);
    } else {
        $data = [
            '@context' => 'https://schema.org',
            '@graph'   => $graphs,
        ];
    }
    return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function au_render_seo_head(
    string $page_title,
    string $page_desc,
    string $canonical,
    array $schema_graphs = [],
    ?string $og_image = null,
    ?string $og_type = 'website',
    bool $noindex = false
): void {
    global $lang_meta, $lang;
    $og_image = $og_image ?: au_seo_og_image();
    $canonical_abs = au_absolute_url($canonical);
    $keywords = $GLOBALS['t']['meta']['keywords'] ?? '';
    $robots = $noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="<?= $robots ?>">
    <meta name="author" content="Ruslan Bilohash / Bilohash">
    <meta name="geo.region" content="NO">
    <meta name="geo.placename" content="Drammen, Norway">
    <meta name="geo.position" content="59.7439;10.2045">
    <meta name="ICBM" content="59.7439, 10.2045">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(au_full_lang_url('no')) ?>">
    <?php foreach (au_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= htmlspecialchars(au_seo_hreflang($code)) ?>" href="<?= htmlspecialchars(au_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <meta property="og:type" content="<?= htmlspecialchars($og_type) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars(AU_SITE_NAME) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:secure_url" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="1200">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <?php foreach (au_langs() as $code => $info):
        if ($code === $lang) continue; ?>
    <meta property="og:locale:alternate" content="<?= htmlspecialchars(str_replace('-', '_', $info['locale'])) ?>">
    <?php endforeach; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@bilohash">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta name="twitter:image:alt" content="<?= htmlspecialchars($page_title) ?>">

    <?php if (!empty($schema_graphs)): ?>
    <script type="application/ld+json"><?= au_seo_json(array_values(array_filter($schema_graphs))) ?></script>
    <?php endif;
}