<?php
require_once __DIR__ . '/init.php';
$id = $_GET['id'] ?? $_POST['id'] ?? '';
$lot = $id ? au_lot_by_id($id) : null;
$success = false;
$ref = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $lot) {
    require_once __DIR__ . '/includes/storage.php';
    $amount = (int)($_POST['amount'] ?? 0);
    $min    = au_min_bid($lot);
    if ($amount < $min) {
        $error = $t['bid']['invalid'];
    } else {
        $success = true;
        $ref = 'AU-DEMO-' . strtoupper(substr(md5(uniqid((string)mt_rand(), true)), 0, 8));
        au_add_bid([
            'ref'      => $ref,
            'lot_id'   => $lot['id'],
            'lot_name' => au_localized($lot, 'name', $lang),
            'bidder'   => trim(($_POST['firstname'] ?? '') . ' ' . ($_POST['lastname'] ?? '')),
            'email'    => trim($_POST['email'] ?? ''),
            'phone'    => trim($_POST['phone'] ?? ''),
            'amount'   => $amount,
            'status'   => 'active',
        ]);
        $lot = au_lot_by_id($id);
    }
}

$name    = $lot ? au_localized($lot, 'name', $lang) : '';
$min_bid = $lot ? au_min_bid($lot) : 0;
$page_title = $success ? $t['bid']['success'] : $t['bid']['title'];
$page_desc  = ($lot ? $name . ' — ' : '') . $t['meta']['description'];
$canonical  = $lot
    ? $site_url . '/bid.php?id=' . urlencode($lot['id'])
    : $site_url . '/bid.php';
$canon_abs  = au_absolute_url($canonical);
$seo_schemas = [au_seo_webpage($canon_abs, $page_title, $page_desc)];
if ($lot) {
    $seo_schemas[] = au_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => au_absolute_url(au_url('index.php'))],
        ['name' => $name, 'url' => au_absolute_url(au_url('lot.php?id=' . urlencode($lot['id'])))],
        ['name' => $t['bid']['title'], 'url' => $canon_abs],
    ]);
}
require __DIR__ . '/includes/header.php';

if (!$lot && !$success):
?>
<div class="au-container">
    <div class="au-form-card au-empty-state">
        <p><?= htmlspecialchars($t['search_page']['no_results']) ?></p>
        <a href="<?= au_url('index.php') ?>" class="au-btn-gold"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
    </div>
</div>
<?php
require __DIR__ . '/includes/footer.php';
exit;
endif;
?>

<?php if ($success): ?>
<div class="au-success">
    <i class="fas fa-circle-check"></i>
    <h1><?= htmlspecialchars($t['bid']['success']) ?></h1>
    <p><?= htmlspecialchars($t['bid']['success_msg']) ?></p>
    <div class="au-ref"><?= htmlspecialchars($ref) ?></div>
    <p class="au-success-meta"><?= htmlspecialchars($name) ?> · <?= au_price((int)($_POST['amount'] ?? 0)) ?></p>
    <div class="au-success-actions">
        <a href="<?= au_url('index.php') ?>" class="au-btn-gold"><?= htmlspecialchars($t['bid']['back_home']) ?></a>
        <a href="<?= au_url('lot.php?id=' . urlencode($lot['id'])) ?>" class="au-btn-outline-gold"><?= htmlspecialchars($t['bid']['view_lot']) ?></a>
    </div>
</div>
<?php else: ?>

<div class="au-container">
    <h1 class="au-page-title"><?= htmlspecialchars($t['bid']['title']) ?></h1>
    <div class="au-form-layout">
        <div class="au-form-card">
            <h2><?= htmlspecialchars($t['bid']['details']) ?></h2>
            <?php if ($error): ?>
            <div class="au-form-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="">
                <input type="hidden" name="id" value="<?= htmlspecialchars($lot['id']) ?>">
                <div class="au-field">
                    <label for="amount"><?= htmlspecialchars($t['bid']['amount']) ?> *</label>
                    <input type="number" id="amount" name="amount" required min="<?= $min_bid ?>" step="<?= (int)($lot['bid_increment'] ?? 100) ?>" value="<?= $min_bid ?>">
                    <small><?= sprintf($t['bid']['amount_hint'], au_price($min_bid)) ?></small>
                </div>
                <div class="au-form-row">
                    <div class="au-field">
                        <label for="firstname"><?= htmlspecialchars($t['bid']['firstname']) ?> *</label>
                        <input type="text" id="firstname" name="firstname" required value="Demo">
                    </div>
                    <div class="au-field">
                        <label for="lastname"><?= htmlspecialchars($t['bid']['lastname']) ?> *</label>
                        <input type="text" id="lastname" name="lastname" required value="Bidder">
                    </div>
                </div>
                <div class="au-field">
                    <label for="email"><?= htmlspecialchars($t['bid']['email']) ?> *</label>
                    <input type="email" id="email" name="email" required value="demo@bilohash.com">
                </div>
                <div class="au-field">
                    <label for="phone"><?= htmlspecialchars($t['bid']['phone']) ?></label>
                    <input type="tel" id="phone" name="phone" value="+4746255885">
                </div>
                <button type="submit" class="au-btn-gold au-btn-block">
                    <i class="fas fa-gavel"></i> <?= htmlspecialchars($t['bid']['submit']) ?>
                </button>
            </form>
        </div>

        <aside class="au-bid-box">
            <h3><?= htmlspecialchars($t['bid']['summary']) ?></h3>
            <img src="<?= htmlspecialchars(au_lot_image($lot)) ?>" alt="" class="au-bid-summary-img" onerror="this.onerror=null;this.src='<?= htmlspecialchars(au_placeholder_image()) ?>';">
            <strong class="au-bid-summary-title"><?= htmlspecialchars($name) ?></strong>
            <div class="au-bid-summary-meta">
                <?= htmlspecialchars($t['lot']['current_bid']) ?>: <strong><?= au_price((int)($lot['current_bid'] ?? 0)) ?></strong><br>
                <?= htmlspecialchars($t['lot']['min_bid']) ?>: <?= au_price($min_bid) ?>
            </div>
            <div class="au-demo-alert"><?= htmlspecialchars($t['lot']['demo_note']) ?></div>
        </aside>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>