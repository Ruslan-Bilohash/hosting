<?php
require_once __DIR__ . '/init.php';
au_admin_require();

if (isset($_GET['download']) && $_GET['download'] === 'csv') {
    $bids = au_load_bids();
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="auction-bids-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, ['ref', 'bidder', 'email', 'phone', 'lot_id', 'lot_name', 'amount', 'status', 'created_at']);
    foreach ($bids as $b) {
        fputcsv($out, [
            $b['ref'] ?? $b['id'] ?? '',
            $b['bidder'] ?? '',
            $b['email'] ?? '',
            $b['phone'] ?? '',
            $b['lot_id'] ?? '',
            $b['lot_name'] ?? '',
            $b['amount'] ?? 0,
            $b['status'] ?? 'active',
            $b['created_at'] ?? '',
        ]);
    }
    fclose($out);
    exit;
}

$admin_page = 'export';
$page_title = $ta['export'] ?? 'Export';
$bids = au_load_bids();
require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['export_bids'] ?? 'Export bids') ?></h2></div>
    <div class="adm-card-body padded">
        <p style="margin:0 0 16px;color:var(--adm-muted)"><?= count($bids) ?> bids in demo database (bids.json).</p>
        <a href="<?= au_admin_url('export.php?download=csv') ?>" class="adm-btn adm-btn-primary">
            <i class="fas fa-download"></i> <?= htmlspecialchars($ta['export'] ?? 'Export CSV') ?>
        </a>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>