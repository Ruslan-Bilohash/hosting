<?php
$p = $search_params ?? au_search_params();
?>
<form class="au-search" action="<?= au_url('search.php') ?>" method="get" role="search">
    <div class="au-search-field" style="flex:2 1 240px">
        <label for="q"><?= htmlspecialchars($t['search']['keyword']) ?></label>
        <input type="search" id="q" name="q" value="<?= htmlspecialchars($p['q']) ?>"
               placeholder="<?= htmlspecialchars($t['search']['placeholder']) ?>" autocomplete="off">
    </div>
    <div class="au-search-field">
        <label for="category"><?= htmlspecialchars($t['search']['category']) ?></label>
        <select id="category" name="category">
            <option value=""><?= htmlspecialchars($t['search']['all_cats']) ?></option>
            <?php foreach (au_categories() as $cat): ?>
            <option value="<?= htmlspecialchars($cat) ?>" <?= $p['category'] === $cat ? 'selected' : '' ?>>
                <?= htmlspecialchars($t['categories'][$cat] ?? $cat) ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="au-search-field">
        <label for="status"><?= htmlspecialchars($t['search_page']['status']) ?></label>
        <select id="status" name="status">
            <option value=""><?= htmlspecialchars($t['search_page']['status_all']) ?></option>
            <option value="live" <?= $p['status'] === 'live' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['status_live']) ?></option>
            <option value="ending" <?= $p['status'] === 'ending' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['status_end']) ?></option>
        </select>
    </div>
    <div class="au-search-btn-wrap">
        <button type="submit" class="au-search-btn"><i class="fas fa-search"></i> <?= htmlspecialchars($t['search']['search_btn']) ?></button>
    </div>
</form>