<?php

/** @return 'good'|'warn'|'bad' */
function bk_checklist_rate_length(int $len, int $goodMin, int $goodMax, int $warnMin = 0): string
{
    if ($len === 0) {
        return 'bad';
    }
    if ($len >= $goodMin && $len <= $goodMax) {
        return 'good';
    }
    if ($len >= $warnMin) {
        return 'warn';
    }
    return 'bad';
}

/** @param list<array{status:string,weight?:int}> $items */
function bk_checklist_score(array $items): int
{
    if ($items === []) {
        return 0;
    }
    $total = 0;
    $weightSum = 0;
    foreach ($items as $item) {
        $w = max(1, (int) ($item['weight'] ?? 1));
        $status = $item['status'] ?? 'bad';
        $points = match ($status) {
            'good' => 100,
            'warn' => 55,
            default => 0,
        };
        $total += $points * $w;
        $weightSum += $w;
    }
    return (int) round($total / max(1, $weightSum));
}

function bk_checklist_grade(int $score, array $labels): array
{
    if ($score >= 90) {
        return ['key' => 'excellent', 'label' => $labels['grade_excellent'] ?? 'Excellent'];
    }
    if ($score >= 75) {
        return ['key' => 'good', 'label' => $labels['grade_good'] ?? 'Good'];
    }
    if ($score >= 50) {
        return ['key' => 'fair', 'label' => $labels['grade_fair'] ?? 'Needs work'];
    }
    return ['key' => 'poor', 'label' => $labels['grade_poor'] ?? 'Poor'];
}

/** @param list<array{status:string}> $items @return list<string> */
function bk_checklist_issue_tags(array $items): array
{
    $tags = [];
    foreach ($items as $item) {
        if (($item['status'] ?? 'bad') === 'good') {
            continue;
        }
        $tags[] = (string) ($item['key'] ?? 'issue');
    }
    return $tags;
}

/**
 * @return array{score:int,grade:array{key:string,label:string},items:list<array<string,mixed>>}
 */
function bk_site_global_seo_checklist(array $settings, array $labels): array
{
    $items = [
        [
            'key' => 'site_name',
            'status' => trim($settings['seo_site_name'] ?? '') !== '' ? 'good' : 'bad',
            'label' => $labels['site_name'] ?? 'Site name',
            'weight' => 3,
        ],
        [
            'key' => 'og_image',
            'status' => trim($settings['seo_default_og_image'] ?? '') !== '' ? 'good' : 'bad',
            'label' => $labels['og_image'] ?? 'Default OG image',
            'weight' => 3,
        ],
        [
            'key' => 'sitemap',
            'status' => !empty($settings['sitemap_enabled']) ? 'good' : 'warn',
            'label' => $labels['sitemap'] ?? 'XML sitemap',
            'weight' => 2,
        ],
        [
            'key' => 'schema_lodging',
            'status' => !empty($settings['seo_schema_lodging']) ? 'good' : 'bad',
            'label' => $labels['schema_lodging'] ?? 'Lodging schema',
            'weight' => 3,
        ],
        [
            'key' => 'schema_org',
            'status' => !empty($settings['seo_schema_organization']) ? 'good' : 'warn',
            'label' => $labels['schema_org'] ?? 'Organization schema',
            'weight' => 2,
        ],
    ];
    $score = bk_checklist_score($items);
    return [
        'score' => $score,
        'grade' => bk_checklist_grade($score, $labels),
        'items' => $items,
    ];
}

/**
 * @return array{score:int,grade:array{key:string,label:string},items:list<array<string,mixed>>}
 */
function bk_property_seo_checklist(array $property, array $labels): array
{
    $items = [];
    foreach (['en', 'no', 'uk'] as $code) {
        $name = trim((string) ($property['name'][$code] ?? ''));
        $city = trim((string) ($property['city'][$code] ?? ''));
        $country = trim((string) ($property['country'][$code] ?? ''));
        $w = $code === 'en' ? 3 : 2;
        $items[] = [
            'key' => 'name_' . $code,
            'status' => $name !== '' ? 'good' : 'bad',
            'label' => ($labels['name'] ?? 'Name') . ' (' . strtoupper($code) . ')',
            'weight' => $w,
        ];
        $items[] = [
            'key' => 'city_' . $code,
            'status' => $city !== '' ? 'good' : 'bad',
            'label' => ($labels['city'] ?? 'City') . ' (' . strtoupper($code) . ')',
            'weight' => $w,
        ];
        $items[] = [
            'key' => 'country_' . $code,
            'status' => $country !== '' ? 'good' : 'bad',
            'label' => ($labels['country'] ?? 'Country') . ' (' . strtoupper($code) . ')',
            'weight' => $w,
        ];
    }
    $image = trim((string) ($property['image'] ?? ''));
    $items[] = [
        'key' => 'image',
        'status' => $image !== '' ? 'good' : 'bad',
        'label' => $labels['image'] ?? 'Property image',
        'weight' => 3,
    ];
    $items[] = [
        'key' => 'active',
        'status' => !empty($property['active']) ? 'good' : 'warn',
        'label' => $labels['active'] ?? 'Published on site',
        'weight' => 2,
    ];
    $score = bk_checklist_score($items);
    return [
        'score' => $score,
        'grade' => bk_checklist_grade($score, $labels),
        'items' => $items,
    ];
}

/**
 * @return list<array{key:string,type:string,label:string,score:int,grade:array{key:string,label:string},issues:list<string>,edit_url:string,public_url:string}>
 */
function bk_seo_pages_audit(array $settings, array $labels, string $lang): array
{
    require_once __DIR__ . '/vertical-lib.php';

    $pages = [];
    $global = bk_site_global_seo_checklist($settings, $labels['global'] ?? $labels);
    $pages[] = [
        'key'        => 'global',
        'type'       => 'settings',
        'label'      => $labels['page_global'] ?? 'Global SEO settings',
        'score'      => $global['score'],
        'grade'      => $global['grade'],
        'issues'     => bk_checklist_issue_tags($global['items']),
        'edit_url'   => bk_admin_url('settings-seo.php'),
        'public_url' => bk_url('index.php'),
    ];

    $homeScore = trim($settings['seo_site_name'] ?? '') !== '' && trim($settings['seo_default_og_image'] ?? '') !== '' ? 88 : 52;
    $pages[] = [
        'key'        => 'homepage',
        'type'       => 'system',
        'label'      => $labels['page_homepage'] ?? 'Homepage',
        'score'      => $homeScore,
        'grade'      => bk_checklist_grade($homeScore, $labels),
        'issues'     => $homeScore >= 75 ? [] : ['missing_global', 'missing_og'],
        'edit_url'   => bk_admin_url('settings-seo.php'),
        'public_url' => bk_url('index.php'),
    ];

    $pages[] = [
        'key'        => 'solutions',
        'type'       => 'system',
        'label'      => $labels['page_solutions'] ?? 'Booking solutions hub',
        'score'      => !empty($settings['sitemap_include_verticals']) ? 78 : 58,
        'grade'      => bk_checklist_grade(!empty($settings['sitemap_include_verticals']) ? 78 : 58, $labels),
        'issues'     => !empty($settings['sitemap_include_verticals']) ? [] : ['missing_sitemap'],
        'edit_url'   => bk_admin_url('settings-seo.php'),
        'public_url' => bk_url('solutions.php'),
    ];

    $propLabels = $labels['property'] ?? $labels;
    foreach (bk_properties() as $property) {
        $id = (string) ($property['id'] ?? '');
        if ($id === '') {
            continue;
        }
        $report = bk_property_seo_checklist($property, $propLabels);
        $name = trim((string) ($property['name'][$lang] ?? $property['name']['en'] ?? $id));
        $pages[] = [
            'key'        => 'property:' . $id,
            'type'       => 'property',
            'label'      => $name . ' (' . $id . ')',
            'score'      => $report['score'],
            'grade'      => $report['grade'],
            'issues'     => bk_checklist_issue_tags($report['items']),
            'edit_url'   => bk_admin_url('property.php?id=' . urlencode($id)),
            'public_url' => bk_url('property.php?id=' . urlencode($id)),
        ];
    }

    foreach (bk_use_case_slugs() as $slug) {
        $pages[] = [
            'key'        => 'vertical:' . $slug,
            'type'       => 'vertical',
            'label'      => ($labels['page_vertical'] ?? 'Vertical') . ': ' . $slug,
            'score'      => !empty($settings['sitemap_include_verticals']) ? 72 : 48,
            'grade'      => bk_checklist_grade(!empty($settings['sitemap_include_verticals']) ? 72 : 48, $labels),
            'issues'     => !empty($settings['sitemap_include_verticals']) ? [] : ['missing_sitemap'],
            'edit_url'   => bk_admin_url('settings-seo.php'),
            'public_url' => bk_url('vertical.php?use=' . urlencode($slug)),
        ];
    }

    usort($pages, static fn(array $a, array $b): int => ($a['score'] ?? 0) <=> ($b['score'] ?? 0));

    return $pages;
}

/** @param list<string> $issues @param array<string, string> $map */
function bk_seo_analysis_issue_labels(array $issues, array $map): string
{
    $parts = [];
    foreach ($issues as $tag) {
        $parts[] = $map[$tag] ?? $tag;
    }
    return implode(', ', $parts);
}

function bk_seo_score_grade_key(int $score): string
{
    if ($score >= 90) {
        return 'excellent';
    }
    if ($score >= 75) {
        return 'good';
    }
    if ($score >= 50) {
        return 'fair';
    }
    return 'poor';
}