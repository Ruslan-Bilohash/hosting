<?php
/** @var array $settings @var array $ta */
require_once dirname(__DIR__, 3) . '/includes/ai-settings.php';
$providers = bk_ai_providers();
$provider = $settings['ai_provider'] ?? 'grok';
$aiKeySet = trim((string) ($settings['ai_api_key'] ?? '')) !== '';
?>
<form method="post" class="adm-settings-form" id="bkAiSettingsForm">
    <div class="adm-card">
        <div class="adm-card-head"><h2><?= htmlspecialchars(bk_settings_admin_label('ai_section', $ta)) ?></h2></div>
        <div class="adm-card-body padded">
            <div class="adm-alert adm-alert-info adm-alert-compact">
                <i class="fas fa-info-circle"></i>
                <?= htmlspecialchars(bk_settings_admin_label('ai_independent_note', $ta)) ?>
            </div>
            <label class="adm-toggle"><input type="checkbox" name="ai_enabled" value="1" <?= !empty($settings['ai_enabled']) ? 'checked' : '' ?>><span><?= htmlspecialchars(bk_settings_admin_label('ai_enabled', $ta)) ?></span></label>
            <div class="adm-form-grid adm-form-grid--settings adm-ai-settings-grid">
                <div class="adm-field">
                    <label><?= htmlspecialchars(bk_settings_admin_label('ai_provider', $ta)) ?></label>
                    <select name="ai_provider"><?php foreach ($providers as $key => $p): ?><option value="<?= htmlspecialchars($key) ?>" <?= $provider === $key ? 'selected' : '' ?>><?= htmlspecialchars($p['label']) ?></option><?php endforeach; ?></select>
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars(bk_settings_admin_label('ai_model', $ta)) ?></label>
                    <select name="ai_model_select"><?php foreach ($providers[$provider]['models'] ?? [] as $m): ?><option value="<?= htmlspecialchars($m) ?>" <?= ($settings['ai_model'] ?? '') === $m ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select>
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars(bk_settings_admin_label('ai_model_seo', $ta)) ?></label>
                    <select name="ai_model_seo_select">
                        <option value=""><?= htmlspecialchars(bk_settings_admin_label('ai_model_use_default', $ta)) ?></option>
                        <?php foreach ($providers[$provider]['models'] ?? [] as $m): ?>
                        <option value="<?= htmlspecialchars($m) ?>" <?= ($settings['ai_model_seo'] ?? '') === $m ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="adm-field adm-field-full">
                    <label><?= htmlspecialchars(bk_settings_admin_label('ai_api_base', $ta)) ?></label>
                    <input type="url" name="ai_api_base" value="<?= htmlspecialchars($settings['ai_api_base'] ?? '') ?>" placeholder="https://api.x.ai/v1" inputmode="url">
                    <span class="adm-field-hint"><?= htmlspecialchars(bk_settings_admin_label('ai_api_base_hint', $ta)) ?></span>
                </div>
                <div class="adm-field adm-field-full">
                    <label><?= htmlspecialchars(bk_settings_admin_label('ai_api_key', $ta)) ?></label>
                    <?php if ($aiKeySet): ?>
                    <p class="adm-help adm-help-compact"><i class="fas fa-check-circle"></i> <?= htmlspecialchars(bk_settings_admin_label('secret_saved', $ta)) ?></p>
                    <?php endif; ?>
                    <input type="password" name="ai_api_key" value="" placeholder="<?= htmlspecialchars($aiKeySet ? bk_settings_admin_label('secret_keep', $ta) : 'xai-... or sk-...') ?>" autocomplete="new-password">
                </div>
                <div class="adm-field adm-field-full">
                    <label><?= htmlspecialchars(bk_settings_admin_label('ai_prompt_seo', $ta)) ?></label>
                    <textarea name="ai_prompt_seo" rows="4"><?= htmlspecialchars($settings['ai_prompt_seo'] ?? '') ?></textarea>
                    <span class="adm-field-hint"><?= htmlspecialchars(bk_settings_admin_label('ai_prompt_seo_hint', $ta)) ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="adm-card">
        <div class="adm-card-head"><h2><i class="fas fa-list-ol"></i> <?= htmlspecialchars(bk_settings_admin_label('ai_instructions_section', $ta)) ?></h2></div>
        <div class="adm-card-body padded">
            <p class="adm-help adm-help-compact"><?= htmlspecialchars(bk_settings_admin_label('ai_instructions_help', $ta)) ?></p>
            <ol class="adm-instructions-list adm-ai-instructions-list">
                <?php for ($i = 1; $i <= 6; $i++):
                    $stepKey = 'ai_instruction_' . $i;
                    $step = bk_settings_admin_label($stepKey, $ta);
                    if ($step === $stepKey) {
                        continue;
                    }
                ?>
                <li><?= htmlspecialchars($step) ?></li>
                <?php endfor; ?>
            </ol>
            <p class="adm-help adm-help-compact" style="margin-top:14px">
                <a href="<?= htmlspecialchars(bk_admin_url('seo-agent-console.php')) ?>" class="adm-btn adm-btn-outline adm-btn-sm">
                    <i class="fas fa-robot"></i> <?= htmlspecialchars(bk_settings_admin_label('ai_link_seo_agent', $ta)) ?>
                </a>
            </p>
        </div>
    </div>

    <div class="adm-form-actions adm-form-actions-sticky">
        <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars(bk_settings_admin_label('save', $ta)) ?></button>
    </div>
</form>