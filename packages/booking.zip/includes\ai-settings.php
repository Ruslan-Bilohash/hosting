<?php
declare(strict_types=1);

function bk_ai_defaults(): array
{
    return [
        'ai_enabled'        => false,
        'ai_provider'       => 'grok',
        'ai_api_key'        => '',
        'ai_api_base'       => '',
        'ai_model'          => 'grok-3-mini',
        'ai_prompt_seo'     => '',
        'ai_model_seo'      => '',
    ];
}

function bk_ai_providers(): array
{
    return [
        'grok' => ['label' => 'Grok xAI', 'models' => ['grok-3-mini', 'grok-3']],
        'gpt'  => ['label' => 'OpenAI GPT', 'models' => ['gpt-4o-mini', 'gpt-4o']],
    ];
}

function bk_ai_merge(array $settings): array
{
    return array_merge(bk_ai_defaults(), $settings);
}

function bk_ai_apply_post(array $post, array $settings): array
{
    $settings = bk_ai_merge($settings);
    $providers = bk_ai_providers();
    $provider = trim((string) ($post['ai_provider'] ?? 'grok'));
    if (!isset($providers[$provider])) {
        $provider = 'grok';
    }
    $settings['ai_enabled'] = !empty($post['ai_enabled']);
    $settings['ai_provider'] = $provider;
    $settings['ai_api_base'] = rtrim(trim((string) ($post['ai_api_base'] ?? '')), '/');
    $model = trim((string) ($post['ai_model'] ?? ''));
    if ($model === '' && !empty($post['ai_model_select'])) {
        $model = trim((string) $post['ai_model_select']);
    }
    $settings['ai_model'] = $model !== '' ? $model : ($providers[$provider]['models'][0] ?? 'grok-3-mini');
    $key = trim((string) ($post['ai_api_key'] ?? ''));
    if ($key !== '') {
        $settings['ai_api_key'] = $key;
        $settings['ai_enabled'] = true;
    }
    $settings['ai_prompt_seo'] = trim((string) ($post['ai_prompt_seo'] ?? ''));
    $seoModel = trim((string) ($post['ai_model_seo'] ?? ''));
    if ($seoModel === '' && array_key_exists('ai_model_seo_select', $post)) {
        $seoModel = trim((string) $post['ai_model_seo_select']);
    }
    $settings['ai_model_seo'] = $seoModel;
    return $settings;
}

function bk_ai_enabled(array $settings): bool
{
    $settings = bk_ai_merge($settings);
    return !empty($settings['ai_enabled']) && trim((string) ($settings['ai_api_key'] ?? '')) !== '';
}

/** @return array{api_base:string,model:string} */
function bk_ai_resolve_config(array $settings, string $context = 'default'): array
{
    $settings = bk_ai_merge($settings);
    $provider = (string) ($settings['ai_provider'] ?? 'grok');
    $defaults = [
        'grok' => ['api_base' => 'https://api.x.ai/v1', 'model' => 'grok-3-mini'],
        'gpt'  => ['api_base' => 'https://api.openai.com/v1', 'model' => 'gpt-4o-mini'],
    ];
    $base = trim((string) ($settings['ai_api_base'] ?? ''));
    if ($base === '') {
        $base = $defaults[$provider]['api_base'] ?? $defaults['grok']['api_base'];
    }
    $model = trim((string) ($settings['ai_model'] ?? ''));
    if ($context === 'seo') {
        $seoModel = trim((string) ($settings['ai_model_seo'] ?? ''));
        if ($seoModel !== '') {
            $model = $seoModel;
        }
    }
    if ($model === '') {
        $model = $defaults[$provider]['model'] ?? 'grok-3-mini';
    }
    return ['api_base' => rtrim($base, '/'), 'model' => $model];
}

function bk_ai_call_chat(array $settings, string $prompt, int $maxTokens = 900, string $context = 'default'): array
{
    $settings = bk_ai_merge($settings);
    $apiKey = trim((string) ($settings['ai_api_key'] ?? ''));
    if ($apiKey === '') {
        return ['ok' => false, 'text' => '', 'error' => 'No API key'];
    }
    $resolved = bk_ai_resolve_config($settings, $context);
    $endpoint = $resolved['api_base'] . '/chat/completions';
    $payload = [
        'model'       => $resolved['model'],
        'messages'    => [
            ['role' => 'system', 'content' => 'Reply with valid JSON only. No markdown fences.'],
            ['role' => 'user', 'content' => $prompt],
        ],
        'temperature' => 0.55,
        'max_tokens'  => $maxTokens,
    ];
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($body === false) {
        return ['ok' => false, 'text' => '', 'error' => 'JSON encode failed'];
    }
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'text' => '', 'error' => 'cURL not available'];
    }
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 45,
    ]);
    $raw = curl_exec($ch);
    $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $http < 200 || $http >= 300) {
        return ['ok' => false, 'text' => '', 'error' => 'AI request failed (' . $http . ')'];
    }
    $json = json_decode((string) $raw, true);
    $text = trim((string) ($json['choices'][0]['message']['content'] ?? ''));
    if ($text === '') {
        return ['ok' => false, 'text' => '', 'error' => 'Empty AI response'];
    }
    return ['ok' => true, 'text' => $text, 'error' => ''];
}

/**
 * @param array{key:string,type:string,label:string,score:int,issues:list<string>} $page
 * @return array{ok:bool,demo:bool,suggestions:list<array{priority:string,title:string,detail:string,action?:string}>,summary:string,error:string}
 */
function bk_ai_seo_page_suggestions(array $settings, array $page, string $lang = 'en'): array
{
    $lang = trim($lang) ?: 'en';
    $label = trim((string) ($page['label'] ?? 'Page'));
    $score = (int) ($page['score'] ?? 0);
    $issues = is_array($page['issues'] ?? null) ? $page['issues'] : [];
    $type = (string) ($page['type'] ?? 'page');

    $issueHints = [
        'site_name'       => 'Set og:site_name in SEO settings for brand consistency.',
        'og_image'        => 'Add a default Open Graph image (1200×630) in SEO settings.',
        'sitemap'         => 'Enable XML sitemap and include properties / verticals.',
        'schema_lodging'  => 'Enable LodgingBusiness schema on property pages.',
        'schema_org'      => 'Enable Organization schema for trust signals.',
        'missing_global'  => 'Complete global site name and organisation fields.',
        'missing_og'      => 'Add default OG image URL.',
        'missing_sitemap' => 'Include vertical pages in sitemap.xml.',
        'image'           => 'Add a high-quality property hero image.',
        'active'          => 'Publish the property so it appears in search and sitemap.',
        'name_en'         => 'Fill property name in English for international SEO.',
        'city_en'         => 'Add city (EN) for local Schema.org markup.',
        'country_en'      => 'Add country (EN) for address schema.',
    ];

    if (!bk_ai_enabled($settings)) {
        $suggestions = [];
        foreach ($issues as $tag) {
            $suggestions[] = [
                'priority' => str_contains((string) $tag, 'missing') || str_contains((string) $tag, 'name_') ? 'high' : 'medium',
                'title'    => str_replace('_', ' ', ucfirst((string) $tag)),
                'detail'   => $issueHints[$tag] ?? 'Review and fix this SEO signal.',
                'action'   => 'edit',
            ];
        }
        if ($suggestions === []) {
            $suggestions[] = [
                'priority' => 'low',
                'title'    => 'Maintain momentum',
                'detail'   => 'Score is ' . $score . '/100 — refresh copy quarterly and monitor Search Console.',
                'action'   => 'monitor',
            ];
        }
        return [
            'ok'          => true,
            'demo'        => true,
            'suggestions' => array_slice($suggestions, 0, 8),
            'summary'     => 'Rule-based audit for "' . $label . '" (enable AI in Settings → AI for deeper suggestions).',
            'error'       => '',
        ];
    }

    $issuesText = $issues !== [] ? implode(', ', $issues) : 'none detected';
    $prompt = 'You are a hospitality SEO consultant. Analyze this booking page and return ONLY valid JSON: '
        . '{"summary":"one sentence","suggestions":[{"priority":"high|medium|low","title":"short","detail":"actionable 1-2 sentences","action":"edit|schema|content|monitor"}]}. '
        . 'Page: "' . $label . '". Type: ' . $type . '. Language: ' . $lang . '. Current SEO score: ' . $score . '/100. '
        . 'Issues: ' . $issuesText . '. Focus on lodging CTR, local SEO and schema. Max 6 suggestions.';

    $custom = trim((string) ($settings['ai_prompt_seo'] ?? ''));
    if ($custom !== '') {
        $prompt = $custom . "\n\n" . $prompt;
    }

    $result = bk_ai_call_chat($settings, $prompt, 900, 'seo');
    if (!$result['ok']) {
        return bk_ai_seo_page_suggestions(array_merge($settings, ['ai_enabled' => false]), $page, $lang);
    }

    $raw = $result['text'];
    if (preg_match('/```(?:json)?\s*([\s\S]*?)```/i', $raw, $m)) {
        $raw = trim($m[1]);
    }
    $parsed = json_decode($raw, true);
    if (!is_array($parsed)) {
        return bk_ai_seo_page_suggestions(array_merge($settings, ['ai_enabled' => false]), $page, $lang);
    }

    $suggestions = [];
    foreach (is_array($parsed['suggestions'] ?? null) ? $parsed['suggestions'] : [] as $s) {
        if (!is_array($s)) {
            continue;
        }
        $suggestions[] = [
            'priority' => in_array($s['priority'] ?? '', ['high', 'medium', 'low'], true) ? $s['priority'] : 'medium',
            'title'    => trim((string) ($s['title'] ?? 'Suggestion')),
            'detail'   => trim((string) ($s['detail'] ?? '')),
            'action'   => (string) ($s['action'] ?? 'edit'),
        ];
    }

    return [
        'ok'          => true,
        'demo'        => false,
        'suggestions' => array_slice($suggestions, 0, 8),
        'summary'     => trim((string) ($parsed['summary'] ?? 'AI suggestions for "' . $label . '".')),
        'error'       => '',
    ];
}