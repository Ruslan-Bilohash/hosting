<?php
require_once __DIR__ . '/init.php';
header('Content-Type: application/xml; charset=utf-8');
$base = rtrim($site_url, '/');
$servers = gh_servers();
$langs = ['no', 'en', 'uk', 'ru'];
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
    <url>
        <loc><?= htmlspecialchars($base . '/') ?></loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc><?= htmlspecialchars($base . '/search.php') ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc><?= htmlspecialchars($base . '/maps.php?game=cs2') ?></loc>
        <changefreq>weekly</changefreq>
        <priority>0.85</priority>
    </url>
    <?php foreach (array_keys(gh_game_counts()) as $game):
        if (gh_game_counts()[$game] < 1) continue;
    ?>
    <url>
        <loc><?= htmlspecialchars($base . '/game.php?game=' . urlencode($game)) ?></loc>
        <changefreq>hourly</changefreq>
        <priority>0.88</priority>
    </url>
    <?php endforeach; ?>
    <url>
        <loc><?= htmlspecialchars($base . '/contact.php') ?></loc>
        <changefreq>monthly</changefreq>
        <priority>0.6</priority>
    </url>
    <?php foreach ($servers as $s):
        $id = $s['id'] ?? '';
        if ($id === '') continue;
    ?>
    <url>
        <loc><?= htmlspecialchars($base . '/server.php?id=' . urlencode($id)) ?></loc>
        <changefreq>hourly</changefreq>
        <priority>0.8</priority>
        <?php foreach ($langs as $lng): ?>
        <xhtml:link rel="alternate" hreflang="<?= $lng === 'uk' ? 'uk' : $lng ?>" href="<?= htmlspecialchars($base . '/server.php?id=' . urlencode($id) . ($lng !== 'no' ? '&lang=' . $lng : '')) ?>"/>
        <?php endforeach; ?>
    </url>
    <?php endforeach; ?>
</urlset>