<?php
/** Language switcher — text codes only (no emoji flags; Windows-safe) */
$current = gh_langs()[$lang] ?? gh_langs()['no'];
?>
<nav class="gh-lang-segment" aria-label="<?= htmlspecialchars($t['nav']['lang'] ?? 'Language') ?>">
    <?php foreach (gh_langs() as $code => $info): ?>
    <a href="<?= htmlspecialchars(gh_lang_url($code)) ?>"
       class="gh-lang-segment-item<?= $lang === $code ? ' is-active' : '' ?>"
       <?= $lang === $code ? 'aria-current="true"' : '' ?>
       title="<?= htmlspecialchars($info['name']) ?>">
        <?= htmlspecialchars($info['label']) ?>
    </a>
    <?php endforeach; ?>
</nav>