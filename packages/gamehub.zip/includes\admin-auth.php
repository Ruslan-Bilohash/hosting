<?php
/**
 * Demo admin — demo / bilogamehub2026
 */
define('GH_ADMIN_USER', 'demo');
define('GH_ADMIN_PASS', 'bilogamehub2026');
define('GH_ADMIN_SESSION_KEY', 'gh_admin_logged');

function gh_admin_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function gh_admin_logged(): bool
{
    gh_admin_start();
    return !empty($_SESSION[GH_ADMIN_SESSION_KEY]);
}

function gh_admin_login(string $user, string $pass): bool
{
    if ($user === GH_ADMIN_USER && $pass === GH_ADMIN_PASS) {
        gh_admin_start();
        $_SESSION[GH_ADMIN_SESSION_KEY] = true;
        $_SESSION['gh_admin_user'] = $user;
        return true;
    }
    return false;
}

function gh_admin_logout(): void
{
    gh_admin_start();
    unset($_SESSION[GH_ADMIN_SESSION_KEY], $_SESSION['gh_admin_user']);
}

function gh_admin_require(): void
{
    if (!gh_admin_logged()) {
        header('Location: ' . gh_admin_url('login.php'), true, 302);
        exit;
    }
}

function gh_admin_url(string $path = ''): string
{
    return gh_url('admin/' . ltrim($path, '/'));
}