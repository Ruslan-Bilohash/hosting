<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require_once dirname(__DIR__) . '/init.php';

$id = trim($_GET['id'] ?? '');
$refresh = !empty($_GET['refresh']);

if ($id !== '') {
    $server = gh_server_by_id($id);
    if ($server === null) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Not found']);
        exit;
    }
    if ($refresh) {
        $server = gh_refresh_server($server);
        gh_server_upsert($server);
    }
    echo json_encode([
        'ok' => true,
        'server' => gh_server_status_payload($server),
    ]);
    exit;
}

$servers = gh_servers();
if ($refresh) {
    gh_refresh_all_servers();
    $servers = gh_servers();
}

$payload = array_map('gh_server_status_payload', $servers);
echo json_encode([
    'ok' => true,
    'count' => count($payload),
    'servers' => $payload,
    'refreshed_at' => date('c'),
]);