<?php
require_once __DIR__ . '/init.php';
$canonical = $site_url . '/';
$page_title = $t['meta']['title'];
$page_desc  = $t['meta']['description'];
require __DIR__ . '/includes/header.php';
?>

<section class="ghs-hero">
    <div class="ghs-container ghs-hero-inner">
        <div class="ghs-hero-content">
            <span class="ghs-badge"><?= htmlspecialchars($t['hero']['badge']) ?></span>
            <h1><?= htmlspecialchars($t['hero']['title']) ?></h1>
            <p class="ghs-hero-sub"><?= htmlspecialchars($t['hero']['subtitle']) ?></p>
            <div class="ghs-hero-cta">
                <a href="<?= ghs_demo_url() ?>" class="ghs-btn-primary ghs-btn-lg"><i class="fas fa-server"></i> <?= htmlspecialchars($t['hero']['cta_demo']) ?></a>
                <a href="<?= ghs_demo_url('admin/login.php') ?>" class="ghs-btn-outline ghs-btn-lg"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['hero']['cta_admin']) ?></a>
                <a href="<?= ghs_demo_url('contact.php') ?>" class="ghs-btn-ghost ghs-btn-lg"><i class="fas fa-comments"></i> <?= htmlspecialchars(cms_contact_texts('gamehub', $lang)['nav_discuss']) ?></a>
            </div>
        </div>
        <div class="ghs-hero-preview" aria-hidden="true">
            <div class="ghs-mockup">
                <div class="ghs-mockup-header">
                    <span></span><span></span><span></span>
                    <span class="ghs-mockup-title">CS2 · Online servers</span>
                </div>
                <div class="ghs-mockup-body">
                    <article class="ghs-mockup-item active">
                        <div class="ghs-mock-thumb" style="background-image:url('<?= ghs_demo_url('assets/images/maps/de_dust2.png') ?>')"></div>
                        <div><strong>Nordic Fraggers #1</strong><span>18/24 · de_dust2</span></div>
                    </article>
                    <article class="ghs-mockup-item">
                        <div class="ghs-mock-thumb" style="background-image:url('<?= ghs_demo_url('assets/images/maps/de_mirage.png') ?>')"></div>
                        <div><strong>Oslo Aim Training</strong><span>6/12 · de_mirage</span></div>
                    </article>
                    <article class="ghs-mockup-item">
                        <div class="ghs-mock-thumb" style="background-image:url('<?= ghs_demo_url('assets/images/maps/de_inferno.png') ?>')"></div>
                        <div><strong>EU Retake Hub</strong><span>10/16 · de_inferno</span></div>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ghs-section ghs-intro">
    <div class="ghs-container">
        <h2><?= htmlspecialchars($t['intro']['title']) ?></h2>
        <p class="ghs-lead"><?= htmlspecialchars($t['intro']['text']) ?></p>
        <?php if (!empty($t['intro']['use_cases'])): ?>
        <p class="ghs-use-label"><?= htmlspecialchars($t['intro']['use_label'] ?? '') ?></p>
        <div class="ghs-usecases">
            <?php foreach ($t['intro']['use_cases'] as $case): ?>
            <span class="ghs-usecase"><?= htmlspecialchars($case) ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<section class="ghs-section" id="features">
    <div class="ghs-container">
        <h2 class="ghs-section-title"><?= htmlspecialchars($t['features']['title']) ?></h2>
        <div class="ghs-features-grid">
            <?php foreach ($t['features']['items'] as $f): ?>
            <article class="ghs-feature-card">
                <div class="ghs-feature-icon"><i class="fas fa-<?= htmlspecialchars($f['icon']) ?>"></i></div>
                <h3><?= htmlspecialchars($f['title']) ?></h3>
                <p><?= htmlspecialchars($f['desc']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ghs-section ghs-tech" id="tech">
    <div class="ghs-container">
        <h2 class="ghs-section-title"><?= htmlspecialchars($t['tech']['title']) ?></h2>
        <ul class="ghs-tech-list">
            <?php foreach ($t['tech']['items'] as $item): ?>
            <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($item) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<section class="ghs-section ghs-demo-block" id="demo">
    <div class="ghs-container">
        <h2 class="ghs-section-title"><?= htmlspecialchars($t['demo']['title']) ?></h2>
        <div class="ghs-demo-grid">
            <article class="ghs-demo-card">
                <h3><i class="fas fa-server"></i> <?= htmlspecialchars($t['demo']['frontend']) ?></h3>
                <p><?= htmlspecialchars($t['demo']['frontend_desc']) ?></p>
                <a href="<?= ghs_demo_url() ?>" class="ghs-btn-primary"><?= htmlspecialchars($t['demo']['open']) ?> →</a>
            </article>
            <article class="ghs-demo-card">
                <h3><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['demo']['admin']) ?></h3>
                <p><?= htmlspecialchars($t['demo']['admin_desc']) ?></p>
                <a href="<?= ghs_demo_url('admin/login.php') ?>" class="ghs-btn-outline"><?= htmlspecialchars($t['demo']['open']) ?> →</a>
            </article>
        </div>
    </div>
</section>

<?php if (!empty($t['faq']['items'])): ?>
<section class="ghs-section ghs-faq" id="faq">
    <div class="ghs-container">
        <h2 class="ghs-section-title"><?= htmlspecialchars($t['faq']['title']) ?></h2>
        <div class="ghs-faq-list">
            <?php foreach ($t['faq']['items'] as $item): ?>
            <details class="ghs-faq-item">
                <summary><?= htmlspecialchars($item['q']) ?></summary>
                <p><?= htmlspecialchars($item['a']) ?></p>
            </details>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="ghs-cta-band">
    <div class="ghs-container ghs-cta-inner">
        <div>
            <h2><?= htmlspecialchars($t['cta']['title']) ?></h2>
            <p><?= htmlspecialchars($t['cta']['text']) ?></p>
        </div>
        <a href="<?= ghs_demo_url('contact.php') ?>" class="ghs-btn-primary ghs-btn-lg"><i class="fas fa-comments"></i> <?= htmlspecialchars($t['cta']['btn']) ?></a>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>