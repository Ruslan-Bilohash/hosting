<?php

function gh_servers(bool $include_inactive = false): array
{
    $list = gh_load_servers_raw();
    if (!$include_inactive) {
        $list = array_values(array_filter($list, fn($s) => ($s['active'] ?? true) !== false));
    }
    return $list;
}

function gh_servers_all(): array
{
    return gh_servers(true);
}

function gh_server_by_id(string $id, bool $include_inactive = false): ?array
{
    foreach (gh_servers($include_inactive) as $s) {
        if (($s['id'] ?? '') === $id) {
            return $s;
        }
    }
    return null;
}

function gh_localized(array $item, string $field, string $lang): string
{
    $val = $item[$field] ?? '';
    if (is_array($val)) {
        return $val[$lang] ?? $val['ru'] ?? $val['uk'] ?? $val['en'] ?? $val['no'] ?? '';
    }
    return (string) $val;
}

function gh_games(): array
{
    return ['cs2', 'minecraft', 'rust', 'ark', 'valheim', 'tf2'];
}

function gh_regions(): array
{
    return ['eu', 'na', 'asia', 'oce'];
}

function gh_search_params(): array
{
    $settings = gh_settings();
    return [
        'q'      => trim($_GET['q'] ?? ''),
        'game'   => $_GET['game'] ?? '',
        'region' => $_GET['region'] ?? '',
        'status' => $_GET['status'] ?? '',
        'map'    => trim($_GET['map'] ?? ''),
        'sort'   => $_GET['sort'] ?? ($settings['default_sort'] ?? 'players'),
    ];
}

function gh_server_is_online(array $server): bool
{
    return ($server['status'] ?? '') === 'online';
}

function gh_server_address(array $server): string
{
    $host = trim($server['host'] ?? '');
    $port = (int)($server['port'] ?? 0);
    return $port > 0 ? $host . ':' . $port : $host;
}

function gh_server_players_label(array $server): string
{
    return (int)($server['players'] ?? 0) . '/' . (int)($server['max_players'] ?? 0);
}

function gh_server_fill_pct(array $server): int
{
    $max = max(1, (int)($server['max_players'] ?? 1));
    return (int) round(((int)($server['players'] ?? 0) / $max) * 100);
}

function gh_filter_servers(array $params, string $lang): array
{
    $items = gh_servers();
    $q = bh_str_lower($params['q']);

    if ($q !== '') {
        $items = array_filter($items, function ($s) use ($q, $lang) {
            $hay = bh_str_lower(
                gh_localized($s, 'name', $lang) . ' '
                . gh_localized($s, 'desc', $lang) . ' '
                . ($s['host'] ?? '') . ' '
                . ($s['map'] ?? '') . ' '
                . ($s['game'] ?? '')
            );
            return str_contains($hay, $q);
        });
    }

    if ($params['game'] !== '' && in_array($params['game'], gh_games(), true)) {
        $items = array_filter($items, fn($s) => ($s['game'] ?? '') === $params['game']);
    }

    if ($params['region'] !== '' && in_array($params['region'], gh_regions(), true)) {
        $items = array_filter($items, fn($s) => ($s['region'] ?? '') === $params['region']);
    }

    if ($params['status'] === 'online') {
        $items = array_filter($items, fn($s) => gh_server_is_online($s));
    } elseif ($params['status'] === 'offline') {
        $items = array_filter($items, fn($s) => !gh_server_is_online($s));
    }

    if (($params['map'] ?? '') !== '') {
        $mapFilter = gh_normalize_map_slug($params['map']);
        $items = array_filter($items, fn($s) => gh_server_map_slug($s) === $mapFilter);
    }

    if (!gh_settings()['show_offline'] && ($params['status'] ?? '') === '') {
        $items = array_filter($items, fn($s) => gh_server_is_online($s) || ($s['status'] ?? '') === 'maintenance');
    }

    $items = array_values($items);

    usort($items, function ($a, $b) use ($params) {
        return match ($params['sort']) {
            'name'    => strcmp(gh_localized($a, 'name', 'en'), gh_localized($b, 'name', 'en')),
            'ping'    => (int)($a['ping_ms'] ?? 999) <=> (int)($b['ping_ms'] ?? 999),
            'game'    => strcmp($a['game'] ?? '', $b['game'] ?? ''),
            default   => (int)($b['players'] ?? 0) <=> (int)($a['players'] ?? 0)
                ?: (int)!empty($b['featured']) <=> (int)!empty($a['featured']),
        };
    });

    return $items;
}

function gh_featured_servers(int $limit = 6): array
{
    $featured = array_values(array_filter(gh_servers(), fn($s) => !empty($s['featured'])));
    if (count($featured) < $limit) {
        $featured = array_merge($featured, gh_servers());
    }
    $seen = [];
    $out = [];
    foreach ($featured as $s) {
        $id = $s['id'] ?? '';
        if ($id === '' || isset($seen[$id])) {
            continue;
        }
        $seen[$id] = true;
        $out[] = $s;
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function gh_online_servers(int $limit = 8): array
{
    $online = array_values(array_filter(gh_servers(), fn($s) => gh_server_is_online($s)));
    usort($online, fn($a, $b) => (int)($b['players'] ?? 0) <=> (int)($a['players'] ?? 0));
    return array_slice($online, 0, $limit);
}

function gh_game_counts(): array
{
    $counts = array_fill_keys(gh_games(), 0);
    foreach (gh_servers() as $s) {
        $g = $s['game'] ?? '';
        if (isset($counts[$g])) {
            $counts[$g]++;
        }
    }
    return $counts;
}

function gh_platform_stats(): array
{
    $servers = gh_servers();
    $online = array_filter($servers, fn($s) => gh_server_is_online($s));
    $players = array_sum(array_map(fn($s) => (int)($s['players'] ?? 0), $online));
    return [
        'servers'       => count($servers),
        'online'        => count($online),
        'players'       => $players,
        'games'         => count(array_filter(gh_game_counts())),
        'featured'      => count(array_filter($servers, fn($s) => !empty($s['featured']))),
    ];
}

function gh_settings(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = gh_load_settings();
    }
    return $cache;
}

function gh_maybe_auto_refresh_servers(): void
{
    $settings = gh_settings();
    $interval = max(30, (int)($settings['refresh_interval_sec'] ?? 60));
    $stampFile = gh_data_path('last-refresh.txt');
    $last = is_file($stampFile) ? (int)file_get_contents($stampFile) : 0;
    if (time() - $last < $interval) {
        return;
    }
    gh_refresh_all_servers();
    @file_put_contents($stampFile, (string)time(), LOCK_EX);
}

function gh_server_image(array $server, string $size = 'lg'): string
{
    $custom = trim($server['image'] ?? '');
    if ($custom !== '') {
        return $custom;
    }
    if (!empty(gh_settings()['show_map_previews'])) {
        $slug = gh_server_map_slug($server);
        if ($slug !== '') {
            return gh_map_image($slug, $server['game'] ?? 'cs2', $size === 'thumb' ? 'thumb' : 'lg');
        }
    }
    return gh_placeholder_image();
}

function gh_steam_connect_url(array $server): string
{
    $host = trim($server['host'] ?? '');
    $port = (int)($server['port'] ?? 0);
    if ($host === '' || $port < 1) {
        return '';
    }
    return 'steam://connect/' . $host . ':' . $port;
}

function gh_server_tags(array $server): array
{
    $tags = $server['tags'] ?? [];
    if (is_string($tags)) {
        $tags = array_filter(array_map('trim', explode(',', $tags)));
    }
    return is_array($tags) ? array_values($tags) : [];
}

function gh_server_player_list(array $server): array
{
    $list = $server['player_list'] ?? [];
    if (is_string($list)) {
        $list = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $list) ?: []));
    }
    return is_array($list) ? array_values($list) : [];
}

function gh_server_status_payload(array $server): array
{
    return [
        'id' => $server['id'] ?? '',
        'status' => $server['status'] ?? 'offline',
        'players' => (int)($server['players'] ?? 0),
        'max_players' => (int)($server['max_players'] ?? 0),
        'map' => $server['map'] ?? '',
        'map_slug' => gh_server_map_slug($server),
        'map_name' => gh_map_display_name(gh_server_map_slug($server), $GLOBALS['lang'] ?? 'en', $server['game'] ?? 'cs2'),
        'ping_ms' => (int)($server['ping_ms'] ?? 0),
        'image' => gh_server_image($server, 'thumb'),
        'last_check' => $server['last_check'] ?? '',
        'address' => gh_server_address($server),
    ];
}

function gh_related_servers(array $server, int $limit = 4): array
{
    $game = $server['game'] ?? '';
    $related = array_values(array_filter(
        gh_servers(),
        fn($s) => ($s['id'] ?? '') !== ($server['id'] ?? '') && ($s['game'] ?? '') === $game
    ));
    if (count($related) < $limit) {
        $extra = array_values(array_filter(
            gh_servers(),
            fn($s) => ($s['id'] ?? '') !== ($server['id'] ?? '')
        ));
        $related = array_merge($related, $extra);
    }
    return array_slice($related, 0, $limit);
}

function gh_server_long_desc(array $server, string $lang): string
{
    $long = gh_localized($server, 'long_desc', $lang);
    if ($long !== '') {
        return $long;
    }
    return gh_localized($server, 'desc', $lang);
}

function gh_lang_url(string $code, bool $for_hreflang = false): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: gh_url('index.php');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);
    if ($code === 'no' && $for_hreflang) {
        unset($q['lang']);
    } else {
        $q['lang'] = $code;
    }
    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}

function gh_game_icon(string $game): string
{
    return match ($game) {
        'cs2'      => 'crosshairs',
        'minecraft'=> 'cube',
        'rust'     => 'fire',
        'ark'      => 'dragon',
        'valheim'  => 'shield-halved',
        'tf2'      => 'hat-cowboy',
        default    => 'server',
    };
}

function gh_status_class(string $status): string
{
    return match ($status) {
        'online'      => 'online',
        'maintenance' => 'maintenance',
        default       => 'offline',
    };
}

function gh_format_last_check(array $server): string
{
    $raw = $server['last_check'] ?? '';
    $ts = strtotime($raw);
    return $ts !== false ? date('d.m.Y H:i', $ts) : '—';
}

function gh_admin_game_chart(): array
{
    $counts = gh_game_counts();
    $max = max(1, max($counts));
    $chart = [];
    foreach ($counts as $game => $n) {
        if ($n === 0) {
            continue;
        }
        $chart[] = ['game' => $game, 'count' => $n, 'pct' => round(($n / $max) * 100)];
    }
    usort($chart, fn($a, $b) => $b['count'] <=> $a['count']);
    return $chart;
}