<?php
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';
$current_page = 'home';
$search_params = gh_search_params();
$featured      = gh_featured_servers(6);
$online        = gh_online_servers(6);
$cs2_servers   = array_values(array_filter(gh_servers(), fn($s) => ($s['game'] ?? '') === 'cs2' && gh_server_is_online($s)));
$game_counts   = gh_game_counts();
$stats         = gh_platform_stats();
$canonical     = $site_url . '/';
$page_title    = $t['meta']['title'];
$page_desc     = $t['meta']['description'];
$canon_abs     = gh_absolute_url($canonical);
$seo_schemas   = [
    gh_seo_organization(),
    gh_seo_website($canon_abs),
    gh_seo_software_app($canon_abs, $page_desc),
    gh_seo_webpage($canon_abs, $page_title, $page_desc),
    gh_seo_professional_service(),
    gh_seo_item_list(gh_servers(), $lang, $canon_abs),
    gh_seo_faq_page([
        ['q' => $t['faq']['q1'] ?? 'What is GameHub CMS?', 'a' => $t['faq']['a1'] ?? ''],
        ['q' => $t['faq']['q2'] ?? 'Which games are supported?', 'a' => $t['faq']['a2'] ?? ''],
        ['q' => $t['faq']['q3'] ?? 'Are server stats live?', 'a' => $t['faq']['a3'] ?? ''],
    ]),
];
require __DIR__ . '/includes/header.php';
?>

<section class="gh-hero cs2-hero" aria-labelledby="cs2-hero-title">
    <canvas id="ghCs2Canvas" class="cs2-hero-canvas" aria-hidden="true"></canvas>
    <div class="cs2-hero-scanlines" aria-hidden="true"></div>
    <div class="cs2-hero-grid" aria-hidden="true"></div>
    <div class="cs2-hero-vignette" aria-hidden="true"></div>

    <div class="cs2-hero-layout">
        <div class="cs2-hero-visual" aria-hidden="true">
            <div class="cs2-scene-wrap">
                <span class="cs2-hud-corner cs2-hud-corner--tl"></span>
                <span class="cs2-hud-corner cs2-hud-corner--tr"></span>
                <span class="cs2-hud-corner cs2-hud-corner--bl"></span>
                <span class="cs2-hud-corner cs2-hud-corner--br"></span>
                <div class="cs2-scene-3d">
                    <div class="cs2-map-block">
                        <div class="cs2-map-face cs2-map-face--front">DUST II</div>
                        <div class="cs2-map-face cs2-map-face--back">128 TICK</div>
                        <div class="cs2-map-face cs2-map-face--right">EU #1</div>
                        <div class="cs2-map-face cs2-map-face--left">VAC</div>
                        <div class="cs2-map-face cs2-map-face--top">CS2</div>
                        <div class="cs2-map-face cs2-map-face--bottom">LIVE</div>
                    </div>
                </div>
                <div class="cs2-crosshair"></div>
            </div>
        </div>

        <div class="cs2-hero-text">
            <span class="cs2-live-badge"><i class="fas fa-circle"></i> <?= htmlspecialchars($t['hero']['badge']) ?></span>
            <h1 class="cs2-title" id="cs2-hero-title"><?= htmlspecialchars($t['hero']['title']) ?></h1>
            <p class="cs2-subtitle"><?= htmlspecialchars($t['hero']['subtitle']) ?></p>
            <div class="cs2-hero-tags">
                <span class="cs2-tag cs2-tag--t">128-tick</span>
                <span class="cs2-tag">VAC Secure</span>
                <span class="cs2-tag cs2-tag--t">EU / Norway</span>
                <span class="cs2-tag">Live demo</span>
            </div>
            <?php require __DIR__ . '/includes/search-form.php'; ?>
        </div>
    </div>
</section>

<section class="gh-stats-bar" aria-label="<?= htmlspecialchars($t['home']['stats_servers']) ?>">
    <div class="gh-container gh-stats-inner">
        <div><strong data-count="<?= (int)$stats['servers'] ?>"><?= (int)$stats['servers'] ?></strong><span><?= htmlspecialchars($t['home']['stats_servers']) ?></span></div>
        <div><strong data-count="<?= (int)$stats['online'] ?>"><?= (int)$stats['online'] ?></strong><span><?= htmlspecialchars($t['home']['stats_online']) ?></span></div>
        <div><strong data-count="<?= (int)$stats['players'] ?>"><?= (int)$stats['players'] ?></strong><span><?= htmlspecialchars($t['home']['stats_players']) ?></span></div>
        <div><strong data-count="<?= (int)$stats['games'] ?>"><?= (int)$stats['games'] ?></strong><span><?= htmlspecialchars($t['home']['stats_games']) ?></span></div>
    </div>
</section>

<?php if ($cs2_servers): ?>
<section class="cs2-showcase">
    <div class="gh-container">
        <div class="cs2-showcase-head">
            <div>
                <h2><i class="fas fa-crosshairs"></i> <?= htmlspecialchars($t['home']['cs2_servers'] ?? 'Counter-Strike 2') ?></h2>
                <p><?= htmlspecialchars($t['home']['cs2_servers_sub'] ?? '') ?></p>
            </div>
            <a href="<?= gh_url('search.php?game=cs2') ?>" class="gh-link-more"><?= htmlspecialchars($t['home']['view_cs2'] ?? 'All CS2 servers') ?> →</a>
        </div>
        <div class="cs2-ticker">
            <?php foreach (array_slice($cs2_servers, 0, 5) as $srv):
                $sname = gh_localized($srv, 'name', $lang);
                $surl  = gh_server_url((string)($srv['id'] ?? ''));
            ?>
            <a href="<?= htmlspecialchars($surl) ?>" class="cs2-ticker-card">
                <?php $thumb = gh_server_image($srv, 'thumb'); ?>
                <img src="<?= htmlspecialchars($thumb) ?>" alt="" class="cs2-ticker-map" loading="lazy" width="48" height="27" onerror="this.style.display='none'">
                <strong><?= htmlspecialchars($sname) ?></strong>
                <span><?= htmlspecialchars(gh_map_display_name(gh_server_map_slug($srv), $lang, 'cs2')) ?> · <?= htmlspecialchars(gh_server_players_label($srv)) ?>
                <?php if ((int)($srv['ping_ms'] ?? 0) > 0): ?><span class="cs2-ping"><?= (int)$srv['ping_ms'] ?> ms</span><?php endif; ?>
                </span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="gh-about-script">
    <div class="gh-container gh-about-script-inner">
        <div>
            <h2><?= htmlspecialchars($t['about_script']['title']) ?></h2>
            <p><?= htmlspecialchars($t['about_script']['text']) ?></p>
            <ul class="gh-about-features">
                <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($t['about_script']['f1']) ?></li>
                <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($t['about_script']['f2']) ?></li>
                <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($t['about_script']['f3']) ?></li>
            </ul>
            <div class="gh-about-actions">
                <a href="<?= gh_url('admin/login.php') ?>" class="gh-btn-primary"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['about_script']['admin_btn']) ?></a>
                <a href="<?= gh_url('contact.php') ?>" class="gh-btn-outline-dark"><i class="fas fa-comments"></i> <?= htmlspecialchars(cms_contact_texts('gamehub', $lang)['nav_discuss']) ?></a>
            </div>
            <p class="gh-about-creds"><i class="fas fa-key"></i> <?= htmlspecialchars($t['about_script']['creds']) ?></p>
        </div>
    </div>
</section>

<section class="gh-section">
    <div class="gh-container">
        <div class="gh-section-head">
            <div>
                <h2><?= htmlspecialchars($t['home']['featured']) ?></h2>
                <p><?= htmlspecialchars($t['home']['featured_sub']) ?></p>
            </div>
            <a href="<?= gh_url('search.php') ?>" class="gh-link-more"><?= htmlspecialchars($t['home']['view_all']) ?> →</a>
        </div>
        <div class="gh-server-grid">
            <?php foreach ($featured as $server):
                require __DIR__ . '/includes/server-card.php';
            endforeach; ?>
        </div>
    </div>
</section>

<section class="gh-section gh-section-alt">
    <div class="gh-container">
        <div class="gh-section-head">
            <div>
                <h2><?= htmlspecialchars($t['home']['online']) ?></h2>
                <p><?= htmlspecialchars($t['home']['online_sub']) ?></p>
            </div>
        </div>
        <div class="gh-server-grid">
            <?php foreach ($online as $server):
                require __DIR__ . '/includes/server-card.php';
            endforeach; ?>
        </div>
    </div>
</section>

<?php $cs2_maps = gh_maps_for_game('cs2'); if ($cs2_maps !== []): ?>
<section class="gh-section gh-section-alt">
    <div class="gh-container">
        <div class="gh-section-head">
            <div>
                <h2><?= htmlspecialchars($t['home']['maps_title'] ?? 'CS2 map previews') ?></h2>
                <p><?= htmlspecialchars($t['home']['maps_sub'] ?? '') ?></p>
            </div>
            <a href="<?= gh_url('maps.php?game=cs2') ?>" class="gh-link-more"><?= htmlspecialchars($t['home']['view_maps'] ?? 'All maps') ?> →</a>
        </div>
        <div class="gh-map-grid gh-map-grid--home">
            <?php foreach (array_slice($cs2_maps, 0, 4, true) as $slug => $entry):
                $mlabel = is_array($entry['name'] ?? null) ? ($entry['name'][$lang] ?? $entry['name']['en'] ?? $slug) : $slug;
            ?>
            <a href="<?= gh_url('search.php?game=cs2&map=' . urlencode($slug)) ?>" class="gh-map-card gh-map-card--compact">
                <img src="<?= htmlspecialchars($entry['thumb'] ?? gh_map_image($slug, 'cs2', 'thumb')) ?>" alt="<?= htmlspecialchars($mlabel) ?>" loading="lazy" width="200" height="112">
                <span><?= htmlspecialchars($mlabel) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="gh-section">
    <div class="gh-container">
        <h2><?= htmlspecialchars($t['home']['games']) ?></h2>
        <div class="gh-game-tags">
            <?php foreach ($game_counts as $game => $count):
                if ($count < 1) continue;
            ?>
            <a href="<?= gh_url('game.php?game=' . urlencode($game)) ?>" class="gh-game-tag-lg">
                <i class="fas fa-<?= htmlspecialchars(gh_game_icon($game)) ?>"></i>
                <?= htmlspecialchars($t['games'][$game] ?? $game) ?>
                <span><?= (int)$count ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>