<?php
$en = require __DIR__ . '/en.php';
return array_replace_recursive($en, [
    'meta' => [
        'title'       => 'GameHub CMS — Spillserverovervåking Norge | PHP monitor',
        'description' => 'Universelt PHP spillserver-monitoreringsskript fra Norge. CS2, Minecraft, Rust og mer. Adminpanel, 4 språk, Schema.org SEO.',
        'keywords'    => 'spillserver monitor, CS2 serverliste, Minecraft server, PHP game hub, Norge, bilohash',
    ],
    'nav' => [
        'servers' => 'Servere', 'games' => 'Spill', 'maps' => 'Kart', 'online' => 'Online nå',
        'search' => 'Søk', 'admin' => 'Admin', 'menu' => 'Meny', 'menu_close' => 'Lukk meny',
        'main_nav' => 'Hovednavigasjon', 'skip' => 'Hopp til innhold', 'lang' => 'Språk',
    ],
    'search' => [
        'keyword' => 'Søk servere', 'game' => 'Spill', 'region' => 'Region',
        'search_btn' => 'Søk', 'placeholder' => 'Servernavn, IP, kart eller spill',
        'all_games' => 'Alle spill', 'all_regions' => 'Alle regioner', 'all_status' => 'Alle statuser',
    ],
    'demo_strip' => [
        'text' => 'Demo overvåkingsplattform — eksempelservere, ingen ekte A2S-forespørsler. Admin kan redigere alle data.',
        'cms'  => 'GameHub CMS',
    ],
    'hero' => [
        'title'    => 'Counter-Strike 2 serverhub',
        'subtitle' => 'Taktisk live-monitor for CS2 — 128-tick, VAC, EU-ping, kart og spillere. Minecraft, Rust og ARK i ett PHP-skript.',
        'badge'    => 'Live demo · CS2-monitor',
    ],
    'about_script' => [
        'title'     => 'Universelt spillserver-monitoreringsskript',
        'text'      => 'GameHub CMS er en PHP serverliste og overvåkingsdashboard fra Norge. Legg til servere i admin, vis online/offline, spillere, kart og regioner — flerspråklig frontend med Schema.org og JSON.',
        'f1'        => 'Offentlig site: serverliste, filtre, detaljsider, kopier IP',
        'f2'        => 'Admin: legg til/rediger servere, spillere, status, featured',
        'f3'        => 'PHP 8+, JSON, 4 språk — klar for Steam A2S / Query API',
        'demo_btn'  => 'Live demo', 'admin_btn' => 'Adminpanel',
        'creds'     => 'Admin demo: demo / bilogamehub2026',
    ],
    'home' => [
        'featured' => 'Utvalgte servere', 'featured_sub' => 'Populære demoservere på tvers av spill',
        'online' => 'Online nå', 'online_sub' => 'Servere med aktive spillere',
        'games' => 'Bla etter spill', 'view_all' => 'Se alle servere', 'servers' => 'servere',
        'stats_servers' => 'Servere', 'stats_online' => 'Online', 'stats_players' => 'Spillere', 'stats_games' => 'Spill',
        'cs2_servers' => 'Counter-Strike 2 — live nå',
        'cs2_servers_sub' => 'EU competitive & practice — dust2, mirage, 128-tick demodata',
        'view_cs2' => 'Alle CS2-servere',
        'maps_title' => 'CS2 kart-forhåndsvisning', 'maps_sub' => 'Live kartminiatyrer — dust2, mirage, inferno og mer',
        'view_maps' => 'Alle kart',
    ],
    'games' => [
        'cs2' => 'Counter-Strike 2', 'minecraft' => 'Minecraft', 'rust' => 'Rust',
        'ark' => 'ARK: Survival', 'valheim' => 'Valheim', 'tf2' => 'Team Fortress 2',
    ],
    'regions' => [
        'eu' => 'Europa', 'na' => 'Nord-Amerika', 'asia' => 'Asia', 'oce' => 'Oseania',
    ],
    'status' => [
        'online' => 'Online', 'offline' => 'Offline', 'maintenance' => 'Vedlikehold',
    ],
    'card' => [
        'players' => 'Spillere', 'view_server' => 'Se server', 'copy_ip' => 'Kopier IP',
        'copied' => 'Kopiert!', 'join_steam' => 'Spill via Steam',
    ],
    'server' => [
        'address' => 'Serveradresse', 'map' => 'Kart / verden', 'players' => 'Spillere',
        'ping' => 'Ping', 'region' => 'Region', 'game' => 'Spill', 'status' => 'Status',
        'last_check' => 'Sist sjekket', 'vac' => 'VAC / secure', 'version' => 'Versjon',
        'join' => 'Spill via Steam', 'copy' => 'Kopier adresse', 'related' => 'Relaterte servere',
        'players_online' => 'Spillere online', 'tickrate' => 'Tickrate', 'mode' => 'Modus',
        'demo_note' => 'Demodata — produksjon kan koble Steam A2S, Minecraft Query eller cron.',
    ],
    'maps_page' => [
        'title' => 'Kartbrowser', 'sub' => 'Forhåndsvis CS2-kart — finn servere per kart.',
        'description' => 'Bla gjennom Counter-Strike 2 kart og finn live-servere per kart.',
        'servers' => 'servere',
    ],
    'game_page' => [
        'title_suffix' => 'live-servere',
        'description' => 'Bla gjennom live %s-servere — spillere, kart, ping og kopier IP.',
        'found' => '%d servere funnet',
    ],
    'faq' => [
        'q1' => 'Hva er GameHub CMS?',
        'a1' => 'GameHub CMS er et PHP spillserver-monitoreringsskript med offentlig browser, kartforhåndsvisning, adminpanel og flerspråklig SEO.',
        'q2' => 'Hvilke spill støttes?',
        'a2' => 'Counter-Strike 2, Minecraft, Rust, ARK og mer — legg til spill via admin.',
        'q3' => 'Er serverstatistikk live?',
        'a3' => 'Denne demoen bruker simulert oppdatering med valgfrie Steam A2S-forespørsler. Produksjon kan aktivere ekte UDP-overvåking.',
    ],
    'search_page' => [
        'title' => 'Serversøk', 'found' => '%d servere funnet',
        'no_results' => 'Ingen servere matcher filtrene.',
        'sort' => 'Sorter', 'sort_players' => 'Flest spillere',
        'sort_name' => 'Navn', 'sort_ping' => 'Lavest ping', 'sort_game' => 'Spill',
        'filter_online' => 'Kun online',
    ],
    'breadcrumb_home' => 'Hjem',
    'footer' => [
        'servers' => 'Alle servere', 'online' => 'Online servere',
        'product_page' => 'Produktside', 'admin_demo' => 'Admin demo',
        'sitemap' => 'Nettstedskart', 'llms' => 'llms.txt',
        'copyright' => '© %s GameHub CMS Demo.',
    ],
    'contact_page' => [
        'maps_title' => 'CS2 kart-forhåndsvisning',
        'maps_sub' => 'Ekte kartminiatyrer — dust2, mirage, inferno og mer.',
        'demo_server' => 'Prøv live demo', 'play_steam' => 'Spill via Steam',
        'view_maps' => 'Alle kart', 'aside' => 'CS2 demo og kart',
    ],
    'admin' => [
        'login' => 'Admin-innlogging', 'servers' => 'Servere', 'dashboard' => 'Dashboard',
        'settings' => 'Innstillinger', 'maps' => 'Kart', 'refresh_now' => 'Oppdater servere',
        'show_map_previews' => 'Kart-forhåndsvisning', 'panel' => 'Adminpanel',
    ],
]);