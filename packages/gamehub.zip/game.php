<?php
require_once __DIR__ . '/init.php';
$current_page = 'game';
$game = trim($_GET['game'] ?? gh_settings()['default_game'] ?? 'cs2');
if (!in_array($game, gh_games(), true)) {
    header('Location: ' . gh_url('search.php'), true, 302);
    exit;
}
$search_params = ['q' => '', 'game' => $game, 'region' => '', 'status' => '', 'sort' => gh_settings()['default_sort'] ?? 'players', 'map' => ''];
$results = gh_filter_servers($search_params, $lang);
$gameName = $t['games'][$game] ?? $game;
$page_title = $gameName . ' — ' . ($t['game_page']['title_suffix'] ?? 'servers');
$page_desc = sprintf($t['game_page']['description'] ?? $t['meta']['description'], $gameName);
$canonical = $site_url . '/game.php?game=' . urlencode($game) . ($lang !== 'no' ? '&lang=' . $lang : '');
$canon_abs = gh_absolute_url($canonical);
$seo_schemas = [
    gh_seo_organization(),
    gh_seo_webpage($canon_abs, $page_title, $page_desc),
    gh_seo_item_list($results, $lang, $canon_abs),
    gh_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => gh_absolute_url(gh_url('index.php'))],
        ['name' => $gameName, 'url' => $canon_abs],
    ]),
];
require __DIR__ . '/includes/header.php';
?>

<section class="gh-hero gh-hero-compact gh-hero-game">
    <div class="gh-hero-inner gh-container">
        <h1><i class="fas fa-<?= htmlspecialchars(gh_game_icon($game)) ?>"></i> <?= htmlspecialchars($gameName) ?></h1>
        <p><?= sprintf(htmlspecialchars($t['game_page']['found'] ?? '%d servers'), count($results)) ?></p>
        <?php require __DIR__ . '/includes/search-form.php'; ?>
    </div>
</section>

<div class="gh-container">
    <div class="gh-server-grid">
        <?php foreach ($results as $server):
            require __DIR__ . '/includes/server-card.php';
        endforeach; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>