<?php
require_once dirname(__DIR__, 3) . '/includes/cms-contact.php';
$cms_nav_discuss = cms_contact_texts('gamehub', $lang)['nav_discuss'];
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? $site_url . '/';
$seo_schemas = $seo_schemas ?? ghs_seo_schemas(ghs_absolute_url($canonical), $page_title, $page_desc);
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php ghs_render_seo_head($page_title, $page_desc, $canonical, $seo_schemas); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(ghs_asset('css/site.css')) ?>?v=1">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%2306080c' width='100' height='100' rx='12'/><text x='50' y='58' font-size='32' text-anchor='middle' fill='%234a9eff' font-family='sans-serif' font-weight='bold'>G</text></svg>">
</head>
<body>
<?php require dirname(__DIR__, 3) . '/includes/ecosystem-top-bar.php'; ?>
<header class="ghs-header" id="ghsHeader">
    <div class="ghs-header-inner">
        <a href="<?= ghs_url('index.php') ?>" class="ghs-logo">
            <span class="ghs-logo-icon"><i class="fas fa-gamepad"></i></span>
            <span class="ghs-logo-text">GameHub <em>CMS</em></span>
        </a>
        <nav class="ghs-nav" aria-label="<?= htmlspecialchars($t['nav']['main_nav'] ?? 'Main') ?>">
            <a href="<?= ghs_url('index.php#features') ?>"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="<?= ghs_url('index.php#tech') ?>"><?= htmlspecialchars($t['nav']['tech']) ?></a>
            <a href="<?= ghs_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a>
            <a href="<?= ghs_url('index.php#faq') ?>">FAQ</a>
        </nav>
        <div class="ghs-header-tools">
            <?php require __DIR__ . '/lang-dropdown.php'; ?>
            <button class="ghs-menu-toggle" id="ghsMenuBtn" aria-label="<?= htmlspecialchars($t['nav']['menu'] ?? 'Menu') ?>" type="button" aria-expanded="false">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="ghs-header-actions">
            <a href="<?= ghs_demo_url() ?>" class="ghs-btn-ghost"><i class="fas fa-server"></i> <?= htmlspecialchars($t['demo']['frontend']) ?></a>
            <a href="<?= ghs_demo_url('admin/login.php') ?>" class="ghs-btn-ghost"><i class="fas fa-lock"></i> <?= htmlspecialchars($t['nav']['admin']) ?></a>
            <a href="<?= ghs_demo_url('contact.php') ?>" class="ghs-btn-primary"><i class="fas fa-comments"></i> <?= htmlspecialchars($cms_nav_discuss) ?></a>
        </div>
    </div>
    <div class="ghs-mobile-panel" id="ghsMobilePanel" hidden>
        <nav class="ghs-nav-mobile">
            <a href="<?= ghs_url('index.php#features') ?>"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="<?= ghs_url('index.php#tech') ?>"><?= htmlspecialchars($t['nav']['tech']) ?></a>
            <a href="<?= ghs_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a>
            <a href="<?= ghs_demo_url() ?>"><?= htmlspecialchars($t['demo']['frontend']) ?></a>
            <a href="<?= ghs_demo_url('contact.php') ?>"><?= htmlspecialchars($cms_nav_discuss) ?></a>
        </nav>
    </div>
</header>