<?php
/** @var array $cms_t @var array $cms_values @var string $cms_alert @var string $cms_alert_type @var string $cms_action @var string $cms_csrf */
$cp = $t['contact_page'] ?? [];
$cs2_maps = gh_maps_for_game('cs2');
$demo_server = null;
foreach (gh_online_servers(12) as $srv) {
    if (($srv['game'] ?? '') === 'cs2') {
        $demo_server = $srv;
        break;
    }
}
if ($demo_server === null) {
    foreach (gh_servers() as $srv) {
        if (($srv['game'] ?? '') === 'cs2') {
            $demo_server = $srv;
            break;
        }
    }
}
$settings = gh_settings();
$steam_url = $demo_server ? gh_steam_connect_url($demo_server) : '';
$steam_online = $demo_server && gh_server_is_online($demo_server);
?>
<div class="gh-contact-wrap">
    <nav class="gh-contact-breadcrumb" aria-label="Breadcrumb">
        <a href="<?= gh_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a>
        <span aria-hidden="true">→</span>
        <span><?= htmlspecialchars($cms_t['h1']) ?></span>
    </nav>

    <header class="gh-contact-hero">
        <div class="gh-contact-kicker"><i class="fas fa-comments"></i> GameHub CMS</div>
        <h1><?= htmlspecialchars($cms_t['h1']) ?></h1>
        <p><?= htmlspecialchars($cms_t['subtitle']) ?></p>
    </header>

    <div class="gh-contact-layout">
        <div class="gh-contact-main">
            <div class="gh-contact-form-card">
                <?php if (!empty($cms_alert)): ?>
                <div class="gh-contact-alert gh-contact-alert--<?= htmlspecialchars($cms_alert_type) ?>" role="status">
                    <?= htmlspecialchars($cms_alert) ?>
                </div>
                <?php endif; ?>

                <form class="gh-contact-form" method="post" action="<?= htmlspecialchars($cms_action) ?>">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($cms_csrf ?? '') ?>">
                    <input type="text" name="website" value="" tabindex="-1" autocomplete="off" class="gh-hp" aria-hidden="true">

                    <div class="gh-contact-grid">
                        <label class="gh-contact-field">
                            <span><?= htmlspecialchars($cms_t['name']) ?> *</span>
                            <input type="text" name="name" required maxlength="120" value="<?= htmlspecialchars($cms_values['name']) ?>" autocomplete="name">
                        </label>
                        <label class="gh-contact-field">
                            <span><?= htmlspecialchars($cms_t['email']) ?> *</span>
                            <input type="email" name="email" required maxlength="160" value="<?= htmlspecialchars($cms_values['email']) ?>" autocomplete="email">
                        </label>
                        <label class="gh-contact-field">
                            <span><?= htmlspecialchars($cms_t['phone']) ?></span>
                            <input type="tel" name="phone" maxlength="24" value="<?= htmlspecialchars($cms_values['phone']) ?>" autocomplete="tel">
                        </label>
                        <label class="gh-contact-field gh-contact-field--full">
                            <span><?= htmlspecialchars($cms_t['subject']) ?></span>
                            <input type="text" name="subject" maxlength="200" value="<?= htmlspecialchars($cms_values['subject']) ?>" placeholder="<?= htmlspecialchars($cms_t['default_subject'] ?? '') ?>">
                        </label>
                        <label class="gh-contact-field gh-contact-field--full">
                            <span><?= htmlspecialchars($cms_t['message']) ?> *</span>
                            <textarea name="message" required rows="7" minlength="20" maxlength="5000" placeholder="<?= htmlspecialchars($cms_t['default_subject'] ?? '') ?>"><?= htmlspecialchars($cms_values['message']) ?></textarea>
                        </label>
                    </div>

                    <?php $cms_recap_key = cms_recaptcha_site_key(); if ($cms_recap_key !== ''): ?>
                    <div class="gh-contact-captcha">
                        <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($cms_recap_key) ?>"></div>
                    </div>
                    <?php endif; ?>

                    <p class="gh-contact-note"><?= htmlspecialchars($cms_t['privacy_note']) ?></p>

                    <button type="submit" class="gh-contact-submit">
                        <i class="fas fa-paper-plane" aria-hidden="true"></i> <?= htmlspecialchars($cms_t['submit']) ?>
                    </button>
                </form>
            </div>
        </div>

        <aside class="gh-contact-aside" aria-label="<?= htmlspecialchars($cp['aside'] ?? 'CS2 demo') ?>">
            <?php if ($cs2_maps !== []): ?>
            <div class="gh-contact-aside-block">
                <h2 class="gh-contact-aside-title"><i class="fas fa-map"></i> <?= htmlspecialchars($cp['maps_title'] ?? 'CS2 map previews') ?></h2>
                <p class="gh-contact-aside-hint"><?= htmlspecialchars($cp['maps_sub'] ?? '') ?></p>
                <div class="gh-contact-map-grid">
                    <?php foreach (array_slice($cs2_maps, 0, 4, true) as $slug => $entry):
                        $mlabel = gh_map_display_name($slug, $lang, 'cs2');
                    ?>
                    <a href="<?= gh_url('search.php?game=cs2&map=' . urlencode($slug)) ?>" class="gh-contact-map-tile">
                        <img src="<?= htmlspecialchars(gh_map_image($slug, 'cs2', 'thumb')) ?>" alt="<?= htmlspecialchars($mlabel) ?>" loading="lazy" width="200" height="112" onerror="this.onerror=null;this.src='<?= htmlspecialchars(gh_placeholder_image()) ?>';">
                        <span><?= htmlspecialchars($mlabel) ?></span>
                    </a>
                    <?php endforeach; ?>
                </div>
                <a href="<?= gh_url('maps.php?game=cs2') ?>" class="gh-contact-aside-link"><?= htmlspecialchars($cp['view_maps'] ?? 'All maps') ?> →</a>
            </div>
            <?php endif; ?>

            <?php if ($demo_server): ?>
            <div class="gh-contact-aside-block">
                <h2 class="gh-contact-aside-title"><i class="fas fa-gamepad"></i> <?= htmlspecialchars($cp['demo_server'] ?? 'Try live demo') ?></h2>
                <div class="gh-contact-demo">
                    <div class="gh-contact-demo-card">
                        <img src="<?= htmlspecialchars(gh_server_image($demo_server, 'thumb')) ?>" alt="<?= htmlspecialchars(gh_map_display_name(gh_server_map_slug($demo_server), $lang, 'cs2')) ?>" loading="lazy" width="96" height="54" onerror="this.onerror=null;this.src='<?= htmlspecialchars(gh_placeholder_image()) ?>';">
                        <div>
                            <h3><?= htmlspecialchars(gh_localized($demo_server, 'name', $lang)) ?></h3>
                            <p><?= htmlspecialchars(gh_map_display_name(gh_server_map_slug($demo_server), $lang, 'cs2')) ?> · <?= htmlspecialchars(gh_server_players_label($demo_server)) ?></p>
                            <div class="gh-contact-demo-actions">
                                <?php if (!empty($settings['steam_connect_enabled']) && $steam_url !== '' && $steam_online): ?>
                                <a href="<?= htmlspecialchars($steam_url) ?>" class="gh-btn-steam">
                                    <i class="fab fa-steam"></i> <?= htmlspecialchars($cp['play_steam'] ?? $t['server']['join'] ?? 'Play via Steam') ?>
                                </a>
                                <?php endif; ?>
                                <a href="<?= htmlspecialchars(gh_server_url((string)($demo_server['id'] ?? ''))) ?>" class="gh-btn-ghost">
                                    <i class="fas fa-server"></i> <?= htmlspecialchars($t['card']['view_server'] ?? 'View server') ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </aside>
    </div>
</div>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>