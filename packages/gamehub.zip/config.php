<?php
/**
 * Bilohash GameHub — game server monitoring CMS demo
 * /gamehub
 */
define('GH_BASE_PATH', '/gamehub');
define('GH_DOMAIN', 'bilohash.com');
define('GH_SITE_NAME', 'GameHub CMS');
define('GH_DEMO_MODE', true);

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, GH_DOMAIN) !== false) ? GH_BASE_PATH : ($detected ?: GH_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function gh_url(string $path = ''): string
{
    global $base_path;
    return rtrim($base_path, '/') . '/' . ltrim($path, '/');
}

function gh_page_url(string $path = ''): string
{
    $url = gh_url($path);
    $lang = $GLOBALS['lang'] ?? 'no';
    if ($lang === 'no') {
        return $url;
    }
    return $url . (str_contains($url, '?') ? '&' : '?') . 'lang=' . rawurlencode($lang);
}

function gh_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function gh_server_url(string $id, ?string $lang = null): string
{
    if ($lang === null) {
        $lang = $GLOBALS['lang'] ?? 'no';
    }
    $id = trim($id);
    if ($id === '') {
        return gh_url('search.php');
    }
    $path = 'server.php?id=' . rawurlencode($id);
    if ($lang !== null && $lang !== '' && $lang !== 'no') {
        $path .= '&lang=' . rawurlencode($lang);
    }
    return gh_url($path);
}

function gh_placeholder_image(): string
{
    return gh_asset('images/placeholder.svg');
}

if (!function_exists('bh_str_lower')) {
    function bh_str_lower(string $str): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($str) : strtolower($str);
    }
}

if (!function_exists('bh_str_sub')) {
    function bh_str_sub(string $str, int $start, ?int $length = null): string
    {
        if (function_exists('mb_substr')) {
            return $length === null ? mb_substr($str, $start) : mb_substr($str, $start, $length);
        }
        return $length === null ? substr($str, $start) : substr($str, $start, $length);
    }
}