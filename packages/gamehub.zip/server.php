<?php
require_once __DIR__ . '/init.php';

$id = trim($_GET['id'] ?? '');
$server = $id !== '' ? gh_server_by_id($id) : null;

if (!$server) {
    http_response_code(404);
    $page_title = '404';
    $page_desc  = $t['meta']['description'];
    $canonical  = $site_url . '/server.php';
    require __DIR__ . '/includes/header.php';
    echo '<div class="gh-container"><div class="gh-empty-state"><i class="fas fa-server"></i><p>Server not found.</p><a href="' . htmlspecialchars(gh_url('search.php')) . '" class="gh-btn-primary">' . htmlspecialchars($t['breadcrumb_home']) . '</a></div></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$name       = gh_localized($server, 'name', $lang);
$desc       = gh_server_long_desc($server, $lang);
$game       = $server['game'] ?? '';
$related    = gh_related_servers($server);
$online     = gh_server_is_online($server);
$fill       = gh_server_fill_pct($server);
$canonical  = $site_url . '/server.php?id=' . urlencode($id) . ($lang !== 'no' ? '&lang=' . $lang : '');
$canon_abs  = gh_absolute_url($canonical);
$page_title = $name . ' — ' . $t['meta']['site_name'];
$page_desc  = bh_str_sub(gh_localized($server, 'desc', $lang), 0, 160);
$map_slug = gh_server_map_slug($server);
$map_name = gh_map_display_name($map_slug, $lang, $game);
$player_list = gh_server_player_list($server);
$tags = gh_server_tags($server);
$steam_url = gh_steam_connect_url($server);
$settings = gh_settings();
$seo_og_image = gh_server_image($server);
$seo_schemas = [
    gh_seo_organization(),
    gh_seo_webpage($canon_abs, $page_title, $page_desc),
    gh_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => gh_absolute_url(gh_url('index.php'))],
        ['name' => $t['games'][$game] ?? $game, 'url' => gh_absolute_url(gh_url('search.php?game=' . urlencode($game)))],
        ['name' => $name, 'url' => $canon_abs],
    ]),
    gh_seo_server($server, $lang, $canon_abs),
];
require __DIR__ . '/includes/header.php';
$addr = gh_server_address($server);
?>

<div class="gh-container gh-server-detail">
    <nav class="gh-breadcrumb">
        <a href="<?= gh_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
        → <a href="<?= gh_url('search.php?game=' . urlencode($game)) ?>"><?= htmlspecialchars($t['games'][$game] ?? $game) ?></a>
        → <?= htmlspecialchars($name) ?>
    </nav>

    <div class="gh-detail-layout">
        <div class="gh-detail-main">
            <figure class="gh-map-hero">
                <img src="<?= htmlspecialchars(gh_server_image($server)) ?>" alt="<?= htmlspecialchars($map_name) ?>" class="gh-detail-img gh-map-hero-img" onerror="this.onerror=null;this.src='<?= htmlspecialchars(gh_placeholder_image()) ?>';">
                <figcaption class="gh-map-hero-cap">
                    <span><i class="fas fa-map"></i> <?= htmlspecialchars($map_name) ?></span>
                    <?php if (!empty($server['tickrate'])): ?><span><i class="fas fa-bolt"></i> <?= (int)$server['tickrate'] ?> tick</span><?php endif; ?>
                    <?php if (!empty($server['mode'])): ?><span><i class="fas fa-gamepad"></i> <?= htmlspecialchars($server['mode']) ?></span><?php endif; ?>
                </figcaption>
            </figure>
            <div class="gh-detail-head">
                <span class="gh-game-tag"><i class="fas fa-<?= htmlspecialchars(gh_game_icon($game)) ?>"></i> <?= htmlspecialchars($t['games'][$game] ?? $game) ?></span>
                <span class="gh-status-badge gh-status-<?= htmlspecialchars(gh_status_class($server['status'] ?? '')) ?>">
                    <?= htmlspecialchars($t['status'][$server['status'] ?? ''] ?? $server['status']) ?>
                </span>
                <?php if (!empty($server['vac'])): ?><span class="gh-vac-badge"><i class="fas fa-shield-halved"></i> VAC</span><?php endif; ?>
            </div>
            <h1><?= htmlspecialchars($name) ?></h1>
            <?php if ($tags !== []): ?>
            <div class="gh-server-tags">
                <?php foreach ($tags as $tag): ?>
                <span class="gh-tag-pill"><?= htmlspecialchars($tag) ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <p class="gh-detail-desc"><?= nl2br(htmlspecialchars($desc)) ?></p>
            <?php if (!empty($settings['show_player_list']) && $player_list !== [] && $online): ?>
            <section class="gh-player-list" aria-labelledby="ghPlayersTitle">
                <h2 id="ghPlayersTitle"><i class="fas fa-users"></i> <?= htmlspecialchars($t['server']['players_online'] ?? 'Players online') ?> (<?= count($player_list) ?>)</h2>
                <ul>
                    <?php foreach ($player_list as $pl): ?>
                    <li><i class="fas fa-user"></i> <?= htmlspecialchars($pl) ?></li>
                    <?php endforeach; ?>
                </ul>
            </section>
            <?php endif; ?>
            <p class="gh-demo-note"><i class="fas fa-info-circle"></i> <?= htmlspecialchars($t['server']['demo_note']) ?></p>
        </div>
        <aside class="gh-detail-side">
            <div class="gh-side-card" id="ghServerLive" data-server-id="<?= htmlspecialchars($id) ?>">
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['address']) ?></span>
                    <strong id="ghServerAddr"><?= htmlspecialchars($addr) ?></strong>
                </div>
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['map']) ?></span>
                    <strong><?= htmlspecialchars($map_name) ?></strong>
                </div>
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['players']) ?></span>
                    <strong><?= htmlspecialchars(gh_server_players_label($server)) ?></strong>
                </div>
                <div class="gh-players-bar gh-players-bar-lg"><span style="width:<?= $fill ?>%"></span></div>
                <?php if ($online && (int)($server['ping_ms'] ?? 0) > 0): ?>
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['ping']) ?></span>
                    <strong><?= (int)$server['ping_ms'] ?> ms</strong>
                </div>
                <?php endif; ?>
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['region']) ?></span>
                    <strong><?= htmlspecialchars($t['regions'][$server['region'] ?? ''] ?? '') ?></strong>
                </div>
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['last_check']) ?></span>
                    <strong><?= htmlspecialchars(gh_format_last_check($server)) ?></strong>
                </div>
                <?php if (!empty($server['version'])): ?>
                <div class="gh-side-row">
                    <span><?= htmlspecialchars($t['server']['version']) ?></span>
                    <strong><?= htmlspecialchars($server['version']) ?></strong>
                </div>
                <?php endif; ?>
                <?php if (!empty($settings['steam_connect_enabled']) && $steam_url !== '' && $online): ?>
                <a href="<?= htmlspecialchars($steam_url) ?>" class="gh-btn-steam">
                    <i class="fab fa-steam"></i> <?= htmlspecialchars($t['server']['join']) ?>
                </a>
                <?php endif; ?>
                <button type="button" class="gh-btn-primary gh-copy-ip" data-copy="<?= htmlspecialchars($addr) ?>">
                    <i class="fas fa-copy"></i> <?= htmlspecialchars($t['server']['copy']) ?>
                </button>
                <?php if (!empty($server['discord_url'])): ?>
                <a href="<?= htmlspecialchars($server['discord_url']) ?>" class="gh-btn-outline gh-btn-discord" target="_blank" rel="noopener"><i class="fab fa-discord"></i> Discord</a>
                <?php endif; ?>
            </div>
        </aside>
    </div>

    <?php if (!empty($related)): ?>
    <section class="gh-related">
        <h2><?= htmlspecialchars($t['server']['related']) ?></h2>
        <div class="gh-server-grid">
            <?php foreach ($related as $related_server):
                $server = $related_server;
                require __DIR__ . '/includes/server-card.php';
            endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>