<?php
return [
    'meta' => [
        'title'       => 'GameHub CMS — Order game server monitoring website | CS2, Minecraft, Rust',
        'description' => 'Order custom PHP game server listing and monitoring CMS. Counter-Strike 2 map previews, A2S query, Steam join links, admin panel, Schema.org SEO and 4 languages. Live demo from Norway.',
        'keywords'    => 'game server monitoring CMS, CS2 server list, PHP game hub, server browser Norway, A2S query script, multiplayer server listing',
        'site_name'   => 'GameHub CMS',
    ],
    'nav' => [
        'features' => 'Features',
        'tech'     => 'Technology',
        'demo'     => 'Live demo',
        'admin'    => 'Admin',
        'contact'  => 'Contact',
        'menu'     => 'Menu',
        'main_nav' => 'Main navigation',
    ],
    'hero' => [
        'badge'       => 'PHP Game Server CMS · CS2 theme',
        'title'       => 'GameHub CMS',
        'subtitle'    => 'Tactical PHP platform for game server communities — Counter-Strike 2, Minecraft, Rust and ARK. Live player counts, map previews, Steam connect and multilingual SEO.',
        'cta_demo'    => 'View live demo',
        'cta_admin'   => 'Admin demo',
    ],
    'intro' => [
        'title' => 'One hub — every game community',
        'text'  => 'GameHub CMS is a standalone PHP monitoring system with server cards, search filters, map thumbnails, A2S refresh and a demo admin dashboard. Start from the live demo and adapt branding, games, Discord webhooks and white-label deployment.',
        'use_label' => 'Ideal for:',
        'use_cases' => ['CS2 communities', 'Minecraft networks', 'Rust clans', 'ARK servers', 'Multi-game hubs', 'LAN events', 'Esports orgs', 'Hosting resellers'],
    ],
    'features' => [
        'title' => 'Key features',
        'items' => [
            ['icon' => 'server', 'title' => 'Server browser', 'desc' => 'Filter by game, status, players and ping. Featured servers, online badges and quick Steam join.'],
            ['icon' => 'map', 'title' => 'CS2 map previews', 'desc' => 'Local map thumbnails for Dust2, Mirage, Inferno and more — with GitHub CDN fallback.'],
            ['icon' => 'globe', 'title' => '4 languages', 'desc' => 'Norwegian, English, Ukrainian and Russian with hreflang and cookie-based switching.'],
            ['icon' => 'crosshairs', 'title' => 'CS2 tactical UI', 'desc' => 'Dark navy theme, Rajdhani typography, gold/blue accents — fully responsive.'],
            ['icon' => 'magnifying-glass', 'title' => 'Search & A2S', 'desc' => 'Keyword search, game filters and optional A2S player refresh from admin settings.'],
            ['icon' => 'shield-halved', 'title' => 'Admin panel', 'desc' => 'Dashboard with stats, game chart and server editor — login demo / bilogamehub2026.'],
        ],
    ],
    'tech' => [
        'title' => 'Tech stack',
        'items' => [
            'PHP 8+ without frameworks — deploy on shared hosting or VPS in Norway/EU',
            'JSON storage for servers and settings (easy migration to MySQL)',
            'Modular i18n with per-locale language files and cookie-based switching',
            'SEO: canonical, hreflang, sitemap, robots.txt, Schema.org, Open Graph, llms.txt for AI agents',
            'CS2-themed responsive UI with Font Awesome 6 — no build step required',
            'Steam connect links, map images, cms-contact.php integration',
        ],
    ],
    'demo' => [
        'title'         => 'Try the demo',
        'frontend'      => 'Frontend demo',
        'frontend_desc' => 'Browse demo servers — stats, maps, search, FAQ and Steam play buttons. Switch languages with NO / EN / UA / RU.',
        'admin'         => 'Admin demo',
        'admin_desc'    => 'Log in with demo / bilogamehub2026 — dashboard, server list and refresh controls.',
        'open'          => 'Open',
    ],
    'faq' => [
        'title' => 'FAQ',
        'items' => [
            ['q' => 'Which games does GameHub CMS support?', 'a' => 'The demo includes Counter-Strike 2, Minecraft, Rust and ARK. New games can be added via JSON config and language files.'],
            ['q' => 'Does it query live player counts?', 'a' => 'Yes — optional A2S query refresh from the admin panel updates online status and player counts on a configurable interval.'],
            ['q' => 'Is there an admin demo?', 'a' => 'Yes — visit /gamehub/admin/ and log in with demo / bilogamehub2026.'],
        ],
    ],
    'cta' => [
        'title' => 'Need a server hub for your community?',
        'text'  => 'GameHub CMS can be adapted for Discord bots, VIP tiers, RCON, multi-tenant hosting panels or white-label esports branding.',
        'btn'   => 'Contact',
    ],
    'footer' => [
        'product'   => 'Product',
        'links'     => 'Links',
        'demo_link' => 'Live GameHub demo',
        'order'     => 'Order development',
        'llms'      => 'llms.txt for AI',
        'copyright' => '© %s GameHub CMS',
    ],
];