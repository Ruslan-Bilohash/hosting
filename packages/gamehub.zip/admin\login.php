<?php
require_once __DIR__ . '/init.php';
$ta = $t['admin'] ?? [];

if (gh_admin_logged()) {
    header('Location: ' . gh_admin_url('index.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (gh_admin_login(trim($_POST['username'] ?? ''), $_POST['password'] ?? '')) {
        header('Location: ' . gh_admin_url('index.php'));
        exit;
    }
    $error = $ta['login_error'] ?? 'Invalid username or password';
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= htmlspecialchars($ta['login_title'] ?? 'GameHub Admin') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(gh_asset('css/admin.css')) ?>?v=1">
</head>
<body>
<div class="adm-login-wrap">
    <div class="adm-login-box">
        <div class="logo">
            <div class="icon">G</div>
            <h1><?= htmlspecialchars($ta['login_title'] ?? 'GameHub Admin') ?></h1>
        </div>
        <div class="adm-demo-hint"><i class="fas fa-info-circle"></i> demo / bilogamehub2026</div>
        <?php if ($error): ?>
        <div class="adm-login-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="adm-field">
                <label for="username"><?= htmlspecialchars($ta['username'] ?? 'Username') ?></label>
                <input type="text" id="username" name="username" required value="demo">
            </div>
            <div class="adm-field">
                <label for="password"><?= htmlspecialchars($ta['password'] ?? 'Password') ?></label>
                <input type="password" id="password" name="password" required value="bilogamehub2026">
            </div>
            <button type="submit" class="adm-btn adm-btn-primary" style="width:100%"><?= htmlspecialchars($ta['login_btn'] ?? 'Sign in') ?></button>
        </form>
        <p style="text-align:center;margin-top:20px"><a href="<?= gh_url('index.php') ?>">← <?= htmlspecialchars($t['breadcrumb_home']) ?></a></p>
    </div>
</div>
</body>
</html>