<?php
$p = $search_params ?? gh_search_params();
?>
<form class="gh-search" action="<?= gh_page_url('search.php') ?>" method="get" role="search">
    <div class="gh-search-field" style="flex:2 1 240px">
        <label for="q"><?= htmlspecialchars($t['search']['keyword']) ?></label>
        <input type="search" id="q" name="q" value="<?= htmlspecialchars($p['q']) ?>"
               placeholder="<?= htmlspecialchars($t['search']['placeholder']) ?>" autocomplete="off">
    </div>
    <div class="gh-search-field">
        <label for="game"><?= htmlspecialchars($t['search']['game']) ?></label>
        <select id="game" name="game">
            <option value=""><?= htmlspecialchars($t['search']['all_games']) ?></option>
            <?php foreach (gh_games() as $g): ?>
            <option value="<?= htmlspecialchars($g) ?>" <?= $p['game'] === $g ? 'selected' : '' ?>><?= htmlspecialchars($t['games'][$g] ?? $g) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="gh-search-field">
        <label for="region"><?= htmlspecialchars($t['search']['region']) ?></label>
        <select id="region" name="region">
            <option value=""><?= htmlspecialchars($t['search']['all_regions']) ?></option>
            <?php foreach (gh_regions() as $r): ?>
            <option value="<?= htmlspecialchars($r) ?>" <?= $p['region'] === $r ? 'selected' : '' ?>><?= htmlspecialchars($t['regions'][$r] ?? $r) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="gh-search-field">
        <label for="status"><?= htmlspecialchars($t['search_page']['filter_online'] ?? 'Status') ?></label>
        <select id="status" name="status">
            <option value=""><?= htmlspecialchars($t['search']['all_status'] ?? 'All') ?></option>
            <option value="online" <?= ($p['status'] ?? '') === 'online' ? 'selected' : '' ?>><?= htmlspecialchars($t['status']['online']) ?></option>
            <option value="offline" <?= ($p['status'] ?? '') === 'offline' ? 'selected' : '' ?>><?= htmlspecialchars($t['status']['offline']) ?></option>
        </select>
    </div>
    <div class="gh-search-field">
        <label for="sort"><?= htmlspecialchars($t['search_page']['sort']) ?></label>
        <select id="sort" name="sort">
            <option value="players" <?= ($p['sort'] ?? '') === 'players' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_players']) ?></option>
            <option value="name" <?= ($p['sort'] ?? '') === 'name' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_name']) ?></option>
            <option value="ping" <?= ($p['sort'] ?? '') === 'ping' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_ping']) ?></option>
            <option value="game" <?= ($p['sort'] ?? '') === 'game' ? 'selected' : '' ?>><?= htmlspecialchars($t['search_page']['sort_game']) ?></option>
        </select>
    </div>
    <div class="gh-search-btn-wrap">
        <button type="submit" class="gh-search-btn"><i class="fas fa-search"></i> <?= htmlspecialchars($t['search']['search_btn']) ?></button>
    </div>
</form>