<?php
require_once __DIR__ . '/init.php';
gh_admin_require();
$admin_page = 'servers';
$page_title = $ta['servers'] ?? 'Servers';

$filter = $_GET['filter'] ?? 'all';
$servers = gh_servers_all();

if ($filter === 'online') {
    $servers = array_values(array_filter($servers, fn($s) => gh_server_is_online($s)));
} elseif ($filter === 'featured') {
    $servers = array_values(array_filter($servers, fn($s) => !empty($s['featured'])));
}

$base = gh_admin_url('servers.php');
require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($ta['servers'] ?? 'Servers') ?> (<?= count($servers) ?>)</h2>
        <a href="<?= gh_admin_url('server.php') ?>" class="adm-btn adm-btn-primary adm-btn-sm"><i class="fas fa-plus"></i> <?= htmlspecialchars($ta['add'] ?? 'Add') ?></a>
    </div>
    <div class="adm-filter-bar">
        <a href="<?= htmlspecialchars($base) ?>" class="<?= $filter === 'all' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_all'] ?? 'All') ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=online') ?>" class="<?= $filter === 'online' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_online'] ?? 'Online') ?></a>
        <a href="<?= htmlspecialchars($base . '?filter=featured') ?>" class="<?= $filter === 'featured' ? 'active' : '' ?>"><?= htmlspecialchars($ta['filter_featured'] ?? 'Featured') ?></a>
    </div>
    <div class="adm-card-body">
        <table class="adm-table">
            <thead>
                <tr>
                    <th><?= htmlspecialchars($ta['name_en'] ?? 'Name') ?></th>
                    <th><?= htmlspecialchars($ta['game'] ?? 'Game') ?></th>
                    <th><?= htmlspecialchars($ta['host'] ?? 'Host') ?></th>
                    <th><?= htmlspecialchars($ta['players'] ?? 'Players') ?></th>
                    <th><?= htmlspecialchars($ta['status'] ?? 'Status') ?></th>
                    <th><?= htmlspecialchars($ta['actions'] ?? 'Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($servers as $s): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($s['name']['en'] ?? $s['id']) ?></strong></td>
                    <td><?= htmlspecialchars($t['games'][$s['game'] ?? ''] ?? $s['game']) ?></td>
                    <td><code><?= htmlspecialchars(gh_server_address($s)) ?></code></td>
                    <td><?= htmlspecialchars(gh_server_players_label($s)) ?></td>
                    <td><span class="adm-badge adm-badge-<?= gh_server_is_online($s) ? 'active' : 'hidden' ?>"><?= htmlspecialchars($s['status'] ?? '') ?></span></td>
                    <td>
                        <a href="<?= gh_admin_url('server.php?id=' . urlencode($s['id'])) ?>" class="adm-btn adm-btn-outline adm-btn-sm"><i class="fas fa-pen"></i></a>
                        <a href="<?= gh_url('server.php?id=' . urlencode($s['id'])) ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank"><i class="fas fa-eye"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>