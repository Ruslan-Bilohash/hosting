
    </div>
</main>
</div>
<script>
(function(){
    var btn=document.getElementById('admMenuBtn'),sb=document.getElementById('admSidebar'),ov=document.getElementById('admOverlay');
    if(!btn||!sb)return;
    btn.addEventListener('click',function(){
        var open=sb.classList.toggle('open');
        document.body.classList.toggle('adm-nav-open',open);
        if(ov){ov.hidden=!open;}
    });
    ov&&ov.addEventListener('click',function(){
        sb.classList.remove('open');
        document.body.classList.remove('adm-nav-open');
        ov.hidden=true;
    });
})();
</script>
</body>
</html>