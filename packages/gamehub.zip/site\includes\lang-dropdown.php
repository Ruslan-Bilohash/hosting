<?php
$current = ghs_langs()[$lang] ?? ghs_langs()['no'];
?>
<div class="ghs-lang-dropdown" id="ghsLangDropdown">
    <button type="button" class="ghs-lang-btn" id="ghsLangBtn" aria-expanded="false">
        <?= $current['flag'] ?> <?= htmlspecialchars($current['label']) ?> <i class="fas fa-chevron-down"></i>
    </button>
    <ul class="ghs-lang-menu" id="ghsLangMenu" hidden>
        <?php foreach (ghs_langs() as $code => $info): ?>
        <li><a href="<?= htmlspecialchars(ghs_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['flag'] ?> <?= htmlspecialchars($info['name']) ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>