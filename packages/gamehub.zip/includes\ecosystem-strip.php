<?php
if (empty($t['ecosystem']['items'])) {
    return;
}
$eco = $t['ecosystem'];
?>
<section class="gh-ecosystem-section" id="ecosystem">
    <div class="gh-container">
        <div class="gh-section-head gh-section-head-center">
            <div>
                <h2 class="gh-section-title"><?= htmlspecialchars($eco['title']) ?></h2>
                <p class="gh-section-sub"><?= htmlspecialchars($eco['subtitle']) ?></p>
            </div>
        </div>
        <div class="gh-ecosystem-grid">
            <?php foreach ($eco['items'] as $item): ?>
            <article class="gh-ecosystem-card">
                <div class="gh-ecosystem-icon">
                    <?php if (($item['icon'] ?? '') === 'wordpress'): ?>
                    <i class="fab fa-wordpress" aria-hidden="true"></i>
                    <?php else: ?>
                    <i class="fas fa-<?= htmlspecialchars($item['icon']) ?>" aria-hidden="true"></i>
                    <?php endif; ?>
                </div>
                <h3><?= htmlspecialchars($item['name']) ?></h3>
                <p><?= htmlspecialchars($item['desc']) ?></p>
                <div class="gh-ecosystem-links">
                    <a href="<?= htmlspecialchars($item['url']) ?>" class="gh-btn-outline-dark gh-btn-sm" rel="related"><?= htmlspecialchars($eco['product_btn']) ?></a>
                    <a href="<?= htmlspecialchars($item['demo']) ?>" class="gh-btn-outline gh-btn-sm" rel="related"><?= htmlspecialchars($eco['demo_btn']) ?></a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>