<?php
/** @var string $page_title */
/** @var string $admin_page */
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= htmlspecialchars($page_title) ?> — GameHub Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(gh_asset('css/admin.css')) ?>?v=4">
    <link rel="stylesheet" href="<?= htmlspecialchars(bh_cms_admin_settings_css_href()) ?>">
</head>
<body class="adm-body">
<div class="adm-sidebar-overlay" id="admOverlay" hidden></div>
<div class="adm-layout">
<aside class="adm-sidebar" id="admSidebar">
    <a href="<?= gh_admin_url('index.php') ?>" class="adm-sidebar-brand">
        <div class="icon"><i class="fas fa-gamepad"></i></div>
        <div>
            <span>GameHub</span>
            <small><?= htmlspecialchars($ta['panel'] ?? 'Admin panel') ?></small>
        </div>
    </a>
    <nav class="adm-nav">
        <a href="<?= gh_admin_url('index.php') ?>" class="<?= $admin_page === 'dashboard' ? 'active' : '' ?>"><i class="fas fa-chart-pie"></i> <?= htmlspecialchars($ta['dashboard'] ?? 'Dashboard') ?></a>
        <a href="<?= gh_admin_url('servers.php') ?>" class="<?= $admin_page === 'servers' ? 'active' : '' ?>"><i class="fas fa-server"></i> <?= htmlspecialchars($ta['servers'] ?? 'Servers') ?></a>
        <a href="<?= gh_admin_url('settings.php') ?>" class="<?= ($admin_page ?? '') === 'gamehub_settings' ? 'active' : '' ?>"><i class="fas fa-sliders-h"></i> <?= htmlspecialchars($ta['hub_settings'] ?? ($ta['settings'] ?? 'Hub')) ?></a>
        <a href="<?= gh_admin_url('settings-appearance.php') ?>" class="<?= ($admin_page ?? '') === 'settings' ? 'active' : '' ?>"><i class="fas fa-palette"></i> <?= htmlspecialchars($ta['site_settings'] ?? 'Site & chat') ?></a>
        <a href="<?= gh_url('maps.php') ?>" target="_blank"><i class="fas fa-map"></i> <?= htmlspecialchars($ta['maps'] ?? 'Maps') ?></a>
        <a href="/gamehub/site/" target="_blank"><i class="fas fa-bullhorn"></i> <?= htmlspecialchars($ta['product_page'] ?? 'Product page') ?></a>
        <a href="<?= gh_url('index.php') ?>" target="_blank"><i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['view_site'] ?? 'View site') ?></a>
    </nav>
    <div class="adm-sidebar-foot">
        <div class="adm-lang-mini">
            <?php foreach (gh_langs() as $code => $info): ?>
            <a href="<?= htmlspecialchars(gh_admin_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['label'] ?></a>
            <?php endforeach; ?>
        </div>
        <a href="<?= gh_admin_url('logout.php') ?>"><i class="fas fa-sign-out-alt"></i> <?= htmlspecialchars($ta['logout'] ?? 'Logout') ?></a>
    </div>
</aside>
<main class="adm-main">
    <header class="adm-topbar">
        <button type="button" class="adm-menu-toggle" id="admMenuBtn" aria-label="Menu"><i class="fas fa-bars"></i></button>
        <h1><?= htmlspecialchars($page_title) ?></h1>
        <span class="adm-user"><i class="fas fa-user-circle"></i> demo</span>
    </header>
    <div class="adm-content">