<?php
require_once __DIR__ . '/init.php';
gh_admin_require();
$admin_page = 'servers';

$id = trim($_GET['id'] ?? '');
$is_new = $id === '';
$server = $is_new ? null : gh_server_by_id($id, true);
$flash = '';
$flash_type = '';

if (!$is_new && !$server) {
    header('Location: ' . gh_admin_url('servers.php'), true, 302);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';
    if ($action === 'delete' && $server) {
        gh_server_delete($id);
        header('Location: ' . gh_admin_url('servers.php?deleted=1'), true, 302);
        exit;
    }

    $new_id = trim($_POST['id'] ?? '');
    if ($new_id === '') {
        $flash = $ta['error'] ?? 'Error';
        $flash_type = 'error';
    } else {
        $mapSlug = trim($_POST['map_slug'] ?? '');
        $mapName = trim($_POST['map'] ?? '');
        if ($mapSlug !== '' && $mapName === '') {
            $mapName = gh_map_display_name($mapSlug, 'en', $_POST['game'] ?? 'cs2');
        }
        $tagsRaw = trim($_POST['tags'] ?? '');
        $tags = $tagsRaw !== '' ? array_values(array_filter(array_map('trim', explode(',', $tagsRaw)))) : [];
        $playersRaw = trim($_POST['player_list'] ?? '');
        $playerList = $playersRaw !== '' ? array_values(array_filter(preg_split('/\r\n|\r|\n/', $playersRaw) ?: [])) : [];

        $record = [
            'id'          => $new_id,
            'game'        => $_POST['game'] ?? 'cs2',
            'host'        => trim($_POST['host'] ?? ''),
            'port'        => (int)($_POST['port'] ?? 0),
            'map'         => $mapName,
            'map_slug'    => $mapSlug !== '' ? $mapSlug : gh_normalize_map_slug($mapName),
            'players'     => (int)($_POST['players'] ?? 0),
            'max_players' => (int)($_POST['max_players'] ?? 16),
            'ping_ms'     => (int)($_POST['ping_ms'] ?? 0),
            'region'      => $_POST['region'] ?? 'eu',
            'status'      => $_POST['status'] ?? 'online',
            'featured'    => !empty($_POST['featured']),
            'active'      => !empty($_POST['active']),
            'vac'         => !empty($_POST['vac']),
            'query_enabled' => !empty($_POST['query_enabled']),
            'password'    => !empty($_POST['password']),
            'tickrate'    => (int)($_POST['tickrate'] ?? 128),
            'mode'        => trim($_POST['mode'] ?? ''),
            'tags'        => $tags,
            'player_list' => $playerList,
            'discord_url' => trim($_POST['discord_url'] ?? ''),
            'website_url' => trim($_POST['website_url'] ?? ''),
            'version'     => trim($_POST['version'] ?? ''),
            'image'       => trim($_POST['image'] ?? ''),
            'last_check'  => date('c'),
            'name' => [
                'en' => trim($_POST['name_en'] ?? ''),
                'no' => trim($_POST['name_no'] ?? ''),
                'uk' => trim($_POST['name_uk'] ?? ''),
                'ru' => trim($_POST['name_ru'] ?? ''),
            ],
            'desc' => [
                'en' => trim($_POST['desc_en'] ?? ''),
                'no' => trim($_POST['desc_no'] ?? ''),
                'uk' => trim($_POST['desc_uk'] ?? ''),
                'ru' => trim($_POST['desc_ru'] ?? ''),
            ],
        ];
        if ($record['name']['en'] === '') {
            $record['name']['en'] = $new_id;
        }
        foreach (['no', 'uk', 'ru'] as $lng) {
            if ($record['name'][$lng] === '') {
                $record['name'][$lng] = $record['name']['en'];
            }
            if ($record['desc'][$lng] === '') {
                $record['desc'][$lng] = $record['desc']['en'];
            }
        }

        if (gh_server_upsert($record)) {
            header('Location: ' . gh_admin_url('server.php?id=' . urlencode($new_id) . '&saved=1'), true, 302);
            exit;
        }
        $flash = $ta['error'] ?? 'Error';
        $flash_type = 'error';
    }
}

if (isset($_GET['saved'])) {
    $flash = $ta['saved'] ?? 'Saved';
    $flash_type = 'success';
    $server = gh_server_by_id($id, true);
}

$page_title = $is_new ? ($ta['add'] ?? 'Add server') : ($ta['edit'] ?? 'Edit server');
$s = $server ?? [
    'id' => '', 'game' => 'cs2', 'host' => '', 'port' => 27015, 'map' => '', 'map_slug' => '',
    'players' => 0, 'max_players' => 16, 'ping_ms' => 0, 'region' => 'eu', 'status' => 'online',
    'featured' => false, 'active' => true, 'vac' => true, 'query_enabled' => false, 'password' => false,
    'tickrate' => 128, 'mode' => 'competitive', 'tags' => [], 'player_list' => [],
    'discord_url' => '', 'website_url' => '', 'version' => '', 'image' => '',
    'name' => ['en'=>'','no'=>'','uk'=>'','ru'=>''], 'desc' => ['en'=>'','no'=>'','uk'=>'','ru'=>''],
];
$mapPreview = gh_server_image($s, 'lg');

require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash): ?>
<div class="adm-alert adm-alert-<?= $flash_type === 'success' ? 'success' : 'error' ?>"><?= htmlspecialchars($flash) ?></div>
<?php endif; ?>

<form method="post" class="adm-form-card">
    <div class="adm-form-grid">
        <div class="adm-field">
            <label>ID (slug)</label>
            <input type="text" name="id" value="<?= htmlspecialchars($s['id']) ?>" <?= $is_new ? '' : 'readonly' ?> required pattern="[a-z][a-z0-9_-]*">
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['game'] ?? 'Game') ?></label>
            <select name="game">
                <?php foreach (gh_games() as $g): ?>
                <option value="<?= $g ?>" <?= ($s['game'] ?? '') === $g ? 'selected' : '' ?>><?= htmlspecialchars($t['games'][$g] ?? $g) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['host'] ?? 'Host') ?></label>
            <input type="text" name="host" value="<?= htmlspecialchars($s['host'] ?? '') ?>" required>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['port'] ?? 'Port') ?></label>
            <input type="number" name="port" value="<?= (int)($s['port'] ?? 0) ?>" min="1" max="65535">
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['map'] ?? 'Map') ?></label>
            <select name="map_slug" id="admMapSlug">
                <option value="">— Custom —</option>
                <?php foreach (gh_map_options_for_game($s['game'] ?? 'cs2') as $slug => $label): ?>
                <option value="<?= htmlspecialchars($slug) ?>" <?= ($s['map_slug'] ?? gh_server_map_slug($s)) === $slug ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['map_custom'] ?? 'Map name (custom)') ?></label>
            <input type="text" name="map" value="<?= htmlspecialchars($s['map'] ?? '') ?>">
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['tickrate'] ?? 'Tickrate') ?></label>
            <select name="tickrate">
                <?php foreach ([64, 128] as $tick): ?>
                <option value="<?= $tick ?>" <?= (int)($s['tickrate'] ?? 128) === $tick ? 'selected' : '' ?>><?= $tick ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['mode'] ?? 'Mode') ?></label>
            <select name="mode">
                <?php foreach (['competitive','practice','retake','wingman','deathmatch','casual','creative','survival','pve'] as $mode): ?>
                <option value="<?= $mode ?>" <?= ($s['mode'] ?? '') === $mode ? 'selected' : '' ?>><?= htmlspecialchars($mode) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['players'] ?? 'Players') ?></label>
            <input type="number" name="players" value="<?= (int)($s['players'] ?? 0) ?>" min="0">
        </div>
        <div class="adm-field">
            <label>Max players</label>
            <input type="number" name="max_players" value="<?= (int)($s['max_players'] ?? 16) ?>" min="1">
        </div>
        <div class="adm-field">
            <label>Ping (ms)</label>
            <input type="number" name="ping_ms" value="<?= (int)($s['ping_ms'] ?? 0) ?>" min="0">
        </div>
        <div class="adm-field">
            <label>Region</label>
            <select name="region">
                <?php foreach (gh_regions() as $r): ?>
                <option value="<?= $r ?>" <?= ($s['region'] ?? '') === $r ? 'selected' : '' ?>><?= htmlspecialchars($t['regions'][$r] ?? $r) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['status'] ?? 'Status') ?></label>
            <select name="status">
                <?php foreach (['online','offline','maintenance'] as $st): ?>
                <option value="<?= $st ?>" <?= ($s['status'] ?? '') === $st ? 'selected' : '' ?>><?= htmlspecialchars($t['status'][$st] ?? $st) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="featured" value="1" <?= !empty($s['featured']) ? 'checked' : '' ?>> Featured</label>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="active" value="1" <?= ($s['active'] ?? true) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['active'] ?? 'Active') ?></label>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="vac" value="1" <?= !empty($s['vac']) ? 'checked' : '' ?>> VAC</label>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="query_enabled" value="1" <?= !empty($s['query_enabled']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['query_enabled'] ?? 'Live A2S query') ?></label>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="password" value="1" <?= !empty($s['password']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['password_protected'] ?? 'Password protected') ?></label>
        </div>
        <div class="adm-field adm-field-full">
            <label><?= htmlspecialchars($ta['tags'] ?? 'Tags (comma-separated)') ?></label>
            <input type="text" name="tags" value="<?= htmlspecialchars(implode(', ', gh_server_tags($s))) ?>">
        </div>
        <div class="adm-field adm-field-full">
            <label>Discord URL</label>
            <input type="url" name="discord_url" value="<?= htmlspecialchars($s['discord_url'] ?? '') ?>">
        </div>
        <div class="adm-field adm-field-full">
            <label>Website URL</label>
            <input type="url" name="website_url" value="<?= htmlspecialchars($s['website_url'] ?? '') ?>">
        </div>
        <div class="adm-field adm-field-full">
            <label><?= htmlspecialchars($ta['player_list'] ?? 'Player list (one per line, demo)') ?></label>
            <textarea name="player_list" rows="4"><?= htmlspecialchars(implode("\n", gh_server_player_list($s))) ?></textarea>
        </div>
        <div class="adm-field adm-field-full">
            <label><?= htmlspecialchars($ta['image_override'] ?? 'Image URL override') ?></label>
            <input type="url" name="image" value="<?= htmlspecialchars($s['image'] ?? '') ?>" placeholder="<?= htmlspecialchars($ta['image_auto'] ?? 'Leave empty for map preview') ?>">
            <?php if ($mapPreview): ?>
            <img src="<?= htmlspecialchars($mapPreview) ?>" alt="" class="adm-menu-preview">
            <?php endif; ?>
        </div>
        <?php foreach (['en'=>'EN','no'=>'NO','uk'=>'UA','ru'=>'RU'] as $code => $label): ?>
        <div class="adm-field adm-field-full">
            <label>Name (<?= $label ?>)</label>
            <input type="text" name="name_<?= $code ?>" value="<?= htmlspecialchars($s['name'][$code] ?? '') ?>">
        </div>
        <div class="adm-field adm-field-full">
            <label>Description (<?= $label ?>)</label>
            <textarea name="desc_<?= $code ?>" rows="2"><?= htmlspecialchars($s['desc'][$code] ?? '') ?></textarea>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="adm-form-actions">
        <button type="submit" name="action" value="save" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save'] ?? 'Save') ?></button>
        <?php if (!$is_new): ?>
        <button type="submit" name="action" value="delete" class="adm-btn adm-btn-danger" onclick="return confirm('Delete?')"><?= htmlspecialchars($ta['delete'] ?? 'Delete') ?></button>
        <?php endif; ?>
        <a href="<?= gh_admin_url('servers.php') ?>" class="adm-btn adm-btn-outline">←</a>
    </div>
</form>

<?php require __DIR__ . '/includes/layout-end.php'; ?>