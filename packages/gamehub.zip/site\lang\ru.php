<?php
return [
    'meta' => [
        'title'       => 'GameHub CMS — Заказать мониторинг игровых серверов | CS2, Minecraft, Rust',
        'description' => 'Закажите кастомный PHP CMS для списка и мониторинга игровых серверов. Превью карт CS2, A2S-запросы, Steam-подключение, админ-панель, Schema.org SEO и 4 языка. Live demo из Норвегии.',
        'keywords'    => 'мониторинг игровых серверов CMS, список серверов CS2, PHP game hub, A2S query, браузер серверов',
        'site_name'   => 'GameHub CMS',
    ],
    'nav' => [
        'features' => 'Возможности',
        'tech'     => 'Технологии',
        'demo'     => 'Демо',
        'admin'    => 'Админ',
        'contact'  => 'Контакт',
        'menu'     => 'Меню',
        'main_nav' => 'Главная навигация',
    ],
    'hero' => [
        'badge'       => 'PHP Game Server CMS · CS2-тема',
        'title'       => 'GameHub CMS',
        'subtitle'    => 'Тактическая PHP-платформа для игровых сообществ — Counter-Strike 2, Minecraft, Rust и ARK. Live-онлайн, превью карт, Steam-подключение и многоязычное SEO.',
        'cta_demo'    => 'Смотреть демо',
        'cta_admin'   => 'Админ демо',
    ],
    'intro' => [
        'title' => 'Один хаб — все игровые сообщества',
        'text'  => 'GameHub CMS — автономная PHP-система мониторинга с карточками серверов, фильтрами поиска, миниатюрами карт, A2S-обновлением и демо-админ-панелью. Начните с live demo и адаптируйте брендинг, игры, Discord webhooks и white-label.',
        'use_label' => 'Идеально для:',
        'use_cases' => ['CS2-сообщества', 'Minecraft-сети', 'Rust-кланы', 'ARK-серверы', 'Мультигейм хабы', 'LAN-ивенты', 'Киберспорт', 'Хостинг-реселлеры'],
    ],
    'features' => [
        'title' => 'Ключевые возможности',
        'items' => [
            ['icon' => 'server', 'title' => 'Браузер серверов', 'desc' => 'Фильтры по игре, статусу, игрокам и пингу. Рекомендованные серверы, бейджи online и быстрый Steam join.'],
            ['icon' => 'map', 'title' => 'Превью карт CS2', 'desc' => 'Локальные миниатюры Dust2, Mirage, Inferno и других — с GitHub CDN fallback.'],
            ['icon' => 'globe', 'title' => '4 языка', 'desc' => 'Норвежский, английский, украинский и русский с hreflang и cookie-переключением.'],
            ['icon' => 'crosshairs', 'title' => 'CS2 tactical UI', 'desc' => 'Тёмная navy-тема, Rajdhani, золото/синие акценты — полностью адаптивный дизайн.'],
            ['icon' => 'magnifying-glass', 'title' => 'Поиск и A2S', 'desc' => 'Поиск по ключевым словам, фильтры игр и опциональное A2S-обновление из админ-настроек.'],
            ['icon' => 'shield-halved', 'title' => 'Админ-панель', 'desc' => 'Дашборд со статистикой, диаграммой игр и редактором серверов — demo / bilogamehub2026.'],
        ],
    ],
    'tech' => [
        'title' => 'Технологии',
        'items' => [
            'PHP 8+ без фреймворков — деплой на shared hosting или VPS в Норвегии/ЕС',
            'JSON-хранилище для серверов и настроек (лёгкая миграция на MySQL)',
            'Модульный i18n с языковыми файлами и cookie-переключением',
            'SEO: canonical, hreflang, sitemap, robots.txt, Schema.org, Open Graph, llms.txt для AI-агентов',
            'CS2-тема, Font Awesome 6 — без build-шага',
            'Steam connect, изображения карт, интеграция cms-contact.php',
        ],
    ],
    'demo' => [
        'title'         => 'Попробуйте демо',
        'frontend'      => 'Frontend демо',
        'frontend_desc' => 'Просмотрите демо-серверы — статистика, карты, поиск, FAQ и кнопки Steam. Языки NO / EN / UA / RU.',
        'admin'         => 'Админ демо',
        'admin_desc'    => 'Вход demo / bilogamehub2026 — дашборд, список серверов и обновление.',
        'open'          => 'Открыть',
    ],
    'faq' => [
        'title' => 'FAQ',
        'items' => [
            ['q' => 'Какие игры поддерживает GameHub CMS?', 'a' => 'Демо включает Counter-Strike 2, Minecraft, Rust и ARK. Новые игры добавляются через JSON-конфиг и языковые файлы.'],
            ['q' => 'Обновляет ли live-количество игроков?', 'a' => 'Да — опциональное A2S-обновление из админ-панели обновляет online-статус и игроков по заданному интервалу.'],
            ['q' => 'Есть ли админ-демо?', 'a' => 'Да — /gamehub/admin/, логин demo / bilogamehub2026.'],
        ],
    ],
    'cta' => [
        'title' => 'Нужен серверный хаб для вашего сообщества?',
        'text'  => 'GameHub CMS можно адаптировать под Discord-ботов, VIP-уровни, RCON, multi-tenant hosting или white-label киберспорт.',
        'btn'   => 'Контакт',
    ],
    'footer' => [
        'product'   => 'Продукт',
        'links'     => 'Ссылки',
        'demo_link' => 'Live GameHub demo',
        'order'     => 'Заказать разработку',
        'llms'      => 'llms.txt для AI',
        'copyright' => '© %s GameHub CMS',
    ],
];