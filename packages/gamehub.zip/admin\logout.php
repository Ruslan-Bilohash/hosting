<?php
require_once __DIR__ . '/init.php';
gh_admin_logout();
header('Location: ' . gh_admin_url('login.php'), true, 302);
exit;