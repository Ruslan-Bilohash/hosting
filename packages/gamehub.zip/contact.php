<?php
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';
require_once __DIR__ . '/includes/site-integrations.php';
gh_boot_public_integrations();

$current_page = 'contact';
$product = 'gamehub';
$body_class = 'gh-page-contact';
$cms_t = cms_contact_texts($product, $lang);
$cms_alert = '';
$cms_alert_type = '';
$cms_values = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = cms_contact_handle_post($product, $lang, 'https://bilohash.com/gamehub/contact.php');
    $cms_alert = $result['alert'];
    $cms_alert_type = $result['alert_type'];
    $cms_values = $result['values'];
}

$cms_csrf = cms_contact_ensure_csrf();
$page_title = $cms_t['page_title'];
$page_desc  = $cms_t['meta_description'];
$canonical  = $site_url . '/contact.php' . ($lang !== 'no' ? '?lang=' . $lang : '');
$seo_schemas = [gh_seo_webpage(gh_absolute_url($canonical), $page_title, $page_desc)];
require __DIR__ . '/includes/header.php';

$cms_action = gh_url('contact.php') . ($lang !== 'no' ? '?lang=' . urlencode($lang) : '');
require __DIR__ . '/includes/contact-section.php';
require __DIR__ . '/includes/footer.php';