<?php

function gh_data_path(string $file): string
{
    return __DIR__ . '/../data/' . $file;
}

function gh_servers_file(): string
{
    return gh_data_path('servers.json');
}

function gh_settings_file(): string
{
    return gh_data_path('settings.json');
}

function gh_default_settings(): array
{
    require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
    return array_merge([
        'refresh_interval_sec'  => 60,
        'show_offline'          => true,
        'default_region'        => 'eu',
        'default_game'          => 'cs2',
        'default_sort'          => 'players',
        'items_per_page'        => 24,
        'site_tagline'          => 'GameHub CMS Demo',
        'a2s_enabled'           => false,
        'a2s_timeout_ms'        => 1500,
        'show_map_previews'     => true,
        'show_player_list'      => true,
        'steam_connect_enabled' => true,
        'maintenance_mode'      => false,
        'seo_og_image'          => '',
        'discord_url'           => '',
        'contact_email'         => 'hello@bilohash.com',
    ], bh_cms_site_settings_defaults(bh_cms_product_accent('gamehub')));
}

function gh_load_settings(): array
{
    $file = gh_settings_file();
    if (!is_file($file)) {
        $defaults = gh_default_settings();
        gh_save_settings($defaults);
        return $defaults;
    }
    $data = json_decode(file_get_contents($file) ?: '{}', true);
    return is_array($data) ? array_merge(gh_default_settings(), $data) : gh_default_settings();
}

function gh_save_settings(array $settings): bool
{
    $json = json_encode(array_merge(gh_default_settings(), $settings), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(gh_settings_file(), $json, LOCK_EX) !== false;
}

function gh_default_servers_from_seed(): ?array
{
    $seedFile = __DIR__ . '/../data/servers.php';
    if (!is_readable($seedFile)) {
        return null;
    }
    $defaults = require $seedFile;
    if (!is_array($defaults)) {
        return null;
    }
    foreach ($defaults as &$server) {
        $server['active'] = $server['active'] ?? true;
    }
    unset($server);
    return $defaults;
}

function gh_ensure_servers_json(): void
{
    $json = gh_servers_file();
    if (!is_file($json)) {
        $defaults = gh_default_servers_from_seed();
        if ($defaults !== null) {
            gh_save_servers($defaults);
        }
        return;
    }

    $defaults = gh_default_servers_from_seed();
    if ($defaults === null) {
        return;
    }

    $existing = json_decode(file_get_contents($json) ?: '[]', true);
    if (!is_array($existing)) {
        gh_save_servers($defaults);
        return;
    }

    $ids = array_column($existing, 'id');
    $merged = $existing;
    $changed = false;
    foreach ($defaults as $server) {
        if (!in_array($server['id'] ?? '', $ids, true)) {
            $merged[] = $server;
            $changed = true;
        }
    }
    if ($changed) {
        gh_save_servers($merged);
    }
}

function gh_save_servers(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(gh_servers_file(), $json, LOCK_EX) !== false;
}

function gh_load_servers_raw(): array
{
    $file = gh_servers_file();
    if (is_readable($file)) {
        $data = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($data) && $data !== []) {
            return $data;
        }
    }

    gh_ensure_servers_json();
    if (is_readable($file)) {
        $data = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($data) && $data !== []) {
            return $data;
        }
    }

    return gh_default_servers_from_seed() ?? [];
}

function gh_bootstrap_data(): void
{
    gh_ensure_servers_json();
    gh_load_settings();
}

function gh_server_upsert(array $record): bool
{
    $id = trim($record['id'] ?? '');
    if ($id === '') {
        return false;
    }

    $list = gh_load_servers_raw();
    $found = false;
    foreach ($list as $i => $srv) {
        if (($srv['id'] ?? '') === $id) {
            $list[$i] = array_merge($srv, $record);
            $found = true;
            break;
        }
    }
    if (!$found) {
        $list[] = $record;
    }
    return gh_save_servers($list);
}

function gh_server_delete(string $id): bool
{
    $list = array_values(array_filter(
        gh_load_servers_raw(),
        fn($s) => ($s['id'] ?? '') !== $id
    ));
    return gh_save_servers($list);
}