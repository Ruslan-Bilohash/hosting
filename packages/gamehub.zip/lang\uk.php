<?php
$en = require __DIR__ . '/en.php';
return array_replace_recursive($en, [
    'meta' => [
        'title'       => 'GameHub CMS — Моніторинг ігрових серверів | PHP скрипт',
        'description' => 'Універсальний PHP-скрипт моніторингу ігрових серверів. CS2, Minecraft, Rust та інші. Адмін-панель, 4 мови, Schema.org SEO.',
        'keywords'    => 'моніторинг серверів, CS2 список серверів, Minecraft браузер, PHP game hub, Норвегія, bilohash',
    ],
    'nav' => [
        'servers' => 'Сервери', 'games' => 'Ігри', 'maps' => 'Карти', 'online' => 'Онлайн',
        'search' => 'Пошук', 'admin' => 'Адмін', 'menu' => 'Меню', 'menu_close' => 'Закрити меню',
        'main_nav' => 'Головна навігація', 'skip' => 'Перейти до контенту', 'lang' => 'Мова',
    ],
    'search' => [
        'keyword' => 'Пошук серверів', 'game' => 'Гра', 'region' => 'Регіон',
        'search_btn' => 'Шукати', 'placeholder' => 'Назва сервера, IP, карта або гра',
        'all_games' => 'Усі ігри', 'all_regions' => 'Усі регіони', 'all_status' => 'Усі статуси',
    ],
    'demo_strip' => [
        'text' => 'Демо-платформа моніторингу — тестові сервери, без реальних A2S-запитів. Усі дані редагуються в адміні.',
        'cms'  => 'GameHub CMS',
    ],
    'hero' => [
        'title'    => 'Хаб серверів Counter-Strike 2',
        'subtitle' => 'Тактичний live-монітор CS2 — 128-tick, VAC, EU ping, карти та слоти. Minecraft, Rust і ARK в одному PHP-скрипті.',
        'badge'    => 'Live demo · CS2 монітор',
    ],
    'about_script' => [
        'title'     => 'Універсальний скрипт моніторингу серверів',
        'text'      => 'GameHub CMS — PHP браузер серверів з Норвегії. Додавайте сервери в адмінці, показуйте онлайн/офлайн, гравців, карти та регіони — багатомовний фронтенд з Schema.org і JSON.',
        'f1'        => 'Публічний сайт: список серверів, фільтри, сторінки деталей, копіювання IP',
        'f2'        => 'Адмін: додавання/редагування серверів, гравці, статус, featured',
        'f3'        => 'PHP 8+, JSON, 4 мови — готово до Steam A2S / Query API',
        'demo_btn'  => 'Live demo', 'admin_btn' => 'Адмін-панель',
        'creds'     => 'Адмін демо: demo / bilogamehub2026',
    ],
    'home' => [
        'featured' => 'Рекомендовані сервери', 'featured_sub' => 'Популярні демо-сервери з різних ігор',
        'online' => 'Зараз онлайн', 'online_sub' => 'Сервери з активними гравцями',
        'games' => 'За іграми', 'view_all' => 'Усі сервери', 'servers' => 'серверів',
        'stats_servers' => 'Сервери', 'stats_online' => 'Онлайн', 'stats_players' => 'Гравці', 'stats_games' => 'Ігри',
        'cs2_servers' => 'Counter-Strike 2 — зараз онлайн',
        'cs2_servers_sub' => 'EU competitive & practice — dust2, mirage, 128-tick демо',
        'view_cs2' => 'Усі CS2 сервери',
        'maps_title' => 'Превʼю карт CS2', 'maps_sub' => 'Мініатюри карт — dust2, mirage, inferno та інші',
        'view_maps' => 'Усі карти',
    ],
    'games' => [
        'cs2' => 'Counter-Strike 2', 'minecraft' => 'Minecraft', 'rust' => 'Rust',
        'ark' => 'ARK: Survival', 'valheim' => 'Valheim', 'tf2' => 'Team Fortress 2',
    ],
    'regions' => [
        'eu' => 'Європа', 'na' => 'Північна Америка', 'asia' => 'Азія', 'oce' => 'Океанія',
    ],
    'status' => [
        'online' => 'Онлайн', 'offline' => 'Офлайн', 'maintenance' => 'Техобслуговування',
    ],
    'card' => [
        'players' => 'Гравці', 'view_server' => 'Деталі', 'copy_ip' => 'Копіювати IP',
        'copied' => 'Скопійовано!', 'join_steam' => 'Грати через Steam',
    ],
    'server' => [
        'address' => 'Адреса сервера', 'map' => 'Карта / світ', 'players' => 'Гравці',
        'ping' => 'Пінг', 'region' => 'Регіон', 'game' => 'Гра', 'status' => 'Статус',
        'last_check' => 'Остання перевірка', 'vac' => 'VAC / secure', 'version' => 'Версія',
        'join' => 'Грати через Steam', 'copy' => 'Копіювати адресу', 'related' => 'Схожі сервери',
        'players_online' => 'Гравці онлайн', 'tickrate' => 'Tickrate', 'mode' => 'Режим',
        'demo_note' => 'Демо-дані — у продакшені можна підключити Steam A2S, Minecraft Query або cron.',
    ],
    'maps_page' => [
        'title' => 'Карти', 'sub' => 'Перегляд карт CS2 — знайдіть сервери на кожній карті.',
        'description' => 'Превʼю карт Counter-Strike 2 та live-сервери на кожній карті.',
        'servers' => 'серверів',
    ],
    'game_page' => [
        'title_suffix' => 'live-сервери',
        'description' => 'Перегляд live-серверів %s — гравці, карти, пінг та копіювання IP.',
        'found' => 'Знайдено %d серверів',
    ],
    'faq' => [
        'q1' => 'Що таке GameHub CMS?',
        'a1' => 'GameHub CMS — PHP-скрипт моніторингу ігрових серверів з публічним браузером, превʼю карт, адмін-панеллю та багатомовним SEO.',
        'q2' => 'Які ігри підтримуються?',
        'a2' => 'Counter-Strike 2, Minecraft, Rust, ARK та інші — додавайте будь-яку гру через адмін.',
        'q3' => 'Чи live статистика серверів?',
        'a3' => 'Демо використовує симульоване оновлення з опційними Steam A2S-запитами. Продакшен може увімкнути реальний UDP-моніторинг.',
    ],
    'search_page' => [
        'title' => 'Пошук серверів', 'found' => 'Знайдено %d серверів',
        'no_results' => 'Жоден сервер не відповідає фільтрам.',
        'sort' => 'Сортування', 'sort_players' => 'Найбільше гравців',
        'sort_name' => 'Назва', 'sort_ping' => 'Найнижчий пінг', 'sort_game' => 'Гра',
        'filter_online' => 'Лише онлайн',
    ],
    'breadcrumb_home' => 'Головна',
    'footer' => [
        'servers' => 'Усі сервери', 'online' => 'Онлайн сервери',
        'product_page' => 'Сторінка продукту', 'admin_demo' => 'Адмін-демо',
        'sitemap' => 'Карта сайту', 'llms' => 'llms.txt',
        'copyright' => '© %s GameHub CMS Demo.',
    ],
    'contact_page' => [
        'maps_title' => 'Превʼю карт CS2',
        'maps_sub' => 'Реальні мініатюри карт — dust2, mirage, inferno та інші.',
        'demo_server' => 'Спробувати live demo', 'play_steam' => 'Грати через Steam',
        'view_maps' => 'Усі карти', 'aside' => 'CS2 demo та карти',
    ],
    'admin' => [
        'login' => 'Вхід в адмін', 'servers' => 'Сервери', 'dashboard' => 'Панель',
        'settings' => 'Налаштування', 'maps' => 'Карти', 'refresh_now' => 'Оновити сервери',
        'show_map_previews' => 'Превʼю карт', 'panel' => 'Адмін-панель',
    ],
]);