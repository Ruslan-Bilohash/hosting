<?php
$ft = $t['footer'] ?? [];
$sh_discuss = cms_contact_texts('gamehub', $lang)['nav_discuss'] ?? 'Contact';
$sh_copyright = sprintf($ft['copyright'] ?? '© %s GameHub CMS Demo.', date('Y'));

if (empty($gh_skip_ecosystem) && is_file(__DIR__ . '/ecosystem-strip.php')) {
    require __DIR__ . '/ecosystem-strip.php';
}
?>
</main>
<footer class="gh-footer">
    <div class="gh-container gh-footer-inner">
        <div class="gh-footer-brand">
            <a href="<?= gh_page_url('index.php') ?>" class="gh-footer-brand-link"><i class="fas fa-gamepad" aria-hidden="true"></i> <?= htmlspecialchars($t['meta']['site_name']) ?></a>
            <p><?= htmlspecialchars($t['meta']['description']) ?></p>
        </div>
        <div>
            <h4><?= htmlspecialchars($ft['servers'] ?? 'Servers') ?></h4>
            <ul>
                <li><a href="<?= gh_url('search.php') ?>"><?= htmlspecialchars($ft['servers'] ?? 'All servers') ?></a></li>
                <li><a href="<?= gh_url('search.php?status=online') ?>"><?= htmlspecialchars($ft['online'] ?? 'Online') ?></a></li>
                <li><a href="<?= gh_url('search.php?game=cs2') ?>">Counter-Strike 2</a></li>
                <li><a href="<?= gh_url('contact.php') ?>"><?= htmlspecialchars($sh_discuss) ?></a></li>
            </ul>
        </div>
        <div>
            <h4>GameHub</h4>
            <ul>
                <li><a href="/gamehub/site/"><?= htmlspecialchars($ft['product_page'] ?? 'Product page') ?></a></li>
                <li><a href="<?= gh_url('admin/login.php') ?>"><?= htmlspecialchars($ft['admin_demo'] ?? 'Admin') ?></a></li>
                <li><a href="<?= gh_url('sitemap.php') ?>"><?= htmlspecialchars($ft['sitemap'] ?? 'Sitemap') ?></a></li>
                <li><a href="<?= gh_url('llms.txt') ?>"><?= htmlspecialchars($ft['llms'] ?? 'llms.txt') ?></a></li>
            </ul>
        </div>
    </div>
    <div class="gh-footer-bottom">
        <div class="gh-container"><?= htmlspecialchars($sh_copyright) ?></div>
    </div>
</footer>
<script src="<?= htmlspecialchars(gh_asset('js/main.js')) ?>?v=4" defer></script>
<?php if (($current_page ?? '') === 'home'): ?>
<script src="<?= htmlspecialchars(gh_asset('js/cs2-scene.js')) ?>?v=1" defer></script>
<?php endif; ?>
<?php bh_cms_render_chat_widget('GameHub CMS', gh_site_settings(), $lang ?? 'en'); ?>
</body>
</html>