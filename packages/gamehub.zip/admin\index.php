<?php
require_once __DIR__ . '/init.php';
gh_admin_require();
$admin_page = 'dashboard';
$page_title = $ta['dashboard'] ?? 'Dashboard';

$servers = gh_servers_all();
$stats   = gh_platform_stats();
$chart   = gh_admin_game_chart();
$online  = array_values(array_filter($servers, fn($s) => gh_server_is_online($s)));

$settings = gh_load_settings();
if (isset($_GET['refreshed'])) {
    $refreshed_count = (int)$_GET['refreshed'];
}

require __DIR__ . '/includes/layout.php';
?>

<?php if (!empty($refreshed_count)): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-sync"></i> <?= sprintf($ta['refreshed'] ?? 'Refreshed %d servers', $refreshed_count) ?></div>
<?php endif; ?>

<div class="adm-stats">
    <div class="adm-stat">
        <div class="adm-stat-icon gold"><i class="fas fa-server"></i></div>
        <div><div class="adm-stat-val"><?= (int)$stats['servers'] ?></div><div class="adm-stat-label"><?= htmlspecialchars($ta['servers'] ?? 'Servers') ?></div></div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon green"><i class="fas fa-signal"></i></div>
        <div><div class="adm-stat-val"><?= (int)$stats['online'] ?></div><div class="adm-stat-label">Online</div></div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon blue"><i class="fas fa-users"></i></div>
        <div><div class="adm-stat-val"><?= (int)$stats['players'] ?></div><div class="adm-stat-label"><?= htmlspecialchars($t['home']['stats_players'] ?? 'Players') ?></div></div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon orange"><i class="fas fa-star"></i></div>
        <div><div class="adm-stat-val"><?= (int)$stats['featured'] ?></div><div class="adm-stat-label"><?= htmlspecialchars($ta['featured'] ?? 'Featured') ?></div></div>
    </div>
</div>

<div class="adm-dash-grid">
    <div class="adm-card">
        <div class="adm-card-head"><h2>By game</h2><a href="<?= gh_admin_url('servers.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm">→</a></div>
        <div class="adm-card-body">
            <?php foreach ($chart as $row): ?>
            <div class="adm-bar-row">
                <span><?= htmlspecialchars($t['games'][$row['game']] ?? $row['game']) ?></span>
                <div class="adm-bar"><span style="width:<?= (int)$row['pct'] ?>%"></span></div>
                <strong><?= (int)$row['count'] ?></strong>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="adm-card">
        <div class="adm-card-head">
            <h2><?= htmlspecialchars($ta['settings'] ?? 'Settings') ?></h2>
            <a href="<?= gh_admin_url('settings.php') ?>" class="adm-btn adm-btn-outline adm-btn-sm">→</a>
        </div>
        <div class="adm-card-body padded adm-settings-preview">
            <p><strong><?= htmlspecialchars($ta['refresh_interval'] ?? 'Refresh') ?>:</strong> <?= (int)($settings['refresh_interval_sec'] ?? 60) ?>s</p>
            <p><strong>A2S:</strong> <?= !empty($settings['a2s_enabled']) ? 'ON' : 'OFF' ?></p>
            <p><strong><?= htmlspecialchars($ta['show_map_previews'] ?? 'Map previews') ?>:</strong> <?= !empty($settings['show_map_previews']) ? 'ON' : 'OFF' ?></p>
            <a href="<?= gh_admin_url('refresh.php') ?>" class="adm-btn adm-btn-primary adm-btn-sm"><i class="fas fa-sync"></i> <?= htmlspecialchars($ta['refresh_now'] ?? 'Refresh now') ?></a>
        </div>
    </div>
    <div class="adm-card">
        <div class="adm-card-head"><h2>Online servers</h2></div>
        <div class="adm-card-body">
            <?php foreach (array_slice($online, 0, 6) as $s): ?>
            <a href="<?= gh_admin_url('server.php?id=' . urlencode($s['id'])) ?>" class="adm-list-item">
                <strong><?= htmlspecialchars($s['name']['en'] ?? $s['id']) ?></strong>
                <span><?= htmlspecialchars(gh_server_players_label($s)) ?> · <?= htmlspecialchars($t['games'][$s['game'] ?? ''] ?? '') ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>