<?php
$en = require __DIR__ . '/en.php';
return array_replace_recursive($en, [
    'meta' => [
        'title'       => 'GameHub CMS — Мониторинг игровых серверов | PHP скрипт',
        'description' => 'Универсальный PHP-скрипт мониторинга игровых серверов. CS2, Minecraft, Rust и другие. Админ-панель, 4 языка, Schema.org SEO.',
        'keywords'    => 'мониторинг серверов, CS2 список серверов, Minecraft браузер, PHP game hub, Норвегия, bilohash',
    ],
    'nav' => [
        'servers' => 'Серверы', 'games' => 'Игры', 'maps' => 'Карты', 'online' => 'Онлайн',
        'search' => 'Поиск', 'admin' => 'Админ', 'menu' => 'Меню', 'menu_close' => 'Закрыть меню',
        'main_nav' => 'Главная навигация', 'skip' => 'Перейти к контенту', 'lang' => 'Язык',
    ],
    'search' => [
        'keyword' => 'Поиск серверов', 'game' => 'Игра', 'region' => 'Регион',
        'search_btn' => 'Искать', 'placeholder' => 'Название сервера, IP, карта или игра',
        'all_games' => 'Все игры', 'all_regions' => 'Все регионы', 'all_status' => 'Все статусы',
    ],
    'demo_strip' => [
        'text' => 'Демо-платформа мониторинга — тестовые серверы, без реальных A2S-запросов. Все данные редактируются в админе.',
        'cms'  => 'GameHub CMS',
    ],
    'hero' => [
        'title'    => 'Хаб серверов Counter-Strike 2',
        'subtitle' => 'Тактический live-монитор CS2 — 128-tick, VAC, EU ping, карты и слоты. Minecraft, Rust и ARK в одном PHP-скрипте.',
        'badge'    => 'Live demo · CS2 монитор',
    ],
    'about_script' => [
        'title'     => 'Универсальный скрипт мониторинга серверов',
        'text'      => 'GameHub CMS — PHP браузер серверов из Норвегии. Добавляйте серверы в админке, показывайте онлайн/офлайн, игроков, карты и регионы — мультиязычный фронтенд с Schema.org и JSON.',
        'f1'        => 'Публичный сайт: список серверов, фильтры, страницы деталей, копирование IP',
        'f2'        => 'Админ: добавление/редактирование серверов, игроки, статус, featured',
        'f3'        => 'PHP 8+, JSON, 4 языка — готово к Steam A2S / Query API',
        'demo_btn'  => 'Live demo', 'admin_btn' => 'Админ-панель',
        'creds'     => 'Админ демо: demo / bilogamehub2026',
    ],
    'home' => [
        'featured' => 'Рекомендуемые серверы', 'featured_sub' => 'Популярные демо-серверы из разных игр',
        'online' => 'Сейчас онлайн', 'online_sub' => 'Серверы с активными игроками',
        'games' => 'По играм', 'view_all' => 'Все серверы', 'servers' => 'серверов',
        'stats_servers' => 'Серверы', 'stats_online' => 'Онлайн', 'stats_players' => 'Игроки', 'stats_games' => 'Игры',
        'cs2_servers' => 'Counter-Strike 2 — сейчас онлайн',
        'cs2_servers_sub' => 'EU competitive & practice — dust2, mirage, 128-tick демо',
        'view_cs2' => 'Все CS2 серверы',
        'maps_title' => 'Превью карт CS2', 'maps_sub' => 'Миниатюры карт — dust2, mirage, inferno и другие',
        'view_maps' => 'Все карты',
    ],
    'games' => [
        'cs2' => 'Counter-Strike 2', 'minecraft' => 'Minecraft', 'rust' => 'Rust',
        'ark' => 'ARK: Survival', 'valheim' => 'Valheim', 'tf2' => 'Team Fortress 2',
    ],
    'regions' => [
        'eu' => 'Европа', 'na' => 'Северная Америка', 'asia' => 'Азия', 'oce' => 'Океания',
    ],
    'status' => [
        'online' => 'Онлайн', 'offline' => 'Офлайн', 'maintenance' => 'Обслуживание',
    ],
    'card' => [
        'players' => 'Игроки', 'view_server' => 'Подробнее', 'copy_ip' => 'Копировать IP',
        'copied' => 'Скопировано!', 'join_steam' => 'Играть через Steam',
    ],
    'server' => [
        'address' => 'Адрес сервера', 'map' => 'Карта / мир', 'players' => 'Игроки',
        'ping' => 'Пинг', 'region' => 'Регион', 'game' => 'Игра', 'status' => 'Статус',
        'last_check' => 'Последняя проверка', 'vac' => 'VAC / secure', 'version' => 'Версия',
        'join' => 'Играть через Steam', 'copy' => 'Копировать адрес', 'related' => 'Похожие серверы',
        'players_online' => 'Игроки онлайн', 'tickrate' => 'Tickrate', 'mode' => 'Режим',
        'demo_note' => 'Демо-данные — в продакшене можно подключить Steam A2S, Minecraft Query или cron.',
    ],
    'maps_page' => [
        'title' => 'Карты', 'sub' => 'Просмотр карт CS2 — найдите серверы на каждой карте.',
        'description' => 'Превью карт Counter-Strike 2 и live-серверы на каждой карте.',
        'servers' => 'серверов',
    ],
    'game_page' => [
        'title_suffix' => 'live-серверы',
        'description' => 'Просмотр live-серверов %s — игроки, карты, пинг и копирование IP.',
        'found' => 'Найдено %d серверов',
    ],
    'faq' => [
        'q1' => 'Что такое GameHub CMS?',
        'a1' => 'GameHub CMS — PHP-скрипт мониторинга игровых серверов с публичным браузером, превью карт, админ-панелью и мультиязычным SEO.',
        'q2' => 'Какие игры поддерживаются?',
        'a2' => 'Counter-Strike 2, Minecraft, Rust, ARK и другие — добавляйте любую игру через админ.',
        'q3' => 'Live ли статистика серверов?',
        'a3' => 'Демо использует симулированное обновление с опциональными Steam A2S-запросами. Продакшен может включить реальный UDP-мониторинг.',
    ],
    'search_page' => [
        'title' => 'Поиск серверов', 'found' => 'Найдено %d серверов',
        'no_results' => 'Ни один сервер не соответствует фильтрам.',
        'sort' => 'Сортировка', 'sort_players' => 'Больше игроков',
        'sort_name' => 'Название', 'sort_ping' => 'Низкий пинг', 'sort_game' => 'Игра',
        'filter_online' => 'Только онлайн',
    ],
    'breadcrumb_home' => 'Главная',
    'footer' => [
        'servers' => 'Все серверы', 'online' => 'Онлайн серверы',
        'product_page' => 'Страница продукта', 'admin_demo' => 'Админ-демо',
        'sitemap' => 'Карта сайта', 'llms' => 'llms.txt',
        'copyright' => '© %s GameHub CMS Demo.',
    ],
    'contact_page' => [
        'maps_title' => 'Превью карт CS2',
        'maps_sub' => 'Реальные миниатюры карт — dust2, mirage, inferno и другие.',
        'demo_server' => 'Попробовать live demo', 'play_steam' => 'Играть через Steam',
        'view_maps' => 'Все карты', 'aside' => 'CS2 demo и карты',
    ],
    'admin' => [
        'login' => 'Вход в админ', 'servers' => 'Серверы', 'dashboard' => 'Панель',
        'settings' => 'Настройки', 'maps' => 'Карты', 'refresh_now' => 'Обновить серверы',
        'show_map_previews' => 'Превью карт', 'panel' => 'Админ-панель',
    ],
]);