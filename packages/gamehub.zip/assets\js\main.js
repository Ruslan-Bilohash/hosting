(function () {
    'use strict';

    document.querySelectorAll('.gh-copy-ip').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var text = btn.getAttribute('data-copy') || '';
            if (!text) return;
            navigator.clipboard.writeText(text).then(function () {
                var orig = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-check"></i> ' + (btn.dataset.copiedLabel || 'Copied!');
                setTimeout(function () { btn.innerHTML = orig; }, 2000);
            });
        });
    });

    var liveCard = document.getElementById('ghServerLive');
    if (liveCard) {
        var sid = liveCard.getAttribute('data-server-id');
        var apiBase = document.body.getAttribute('data-api-base') || '/gamehub/api/server-status.php';
        if (sid) {
            setInterval(function () {
                fetch(apiBase + '?id=' + encodeURIComponent(sid) + '&refresh=1', { credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (!data || !data.ok || !data.server) return;
                        var s = data.server;
                        var playersEl = liveCard.querySelector('.gh-side-row:nth-child(3) strong');
                        if (playersEl) playersEl.textContent = s.players + '/' + s.max_players;
                        var mapEl = liveCard.querySelector('.gh-side-row:nth-child(2) strong');
                        if (mapEl && s.map_name) mapEl.textContent = s.map_name;
                    })
                    .catch(function () {});
            }, 60000);
        }
    }

    var menuBtn = document.getElementById('ghMenuBtn');
    var panel = document.getElementById('ghHeaderPanel');
    var header = document.getElementById('ghHeader');
    var overlay = document.getElementById('ghNavOverlay');

    function setNavOpen(open) {
        if (!header) return;
        header.classList.toggle('nav-open', open);
        document.body.classList.toggle('gh-nav-open', open);
        if (menuBtn) menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (overlay) {
            overlay.hidden = !open;
            overlay.setAttribute('aria-hidden', open ? 'false' : 'true');
        }
    }

    if (menuBtn && panel && header) {
        menuBtn.addEventListener('click', function () {
            setNavOpen(!header.classList.contains('nav-open'));
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function () { setNavOpen(false); });
    }
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') setNavOpen(false);
    });
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 1100) setNavOpen(false);
    });
})();