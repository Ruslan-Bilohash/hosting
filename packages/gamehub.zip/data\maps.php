<?php
declare(strict_types=1);

/**
 * CS2 / Source map catalog — preview images via GameTracker CDN
 */
return [
    'cs2' => [
        'de_dust2' => [
            'name' => ['en' => 'Dust II', 'no' => 'Dust II', 'uk' => 'Dust II', 'ru' => 'Dust II'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_dust2.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_dust2.jpg',
        ],
        'de_mirage' => [
            'name' => ['en' => 'Mirage', 'no' => 'Mirage', 'uk' => 'Mirage', 'ru' => 'Mirage'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_mirage.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_mirage.jpg',
        ],
        'de_inferno' => [
            'name' => ['en' => 'Inferno', 'no' => 'Inferno', 'uk' => 'Inferno', 'ru' => 'Inferno'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_inferno.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_inferno.jpg',
        ],
        'de_nuke' => [
            'name' => ['en' => 'Nuke', 'no' => 'Nuke', 'uk' => 'Nuke', 'ru' => 'Nuke'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_nuke.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_nuke.jpg',
        ],
        'de_ancient' => [
            'name' => ['en' => 'Ancient', 'no' => 'Ancient', 'uk' => 'Ancient', 'ru' => 'Ancient'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_ancient.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_ancient.jpg',
        ],
        'de_anubis' => [
            'name' => ['en' => 'Anubis', 'no' => 'Anubis', 'uk' => 'Anubis', 'ru' => 'Anubis'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_anubis.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_anubis.jpg',
        ],
        'de_vertigo' => [
            'name' => ['en' => 'Vertigo', 'no' => 'Vertigo', 'uk' => 'Vertigo', 'ru' => 'Vertigo'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_vertigo.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_vertigo.jpg',
        ],
        'de_overpass' => [
            'name' => ['en' => 'Overpass', 'no' => 'Overpass', 'uk' => 'Overpass', 'ru' => 'Overpass'],
            'image' => 'https://image.gametracker.com/images/maps/400x300/csgo/de_overpass.jpg',
            'thumb' => 'https://image.gametracker.com/images/maps/160x120/csgo/de_overpass.jpg',
        ],
    ],
    'minecraft' => [
        'creative' => [
            'name' => ['en' => 'Creative World', 'no' => 'Kreativ verden', 'uk' => 'Креативний світ', 'ru' => 'Креативный мир'],
            'image' => 'https://images.unsplash.com/photo-1627856014099-f390bc1e0c52?w=800&q=80',
            'thumb' => 'https://images.unsplash.com/photo-1627856014099-f390bc1e0c52?w=320&q=60',
        ],
    ],
    'rust' => [
        'procedural' => [
            'name' => ['en' => 'Procedural Map', 'no' => 'Procedural kart', 'uk' => 'Процедурна карта', 'ru' => 'Процедурная карта'],
            'image' => 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&q=80',
            'thumb' => 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=320&q=60',
        ],
    ],
    'ark' => [
        'the_island' => [
            'name' => ['en' => 'The Island', 'no' => 'The Island', 'uk' => 'The Island', 'ru' => 'The Island'],
            'image' => 'https://images.unsplash.com/photo-1518709268805-4e9042af9f48?w=800&q=80',
            'thumb' => 'https://images.unsplash.com/photo-1518709268805-4e9042af9f48?w=320&q=60',
        ],
    ],
];