<?php

function ghs_seo_og_image(): string
{
    return 'https://bilohash.com/gamehub/assets/images/maps/de_dust2.png';
}

function ghs_seo_json(array $graphs): string
{
    $graphs = array_values(array_filter($graphs));
    $data = count($graphs) === 1
        ? array_merge(['@context' => 'https://schema.org'], $graphs[0])
        : ['@context' => 'https://schema.org', '@graph' => $graphs];
    return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

function ghs_seo_schemas(string $canonical, string $title, string $desc): array
{
    global $lang, $t;
    $faq = [];
    foreach ($t['faq']['items'] ?? [] as $item) {
        $faq[] = [
            '@type' => 'Question',
            'name' => $item['q'],
            'acceptedAnswer' => ['@type' => 'Answer', 'text' => $item['a']],
        ];
    }
    $graphs = [
        [
            '@type' => 'Organization',
            '@id'   => 'https://bilohash.com/gamehub/#organization',
            'name'  => 'GameHub CMS',
            'url'   => 'https://bilohash.com/gamehub/site/',
            'logo'  => ghs_seo_og_image(),
        ],
        [
            '@type'               => 'SoftwareApplication',
            '@id'                 => $canonical . '#software',
            'name'                => GHS_PRODUCT_NAME,
            'applicationCategory' => 'GameApplication',
            'applicationSubCategory' => 'Game server monitoring and listing CMS',
            'operatingSystem'     => 'Web',
            'description'         => $desc,
            'url'                 => $canonical,
            'image'               => ghs_seo_og_image(),
            'inLanguage'          => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
            'offers'              => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'NOK'],
            'author'              => ['@type' => 'Organization', 'name' => 'BILOHASH', 'url' => 'https://bilohash.com/'],
            'downloadUrl'         => 'https://bilohash.com/gamehub/',
        ],
        [
            '@type' => 'WebPage',
            '@id'   => $canonical . '#webpage',
            'url'   => $canonical,
            'name'  => $title,
            'description' => $desc,
            'inLanguage' => ghs_langs()[$lang]['locale'] ?? 'nb-NO',
            'isPartOf' => ['@type' => 'WebSite', 'name' => GHS_PRODUCT_NAME, 'url' => 'https://bilohash.com/gamehub/site/'],
        ],
    ];
    if ($faq !== []) {
        $graphs[] = [
            '@type' => 'FAQPage',
            '@id'   => $canonical . '#faq',
            'mainEntity' => $faq,
        ];
    }
    return $graphs;
}

function ghs_render_seo_head(string $page_title, string $page_desc, string $canonical, array $schema_graphs = []): void
{
    global $lang_meta, $lang;
    $canonical_abs = ghs_absolute_url($canonical);
    $keywords = $GLOBALS['t']['meta']['keywords'] ?? '';
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="author" content="GameHub CMS · BILOHASH">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(ghs_full_lang_url('no')) ?>">
    <?php foreach (ghs_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= $code === 'uk' ? 'uk' : $code ?>" href="<?= htmlspecialchars(ghs_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <link rel="alternate" type="text/plain" href="https://bilohash.com/gamehub/llms.txt" title="LLM context">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars(GHS_PRODUCT_NAME) ?>">
    <meta property="og:image" content="<?= ghs_seo_og_image() ?>">
    <meta property="og:image:alt" content="Counter-Strike 2 map preview — GameHub CMS">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <?php foreach (ghs_langs() as $code => $info):
        if ($code === $lang) continue; ?>
    <meta property="og:locale:alternate" content="<?= htmlspecialchars(str_replace('-', '_', $info['locale'])) ?>">
    <?php endforeach; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= ghs_seo_og_image() ?>">
    <?php if (!empty($schema_graphs)): ?>
    <script type="application/ld+json"><?= ghs_seo_json($schema_graphs) ?></script>
    <?php endif;
}