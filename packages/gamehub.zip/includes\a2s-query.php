<?php

function gh_a2s_build_query(): string
{
    return "\xFF\xFF\xFF\xFFTSource Engine Query\x00";
}

function gh_a2s_query(string $host, int $port, int $timeoutMs = 1500): ?array
{
    if ($host === '' || $port < 1 || $port > 65535) {
        return null;
    }
    if (!function_exists('socket_create')) {
        return null;
    }

    $socket = @socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
    if ($socket === false) {
        return null;
    }

    socket_set_nonblock($socket);
    @socket_connect($socket, $host, $port);
    @socket_send($socket, gh_a2s_build_query(), strlen(gh_a2s_build_query()), 0);

    $start = microtime(true);
    $response = '';
    while ((microtime(true) - $start) * 1000 < $timeoutMs) {
        $chunk = @socket_recv($socket, $buf, 4096, 0);
        if ($chunk !== false && $chunk > 0) {
            $response .= $buf;
            break;
        }
        usleep(50000);
    }
    @socket_close($socket);

    if ($response === '' || strlen($response) < 6) {
        return null;
    }

    return gh_a2s_parse_info($response);
}

function gh_a2s_parse_info(string $packet): ?array
{
    if (strlen($packet) < 6) {
        return null;
    }
    $offset = 4;
    $header = ord($packet[$offset] ?? "\0");
    if ($header === 0x41) {
        $offset += 1;
    } elseif ($header === 0x49) {
        $offset += 1;
    } else {
        return null;
    }

    $readString = static function () use ($packet, &$offset): string {
        $end = strpos($packet, "\x00", $offset);
        if ($end === false) {
            return '';
        }
        $str = substr($packet, $offset, $end - $offset);
        $offset = $end + 1;
        return $str;
    };

    $protocol = ord($packet[$offset] ?? "\0");
    $offset += 1;
    $name = $readString();
    $map = $readString();
    $folder = $readString();
    $game = $readString();
    $appId = unpack('v', substr($packet, $offset, 2))[1] ?? 0;
    $offset += 2;
    $players = ord($packet[$offset] ?? "\0");
    $offset += 1;
    $maxPlayers = ord($packet[$offset] ?? "\0");

    return [
        'name' => $name,
        'map' => $map,
        'game' => $game,
        'players' => $players,
        'max_players' => $maxPlayers,
        'protocol' => $protocol,
        'app_id' => $appId,
    ];
}

function gh_simulate_server_status(array $server): array
{
    $id = $server['id'] ?? 'x';
    $seed = crc32($id . date('Y-m-d-H'));
    $max = max(1, (int)($server['max_players'] ?? 16));
    $base = (int)($server['players'] ?? 0);
    $status = $server['status'] ?? 'online';

    if ($status === 'maintenance' || $status === 'offline') {
        $server['players'] = 0;
        $server['ping_ms'] = 0;
        $server['last_check'] = date('c');
        return $server;
    }

    $variance = ($seed % 5) - 2;
    $players = max(0, min($max, $base + $variance));
    if ($players === 0 && $base > 0 && ($seed % 3) !== 0) {
        $players = max(1, min($max, $base));
    }

    $server['players'] = $players;
    $server['ping_ms'] = max(8, min(120, (int)($server['ping_ms'] ?? 30) + (($seed % 7) - 3)));
    $server['status'] = 'online';
    $server['last_check'] = date('c');

    $maps = array_keys(gh_maps_for_game($server['game'] ?? 'cs2'));
    if (($server['game'] ?? '') === 'cs2' && $maps !== [] && ($seed % 12) === 0) {
        $server['map'] = $maps[$seed % count($maps)];
        $server['map_slug'] = $server['map'];
    }

    return $server;
}

function gh_refresh_server(array $server, ?array $settings = null): array
{
    $settings = $settings ?? gh_settings();
    $timeout = max(500, (int)($settings['a2s_timeout_ms'] ?? 1500));
    $queryEnabled = !empty($settings['a2s_enabled']) && !empty($server['query_enabled']);

    if ($queryEnabled) {
        $host = trim($server['host'] ?? '');
        $port = (int)($server['port'] ?? 0);
        $live = gh_a2s_query($host, $port, $timeout);
        if ($live !== null) {
            $server['players'] = (int)($live['players'] ?? $server['players'] ?? 0);
            $server['max_players'] = (int)($live['max_players'] ?? $server['max_players'] ?? 16);
            if (!empty($live['map'])) {
                $server['map'] = $live['map'];
                $server['map_slug'] = gh_normalize_map_slug($live['map']);
            }
            $server['status'] = 'online';
            $server['last_check'] = date('c');
            return $server;
        }
    }

    return gh_simulate_server_status($server);
}

function gh_refresh_all_servers(): int
{
    $settings = gh_settings();
    $list = gh_load_servers_raw();
    $updated = 0;
    foreach ($list as $i => $server) {
        if (($server['active'] ?? true) === false) {
            continue;
        }
        $list[$i] = gh_refresh_server($server, $settings);
        $updated++;
    }
    gh_save_servers($list);
    return $updated;
}