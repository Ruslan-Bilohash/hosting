<?php
return [
    'meta' => [
        'title'       => 'GameHub CMS — Bestill spillserver-overvåking | CS2, Minecraft, Rust',
        'description' => 'Bestill tilpasset PHP CMS for spillserver-lister og overvåking. CS2-kartforhåndsvisning, A2S-spørring, Steam-kobling, admin-panel, Schema.org SEO og 4 språk. Live demo fra Norge.',
        'keywords'    => 'spillserver overvåking CMS, CS2 serverliste, PHP game hub, server browser Norge, A2S query script',
        'site_name'   => 'GameHub CMS',
    ],
    'nav' => [
        'features' => 'Funksjoner',
        'tech'     => 'Teknologi',
        'demo'     => 'Live demo',
        'admin'    => 'Admin',
        'contact'  => 'Kontakt',
        'menu'     => 'Meny',
        'main_nav' => 'Hovednavigasjon',
    ],
    'hero' => [
        'badge'       => 'PHP Game Server CMS · CS2-tema',
        'title'       => 'GameHub CMS',
        'subtitle'    => 'Taktisk PHP-plattform for spillfellesskap — Counter-Strike 2, Minecraft, Rust og ARK. Live spillertall, kartforhåndsvisning, Steam-kobling og flerspråklig SEO.',
        'cta_demo'    => 'Se live demo',
        'cta_admin'   => 'Admin demo',
    ],
    'intro' => [
        'title' => 'Én hub — alle spillfellesskap',
        'text'  => 'GameHub CMS er et frittstående PHP-overvåkingssystem med serverkort, søkefiltre, kartminiatyrer, A2S-oppdatering og demo-admin. Start fra live demo og tilpass merkevare, spill, Discord-webhooks og white-label.',
        'use_label' => 'Ideelt for:',
        'use_cases' => ['CS2-fellesskap', 'Minecraft-nettverk', 'Rust-klaner', 'ARK-servere', 'Multi-game hubs', 'LAN-events', 'Esport-organisasjoner', 'Hosting-forhandlere'],
    ],
    'features' => [
        'title' => 'Nøkkelfunksjoner',
        'items' => [
            ['icon' => 'server', 'title' => 'Serverbrowser', 'desc' => 'Filtrer på spill, status, spillere og ping. Fremhevede servere, online-merker og rask Steam-kobling.'],
            ['icon' => 'map', 'title' => 'CS2-kartforhåndsvisning', 'desc' => 'Lokale kartminiatyrer for Dust2, Mirage, Inferno og mer — med GitHub CDN-fallback.'],
            ['icon' => 'globe', 'title' => '4 språk', 'desc' => 'Norsk, engelsk, ukrainsk og russisk med hreflang og cookie-basert bytte.'],
            ['icon' => 'crosshairs', 'title' => 'CS2 taktisk UI', 'desc' => 'Mørkt navy-tema, Rajdhani-typografi, gull/blå aksenter — fullt responsivt.'],
            ['icon' => 'magnifying-glass', 'title' => 'Søk og A2S', 'desc' => 'Nøkkelordsøk, spillfiltre og valgfri A2S-oppdatering fra admin-innstillinger.'],
            ['icon' => 'shield-halved', 'title' => 'Admin-panel', 'desc' => 'Dashboard med statistikk, spilldiagram og serverredigering — demo / bilogamehub2026.'],
        ],
    ],
    'tech' => [
        'title' => 'Teknologistack',
        'items' => [
            'PHP 8+ uten rammeverk — deploy på delt hosting eller VPS i Norge/EU',
            'JSON-lagring for servere og innstillinger (enkel migrering til MySQL)',
            'Modulær i18n med språkfiler per locale og cookie-basert bytte',
            'SEO: canonical, hreflang, sitemap, robots.txt, Schema.org, Open Graph, llms.txt for AI-agenter',
            'CS2-tema responsivt UI med Font Awesome 6 — ingen build-steg',
            'Steam-kobling, kartbilder, cms-contact.php-integrasjon',
        ],
    ],
    'demo' => [
        'title'         => 'Prøv demoen',
        'frontend'      => 'Frontend demo',
        'frontend_desc' => 'Bla gjennom demo-servere — statistikk, kart, søk, FAQ og Steam-knapper. Bytt språk med NO / EN / UA / RU.',
        'admin'         => 'Admin demo',
        'admin_desc'    => 'Logg inn med demo / bilogamehub2026 — dashboard, serverliste og oppdateringskontroller.',
        'open'          => 'Åpne',
    ],
    'faq' => [
        'title' => 'FAQ',
        'items' => [
            ['q' => 'Hvilke spill støtter GameHub CMS?', 'a' => 'Demoen inkluderer Counter-Strike 2, Minecraft, Rust og ARK. Nye spill kan legges til via JSON-konfig og språkfiler.'],
            ['q' => 'Henter den live spillertall?', 'a' => 'Ja — valgfri A2S-oppdatering fra admin-panelet oppdaterer online-status og spillertall på konfigurerbart intervall.'],
            ['q' => 'Finnes det admin-demo?', 'a' => 'Ja — besøk /gamehub/admin/ og logg inn med demo / bilogamehub2026.'],
        ],
    ],
    'cta' => [
        'title' => 'Trenger du en serverhub for fellesskapet ditt?',
        'text'  => 'GameHub CMS kan tilpasses med Discord-bots, VIP-nivåer, RCON, multi-tenant hosting eller white-label esport-merkevare.',
        'btn'   => 'Kontakt',
    ],
    'footer' => [
        'product'   => 'Produkt',
        'links'     => 'Lenker',
        'demo_link' => 'Live GameHub demo',
        'order'     => 'Bestill utvikling',
        'llms'      => 'llms.txt for AI',
        'copyright' => '© %s GameHub CMS',
    ],
];