<?php
require_once __DIR__ . '/init.php';
$current_page = 'maps';
$game = trim($_GET['game'] ?? 'cs2');
if (!in_array($game, gh_games(), true)) {
    $game = 'cs2';
}
$catalog = gh_maps_for_game($game);
$servers = array_values(array_filter(gh_servers(), fn($s) => ($s['game'] ?? '') === $game));
$page_title = ($t['maps_page']['title'] ?? 'Maps') . ' — ' . ($t['games'][$game] ?? $game);
$page_desc = $t['maps_page']['description'] ?? $t['meta']['description'];
$canonical = $site_url . '/maps.php?game=' . urlencode($game) . ($lang !== 'no' ? '&lang=' . $lang : '');
$canon_abs = gh_absolute_url($canonical);
$seo_schemas = [
    gh_seo_organization(),
    gh_seo_webpage($canon_abs, $page_title, $page_desc),
    gh_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => gh_absolute_url(gh_url('index.php'))],
        ['name' => $t['maps_page']['title'] ?? 'Maps', 'url' => $canon_abs],
    ]),
];
require __DIR__ . '/includes/header.php';
?>

<div class="gh-container gh-maps-page">
    <nav class="gh-breadcrumb">
        <a href="<?= gh_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
        → <?= htmlspecialchars($t['maps_page']['title'] ?? 'Maps') ?>
    </nav>
    <div class="gh-section-head">
        <div>
            <h1><?= htmlspecialchars($t['maps_page']['title'] ?? 'Map browser') ?></h1>
            <p><?= htmlspecialchars($t['maps_page']['sub'] ?? '') ?></p>
        </div>
        <div class="gh-game-tags">
            <?php foreach (gh_games() as $g):
                if (gh_maps_for_game($g) === []) continue;
            ?>
            <a href="<?= gh_url('maps.php?game=' . urlencode($g)) ?>" class="gh-game-tag-lg <?= $g === $game ? 'active' : '' ?>">
                <?= htmlspecialchars($t['games'][$g] ?? $g) ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="gh-map-grid">
        <?php foreach ($catalog as $slug => $entry):
            $label = is_array($entry['name'] ?? null) ? ($entry['name'][$lang] ?? $entry['name']['en'] ?? $slug) : $slug;
            $img = $entry['image'] ?? gh_map_image($slug, $game);
            $onMap = count(array_filter($servers, fn($s) => gh_server_map_slug($s) === $slug));
        ?>
        <article class="gh-map-card">
            <a href="<?= gh_url('search.php?game=' . urlencode($game) . '&map=' . urlencode($slug)) ?>">
                <img src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($label) ?>" loading="lazy" width="400" height="225" onerror="this.onerror=null;this.src='<?= htmlspecialchars(gh_placeholder_image()) ?>';">
                <div class="gh-map-card-body">
                    <h2><?= htmlspecialchars($label) ?></h2>
                    <span><?= (int)$onMap ?> <?= htmlspecialchars($t['maps_page']['servers'] ?? 'servers') ?></span>
                </div>
            </a>
        </article>
        <?php endforeach; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>