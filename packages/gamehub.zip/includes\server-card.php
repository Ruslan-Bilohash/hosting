<?php
/** @var array $server */
/** @var array $t */
/** @var string $lang */
$detail_url = gh_server_url((string)($server['id'] ?? ''));
$name       = gh_localized($server, 'name', $lang);
$desc       = gh_localized($server, 'desc', $lang);
$game       = $server['game'] ?? '';
$status     = $server['status'] ?? 'offline';
$online     = gh_server_is_online($server);
$fill       = gh_server_fill_pct($server);
$layout     = $server_card_layout ?? 'grid';
$is_cs2     = $game === 'cs2';
$map_slug   = gh_server_map_slug($server);
$map_label  = gh_map_display_name($map_slug, $lang, $game);
$settings   = gh_settings();
$steam_url  = gh_steam_connect_url($server);
$card_class = 'gh-server-card' . ($layout === 'list' ? ' gh-server-card--list' : '') . ($is_cs2 ? ' gh-server-card--cs2' : '');
?>
<article class="<?= $card_class ?>" data-server-id="<?= htmlspecialchars($server['id'] ?? '') ?>">
    <div class="gh-server-media">
        <a href="<?= htmlspecialchars($detail_url) ?>" class="gh-map-preview-link">
            <img src="<?= htmlspecialchars(gh_server_image($server, 'lg')) ?>" alt="<?= htmlspecialchars($map_label) ?>" loading="lazy" width="320" height="180" class="gh-map-preview-img" onerror="this.onerror=null;this.src='<?= htmlspecialchars(gh_placeholder_image()) ?>';">
            <?php if ($map_slug !== ''): ?>
            <span class="gh-map-preview-badge"><i class="fas fa-map"></i> <?= htmlspecialchars($map_label) ?></span>
            <?php endif; ?>
        </a>
        <span class="gh-status-badge gh-status-<?= htmlspecialchars(gh_status_class($status)) ?>">
            <i class="fas fa-circle"></i> <?= htmlspecialchars($t['status'][$status] ?? $status) ?>
        </span>
        <?php if (!empty($server['featured'])): ?>
        <span class="gh-featured-badge"><i class="fas fa-star"></i></span>
        <?php endif; ?>
    </div>
    <div class="gh-server-body">
        <div class="gh-server-meta">
            <span class="gh-game-tag"><i class="fas fa-<?= htmlspecialchars(gh_game_icon($game)) ?>"></i> <?= htmlspecialchars($t['games'][$game] ?? $game) ?></span>
            <span class="gh-region-tag"><?= htmlspecialchars($t['regions'][$server['region'] ?? ''] ?? $server['region'] ?? '') ?></span>
        </div>
        <h3><a href="<?= htmlspecialchars($detail_url) ?>"><?= htmlspecialchars($name) ?></a></h3>
        <div class="gh-server-address"><i class="fas fa-network-wired"></i> <?= htmlspecialchars(gh_server_address($server)) ?></div>
        <div class="gh-server-map"><i class="fas fa-map"></i> <?= htmlspecialchars($map_label) ?></div>
        <?php if (!empty($server['tickrate'])): ?>
        <div class="gh-server-tick"><i class="fas fa-bolt"></i> <?= (int)$server['tickrate'] ?> tick</div>
        <?php endif; ?>
        <p class="gh-desc-snippet"><?= htmlspecialchars(bh_str_sub($desc, 0, 90)) ?>…</p>
    </div>
    <div class="gh-server-side">
        <div class="gh-players-block">
            <div class="gh-players-label"><?= htmlspecialchars($t['card']['players']) ?></div>
            <div class="gh-players-count"><?= htmlspecialchars(gh_server_players_label($server)) ?></div>
            <div class="gh-players-bar" role="presentation"><span style="width:<?= $fill ?>%"></span></div>
            <?php if ($online && (int)($server['ping_ms'] ?? 0) > 0): ?>
            <div class="gh-ping"><i class="fas fa-signal"></i> <?= (int)$server['ping_ms'] ?> ms</div>
            <?php endif; ?>
            <?php if (!empty($settings['steam_connect_enabled']) && $steam_url !== '' && $online): ?>
            <a href="<?= htmlspecialchars($steam_url) ?>" class="gh-btn-steam gh-btn-steam--card">
                <i class="fab fa-steam"></i> <?= htmlspecialchars($t['card']['join_steam'] ?? $t['server']['join'] ?? 'Play via Steam') ?>
            </a>
            <?php endif; ?>
            <a href="<?= htmlspecialchars($detail_url) ?>" class="gh-btn-primary"><?= htmlspecialchars($t['card']['view_server']) ?></a>
            <button type="button" class="gh-btn-ghost gh-copy-ip" data-copy="<?= htmlspecialchars(gh_server_address($server)) ?>">
                <i class="fas fa-copy"></i> <?= htmlspecialchars($t['card']['copy_ip']) ?>
            </button>
        </div>
    </div>
</article>