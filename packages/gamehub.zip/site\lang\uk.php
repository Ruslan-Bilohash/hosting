<?php
return [
    'meta' => [
        'title'       => 'GameHub CMS — Замовити моніторинг ігрових серверів | CS2, Minecraft, Rust',
        'description' => 'Замовте кастомний PHP CMS для списку та моніторингу ігрових серверів. Превʼю карт CS2, A2S-запити, Steam-підключення, адмін-панель, Schema.org SEO та 4 мови. Live demo з Норвегії.',
        'keywords'    => 'моніторинг ігрових серверів CMS, список серверів CS2, PHP game hub, A2S query, браузер серверів',
        'site_name'   => 'GameHub CMS',
    ],
    'nav' => [
        'features' => 'Можливості',
        'tech'     => 'Технології',
        'demo'     => 'Демо',
        'admin'    => 'Адмін',
        'contact'  => 'Контакт',
        'menu'     => 'Меню',
        'main_nav' => 'Головна навігація',
    ],
    'hero' => [
        'badge'       => 'PHP Game Server CMS · CS2-тема',
        'title'       => 'GameHub CMS',
        'subtitle'    => 'Тактична PHP-платформа для ігрових спільнот — Counter-Strike 2, Minecraft, Rust та ARK. Live-онлайн, превʼю карт, Steam-підключення та багатомовне SEO.',
        'cta_demo'    => 'Переглянути демо',
        'cta_admin'   => 'Адмін демо',
    ],
    'intro' => [
        'title' => 'Один хаб — усі ігрові спільноти',
        'text'  => 'GameHub CMS — автономна PHP-система моніторингу з картками серверів, фільтрами пошуку, мініатюрами карт, A2S-оновленням та демо-адмін-панеллю. Почніть з live demo та адаптуйте брендинг, ігри, Discord webhooks і white-label.',
        'use_label' => 'Ідеально для:',
        'use_cases' => ['CS2-спільноти', 'Minecraft-мережі', 'Rust-клани', 'ARK-сервери', 'Мультигейм хаби', 'LAN-івенти', 'Кіберспорт', 'Хостинг-реселери'],
    ],
    'features' => [
        'title' => 'Ключові можливості',
        'items' => [
            ['icon' => 'server', 'title' => 'Браузер серверів', 'desc' => 'Фільтри за грою, статусом, гравцями та пінгом. Рекомендовані сервери, бейджі online та швидкий Steam join.'],
            ['icon' => 'map', 'title' => 'Превʼю карт CS2', 'desc' => 'Локальні мініатюри Dust2, Mirage, Inferno та інших — з GitHub CDN fallback.'],
            ['icon' => 'globe', 'title' => '4 мови', 'desc' => 'Норвезька, англійська, українська та російська з hreflang і cookie-перемиканням.'],
            ['icon' => 'crosshairs', 'title' => 'CS2 tactical UI', 'desc' => 'Темна navy-тема, Rajdhani, золото/сині акценти — повністю адаптивний дизайн.'],
            ['icon' => 'magnifying-glass', 'title' => 'Пошук і A2S', 'desc' => 'Пошук за ключовими словами, фільтри ігор та опційне A2S-оновлення з адмін-налаштувань.'],
            ['icon' => 'shield-halved', 'title' => 'Адмін-панель', 'desc' => 'Дашборд зі статистикою, діаграмою ігор та редактором серверів — demo / bilogamehub2026.'],
        ],
    ],
    'tech' => [
        'title' => 'Технології',
        'items' => [
            'PHP 8+ без фреймворків — деплой на shared hosting або VPS у Норвегії/ЄС',
            'JSON-сховище для серверів і налаштувань (легка міграція на MySQL)',
            'Модульний i18n з мовними файлами та cookie-перемиканням',
            'SEO: canonical, hreflang, sitemap, robots.txt, Schema.org, Open Graph, llms.txt для AI-агентів',
            'CS2-тема, Font Awesome 6 — без build-кроку',
            'Steam connect, зображення карт, інтеграція cms-contact.php',
        ],
    ],
    'demo' => [
        'title'         => 'Спробуйте демо',
        'frontend'      => 'Frontend демо',
        'frontend_desc' => 'Перегляньте демо-сервери — статистика, карти, пошук, FAQ та кнопки Steam. Мови NO / EN / UA / RU.',
        'admin'         => 'Адмін демо',
        'admin_desc'    => 'Вхід demo / bilogamehub2026 — дашборд, список серверів і оновлення.',
        'open'          => 'Відкрити',
    ],
    'faq' => [
        'title' => 'FAQ',
        'items' => [
            ['q' => 'Які ігри підтримує GameHub CMS?', 'a' => 'Демо включає Counter-Strike 2, Minecraft, Rust та ARK. Нові ігри додаються через JSON-конфіг і мовні файли.'],
            ['q' => 'Чи оновлює live-кількість гравців?', 'a' => 'Так — опційне A2S-оновлення з адмін-панелі оновлює online-статус і гравців за заданим інтервалом.'],
            ['q' => 'Чи є адмін-демо?', 'a' => 'Так — /gamehub/admin/, логін demo / bilogamehub2026.'],
        ],
    ],
    'cta' => [
        'title' => 'Потрібен серверний хаб для вашої спільноти?',
        'text'  => 'GameHub CMS можна адаптувати під Discord-ботів, VIP-рівні, RCON, multi-tenant hosting або white-label кіберспорт.',
        'btn'   => 'Контакт',
    ],
    'footer' => [
        'product'   => 'Продукт',
        'links'     => 'Посилання',
        'demo_link' => 'Live GameHub demo',
        'order'     => 'Замовити розробку',
        'llms'      => 'llms.txt для AI',
        'copyright' => '© %s GameHub CMS',
    ],
];