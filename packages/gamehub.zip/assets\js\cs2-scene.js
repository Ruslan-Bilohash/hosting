(function () {
    'use strict';

    var canvas = document.getElementById('ghCs2Canvas');
    if (!canvas) return;

    var ctx = canvas.getContext('2d');
    var particles = [];
    var frame = 0;
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function resize() {
        var dpr = Math.min(window.devicePixelRatio || 1, 2);
        var rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        canvas.style.width = rect.width + 'px';
        canvas.style.height = rect.height + 'px';
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        initParticles(rect.width, rect.height);
    }

    function initParticles(w, h) {
        particles = [];
        var count = reduced ? 40 : Math.min(120, Math.floor((w * h) / 8000));
        for (var i = 0; i < count; i++) {
            particles.push({
                x: Math.random() * w,
                y: Math.random() * h,
                z: Math.random(),
                vx: (Math.random() - 0.5) * 0.4,
                vy: (Math.random() - 0.5) * 0.4,
                size: Math.random() * 2 + 0.5,
                hue: Math.random() > 0.5 ? 38 : 210
            });
        }
    }

    function project3D(x, y, z, cx, cy, scale) {
        var f = scale / (scale + z);
        return { x: cx + x * f, y: cy + y * f, s: f };
    }

    function drawWireMap(w, h) {
        var cx = w * 0.72;
        var cy = h * 0.48;
        var rot = frame * 0.008;
        var scale = 180;
        var verts = [
            [-1, -0.6, -1], [1, -0.6, -1], [1, -0.6, 1], [-1, -0.6, 1],
            [-1, 0.6, -1], [1, 0.6, -1], [1, 0.6, 1], [-1, 0.6, 1]
        ];
        var edges = [
            [0,1],[1,2],[2,3],[3,0],
            [4,5],[5,6],[6,7],[7,4],
            [0,4],[1,5],[2,6],[3,7]
        ];
        var projected = verts.map(function (v) {
            var x = v[0], y = v[1], z = v[2];
            var cos = Math.cos(rot), sin = Math.sin(rot);
            var rx = x * cos - z * sin;
            var rz = x * sin + z * cos;
            var tilt = 0.35;
            var ry = y * Math.cos(tilt) - rz * Math.sin(tilt);
            var rz2 = y * Math.sin(tilt) + rz * Math.cos(tilt);
            return project3D(rx * scale, ry * scale, rz2 * scale + 200, cx, cy, 400);
        });

        ctx.strokeStyle = 'rgba(232, 160, 32, 0.35)';
        ctx.lineWidth = 1;
        edges.forEach(function (e) {
            var a = projected[e[0]], b = projected[e[1]];
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
        });

        projected.forEach(function (p) {
            ctx.fillStyle = 'rgba(74, 158, 255, ' + (0.3 + p.s * 0.5) + ')';
            ctx.beginPath();
            ctx.arc(p.x, p.y, 2 * p.s, 0, Math.PI * 2);
            ctx.fill();
        });

        ctx.font = '11px Share Tech Mono, monospace';
        ctx.fillStyle = 'rgba(232, 160, 32, 0.5)';
        ctx.fillText('DE_DUST2', cx - 30, cy + scale * 0.55);
    }

    function drawParticles(w, h) {
        particles.forEach(function (p) {
            if (!reduced) {
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0 || p.x > w) p.vx *= -1;
                if (p.y < 0 || p.y > h) p.vy *= -1;
            }
            ctx.fillStyle = 'hsla(' + p.hue + ', 80%, 60%, ' + (0.15 + p.z * 0.25) + ')';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        });
    }

    function draw() {
        var w = canvas.parentElement.clientWidth;
        var h = canvas.parentElement.clientHeight;
        ctx.clearRect(0, 0, w, h);

        var grad = ctx.createRadialGradient(w * 0.5, h * 0.3, 0, w * 0.5, h * 0.5, w * 0.8);
        grad.addColorStop(0, 'rgba(74, 158, 255, 0.06)');
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        drawParticles(w, h);
        if (!reduced) drawWireMap(w, h);

        frame++;
        requestAnimationFrame(draw);
    }

    resize();
    window.addEventListener('resize', resize);
    requestAnimationFrame(draw);

    document.querySelectorAll('[data-count]').forEach(function (el) {
        var target = parseInt(el.getAttribute('data-count'), 10);
        if (isNaN(target) || reduced) return;
        var start = 0;
        var dur = 1200;
        var t0 = performance.now();
        function tick(now) {
            var p = Math.min(1, (now - t0) / dur);
            var ease = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(start + (target - start) * ease);
            if (p < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    });
})();