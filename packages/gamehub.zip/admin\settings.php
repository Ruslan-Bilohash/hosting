<?php
require_once __DIR__ . '/init.php';
gh_admin_require();
$admin_page = 'gamehub_settings';
$page_title = $ta['settings'] ?? 'Settings';
$settings = gh_load_settings();
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings['refresh_interval_sec']  = max(30, (int)($_POST['refresh_interval_sec'] ?? 60));
    $settings['show_offline']          = !empty($_POST['show_offline']);
    $settings['default_region']        = $_POST['default_region'] ?? 'eu';
    $settings['default_game']          = $_POST['default_game'] ?? 'cs2';
    $settings['default_sort']          = $_POST['default_sort'] ?? 'players';
    $settings['items_per_page']        = max(6, min(100, (int)($_POST['items_per_page'] ?? 24)));
    $settings['site_tagline']          = trim($_POST['site_tagline'] ?? '');
    $settings['a2s_enabled']           = !empty($_POST['a2s_enabled']);
    $settings['a2s_timeout_ms']        = max(500, (int)($_POST['a2s_timeout_ms'] ?? 1500));
    $settings['show_map_previews']     = !empty($_POST['show_map_previews']);
    $settings['show_player_list']      = !empty($_POST['show_player_list']);
    $settings['steam_connect_enabled'] = !empty($_POST['steam_connect_enabled']);
    $settings['maintenance_mode']      = !empty($_POST['maintenance_mode']);
    $settings['seo_og_image']          = trim($_POST['seo_og_image'] ?? '');
    $settings['discord_url']           = trim($_POST['discord_url'] ?? '');
    $settings['contact_email']         = trim($_POST['contact_email'] ?? '');
    $flash = gh_save_settings($settings) ? 'success' : 'error';
    $settings = gh_load_settings();
}

require __DIR__ . '/includes/layout.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['settings_saved'] ?? 'Settings saved.') ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error'] ?? 'Error') ?></div>
<?php endif; ?>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['settings_general'] ?? 'General') ?></h2></div>
    <div class="adm-card-body padded">
        <form method="post" class="adm-form-grid">
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['site_tagline'] ?? 'Site tagline') ?></label>
                <input type="text" name="site_tagline" value="<?= htmlspecialchars($settings['site_tagline'] ?? '') ?>">
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['contact_email'] ?? 'Contact email') ?></label>
                <input type="email" name="contact_email" value="<?= htmlspecialchars($settings['contact_email'] ?? '') ?>">
            </div>
            <div class="adm-field">
                <label>Discord URL</label>
                <input type="url" name="discord_url" value="<?= htmlspecialchars($settings['discord_url'] ?? '') ?>" placeholder="https://discord.gg/...">
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['default_game'] ?? 'Default game') ?></label>
                <select name="default_game">
                    <?php foreach (gh_games() as $g): ?>
                    <option value="<?= $g ?>" <?= ($settings['default_game'] ?? '') === $g ? 'selected' : '' ?>><?= htmlspecialchars($t['games'][$g] ?? $g) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['default_region'] ?? 'Default region') ?></label>
                <select name="default_region">
                    <?php foreach (gh_regions() as $r): ?>
                    <option value="<?= $r ?>" <?= ($settings['default_region'] ?? '') === $r ? 'selected' : '' ?>><?= htmlspecialchars($t['regions'][$r] ?? $r) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['default_sort'] ?? 'Default sort') ?></label>
                <select name="default_sort">
                    <?php foreach (['players','name','ping','game'] as $sort): ?>
                    <option value="<?= $sort ?>" <?= ($settings['default_sort'] ?? '') === $sort ? 'selected' : '' ?>><?= htmlspecialchars($sort) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['items_per_page'] ?? 'Items per page') ?></label>
                <input type="number" name="items_per_page" min="6" max="100" value="<?= (int)($settings['items_per_page'] ?? 24) ?>">
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="show_offline" value="1" <?= !empty($settings['show_offline']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['show_offline'] ?? 'Show offline servers') ?></label>
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="maintenance_mode" value="1" <?= !empty($settings['maintenance_mode']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['maintenance_mode'] ?? 'Maintenance mode banner') ?></label>
            </div>
            <div class="adm-field adm-field-full"><hr></div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['refresh_interval'] ?? 'Auto-refresh (sec)') ?></label>
                <input type="number" name="refresh_interval_sec" min="30" max="3600" value="<?= (int)($settings['refresh_interval_sec'] ?? 60) ?>">
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="a2s_enabled" value="1" <?= !empty($settings['a2s_enabled']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['a2s_enabled'] ?? 'Enable Steam A2S queries') ?></label>
            </div>
            <div class="adm-field">
                <label><?= htmlspecialchars($ta['a2s_timeout'] ?? 'A2S timeout (ms)') ?></label>
                <input type="number" name="a2s_timeout_ms" min="500" max="10000" value="<?= (int)($settings['a2s_timeout_ms'] ?? 1500) ?>">
            </div>
            <div class="adm-field adm-field-full"><hr></div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="show_map_previews" value="1" <?= !empty($settings['show_map_previews']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['show_map_previews'] ?? 'Show map preview images') ?></label>
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="show_player_list" value="1" <?= !empty($settings['show_player_list']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['show_player_list'] ?? 'Show player list on detail') ?></label>
            </div>
            <div class="adm-field adm-field-check">
                <label><input type="checkbox" name="steam_connect_enabled" value="1" <?= !empty($settings['steam_connect_enabled']) ? 'checked' : '' ?>> <?= htmlspecialchars($ta['steam_connect'] ?? 'Steam connect button') ?></label>
            </div>
            <div class="adm-field adm-field-full">
                <label>SEO OG image URL</label>
                <input type="url" name="seo_og_image" value="<?= htmlspecialchars($settings['seo_og_image'] ?? '') ?>" placeholder="https://...">
            </div>
            <div class="adm-field adm-field-full">
                <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save'] ?? 'Save') ?></button>
                <a href="<?= gh_admin_url('refresh.php') ?>" class="adm-btn adm-btn-outline"><i class="fas fa-sync"></i> <?= htmlspecialchars($ta['refresh_now'] ?? 'Refresh servers now') ?></a>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>