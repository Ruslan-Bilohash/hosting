<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/init.php';

$count = gh_refresh_all_servers();
@file_put_contents(gh_data_path('last-refresh.txt'), (string)time(), LOCK_EX);

if (PHP_SAPI === 'cli') {
    echo "Refreshed {$count} servers at " . date('c') . PHP_EOL;
    exit(0);
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'count' => $count, 'at' => date('c')]);