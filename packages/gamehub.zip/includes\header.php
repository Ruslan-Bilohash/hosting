<?php
require_once dirname(__DIR__, 2) . '/includes/cms-contact.php';
require_once __DIR__ . '/site-integrations.php';
gh_boot_public_integrations();
$cms_nav_discuss = cms_contact_texts('gamehub', $lang)['nav_discuss'] ?? 'Contact';
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? $site_url . '/';
$body_class = $body_class ?? '';
$seo_schemas = $seo_schemas ?? [];
$seo_og_image = $seo_og_image ?? null;
$seo_og_type  = $seo_og_type ?? 'website';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php gh_render_seo_head($page_title, $page_desc, $canonical, $seo_schemas, $seo_og_image, $seo_og_type, !empty($seo_noindex)); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"></noscript>
    <link rel="stylesheet" href="<?= htmlspecialchars(gh_asset('css/style.css')) ?>?v=4">
    <?php bh_cms_render_theme_styles('gamehub', gh_site_settings()); ?>
    <link rel="stylesheet" href="<?= htmlspecialchars(gh_asset('css/servers.css')) ?>?v=4">
    <link rel="stylesheet" href="<?= htmlspecialchars(gh_asset('css/cs2-theme.css')) ?>?v=4">
    <?php if (($current_page ?? '') === 'contact'): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars(gh_asset('css/contact.css')) ?>?v=1">
    <?php endif; ?>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%23090b10' width='100' height='100' rx='12'/><text x='50' y='58' font-size='26' text-anchor='middle' fill='%2322d3ee' font-family='system-ui' font-weight='700'>GH</text></svg>">
    <?php
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    ecosystem_subscription_strip_head_link();
    ?>
</head>
<body class="gh-cs2-theme <?= htmlspecialchars($body_class) ?>" data-api-base="<?= htmlspecialchars(gh_url('api/server-status.php')) ?>">

<a class="gh-skip-link" href="#ghMain"><?= htmlspecialchars($t['nav']['skip'] ?? 'Skip') ?></a>

<div class="gh-top-bar">
    <?php ecosystem_subscription_strip_render($lang); ?>

    <header class="gh-header gh-header-v2" id="ghHeader">
        <div class="gh-header-inner">
            <a href="<?= gh_page_url('index.php') ?>" class="gh-brand" title="<?= htmlspecialchars($t['meta']['site_name']) ?>">
                <span class="gh-brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 32 32" width="32" height="32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16 2L28 9v14l-12 7L4 23V9L16 2z" stroke="currentColor" stroke-width="1.5"/>
                        <circle cx="16" cy="16" r="5" stroke="currentColor" stroke-width="1.5"/>
                        <path d="M16 11v10M11 16h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </span>
                <span class="gh-brand-text">
                    <span class="gh-brand-name">GameHub</span>
                    <span class="gh-brand-badge">CMS</span>
                </span>
            </a>

            <button type="button" class="gh-menu-toggle" id="ghMenuBtn" aria-expanded="false" aria-controls="ghHeaderPanel" aria-label="<?= htmlspecialchars($t['nav']['menu'] ?? 'Menu') ?>">
                <i class="fas fa-bars gh-menu-icon-open" aria-hidden="true"></i>
                <i class="fas fa-xmark gh-menu-icon-close" aria-hidden="true"></i>
            </button>

            <div class="gh-header-panel" id="ghHeaderPanel">
                <nav class="gh-nav" aria-label="<?= htmlspecialchars($t['nav']['main_nav'] ?? 'Main') ?>">
                    <a href="<?= gh_page_url('index.php') ?>" class="<?= ($current_page ?? '') === 'home' ? 'active' : '' ?>"><i class="fas fa-server" aria-hidden="true"></i> <?= htmlspecialchars($t['nav']['servers']) ?></a>
                    <a href="<?= gh_page_url('search.php') ?>" class="<?= ($current_page ?? '') === 'search' ? 'active' : '' ?>"><i class="fas fa-magnifying-glass" aria-hidden="true"></i> <?= htmlspecialchars($t['nav']['search']) ?></a>
                    <a href="<?= gh_page_url('search.php?status=online') ?>"><i class="fas fa-signal" aria-hidden="true"></i> <?= htmlspecialchars($t['nav']['online']) ?></a>
                    <a href="<?= gh_page_url('game.php?game=cs2') ?>" class="<?= ($current_page ?? '') === 'game' ? 'active' : '' ?>"><i class="fas fa-crosshairs" aria-hidden="true"></i> CS2</a>
                    <a href="<?= gh_page_url('maps.php?game=cs2') ?>" class="<?= ($current_page ?? '') === 'maps' ? 'active' : '' ?>"><i class="fas fa-map" aria-hidden="true"></i> <?= htmlspecialchars($t['nav']['maps'] ?? 'Maps') ?></a>
                </nav>
                <div class="gh-header-actions">
                    <?php require __DIR__ . '/lang-dropdown.php'; ?>
                    <a href="<?= gh_page_url('contact.php') ?>" class="gh-btn-contact"><i class="fas fa-comments" aria-hidden="true"></i> <span><?= htmlspecialchars($cms_nav_discuss) ?></span></a>
                    <a href="<?= gh_url('admin/login.php') ?>" class="gh-btn-admin" title="<?= htmlspecialchars($t['nav']['admin']) ?>"><i class="fas fa-user-shield" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
    </header>
    <div class="gh-nav-overlay" id="ghNavOverlay" hidden aria-hidden="true"></div>
</div>

<main id="ghMain">