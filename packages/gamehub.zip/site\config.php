<?php
/**
 * GameHub CMS — product marketing site
 * /gamehub/site
 */
require_once dirname(__DIR__) . '/config.php';

define('GHS_BASE_PATH', '/gamehub/site');
define('GHS_PRODUCT_NAME', 'GameHub CMS');
define('GHS_PARENT_PATH', '/gamehub');

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, GH_DOMAIN) !== false) ? GHS_BASE_PATH : ($detected ?: GHS_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function ghs_url(string $path = ''): string
{
    global $base_path;
    return rtrim($base_path, '/') . '/' . ltrim($path, '/');
}

function ghs_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function ghs_demo_url(string $path = ''): string
{
    global $host, $protocol;
    return rtrim($protocol . '://' . $host . GHS_PARENT_PATH, '/') . '/' . ltrim($path, '/');
}