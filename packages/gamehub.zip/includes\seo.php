<?php

function gh_protocol(): string
{
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    ) ? 'https' : 'http';
}

function gh_host(): string
{
    return $_SERVER['HTTP_HOST'] ?? GH_DOMAIN;
}

function gh_absolute_url(string $path): string
{
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return gh_protocol() . '://' . gh_host() . (str_starts_with($path, '/') ? $path : '/' . $path);
}

function gh_full_lang_url(string $code): string
{
    return gh_absolute_url(gh_lang_url($code, true));
}

function gh_seo_og_image(): string
{
    $custom = trim(gh_settings()['seo_og_image'] ?? '');
    if ($custom !== '') {
        return str_starts_with($custom, 'http') ? $custom : gh_absolute_url($custom);
    }
    return gh_absolute_url(gh_asset('images/placeholder.svg'));
}

function gh_seo_organization(): array
{
    return [
        '@type' => 'Organization',
        '@id'   => 'https://bilohash.com/gamehub/#organization',
        'name'  => GH_SITE_NAME,
        'url'   => 'https://bilohash.com/gamehub/',
        'logo'  => 'https://bilohash.com/favicon.ico',
        'areaServed' => ['NO', 'UA', 'EU'],
        'knowsAbout' => [
            'Game server monitoring',
            'Counter-Strike 2 server browser',
            'PHP game hub scripts',
            'Multilingual SEO',
            'Schema.org structured data',
        ],
    ];
}

function gh_seo_software_app(string $canonical, string $description): array
{
    return [
        '@type'               => 'SoftwareApplication',
        '@id'                 => $canonical . '#software',
        'name'                => GH_SITE_NAME,
        'applicationCategory' => 'GameApplication',
        'applicationSubCategory' => 'Game server monitoring and browser',
        'operatingSystem'     => 'Web',
        'description'         => $description,
        'url'                 => $canonical,
        'image'               => gh_seo_og_image(),
        'inLanguage'          => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'offers'              => [
            '@type'         => 'Offer',
            'price'         => '0',
            'priceCurrency' => 'NOK',
            'availability'  => 'https://schema.org/InStock',
            'url'           => 'https://bilohash.com/gamehub/',
        ],
        'publisher' => gh_seo_organization(),
        'featureList' => 'Server list, CS2/Minecraft/Rust filters, player counts, admin CRUD, JSON storage, Schema.org SEO, 4 languages',
    ];
}

function gh_seo_website(string $canonical): array
{
    global $site_url;
    return [
        '@type' => 'WebSite',
        '@id'   => rtrim($site_url, '/') . '/#website',
        'name'  => GH_SITE_NAME,
        'url'   => rtrim($site_url, '/') . '/',
        'inLanguage' => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'publisher' => ['@id' => 'https://bilohash.com/gamehub/#organization'],
        'potentialAction' => [
            '@type'       => 'SearchAction',
            'target'      => [
                '@type'       => 'EntryPoint',
                'urlTemplate' => rtrim($site_url, '/') . '/search.php?q={search_term_string}',
            ],
            'query-input' => 'required name=search_term_string',
        ],
    ];
}

function gh_seo_webpage(string $canonical, string $title, string $description): array
{
    global $lang;
    return [
        '@type'       => 'WebPage',
        '@id'         => $canonical . '#webpage',
        'url'         => $canonical,
        'name'        => $title,
        'description' => $description,
        'isPartOf'    => ['@id' => rtrim($GLOBALS['site_url'], '/') . '/#website'],
        'about'       => ['@id' => rtrim($GLOBALS['site_url'], '/') . '/#software'],
        'inLanguage'  => gh_langs()[$lang]['locale'] ?? 'en-GB',
    ];
}

function gh_seo_breadcrumbs(array $items): array
{
    $list = [];
    $pos = 1;
    foreach ($items as $item) {
        $entry = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => $item['name'],
        ];
        if (!empty($item['url'])) {
            $entry['item'] = $item['url'];
        }
        $list[] = $entry;
    }
    return [
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $list,
    ];
}

function gh_seo_server(array $server, string $lang, string $canonical): array
{
    global $t;
    $name = gh_localized($server, 'name', $lang);
    $desc = gh_localized($server, 'desc', $lang);
    $game = $server['game'] ?? '';
    $gameName = $t['games'][$game] ?? $game;
    $mapName = gh_map_display_name(gh_server_map_slug($server), $lang, $game);

    return [
        '@type' => 'WebPage',
        '@id'   => $canonical . '#webpage',
        'url'   => $canonical,
        'name'  => $name,
        'description' => $desc,
        'image' => gh_server_image($server),
        'dateModified' => $server['last_check'] ?? date('c'),
        'mainEntity' => [
            '@type' => 'GameServer',
            '@id'   => $canonical . '#gameserver',
            'name'  => $name,
            'description' => $desc,
            'url'   => $canonical,
            'image' => gh_server_image($server),
            'game'  => [
                '@type' => 'VideoGame',
                'name'  => $gameName,
                'gamePlatform' => 'PC',
                'applicationCategory' => 'Game',
            ],
            'serverStatus' => ($server['status'] ?? '') === 'online' ? 'https://schema.org/Online' : 'https://schema.org/Offline',
            'playersOnline' => (int)($server['players'] ?? 0),
            'maximumAttendeeCapacity' => (int)($server['max_players'] ?? 0),
            'gameLocation' => gh_server_address($server),
            'additionalProperty' => array_values(array_filter([
                ['@type' => 'PropertyValue', 'name' => 'map', 'value' => $mapName],
                ['@type' => 'PropertyValue', 'name' => 'region', 'value' => $t['regions'][$server['region'] ?? ''] ?? ($server['region'] ?? '')],
                !empty($server['tickrate']) ? ['@type' => 'PropertyValue', 'name' => 'tickrate', 'value' => (string)$server['tickrate']] : null,
                !empty($server['mode']) ? ['@type' => 'PropertyValue', 'name' => 'mode', 'value' => (string)$server['mode']] : null,
            ])),
        ],
    ];
}

function gh_seo_faq_page(array $items): array
{
    $main = [];
    foreach ($items as $item) {
        if (empty($item['q']) || empty($item['a'])) {
            continue;
        }
        $main[] = [
            '@type' => 'Question',
            'name' => $item['q'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $item['a'],
            ],
        ];
    }
    return [
        '@type' => 'FAQPage',
        'mainEntity' => $main,
    ];
}

function gh_seo_item_list(array $servers, string $lang, string $listUrl): array
{
    $elements = [];
    $pos = 1;
    foreach (array_slice($servers, 0, 20) as $s) {
        $url = gh_absolute_url(gh_server_url($s['id'] ?? ''));
        $elements[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'url'      => $url,
            'name'     => gh_localized($s, 'name', $lang),
        ];
    }
    return [
        '@type'           => 'ItemList',
        'url'             => $listUrl,
        'numberOfItems'   => count($servers),
        'itemListElement' => $elements,
    ];
}

function gh_seo_professional_service(): array
{
    return [
        '@type' => 'ProfessionalService',
        '@id'   => 'https://bilohash.com/gamehub/#service',
        'name'  => 'Custom game server monitoring website — Norway & Europe',
        'url'   => 'https://bilohash.com/gamehub/',
        'description' => 'Order development of game server browsers, CS2/Minecraft monitoring dashboards and PHP GameHub scripts.',
        'areaServed' => ['Norway', 'Ukraine', 'Europe'],
        'provider' => gh_seo_organization(),
    ];
}

function gh_seo_json(array $graphs): string
{
    $graphs = array_values(array_filter($graphs));
    if (count($graphs) === 1) {
        $data = array_merge(['@context' => 'https://schema.org'], $graphs[0]);
    } else {
        $data = [
            '@context' => 'https://schema.org',
            '@graph'   => $graphs,
        ];
    }
    return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function gh_render_seo_head(
    string $page_title,
    string $page_desc,
    string $canonical,
    array $schema_graphs = [],
    ?string $og_image = null,
    ?string $og_type = 'website',
    bool $noindex = false
): void {
    global $lang_meta, $lang;
    $og_image = $og_image ?: gh_seo_og_image();
    $canonical_abs = gh_absolute_url($canonical);
    $keywords = $GLOBALS['t']['meta']['keywords'] ?? '';
    $robots = $noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="<?= $robots ?>">
    <meta name="author" content="GameHub CMS">
    <meta name="geo.region" content="NO">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(gh_full_lang_url('no')) ?>">
    <?php foreach (gh_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= $code === 'uk' ? 'uk' : $code ?>" href="<?= htmlspecialchars(gh_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <meta property="og:type" content="<?= htmlspecialchars($og_type) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars(GH_SITE_NAME) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">
    <?php if (!empty($schema_graphs)): ?>
    <script type="application/ld+json"><?= gh_seo_json(array_values(array_filter($schema_graphs))) ?></script>
    <?php endif;
}