<?php
require_once __DIR__ . '/config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/includes/i18n.php';
require_once __DIR__ . '/includes/storage.php';
require_once __DIR__ . '/includes/maps.php';
require_once __DIR__ . '/includes/a2s-query.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/seo.php';
gh_bootstrap_data();
gh_maybe_auto_refresh_servers();