<footer class="ghs-footer">
    <div class="ghs-container ghs-footer-inner">
        <div class="ghs-footer-grid">
            <div>
                <strong>GameHub CMS</strong>
                <p><?= htmlspecialchars($t['meta']['description']) ?></p>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['product']) ?></h4>
                <ul>
                    <li><a href="<?= ghs_url('index.php') ?>">GameHub CMS</a></li>
                    <li><a href="<?= ghs_demo_url() ?>"><?= htmlspecialchars($t['footer']['demo_link']) ?></a></li>
                    <li><a href="<?= ghs_demo_url('llms.txt') ?>"><?= htmlspecialchars($t['footer']['llms']) ?></a></li>
                </ul>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['links']) ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/" rel="author"><?= htmlspecialchars($t['footer']['order']) ?></a></li>
                    <li><a href="<?= ghs_demo_url('admin/login.php') ?>"><?= htmlspecialchars($t['nav']['admin']) ?></a></li>
                    <li><a href="<?= ghs_demo_url('llms.txt') ?>"><?= htmlspecialchars($t['footer']['llms']) ?></a></li>
                </ul>
            </div>
            <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-column.php'; ?>
        </div>
        <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-pills.php'; ?>
        <div class="ghs-footer-bottom">
            <?= sprintf(htmlspecialchars($t['footer']['copyright']), date('Y')) ?>
        </div>
    </div>
</footer>
<script src="<?= htmlspecialchars(ghs_asset('js/site.js')) ?>?v=1" defer></script>
</body>
</html>