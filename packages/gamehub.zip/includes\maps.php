<?php

function gh_map_catalog(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $file = __DIR__ . '/../data/maps.php';
    if (!is_readable($file)) {
        return $cache = [];
    }
    $data = require $file;
    return $cache = is_array($data) ? $data : [];
}

function gh_maps_for_game(string $game): array
{
    return gh_map_catalog()[$game] ?? [];
}

function gh_normalize_map_slug(string $map): string
{
    $map = trim(bh_str_lower($map));
    if ($map === '') {
        return '';
    }
    $map = str_replace([' ', '-'], '_', $map);
    if (!str_starts_with($map, 'de_') && preg_match('/^(dust2|mirage|inferno|nuke|ancient|anubis|vertigo|overpass)$/', $map)) {
        $map = 'de_' . $map;
    }
    return $map;
}

function gh_server_map_slug(array $server): string
{
    $slug = trim($server['map_slug'] ?? '');
    if ($slug !== '') {
        return gh_normalize_map_slug($slug);
    }
    return gh_normalize_map_slug((string)($server['map'] ?? ''));
}

function gh_map_entry(string $mapSlug, string $game = 'cs2'): ?array
{
    $slug = gh_normalize_map_slug($mapSlug);
    if ($slug === '') {
        return null;
    }
    $catalog = gh_maps_for_game($game);
    if (isset($catalog[$slug])) {
        return $catalog[$slug];
    }
    foreach ($catalog as $key => $entry) {
        if (gh_normalize_map_slug($key) === $slug) {
            return $entry;
        }
    }
    return null;
}

function gh_map_display_name(string $mapSlug, string $lang, string $game = 'cs2'): string
{
    $entry = gh_map_entry($mapSlug, $game);
    if ($entry !== null) {
        $names = $entry['name'] ?? [];
        if (is_array($names)) {
            return $names[$lang] ?? $names['en'] ?? $names['no'] ?? $mapSlug;
        }
    }
    $slug = gh_normalize_map_slug($mapSlug);
    if (str_starts_with($slug, 'de_')) {
        return ucwords(str_replace('_', ' ', substr($slug, 3)));
    }
    return $mapSlug;
}

function gh_map_image(string $mapSlug, string $game = 'cs2', string $size = 'lg'): string
{
    $slug = gh_normalize_map_slug($mapSlug);
    if ($slug !== '') {
        $local = __DIR__ . '/../assets/images/maps/' . $slug . '.png';
        if (is_file($local)) {
            return gh_asset('images/maps/' . $slug . '.png');
        }
        if ($game === 'cs2') {
            return 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/' . $slug . '.png';
        }
    }

    $entry = gh_map_entry($mapSlug, $game);
    if ($entry === null) {
        return gh_placeholder_image();
    }
    if ($size === 'thumb' && !empty($entry['thumb']) && !str_contains((string)$entry['thumb'], 'gametracker.com')) {
        return $entry['thumb'];
    }
    $image = $entry['image'] ?? $entry['thumb'] ?? '';
    if ($image !== '' && !str_contains((string)$image, 'gametracker.com')) {
        return $image;
    }
    return gh_placeholder_image();
}

function gh_map_options_for_game(string $game): array
{
    $out = [];
    foreach (gh_maps_for_game($game) as $slug => $entry) {
        $out[$slug] = is_array($entry['name'] ?? null)
            ? ($entry['name']['en'] ?? $slug)
            : (string)($entry['name'] ?? $slug);
    }
    return $out;
}