<?php
$cms_404_home = '/gamehub/';
$cms_404_name = 'GameHub CMS';
require dirname(__DIR__) . '/includes/cms-404.php';