<?php
require_once __DIR__ . '/init.php';
$current_page = 'search';
$search_params = gh_search_params();
$results = gh_filter_servers($search_params, $lang);
$page_title = $t['search_page']['title'] . ($search_params['q'] ? ' — ' . $search_params['q'] : '');
$page_desc  = sprintf($t['search_page']['found'], count($results)) . '. ' . $t['meta']['description'];
$canonical = $site_url . '/search.php?' . http_build_query(array_filter($search_params));
$canon_abs = gh_absolute_url($canonical);
$seo_noindex = count($results) === 0 && $search_params['q'] === '';
$seo_schemas = [
    gh_seo_webpage($canon_abs, $page_title, $page_desc),
    gh_seo_item_list($results, $lang, $canon_abs),
    gh_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'], 'url' => gh_absolute_url(gh_url('index.php'))],
        ['name' => $t['search_page']['title'], 'url' => $canon_abs],
    ]),
];
require __DIR__ . '/includes/header.php';
?>

<section class="gh-hero gh-hero-compact">
    <div class="gh-hero-inner">
        <?php require __DIR__ . '/includes/search-form.php'; ?>
    </div>
</section>

<div class="gh-container">
    <p class="gh-results-count"><?= sprintf(htmlspecialchars($t['search_page']['found']), count($results)) ?></p>
    <?php if (empty($results)): ?>
    <div class="gh-empty-state">
        <i class="fas fa-search"></i>
        <p><?= htmlspecialchars($t['search_page']['no_results']) ?></p>
        <a href="<?= gh_url('index.php') ?>" class="gh-btn-primary"><?= htmlspecialchars($t['breadcrumb_home']) ?></a>
    </div>
    <?php else: ?>
    <div class="gh-server-grid">
        <?php foreach ($results as $server):
            require __DIR__ . '/includes/server-card.php';
        endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>