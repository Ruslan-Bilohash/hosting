<?php
require_once __DIR__ . '/init.php';
gh_admin_require();

$count = gh_refresh_all_servers();
@file_put_contents(gh_data_path('last-refresh.txt'), (string)time(), LOCK_EX);

header('Location: ' . gh_admin_url('index.php?refreshed=' . $count), true, 302);
exit;