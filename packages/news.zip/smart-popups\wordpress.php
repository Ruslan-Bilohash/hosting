<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = 'WordPress Integration — Bilohash Smart Popups';
$page_description = t('meta_description');
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/header.php';
}
?>
<section class="max-w-screen-xl mx-auto px-6 py-16 border-t">
    <div class="grid lg:grid-cols-12 gap-x-16 items-start">
        <div class="lg:col-span-5">
            <div class="sticky top-8">
                <span class="uppercase tracking-[1.5px] text-xs font-bold text-violet-600 mb-3">WORDPRESS INTEGRATION</span>
                <h2 class="section-title mt-3 leading-none"><?php echo t('wordpress_integration_title'); ?></h2>
                <p class="mt-6 text-slate-600"><?php echo t('wordpress_integration_desc'); ?></p>
                
                <div class="mt-8">
                    <a href="https://wordpress.org/plugins/bilohash-smart-popups/" target="_blank" class="inline-flex items-center px-6 py-3 bg-white border rounded-3xl text-sm font-semibold hover:bg-slate-50 transition-colors">
                        <span><?php echo t('view_on_wp_org'); ?></span>
                        <i class="ml-2 fa-solid fa-external-link-alt text-xs"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="lg:col-span-7 mt-10 lg:mt-0">
            <div class="space-y-8">
                <div>
                    <h3 class="font-semibold mb-4 text-lg"><?php echo t('admin_menus_tabs'); ?></h3>
                    
                    <div class="space-y-4 text-sm">
                        <div class="bg-white border p-4 rounded-2xl">
                            <div class="font-semibold">Smart Popups (main menu)</div>
                            <div class="text-xs mt-1 text-slate-600"><?php echo t('admin_menu_description'); ?></div>
                        </div>
                        <div class="bg-white border p-4 rounded-2xl">
                            <div class="font-semibold">Live Preview (Design tab)</div>
                            <div class="text-xs mt-1 text-slate-600"><?php echo t('all_requests_description'); ?></div>
                        </div>
                        <div class="bg-white border p-4 rounded-2xl">
                            <div class="font-semibold">Ready Templates</div>
                            <div class="text-xs mt-1 text-slate-600"><?php echo t('subscribers_description'); ?></div>
                        </div>
                        <div class="bg-white border p-4 rounded-2xl">
                            <div class="font-semibold">Targeting per popup</div>
                            <div class="text-xs mt-1 text-slate-600"><?php echo t('mass_mailing_description'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/footer.php';
}
?>
