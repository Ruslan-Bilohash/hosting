<?php
// DEBUG: Show all errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/lang/lang.php';
$current = get_current_lang();
define('LANDING_PAGE', true);

$page_description = t('meta_description');
$page_keywords = t('meta_keywords');
?>
<?php include 'header.php'; ?>

    <!-- Hero -->
    <div class="hero-bg border-b">
        <div class="max-w-screen-xl mx-auto px-6 pt-16 pb-20">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center gap-x-2 px-4 py-1.5 rounded-3xl bg-white border shadow-sm mb-6">
                        <div class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                        <span class="text-sm font-semibold text-slate-700"><?php echo t('version_badge'); ?></span>
                    </div>
                    
                    <h1 class="text-6xl lg:text-6xl font-semibold tracking-tighter leading-none mb-6">
                        <?php echo t('hero_title'); ?>
                    </h1>
                    
                    <p class="text-2xl text-slate-600 max-w-md mb-8">
                        <?php echo t('hero_subtitle'); ?>
                    </p>

                    <div class="flex flex-wrap gap-4">
                        <a href="download.php" class="inline-flex items-center justify-center gap-x-3 px-8 h-14 bg-slate-900 hover:bg-black transition-all text-white rounded-3xl font-semibold text-base shadow-lg">
                            <i class="fa-solid fa-download"></i>
                            <span><?php echo t('nav_download'); ?></span>
                        </a>
                        <a href="#instructions" class="inline-flex items-center justify-center gap-x-3 px-7 h-14 border border-slate-300 hover:bg-white transition-colors rounded-3xl font-semibold text-base">
                            <?php echo t('nav_instructions'); ?>
                        </a>
                    </div>
                </div>

                <div class="relative">
                    <div class="bg-white border shadow-xl rounded-3xl p-2">
                        <img src="screen/general.jpg" alt="Smart Popups - My Popups list and overview" class="rounded-2xl w-full" width="800" height="450" loading="eager" fetchpriority="high">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Trust / SEO bar -->
    <div class="border-b bg-white">
        <div class="max-w-screen-xl mx-auto px-6 py-3 text-xs flex flex-wrap gap-x-6 gap-y-1 text-slate-600 justify-center">
            <span>✓ Free &amp; Open Source (GPLv2)</span>
            <span>✓ Unlimited popups • Live preview</span>
            <span>✓ Works with any theme &amp; Gutenberg/Elementor</span>
            <span>✓ 18 languages included • No monthly fees</span>
        </div>
    </div>

    <?php
    include 'content.php';
    include 'instruction.php';
    include 'wordpress.php';
    echo '<div id="download">';
    include 'download.php';
    echo '</div>';
    ?>

    <?php include 'footer.php'; ?>
