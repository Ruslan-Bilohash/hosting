<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('privacy_policy');
$page_description = t('meta_description');
$page_keywords = t('meta_keywords');
?>
<?php include 'header.php'; ?>

<div class="max-w-screen-xl mx-auto px-6 py-16 max-w-3xl">
    <h1 class="section-title mb-8"><?php echo t('privacy_policy'); ?></h1>
    
    <div class="prose prose-slate max-w-none">
        <p><?php echo t('privacy_intro'); ?></p>
        
        <h3><?php echo t('privacy_data_site'); ?></h3>
        <p><?php echo t('privacy_data_site_desc'); ?></p>
        
        <h3><?php echo t('privacy_data_plugin'); ?></h3>
        <p><?php echo t('privacy_data_plugin_desc'); ?></p>
        
        <h3><?php echo t('privacy_third_party'); ?></h3>
        <p><?php echo t('privacy_third_party_desc'); ?></p>
        
        <h3><?php echo t('privacy_rights'); ?></h3>
        <p><?php echo t('privacy_rights_desc'); ?></p>
    </div>

    <p class="mt-8 text-sm text-slate-500">
        Contact: <a href="mailto:email@bilohash.com">email@bilohash.com</a> &nbsp;·&nbsp; 
        <a href="https://github.com/Ruslan-Bilohash/smart-popups/issues" target="_blank" class="text-violet-600 hover:underline">Open issue on GitHub</a>
    </p>
</div>

<?php include 'footer.php'; ?>
