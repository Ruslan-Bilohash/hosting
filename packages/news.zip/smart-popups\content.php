<!-- Features -->
<section id="features" class="max-w-screen-xl mx-auto px-6 pt-16 pb-12">
    <div class="text-center mb-12">
        <span class="inline-block px-4 py-1 bg-violet-100 text-violet-700 rounded-3xl text-xs font-semibold tracking-widest"><?php echo t('powerful_simple'); ?></span>
        <h2 class="section-title mt-3"><?php echo t('features_title'); ?></h2>
    </div>

    <div class="grid md:grid-cols-3 gap-6">
        <div class="feature-card bg-white border border-slate-200 rounded-3xl p-7">
            <div class="w-11 h-11 bg-violet-100 text-violet-600 rounded-2xl flex items-center justify-center mb-5">
                <i class="fa-solid fa-bolt text-2xl"></i>
            </div>
            <h3 class="font-semibold text-xl mb-3"><?php echo t('feature1_title'); ?></h3>
            <p class="text-slate-600 leading-relaxed"><?php echo t('feature1_desc'); ?></p>
            <div class="mt-4 text-xs text-slate-500 space-y-1">
                <div>• <?php echo t('feature_triggers'); ?></div>
                <div>• <?php echo t('feature_countdown'); ?></div>
            </div>
        </div>
        
        <div class="feature-card bg-white border border-slate-200 rounded-3xl p-7">
            <div class="w-11 h-11 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mb-5">
                <i class="fa-solid fa-palette text-2xl"></i>
            </div>
            <h3 class="font-semibold text-xl mb-3"><?php echo t('feature2_title'); ?></h3>
            <p class="text-slate-600 leading-relaxed"><?php echo t('feature2_desc'); ?></p>
            <div class="mt-4 text-xs text-slate-500 space-y-1">
                <div>• <?php echo t('feature_icons'); ?></div>
                <div>• <?php echo t('feature_design'); ?></div>
            </div>
        </div>

        <div class="feature-card bg-white border border-slate-200 rounded-3xl p-7">
            <div class="w-11 h-11 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-5">
                <i class="fa-solid fa-crosshairs text-2xl"></i>
            </div>
            <h3 class="font-semibold text-xl mb-3"><?php echo t('feature3_title'); ?></h3>
            <p class="text-slate-600 leading-relaxed"><?php echo t('feature3_desc'); ?></p>
            <div class="mt-4 text-xs text-slate-500 space-y-1">
                <div>• <?php echo t('feature_targeting'); ?></div>
                <div>• <?php echo t('feature_multi'); ?></div>
            </div>
        </div>
    </div>
</section>

<!-- Screenshots -->
<section id="screenshots" class="max-w-screen-xl mx-auto px-6 pb-16">
    <div class="flex items-end justify-between mb-8">
        <div>
            <span class="text-violet-600 font-semibold text-sm tracking-widest"><?php echo t('see_it_in_action'); ?></span>
            <h2 class="section-title mt-1"><?php echo t('screenshots_title'); ?></h2>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="screenshot-grid">
        <div class="screenshot bg-white border rounded-3xl overflow-hidden cursor-pointer group" onclick="openGallery(0)">
            <div class="relative">
                <img src="screen/general.jpg" alt="<?php echo t('general_settings'); ?>" class="w-full transition-transform group-hover:scale-105" width="640" height="360" loading="lazy">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition flex items-center justify-center">
                    <i class="fa-solid fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-80 transition"></i>
                </div>
            </div>
            <div class="p-4"><strong><?php echo t('general_settings'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden cursor-pointer group" onclick="openGallery(1)">
            <div class="relative">
                <img src="screen/design.jpg" alt="<?php echo t('design_live_preview'); ?>" class="w-full transition-transform group-hover:scale-105" width="640" height="360" loading="lazy">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition flex items-center justify-center">
                    <i class="fa-solid fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-80 transition"></i>
                </div>
            </div>
            <div class="p-4"><strong><?php echo t('design_live_preview'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden cursor-pointer group" onclick="openGallery(2)">
            <div class="relative">
                <img src="screen/templates.jpg" alt="<?php echo t('subscribe_form_separate_design'); ?>" class="w-full transition-transform group-hover:scale-105" width="640" height="360" loading="lazy">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition flex items-center justify-center">
                    <i class="fa-solid fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-80 transition"></i>
                </div>
            </div>
            <div class="p-4"><strong><?php echo t('subscribe_form_separate_design'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden cursor-pointer group" onclick="openGallery(3)">
            <div class="relative">
                <img src="screen/triggers.jpg" alt="<?php echo t('email_smtp_test'); ?>" class="w-full transition-transform group-hover:scale-105" width="640" height="360" loading="lazy">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition flex items-center justify-center">
                    <i class="fa-solid fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-80 transition"></i>
                </div>
            </div>
            <div class="p-4"><strong><?php echo t('email_smtp_test'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden cursor-pointer group" onclick="openGallery(4)">
            <div class="relative">
                <img src="screen/rules.jpg" alt="<?php echo t('mass_mailing_cool_header_footer'); ?>" class="w-full transition-transform group-hover:scale-105" width="640" height="360" loading="lazy">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition flex items-center justify-center">
                    <i class="fa-solid fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-80 transition"></i>
                </div>
            </div>
            <div class="p-4"><strong><?php echo t('mass_mailing_cool_header_footer'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden cursor-pointer group" onclick="openGallery(5)">
            <div class="relative">
                <img src="screen/about.jpg" alt="<?php echo t('integrations_recaptcha'); ?>" class="w-full transition-transform group-hover:scale-105" width="640" height="360" loading="lazy">
                <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition flex items-center justify-center">
                    <i class="fa-solid fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-80 transition"></i>
                </div>
            </div>
            <div class="p-4"><strong><?php echo t('integrations_recaptcha'); ?></strong></div>
        </div>
    </div>
</section>

<!-- Clickable Gallery Modal -->
<div id="gallery-modal" onclick="if (event.target.id === 'gallery-modal') closeGallery()" class="hidden fixed inset-0 z-[400] bg-black/95 flex items-center justify-center p-4 md:p-8">
    <div class="relative w-full max-w-6xl" onclick="event.stopImmediatePropagation()">
        <!-- Close button -->
        <button onclick="closeGallery()" class="absolute -top-14 right-0 text-white hover:text-violet-400 text-4xl leading-none z-10">
            &times;
        </button>

        <!-- Main image container -->
        <div class="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-white/10">
            <img id="gallery-image" 
                 class="w-full max-h-[82vh] object-contain bg-black cursor-zoom-in" 
                 onclick="nextImage()"
                 alt="">

            <!-- Caption bar -->
            <div class="bg-white px-6 py-4 flex items-center justify-between">
                <div>
                    <div id="gallery-caption" class="font-semibold text-slate-900 text-lg"></div>
                    <div id="gallery-sub" class="text-xs text-slate-500 mt-0.5">Beautiful admin panel &amp; real popups</div>
                </div>
                <div id="gallery-counter" class="text-sm font-medium text-slate-600 bg-slate-100 px-3 py-1 rounded-2xl"></div>
            </div>
        </div>

        <!-- Navigation arrows -->
        <button onclick="prevImage()" 
                class="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-slate-900 w-11 h-11 rounded-2xl flex items-center justify-center shadow-lg transition text-xl">
            <i class="fa-solid fa-chevron-left"></i>
        </button>
        <button onclick="nextImage()" 
                class="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-slate-900 w-11 h-11 rounded-2xl flex items-center justify-center shadow-lg transition text-xl">
            <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>
</div>

<script>
let galleryIndex = 0;
let galleryItems = [];

function initGallery() {
    const grid = document.getElementById('screenshot-grid');
    if (!grid) return;

    const cards = grid.querySelectorAll('.screenshot');
    galleryItems = [];

    cards.forEach((card, i) => {
        const img = card.querySelector('img');
        const captionEl = card.querySelector('strong');
        if (img) {
            galleryItems.push({
                src: img.getAttribute('src'),
                caption: captionEl ? captionEl.textContent : (img.alt || 'Screenshot')
            });
        }
    });
}

function openGallery(index) {
    if (galleryItems.length === 0) initGallery();
    if (galleryItems.length === 0) return;

    galleryIndex = Math.max(0, Math.min(index, galleryItems.length - 1));
    const modal = document.getElementById('gallery-modal');
    const imgEl = document.getElementById('gallery-image');
    const capEl = document.getElementById('gallery-caption');
    const counterEl = document.getElementById('gallery-counter');

    const item = galleryItems[galleryIndex];
    imgEl.src = item.src;
    capEl.textContent = item.caption;
    counterEl.textContent = (galleryIndex + 1) + ' / ' + galleryItems.length;

    modal.classList.remove('hidden');
    modal.classList.add('flex');
    document.body.style.overflow = 'hidden';
}

function closeGallery() {
    const modal = document.getElementById('gallery-modal');
    modal.classList.remove('flex');
    modal.classList.add('hidden');
    document.body.style.overflow = '';
}

function prevImage() {
    if (galleryItems.length === 0) return;
    galleryIndex = (galleryIndex - 1 + galleryItems.length) % galleryItems.length;
    updateGalleryImage();
}

function nextImage() {
    if (galleryItems.length === 0) return;
    galleryIndex = (galleryIndex + 1) % galleryItems.length;
    updateGalleryImage();
}

function updateGalleryImage() {
    const imgEl = document.getElementById('gallery-image');
    const capEl = document.getElementById('gallery-caption');
    const counterEl = document.getElementById('gallery-counter');

    const item = galleryItems[galleryIndex];
    imgEl.src = item.src;
    capEl.textContent = item.caption;
    counterEl.textContent = (galleryIndex + 1) + ' / ' + galleryItems.length;
}

// Keyboard support
document.addEventListener('keydown', function(e) {
    const modal = document.getElementById('gallery-modal');
    if (!modal || modal.classList.contains('hidden')) return;

    if (e.key === 'Escape') {
        closeGallery();
    } else if (e.key === 'ArrowLeft') {
        prevImage();
    } else if (e.key === 'ArrowRight') {
        nextImage();
    }
});

// Init on load
document.addEventListener('DOMContentLoaded', function() {
    initGallery();
});
</script>

<!-- Templates Section -->
<section id="templates" class="max-w-screen-xl mx-auto px-6 py-12">
    <div class="bg-white border border-slate-200 rounded-3xl p-8 md:p-12">
        <div class="grid lg:grid-cols-12 gap-x-12 items-center">
            <div class="lg:col-span-5">
                <div class="uppercase tracking-[1.5px] text-xs font-bold text-violet-600 mb-3"><?php echo t('powerful_simple'); ?></div>
                <h2 class="section-title leading-none mb-6"><?php echo t('templates_title'); ?></h2>
                <p class="text-lg text-slate-600 mb-8"><?php echo t('templates_desc'); ?></p>
                
                <div class="space-y-2 text-sm">
                    <div class="flex items-center gap-x-2">
                        <i class="fa-solid fa-check text-emerald-500"></i>
                        <span><?php echo t('feature_triggers'); ?></span>
                    </div>
                    <div class="flex items-center gap-x-2">
                        <i class="fa-solid fa-check text-emerald-500"></i>
                        <span><?php echo t('feature_preview'); ?></span>
                    </div>
                    <div class="flex items-center gap-x-2">
                        <i class="fa-solid fa-check text-emerald-500"></i>
                        <span><?php echo t('feature_responsive'); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Visual grid of template ideas -->
            <div class="lg:col-span-7 mt-10 lg:mt-0">
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div class="rounded-2xl border bg-gradient-to-br from-rose-500 to-pink-600 p-5 text-white">
                        <div class="text-sm opacity-75 mb-1">Template</div>
                        <div class="font-semibold text-lg">Discount / Sale</div>
                        <div class="text-xs mt-4 opacity-80">Big % + countdown</div>
                    </div>
                    <div class="rounded-2xl border bg-gradient-to-br from-sky-500 to-indigo-600 p-5 text-white">
                        <div class="text-sm opacity-75 mb-1">Template</div>
                        <div class="font-semibold text-lg">Newsletter</div>
                        <div class="text-xs mt-4 opacity-80">Email capture</div>
                    </div>
                    <div class="rounded-2xl border bg-gradient-to-br from-amber-500 to-orange-600 p-5 text-white">
                        <div class="text-sm opacity-75 mb-1">Template</div>
                        <div class="font-semibold text-lg">Exit Offer</div>
                        <div class="text-xs mt-4 opacity-80">Last chance</div>
                    </div>
                    <div class="rounded-2xl border bg-gradient-to-br from-teal-500 to-emerald-600 p-5 text-white">
                        <div class="text-sm opacity-75 mb-1">Template</div>
                        <div class="font-semibold text-lg">Announcement</div>
                        <div class="text-xs mt-4 opacity-80">New feature / update</div>
                    </div>
                    <div class="rounded-2xl border bg-gradient-to-br from-purple-500 to-violet-600 p-5 text-white">
                        <div class="text-sm opacity-75 mb-1">Template</div>
                        <div class="font-semibold text-lg">Limited Time</div>
                        <div class="text-xs mt-4 opacity-80">Flash deal</div>
                    </div>
                    <div class="rounded-2xl border bg-gradient-to-br from-slate-700 to-slate-900 p-5 text-white">
                        <div class="text-sm opacity-75 mb-1">Template</div>
                        <div class="font-semibold text-lg">Corner Promo</div>
                        <div class="text-xs mt-4 opacity-80">Sticky bottom-right</div>
                    </div>
                </div>
                <p class="text-center text-xs mt-4 text-slate-500">All templates are fully customizable after selection.</p>
            </div>
        </div>
    </div>
</section>
