<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('changelog_title');
$page_description = t('meta_description_changelog');
$page_keywords = t('meta_keywords_changelog');
include __DIR__ . '/header.php';
?>
<div class="max-w-screen-xl mx-auto px-6 py-14">
    <div class="max-w-3xl mx-auto">
        <h1 class="text-4xl font-semibold tracking-tighter mb-3"><?php echo t('changelog_title'); ?></h1>
        <p class="text-xl text-slate-600 mb-8"><?php echo t('changelog_intro'); ?></p>

        <div class="prose prose-slate max-w-none">
            <!-- 1.2.0 -->
            <div class="mb-10 border-l-4 border-blue-600 pl-6">
                <div class="flex items-center gap-x-3 mb-1">
                    <h2 class="text-2xl font-semibold m-0"><?php echo t('changelog_v120'); ?></h2>
                    <span class="text-xs px-3 py-1 bg-blue-100 text-blue-700 rounded-2xl"><?php echo t('changelog_v120_date'); ?></span>
                </div>
                <ul class="text-sm space-y-1 mt-3">
                    <li><?php echo t('changelog_v120_1'); ?></li>
                    <li><?php echo t('changelog_v120_2'); ?></li>
                    <li><?php echo t('changelog_v120_3'); ?></li>
                    <li><?php echo t('changelog_v120_4'); ?></li>
                    <li><?php echo t('changelog_v120_5'); ?></li>
                    <li><?php echo t('changelog_v120_6'); ?></li>
                </ul>
                <p class="text-xs mt-3 text-slate-500"><?php echo t('changelog_v120_note'); ?></p>
            </div>

            <!-- 1.1.0 -->
            <div class="mb-10 border-l-4 border-slate-300 pl-6">
                <h2 class="text-2xl font-semibold"><?php echo t('changelog_v110'); ?></h2>
                <ul class="text-sm space-y-1 mt-2">
                    <li><?php echo t('changelog_v110_1'); ?></li>
                    <li><?php echo t('changelog_v110_2'); ?></li>
                    <li><?php echo t('changelog_v110_3'); ?></li>
                </ul>
            </div>

            <!-- 1.0 -->
            <div class="border-l-4 border-slate-300 pl-6">
                <h2 class="text-2xl font-semibold"><?php echo t('changelog_v100'); ?></h2>
                <ul class="text-sm space-y-1 mt-2">
                    <li><?php echo t('changelog_v100_1'); ?></li>
                </ul>
            </div>
        </div>

        <div class="mt-12 p-6 bg-white border rounded-3xl">
            <h3 class="font-semibold mb-2"><?php echo t('changelog_why_title'); ?></h3>
            <div class="text-sm text-slate-600 grid md:grid-cols-2 gap-x-8 gap-y-1">
                <div>• <?php echo t('changelog_why_1'); ?></div>
                <div>• <?php echo t('changelog_why_2'); ?></div>
                <div>• <?php echo t('changelog_why_3'); ?></div>
                <div>• <?php echo t('changelog_why_4'); ?></div>
                <div>• <?php echo t('changelog_why_5'); ?></div>
                <div>• <?php echo t('changelog_why_6'); ?></div>
            </div>
            <a href="download.php" class="inline-block mt-4 text-sm font-semibold text-blue-600 hover:underline"><?php echo t('changelog_download_free'); ?></a>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>