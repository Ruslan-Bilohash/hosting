<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('instructions_title') . ' — Free WordPress Plugin';
$page_description = t('meta_description');
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/header.php';
}
?>
<section id="instructions" class="max-w-screen-xl mx-auto px-6 py-16 bg-white border-t">
    <div class="text-center mb-10">
        <h2 class="section-title mt-4"><?php echo t('instructions_title'); ?></h2>
        <p class="text-slate-500 mt-3"><?php echo t('instructions_subtitle'); ?></p>
    </div>

    <!-- Language Tabs (only 4 languages) -->
    <div class="flex flex-wrap justify-center gap-2 mb-8">
        <button onclick="switchLang('en')" data-lang="en" class="lang-tab px-5 py-2 text-sm font-semibold border bg-violet-600 text-white rounded-3xl active">English</button>
        <button onclick="switchLang('ru')" data-lang="ru" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Русский</button>
        <button onclick="switchLang('ua')" data-lang="ua" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Українська</button>
        <button onclick="switchLang('no')" data-lang="no" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Norsk</button>
    </div>

    <!-- English Instructions -->
    <div id="lang-en" class="lang-content">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4"><?php echo t('language_en'); ?> — <?php echo t('quick_start'); ?></h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Upload the plugin to <code>/wp-content/plugins/bilohash-smart-popups/</code></li>
                <li>Activate it in WordPress</li>
                <li>Go to <strong>Smart Popups</strong> in the admin sidebar</li>
                <li>Click "+ Add new popup" or use one of the 6 ready templates</li>
                <li>Configure Design (with live preview), Triggers, Device &amp; Page targeting</li>
                <li>Save — the popup will appear automatically according to your rules</li>
            </ol>
            <p class="mt-4 text-xs text-slate-500">No shortcodes needed. Popups are shown based on per-popup targeting rules.</p>
        </div>
    </div>

    <!-- Russian -->
    <div id="lang-ru" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Русский — <?php echo t('quick_start'); ?></h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Загрузите плагин в <code>/wp-content/plugins/bilohash-smart-popups/</code></li>
                <li>Активируйте в меню «Плагины»</li>
                <li>Перейдите в <strong>Smart Popups</strong> в боковой панели админки</li>
                <li>Нажмите «+ Добавить новый попап» или используйте один из 6 готовых шаблонов</li>
                <li>Настройте Дизайн (с живым превью), Триггеры, Таргетинг устройств и страниц</li>
                <li>Сохраните — попап появится автоматически по вашим правилам</li>
            </ol>
        </div>
    </div>

    <!-- Ukrainian -->
    <div id="lang-ua" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Українська — Швидкий старт</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Завантажте плагін у <code>/wp-content/plugins/bilohash-smart-popups/</code></li>
                <li>Активуйте через меню «Плагіни»</li>
                <li>Перейдіть у <strong>Smart Popups</strong> в бічній панелі адмінки</li>
                <li>Натисніть «+ Додати новий попап» або оберіть один із 6 готових шаблонів</li>
                <li>Налаштуйте Дизайн (з живим прев'ю), Тригери, Таргетинг пристроїв і сторінок</li>
                <li>Збережіть — попап з'явиться автоматично за вашими правилами</li>
            </ol>
        </div>
    </div>

    <!-- Norwegian -->
    <div id="lang-no" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Norsk — Rask start</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Last opp pluginen til <code>/wp-content/plugins/bilohash-smart-popups/</code></li>
                <li>Aktiver den i WordPress</li>
                <li>Gå til <strong>Smart Popups</strong> i admin-sidemenyen</li>
                <li>Klikk "+ Legg til ny popup" eller bruk en av de 6 klare malene</li>
                <li>Konfigurer Design (med live preview), Utløsere, Enhets- og sidetargeting</li>
                <li>Lagre — popupen vises automatisk i henhold til reglene dine</li>
            </ol>
        </div>
    </div>
</section>

<script>
function switchLang(lang) {
    document.querySelectorAll('.lang-content').forEach(el => el.classList.add('hidden'));
    const target = document.getElementById('lang-' + lang);
    if (target) target.classList.remove('hidden');
    
    document.querySelectorAll('.lang-tab').forEach(tab => {
        tab.classList.remove('bg-violet-600', 'text-white');
        tab.classList.add('text-slate-600', 'border');
        if (tab.dataset.lang === lang) {
            tab.classList.add('bg-violet-600', 'text-white');
            tab.classList.remove('text-slate-600', 'border');
        }
    });
}
</script>
<?php
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/footer.php';
}
?>
