<?php
/**
 * Snapshot current PHP defaults for admin import (no HTML output).
 */
function news_hub_defaults_snapshot(): array
{
    if (!defined('BH_NEWS_EXPORT_DATA')) {
        define('BH_NEWS_EXPORT_DATA', true);
    }
    $GLOBALS['lang'] = 'en';
    $_SERVER['HTTP_HOST'] = $_SERVER['HTTP_HOST'] ?? 'bilohash.com';
    $_SERVER['HTTPS'] = $_SERVER['HTTPS'] ?? 'on';
    $_GET['lang'] = $_GET['lang'] ?? 'en';
    $_SERVER['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $result = include __DIR__ . '/index.php';
    return is_array($result) ? $result : ['cms_products' => [], 'modules' => [], 'all_news' => []];
}