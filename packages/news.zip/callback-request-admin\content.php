<!-- Features -->
<section id="features" class="max-w-screen-xl mx-auto px-6 pt-16 pb-12">
    <div class="text-center mb-12">
        <span class="inline-block px-4 py-1 bg-blue-100 text-blue-700 rounded-3xl text-xs font-semibold tracking-widest"><?php echo t('powerful_simple'); ?></span>
        <h2 class="section-title mt-3"><?php echo t('features_title'); ?></h2>
    </div>

    <div class="grid md:grid-cols-3 gap-6">
        <div class="feature-card bg-white border border-slate-200 rounded-3xl p-7">
            <div class="w-11 h-11 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-5">
                <i class="fa-solid fa-phone-volume text-2xl"></i>
            </div>
            <h3 class="font-semibold text-xl mb-3"><?php echo t('feature1_title'); ?></h3>
            <p class="text-slate-600 leading-relaxed"><?php echo t('feature1_desc'); ?></p>
        </div>
        
        <div class="feature-card bg-white border border-slate-200 rounded-3xl p-7">
            <div class="w-11 h-11 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mb-5">
                <i class="fa-solid fa-envelope text-2xl"></i>
            </div>
            <h3 class="font-semibold text-xl mb-3"><?php echo t('feature2_title'); ?></h3>
            <p class="text-slate-600 leading-relaxed"><?php echo t('feature2_desc'); ?></p>
        </div>

        <div class="feature-card bg-white border border-slate-200 rounded-3xl p-7">
            <div class="w-11 h-11 bg-violet-100 text-violet-600 rounded-2xl flex items-center justify-center mb-5">
                <i class="fa-solid fa-paper-plane text-2xl"></i>
            </div>
            <h3 class="font-semibold text-xl mb-3"><?php echo t('feature3_title'); ?></h3>
            <p class="text-slate-600 leading-relaxed"><?php echo t('feature3_desc'); ?></p>
        </div>
    </div>
</section>

<!-- Screenshots -->
<section id="screenshots" class="max-w-screen-xl mx-auto px-6 pb-16">
    <div class="flex items-end justify-between mb-8">
        <div>
            <span class="text-blue-600 font-semibold text-sm tracking-widest"><?php echo t('see_it_in_action'); ?></span>
            <h2 class="section-title mt-1"><?php echo t('screenshots_title'); ?></h2>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div class="screenshot bg-white border rounded-3xl overflow-hidden">
            <img src="screen/general.jpg" alt="<?php echo t('general_settings'); ?>" class="w-full" width="640" height="360" loading="lazy">
            <div class="p-4"><strong><?php echo t('general_settings'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden">
            <img src="screen/design.jpg" alt="<?php echo t('design_live_preview'); ?>" class="w-full" width="640" height="360" loading="lazy">
            <div class="p-4"><strong><?php echo t('design_live_preview'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden">
            <img src="screen/subscribe.jpg" alt="<?php echo t('subscribe_form_separate_design'); ?>" class="w-full" width="640" height="360" loading="lazy">
            <div class="p-4"><strong><?php echo t('subscribe_form_separate_design'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden">
            <img src="screen/email.jpg" alt="<?php echo t('email_smtp_test'); ?>" class="w-full" width="640" height="360" loading="lazy">
            <div class="p-4"><strong><?php echo t('email_smtp_test'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden">
            <img src="screen/messages.jpg" alt="<?php echo t('mass_mailing_cool_header_footer'); ?>" class="w-full" width="640" height="360" loading="lazy">
            <div class="p-4"><strong><?php echo t('mass_mailing_cool_header_footer'); ?></strong></div>
        </div>
        <div class="screenshot bg-white border rounded-3xl overflow-hidden">
            <img src="screen/integration.jpg" alt="<?php echo t('integrations_recaptcha'); ?>" class="w-full" width="640" height="360" loading="lazy">
            <div class="p-4"><strong><?php echo t('integrations_recaptcha'); ?></strong></div>
        </div>
    </div>
</section>

<!-- Mass Mailing with Cool Header/Footer -->
<section id="mass-mailing" class="max-w-screen-xl mx-auto px-6 py-12">
    <div class="bg-white border border-slate-200 rounded-3xl p-8 md:p-12">
        <div class="grid lg:grid-cols-12 gap-x-12 items-center">
            <div class="lg:col-span-5">
                <div class="uppercase tracking-[1.5px] text-xs font-bold text-blue-600 mb-3"><?php echo t('powerful_tool'); ?></div>
                <h2 class="section-title leading-none mb-6"><?php echo t('mass_mailing_title'); ?></h2>
                <p class="text-lg text-slate-600 mb-8"><?php echo t('mass_mailing_desc'); ?></p>
                
                <div class="space-y-2 text-sm">
                    <div class="flex items-center gap-x-2">
                        <i class="fa-solid fa-check text-emerald-500"></i>
                        <span><?php echo t('mass_mailing_header_color'); ?></span>
                    </div>
                    <div class="flex items-center gap-x-2">
                        <i class="fa-solid fa-check text-emerald-500"></i>
                        <span><?php echo t('mass_mailing_footer_color'); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Cool Email Demo with Header/Footer -->
            <div class="lg:col-span-7 mt-10 lg:mt-0">
                <div class="email-demo bg-white">
                    <!-- Cool Header -->
                    <div class="px-8 pt-6 pb-5 text-white" style="background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-x-3">
                                <div class="w-8 h-8 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center">
                                    <i class="fa-solid fa-bullhorn text-white"></i>
                                </div>
                                <div>
                                    <div class="font-semibold"><?php echo t('mass_mailing_title'); ?></div>
                                    <div class="text-xs text-blue-200 -mt-0.5">Callback Request Admin</div>
                                </div>
                            </div>
                            <div class="text-right text-xs font-medium bg-white/15 px-3 py-1 rounded-2xl">Now</div>
                        </div>
                    </div>
                    
                    <div class="px-8 py-7 bg-white">
                        <div class="text-lg font-semibold mb-2">Dear {name},</div>
                        <div class="text-slate-600 leading-relaxed">
                            Thank you for being part of our community.<br>
                            Here’s an exclusive update just for you.
                        </div>
                        
                        <div class="mt-7 pt-5 border-t text-sm text-slate-500">
                            Best regards,<br>
                            <span class="font-semibold text-slate-700">The Team</span>
                        </div>
                    </div>
                    
                    <!-- Cool Footer -->
                    <div class="px-8 py-4 bg-slate-100 text-xs text-slate-500 flex items-center justify-between">
                        <div>
                            You received this because you are subscribed.<br>
                            <a href="#" class="text-blue-600 hover:underline"><?php echo t('unsubscribe_link'); ?></a>
                        </div>
                        <div class="text-right text-[10px]">
                            <?php echo t('powered_by'); ?><br>
                            <span class="font-semibold text-slate-700">Callback Request Admin</span>
                        </div>
                    </div>
                </div>
                <p class="text-center text-xs mt-3 text-slate-500"><?php echo t('header_footer_note'); ?></p>
            </div>
        </div>
    </div>
</section>