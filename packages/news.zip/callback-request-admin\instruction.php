<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('instructions_title') . ' — Free WordPress Plugin';
$page_description = t('meta_description');
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/header.php';
}
?>
<section id="instructions" class="max-w-screen-xl mx-auto px-6 py-16 bg-white border-t">
    <div class="text-center mb-10">
        <h2 class="section-title mt-4"><?php echo t('instructions_title'); ?></h2>
        <p class="text-slate-500 mt-3"><?php echo t('instructions_subtitle'); ?></p>
    </div>

    <!-- Language Tabs -->
    <div class="flex flex-wrap justify-center gap-2 mb-8">
        <button onclick="switchLang('en')" data-lang="en" class="lang-tab px-5 py-2 text-sm font-semibold border bg-blue-600 text-white rounded-3xl active">English</button>
        <button onclick="switchLang('ua')" data-lang="ua" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Українська</button>
        <button onclick="switchLang('no')" data-lang="no" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Norsk</button>
        <button onclick="switchLang('ru')" data-lang="ru" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Русский</button>
        <button onclick="switchLang('lt')" data-lang="lt" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Lietuvių</button>
        <button onclick="switchLang('sv')" data-lang="sv" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Svenska</button>
        <button onclick="switchLang('de')" data-lang="de" class="lang-tab px-5 py-2 text-sm font-semibold border text-slate-600 rounded-3xl">Deutsch</button>
    </div>

    <!-- English Instructions -->
    <div id="lang-en" class="lang-content">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4"><?php echo t('language_en'); ?> — <?php echo t('quick_start'); ?></h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Upload the plugin to <code>/wp-content/plugins/callback-request-admin/</code></li>
                <li>Activate it in WordPress</li>
                <li>Go to <strong>Callback Requests → Settings</strong></li>
                <li>Configure General, Design, Email (SMTP recommended), reCAPTCHA, Subscribe tabs</li>
                <li>Use shortcodes: <code>[callback_request_form]</code> and <code>[callback_subscribe_form]</code></li>
                <li>Use the separate <strong>Mass Mailing</strong> menu item for bulk emails (with custom header/footer colors)</li>
            </ol>
            <p class="mt-4 text-xs text-slate-500">Full menu descriptions are available in the WordPress integration section.</p>
        </div>
    </div>

    <!-- Ukrainian -->
    <div id="lang-ua" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Українська — Швидкий старт</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Завантажте плагін у <code>/wp-content/plugins/callback-request-admin/</code></li>
                <li>Активуйте через меню «Плагіни»</li>
                <li>Перейдіть у <strong>Callback Requests → Settings</strong></li>
                <li>Налаштуйте вкладки Загальні, Дизайн, Пошта (SMTP), reCAPTCHA, Підписка</li>
                <li>Використовуйте шорткоди: <code>[callback_request_form]</code> та <code>[callback_subscribe_form]</code></li>
                <li>Для масової розсилки використовуйте окремий пункт меню <strong>Mass Mailing</strong> (з налаштуванням кольорів шапки/футера)</li>
            </ol>
        </div>
    </div>

    <!-- Norwegian -->
    <div id="lang-no" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Norsk — Rask start</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Last opp pluginen til <code>/wp-content/plugins/callback-request-admin/</code></li>
                <li>Aktiver den i WordPress</li>
                <li>Gå til <strong>Callback Requests → Settings</strong></li>
                <li>Konfigurer fanene Generelt, Design, E-post (SMTP), reCAPTCHA, Abonnement</li>
                <li>Bruk shortcodes: <code>[callback_request_form]</code> og <code>[callback_subscribe_form]</code></li>
                <li>For masseutsendelse bruk den separate <strong>Mass Mailing</strong>-menyen (med fargeinnstillinger for header/footer)</li>
            </ol>
        </div>
    </div>

    <!-- Russian / Lithuanian / Swedish / German abbreviated for brevity but full in spirit -->
    <div id="lang-ru" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Русский — Быстрый старт</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Загрузите плагин в <code>/wp-content/plugins/callback-request-admin/</code></li>
                <li>Активируйте через меню «Плагины»</li>
                <li>Перейдите в <strong>Callback Requests → Settings</strong></li>
                <li>Настройте вкладки Общие, Дизайн, Почта (SMTP), reCAPTCHA, Подписка</li>
                <li>Используйте шорткоды: <code>[callback_request_form]</code> и <code>[callback_subscribe_form]</code></li>
                <li>Для массовой рассылки используйте отдельный пункт меню <strong>Mass Mailing</strong> (с настройкой цветов шапки/футера)</li>
            </ol>
        </div>
    </div>

    <div id="lang-lt" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Lietuvių — Greita pradžia</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Įkelkite papildinį į <code>/wp-content/plugins/callback-request-admin/</code></li>
                <li>Aktyvuokite per „Plugins“ meniu</li>
                <li>Eikite į <strong>Callback Requests → Settings</strong></li>
                <li>Konfigūruokite skirtukus Bendrieji, Dizainas, El. paštas (SMTP), reCAPTCHA, Prenumerata</li>
                <li>Naudokite šortkodus: <code>[callback_request_form]</code> ir <code>[callback_subscribe_form]</code></li>
                <li>Masinėms siuntoms naudokite atskirą <strong>Mass Mailing</strong> meniu punktą (su antraštės/poraštės spalvų nustatymais)</li>
            </ol>
        </div>
    </div>

    <div id="lang-sv" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Svenska — Snabbstart</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Ladda upp pluginet till <code>/wp-content/plugins/callback-request-admin/</code></li>
                <li>Aktivera det i WordPress Plugins-menyn</li>
                <li>Gå till <strong>Callback Requests → Settings</strong></li>
                <li>Konfigurera flikarna Allmänt, Design, E-post (SMTP), reCAPTCHA, Prenumeration</li>
                <li>Använd shortcodes: <code>[callback_request_form]</code> och <code>[callback_subscribe_form]</code></li>
                <li>För massutskick använd den separata <strong>Mass Mailing</strong>-menyn (med färgval för header/footer)</li>
            </ol>
        </div>
    </div>

    <div id="lang-de" class="lang-content hidden">
        <div class="max-w-3xl mx-auto bg-slate-50 border rounded-3xl p-8">
            <h3 class="font-semibold text-xl mb-4">Deutsch — Schnellstart</h3>
            <ol class="list-decimal pl-5 space-y-2 text-sm">
                <li>Laden Sie das Plugin in <code>/wp-content/plugins/callback-request-admin/</code> hoch</li>
                <li>Aktivieren Sie es im WordPress-Plugins-Menü</li>
                <li>Gehen Sie zu <strong>Callback Requests → Settings</strong></li>
                <li>Konfigurieren Sie die Tabs Allgemein, Design, E-Mail (SMTP), reCAPTCHA, Abonnement</li>
                <li>Verwenden Sie Shortcodes: <code>[callback_request_form]</code> und <code>[callback_subscribe_form]</code></li>
                <li>Für Massenversand nutzen Sie den separaten <strong>Mass Mailing</strong>-Menüpunkt (mit Farbeinstellungen für Header/Footer)</li>
            </ol>
        </div>
    </div>
</section>

<script>
function switchLang(lang) {
    document.querySelectorAll('.lang-content').forEach(el => el.classList.add('hidden'));
    const target = document.getElementById('lang-' + lang);
    if (target) target.classList.remove('hidden');
    
    document.querySelectorAll('.lang-tab').forEach(tab => {
        tab.classList.remove('bg-blue-600', 'text-white');
        tab.classList.add('text-slate-600', 'border');
        if (tab.dataset.lang === lang) {
            tab.classList.add('bg-blue-600', 'text-white');
            tab.classList.remove('text-slate-600', 'border');
        }
    });
}
</script>
<?php
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/footer.php';
}
?>