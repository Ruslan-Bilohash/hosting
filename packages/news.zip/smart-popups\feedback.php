<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('feedback_title');
$page_description = t('meta_description_feedback');
$page_keywords = t('meta_keywords_feedback');
include 'header.php';

// === PHPMailer from domain root ===
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/src/Exception.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/src/PHPMailer.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// === НАЛАШТУВАННЯ ===
$to_email = "rbilohash@gmail.com";
$site_name = "Bilohash Smart Popups";
$from_email = "email@bilohash.com";

// SMTP (from user)
$smtpHost      = "smtp.hostinger.com";
$smtpPort      = 465;
$smtpUsername  = "email@bilohash.com";
$smtpPassword  = "Odifarka78@";
$smtpSecure    = "ssl";

// Google reCAPTCHA v2 (use your keys)
$recaptcha_site_key   = '6LdEdcosAAAAAD80bEr40Jhk2pquDQyUApONukMj';
$recaptcha_secret_key = '6LdEdcosAAAAAIgVKDlLXrD08v5m8hYn-KiXHMz2';
$recaptcha_enabled = true;

$lang = isset($_GET['lang']) ? strtolower($_GET['lang']) : 'ua';

$texts = $texts ?? [
    'ua' => [
        'title' => 'Зворотний зв\'язок',
        'name' => 'Ваше ім\'я',
        'email' => 'Ваш Email',
        'subject' => 'Тема повідомлення',
        'message' => 'Ваше повідомлення',
        'submit' => 'Надіслати повідомлення',
        'success' => '✅ Дякуємо! Ваше повідомлення успішно надіслано.',
        'error' => '❌ Помилка. Перевірте всі поля.',
        'recaptcha_error' => '❌ Перевірку reCAPTCHA не пройдено. Спробуйте ще раз.'
    ],
    'en' => [
        'title' => 'Contact Form',
        'name' => 'Your Name',
        'email' => 'Your Email',
        'subject' => 'Subject',
        'message' => 'Your Message',
        'submit' => 'Send Message',
        'success' => '✅ Thank you! Your message has been sent successfully.',
        'error' => '❌ Error. Please check all fields.',
        'recaptcha_error' => '❌ reCAPTCHA verification failed. Please try again.'
    ],
    'ru' => [
        'title' => 'Обратная связь',
        'name' => 'Ваше имя',
        'email' => 'Ваш Email',
        'subject' => 'Тема сообщения',
        'message' => 'Ваше сообщение',
        'submit' => 'Отправить сообщение',
        'success' => '✅ Спасибо! Ваше сообщение успешно отправлено.',
        'error' => '❌ Ошибка. Проверьте все поля.',
        'recaptcha_error' => '❌ Проверка reCAPTCHA не пройдена. Попробуйте ещё раз.'
    ],
    'no' => [
        'title' => 'Kontaktskjema',
        'name' => 'Ditt navn',
        'email' => 'Din e-post',
        'subject' => 'Emne',
        'message' => 'Din melding',
        'submit' => 'Send melding',
        'success' => '✅ Takk! Meldingen din er sendt.',
        'error' => '❌ Feil. Vennligst sjekk alle felt.',
        'recaptcha_error' => '❌ reCAPTCHA-verifisering mislyktes. Prøv igjen.'
    ]
];

$t = $texts[$lang] ?? $texts['en'];

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $recaptcha_response = $_POST['g-recaptcha-response'] ?? '';

    if ($recaptcha_enabled) {
        $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$recaptcha_secret_key}&response={$recaptcha_response}");
        $captcha_success = json_decode($verify);
        if (!$captcha_success->success) {
            $error = $t['recaptcha_error'];
        }
    }

    if (empty($error) && $name && $email && $subject && $message) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $smtpHost;
            $mail->SMTPAuth   = true;
            $mail->Username   = $smtpUsername;
            $mail->Password   = $smtpPassword;
            $mail->SMTPSecure = $smtpSecure;
            $mail->Port       = $smtpPort;

            $mail->setFrom($from_email, $site_name);
            $mail->addAddress($to_email);
            $mail->addReplyTo($email, $name);

            $mail->isHTML(true);
            $mail->Subject = "[Smart Popups] " . $subject;
            $mail->Body    = "<strong>From:</strong> {$name} &lt;{$email}&gt;<br><br>" . nl2br(htmlspecialchars($message));

            $mail->send();
            $success = $t['success'];
        } catch (Exception $e) {
            $error = $t['error'] . ' ' . $mail->ErrorInfo;
        }
    } elseif (empty($error)) {
        $error = $t['error'];
    }
}
?>

<div class="max-w-screen-xl mx-auto px-6 py-16 max-w-2xl">
    <div class="text-center mb-10">
        <h1 class="text-4xl font-semibold tracking-tighter mb-3"><?php echo $t['title']; ?></h1>
        <p class="text-slate-600"><?php echo t('feedback_subtitle'); ?></p>
    </div>

    <?php if ($success): ?>
        <div class="mb-8 p-6 bg-emerald-50 border border-emerald-200 rounded-3xl text-emerald-700"><?php echo $success; ?></div>
    <?php elseif ($error): ?>
        <div class="mb-8 p-6 bg-red-50 border border-red-200 rounded-3xl text-red-700"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="post" class="bg-white border border-slate-200 rounded-3xl p-8 space-y-5">
        <div>
            <label class="block text-sm font-medium mb-1.5"><?php echo $t['name']; ?></label>
            <input type="text" name="name" required class="w-full border border-slate-300 rounded-2xl px-4 h-12 focus:outline-none focus:border-violet-400">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1.5"><?php echo $t['email']; ?></label>
            <input type="email" name="email" required class="w-full border border-slate-300 rounded-2xl px-4 h-12 focus:outline-none focus:border-violet-400">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1.5"><?php echo $t['subject']; ?></label>
            <input type="text" name="subject" required class="w-full border border-slate-300 rounded-2xl px-4 h-12 focus:outline-none focus:border-violet-400">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1.5"><?php echo $t['message']; ?></label>
            <textarea name="message" rows="6" required class="w-full border border-slate-300 rounded-2xl px-4 py-3 focus:outline-none focus:border-violet-400"></textarea>
        </div>

        <?php if ($recaptcha_enabled): ?>
        <div class="pt-2">
            <div class="g-recaptcha" data-sitekey="<?php echo $recaptcha_site_key; ?>"></div>
        </div>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <?php endif; ?>

        <button type="submit" class="w-full h-12 bg-violet-600 hover:bg-violet-700 transition text-white font-semibold rounded-3xl">
            <?php echo $t['submit']; ?>
        </button>
    </form>

    <p class="text-center text-xs text-slate-500 mt-6">
        Your message goes directly to the developer. We usually reply within 24-48 hours.
    </p>
</div>

<?php include 'footer.php'; ?>
