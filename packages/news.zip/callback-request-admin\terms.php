<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('terms_of_service');
$page_description = t('meta_description');
$page_keywords = t('meta_keywords');
?>
<?php include 'header.php'; ?>

<div class="max-w-screen-xl mx-auto px-6 py-16">
<h1 class="section-title mb-8"><?php echo t('terms_of_service'); ?></h1>
    
    <div class="prose max-w-none">
        <p><?php echo t('terms_intro'); ?></p>
        
        <h3><?php echo t('terms_license'); ?></h3>
        <p><?php echo t('terms_license_desc'); ?></p>
        
        <h3><?php echo t('terms_responsibility'); ?></h3>
        <p><?php echo t('terms_responsibility_desc'); ?></p>
        
        <h3><?php echo t('terms_no_warranty'); ?></h3>
        <p><?php echo t('terms_no_warranty_desc'); ?></p>
        
        <h3><?php echo t('terms_contact'); ?></h3>
        <p><?php echo t('terms_contact_desc'); ?></p>
        
        <p class="mt-8 text-sm">Contact: <a href="mailto:email@bilohash.com">email@bilohash.com</a></p>
    </div>
</div>

<?php include 'footer.php'; ?>