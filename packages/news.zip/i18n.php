<?php
/**
 * BILOHASH News — UI strings & badge labels (en, no, lt, pl, de, sv, ua)
 */

$ecosystem = [
    'en' => 'BILOHASH Ecosystem',
    'no' => 'BILOHASH Økosystem',
    'lt' => 'BILOHASH ekosistema',
    'pl' => 'Ekosystem BILOHASH',
    'de' => 'BILOHASH Ökosystem',
    'sv' => 'BILOHASH-ekosystemet',
    'ua' => 'Екосистема BILOHASH',
];

$hero_sub = [
    'en' => 'Release notes · Live demos · Product pages · Admin access',
    'no' => 'Utgivelsesnotater · Live demoer · Produktsider · Admin-tilgang',
    'lt' => 'Leidimų pastabos · Live demo · Produktų puslapiai · Admin prieiga',
    'pl' => 'Informacje o wydaniach · Demo na żywo · Strony produktów · Dostęp do panelu',
    'de' => 'Release Notes · Live-Demos · Produktseiten · Admin-Zugang',
    'sv' => 'Release notes · Live-demo · Produktsidor · Adminåtkomst',
    'ua' => 'Нотатки релізів · Live demo · Продуктові сторінки · Доступ до адмінки',
];

$hero_tagline = [
    'en' => 'Every BILOHASH script ships with a live demo, full admin panel and a dedicated product page. Browse releases, open demos and request deployment for Norway & Europe.',
    'no' => 'Hvert BILOHASH-skript leveres med live demo, fullt adminpanel og egen produktside. Bla gjennom utgivelser, åpne demoer og be om utrulling for Norge og Europa.',
    'lt' => 'Kiekvienas BILOHASH skriptas turi live demo, pilną admin panelę ir atskirą produkto puslapį. Naršykite leidimus, atidarykite demo ir užsakykite diegimą Norvegijai ir Europai.',
    'pl' => 'Każdy skrypt BILOHASH ma demo na żywo, pełny panel admina i dedykowaną stronę produktu. Przeglądaj wydania, otwieraj demo i zamawiaj wdrożenie dla Norwegii i Europy.',
    'de' => 'Jedes BILOHASH-Skript liefert mit Live-Demo, vollem Admin-Panel und eigener Produktseite. Durchsuchen Sie Releases, öffnen Sie Demos und fordern Sie Deployment für Norwegen und Europa an.',
    'sv' => 'Varje BILOHASH-skript levereras med live-demo, fullt adminpanel och egen produktsida. Bläddra bland lanseringar, öppna demo och begär driftsättning för Norge och Europa.',
    'ua' => 'Кожен скрипт BILOHASH має live demo, повну адмін-панель і окрему продуктову сторінку. Переглядайте релізи, відкривайте демо та замовляйте розгортання для Норвегії та Європи.',
];

$hero_hub_caption = [
    'en' => 'Click a planet — open a live CMS demo in a new tab.',
    'no' => 'Klikk en planet — åpne live CMS-demo i ny fane.',
    'lt' => 'Spustelėkite planetą — atidarykite live CMS demo naujame skirtuke.',
    'pl' => 'Kliknij planetę — otwórz demo CMS na żywo w nowej karcie.',
    'de' => 'Planet anklicken — Live-CMS-Demo in neuem Tab öffnen.',
    'sv' => 'Klicka på en planet — öppna live CMS-demo i ny flik.',
    'ua' => 'Натисніть на планету — відкриється live demo CMS у новій вкладці.',
];

$hero_h1 = [
    'en' => 'Product releases & live demos',
    'no' => 'Produktutgivelser og live demoer',
    'lt' => 'Produktų leidimai ir live demo',
    'pl' => 'Wydania produktów i demo na żywo',
    'de' => 'Produkt-Releases & Live-Demos',
    'sv' => 'Produktlanseringar och live-demo',
    'ua' => 'Релізи продуктів та live demo',
];

$section_h2 = [
    'demos' => [
        'en' => 'Live demo previews',
        'no' => 'Forhåndsvisning av live demoer',
        'lt' => 'Live demo peržiūros',
        'pl' => 'Podglądy demo na żywo',
        'de' => 'Live-Demo-Vorschauen',
        'sv' => 'Förhandsvisning av live-demo',
        'ua' => 'Превʼю live demo',
    ],
    'cms' => [
        'en' => 'PHP CMS scripts with live demo',
        'no' => 'PHP CMS-skript med live demo',
        'lt' => 'PHP CMS skriptai su live demo',
        'pl' => 'Skrypty PHP CMS z demo na żywo',
        'de' => 'PHP-CMS-Skripte mit Live-Demo',
        'sv' => 'PHP CMS-skript med live-demo',
        'ua' => 'PHP CMS-скрипти з live demo',
    ],
    'modules' => [
        'en' => 'AI, WordPress & extensions',
        'no' => 'AI, WordPress og utvidelser',
        'lt' => 'AI, WordPress ir plėtiniai',
        'pl' => 'AI, WordPress i rozszerzenia',
        'de' => 'KI, WordPress & Erweiterungen',
        'sv' => 'AI, WordPress och tillägg',
        'ua' => 'AI, WordPress та розширення',
    ],
    'timeline_title' => [
        'en' => 'Complete release timeline',
        'no' => 'Full utgivelsestidslinje',
        'lt' => 'Visa leidimų chronologija',
        'pl' => 'Pełna oś czasu wydań',
        'de' => 'Vollständige Release-Zeitleiste',
        'sv' => 'Fullständig lanserings-tidslinje',
        'ua' => 'Повна стрічка релізів',
    ],
    'timeline_desc' => [
        'en' => 'Every CMS launch, module update and product page in the BILOHASH ecosystem — newest first.',
        'no' => 'Hver CMS-lansering, moduloppdatering og produktside i BILOHASH-økosystemet — nyeste først.',
        'lt' => 'Kiekvienas CMS paleidimas, modulio atnaujinimas ir produkto puslapis BILOHASH ekosistemoje — naujausi pirmi.',
        'pl' => 'Każde uruchomienie CMS, aktualizacja modułu i strona produktu w ekosystemie BILOHASH — najnowsze na górze.',
        'de' => 'Jeder CMS-Launch, Modul-Update und jede Produktseite im BILOHASH-Ökosystem — neueste zuerst.',
        'sv' => 'Varje CMS-lansering, moduluppdatering och produktsida i BILOHASH-ekosystemet — nyaste först.',
        'ua' => 'Усі запуски CMS, оновлення модулів і продуктові сторінки екосистеми BILOHASH — спочатку найновіші.',
    ],
];

$section = [
    'cms'      => ['en' => 'CMS Scripts', 'no' => 'CMS-skript', 'lt' => 'CMS skriptai', 'pl' => 'Skrypty CMS', 'de' => 'CMS-Skripte', 'sv' => 'CMS-skript', 'ua' => 'CMS-скрипти'],
    'demos'    => ['en' => 'Demo screenshots', 'no' => 'Demo-skjermbilder', 'lt' => 'Demo ekrano nuotraukos', 'pl' => 'Zrzuty ekranu demo', 'de' => 'Demo-Screenshots', 'sv' => 'Demo-skärmdumpar', 'ua' => 'Скриншоти демо'],
    'modules'  => ['en' => 'Modules & Tools', 'no' => 'Moduler og verktøy', 'lt' => 'Moduliai ir įrankiai', 'pl' => 'Moduły i narzędzia', 'de' => 'Module & Tools', 'sv' => 'Moduler och verktyg', 'ua' => 'Модулі та інструменти'],
    'all_news' => ['en' => 'All ecosystem news', 'no' => 'Alle økosystemnyheter', 'lt' => 'Visos ekosistemos naujienos', 'pl' => 'Wszystkie aktualności ekosystemu', 'de' => 'Alle Ökosystem-News', 'sv' => 'Alla ekosystemnyheter', 'ua' => 'Усі новини екосистеми'],
    'releases' => ['en' => 'Latest releases', 'no' => 'Siste utgivelser', 'lt' => 'Naujausi leidimai', 'pl' => 'Najnowsze wydania', 'de' => 'Neueste Releases', 'sv' => 'Senaste lanseringar', 'ua' => 'Останні релізи'],
    'contact'  => ['en' => 'Product inquiry', 'no' => 'Produkthenvendelse', 'lt' => 'Užklausa dėl produkto', 'pl' => 'Zapytanie o produkt', 'de' => 'Produktanfrage', 'sv' => 'Produktförfrågan', 'ua' => 'Запит щодо продукту'],
];

$demo_gallery_intro = [
    'en' => 'Visual previews of every live BILOHASH demo — frontend and admin panels. Click any image to enlarge.',
    'no' => 'Visuelle forhåndsvisninger av alle live BILOHASH-demoer — frontend og adminpaneler. Klikk for å forstørre.',
    'lt' => 'Vizualinės kiekvieno live BILOHASH demo peržiūros — frontend ir admin panelės. Spustelėkite norėdami padidinti.',
    'pl' => 'Wizualne podglądy każdego live demo BILOHASH — frontend i panele admina. Kliknij, aby powiększyć.',
    'de' => 'Visuelle Vorschauen jeder live BILOHASH-Demo — Frontend und Admin-Panels. Klicken zum Vergrößern.',
    'sv' => 'Visuella förhandsvisningar av varje live BILOHASH-demo — frontend och adminpaneler. Klicka för att förstora.',
    'ua' => 'Візуальні превʼю кожного live demo BILOHASH — фронтенд і адмін-панелі. Натисніть на зображення, щоб збільшити.',
];

$shot_labels = [
    'frontend' => ['en' => 'Frontend', 'no' => 'Frontend', 'lt' => 'Frontend', 'pl' => 'Frontend', 'de' => 'Frontend', 'sv' => 'Frontend', 'ua' => 'Фронтенд'],
    'admin'    => ['en' => 'Admin', 'no' => 'Admin', 'lt' => 'Admin', 'pl' => 'Admin', 'de' => 'Admin', 'sv' => 'Admin', 'ua' => 'Адмін'],
];

$labels = [
    'demo'      => ['en' => 'Live demo', 'no' => 'Live demo', 'lt' => 'Live demo', 'pl' => 'Demo na żywo', 'de' => 'Live-Demo', 'sv' => 'Live-demo', 'ua' => 'Live demo'],
    'admin'     => ['en' => 'Admin panel', 'no' => 'Adminpanel', 'lt' => 'Admin panelė', 'pl' => 'Panel admina', 'de' => 'Admin-Panel', 'sv' => 'Adminpanel', 'ua' => 'Адмін-панель'],
    'product'   => ['en' => 'Product page', 'no' => 'Produktside', 'lt' => 'Produkto puslapis', 'pl' => 'Strona produktu', 'de' => 'Produktseite', 'sv' => 'Produktsida', 'ua' => 'Сторінка продукту'],
    'release'   => ['en' => 'Release notes', 'no' => 'Utgivelse', 'lt' => 'Leidimo pastabos', 'pl' => 'Informacje o wydaniu', 'de' => 'Release Notes', 'sv' => 'Release notes', 'ua' => 'Реліз'],
    'home'      => ['en' => 'All products', 'no' => 'Alle produkter', 'lt' => 'Visi produktai', 'pl' => 'Wszystkie produkty', 'de' => 'Alle Produkte', 'sv' => 'Alla produkter', 'ua' => 'Усі продукти'],
    'developer' => ['en' => 'Developer', 'no' => 'Utvikler', 'lt' => 'Kūrėjas', 'pl' => 'Deweloper', 'de' => 'Entwickler', 'sv' => 'Utvecklare', 'ua' => 'Розробник'],
    'join'      => ['en' => 'Join ecosystem', 'no' => 'Bli med i økosystemet', 'lt' => 'Prisijungti prie ekosistemos', 'pl' => 'Dołącz do ekosystemu', 'de' => 'Ökosystem beitreten', 'sv' => 'Gå med i ekosystemet', 'ua' => 'Вступити в екосистему'],
    'menu'      => ['en' => 'Menu', 'no' => 'Meny', 'lt' => 'Meniu', 'pl' => 'Menu', 'de' => 'Menü', 'sv' => 'Meny', 'ua' => 'Меню'],
    'close'     => ['en' => 'Close', 'no' => 'Lukk', 'lt' => 'Uždaryti', 'pl' => 'Zamknij', 'de' => 'Schließen', 'sv' => 'Stäng', 'ua' => 'Закрити'],
    'read'      => ['en' => 'Read', 'no' => 'Les', 'lt' => 'Skaityti', 'pl' => 'Czytaj', 'de' => 'Lesen', 'sv' => 'Läs', 'ua' => 'Читати'],
    'changelog' => ['en' => 'Changelog', 'no' => 'Endringslogg', 'lt' => 'Pakeitimų žurnalas', 'pl' => 'Historia zmian', 'de' => 'Changelog', 'sv' => 'Ändringslogg', 'ua' => 'Changelog'],
];

$contact_cta = [
    'en' => 'Need a live demo, license or custom deployment of a BILOHASH product? Get in touch — we adapt platforms for Norway and Europe.',
    'no' => 'Trenger du live demo, lisens eller tilpasset utrulling av et BILOHASH-produkt? Ta kontakt — vi tilpasser plattformer for Norge og Europa.',
    'lt' => 'Reikia live demo, licencijos ar individualaus BILOHASH produkto diegimo? Susisiekite — pritaikome platformas Norvegijai ir Europai.',
    'pl' => 'Potrzebujesz demo na żywo, licencji lub wdrożenia produktu BILOHASH? Napisz — dostosowujemy platformy dla Norwegii i Europy.',
    'de' => 'Brauchen Sie eine Live-Demo, Lizenz oder individuelles Deployment eines BILOHASH-Produkts? Kontaktieren Sie uns — wir passen Plattformen für Norwegen und Europa an.',
    'sv' => 'Behöver du live-demo, licens eller anpassad driftsättning av en BILOHASH-produkt? Hör av dig — vi anpassar plattformar för Norge och Europa.',
    'ua' => 'Потрібне live demo, ліцензія або кастомне розгортання продукту BILOHASH? Зв\'яжіться — адаптуємо платформи для Норвегії та Європи.',
];

$news_footer_badge = [
    'en' => 'News',
    'no' => 'Nyheter',
    'lt' => 'Naujienos',
    'pl' => 'Aktualności',
    'de' => 'News',
    'sv' => 'Nyheter',
    'ua' => 'Новини',
];

$news_badges = [
    'UPDATE'   => ['en' => 'UPDATE', 'no' => 'OPPDATERING', 'lt' => 'ATNAUJINTA', 'pl' => 'AKTUALIZACJA', 'de' => 'UPDATE', 'sv' => 'UPPDATERING', 'ua' => 'ОНОВЛЕННЯ'],
    'NEW'      => ['en' => 'NEW', 'no' => 'NY', 'lt' => 'NAUJA', 'pl' => 'NOWOŚĆ', 'de' => 'NEU', 'sv' => 'NY', 'ua' => 'НОВЕ'],
    'DEMO'     => ['en' => 'Demo', 'no' => 'Demo', 'lt' => 'Demo', 'pl' => 'Demo', 'de' => 'Demo', 'sv' => 'Demo', 'ua' => 'Демо'],
    'LIVE'     => ['en' => 'Live', 'no' => 'Live', 'lt' => 'Live', 'pl' => 'Na żywo', 'de' => 'Live', 'sv' => 'Live', 'ua' => 'Live'],
    'OFFICIAL' => ['en' => 'OFFICIAL', 'no' => 'OFFISIELL', 'lt' => 'OFICIALU', 'pl' => 'OFICJALNE', 'de' => 'OFFIZIELL', 'sv' => 'OFFICIELL', 'ua' => 'ОФІЦІЙНО'],
    'AI'       => ['en' => 'AI', 'no' => 'AI', 'lt' => 'AI', 'pl' => 'AI', 'de' => 'KI', 'sv' => 'AI', 'ua' => 'AI'],
    'MODULE'   => ['en' => 'Module', 'no' => 'Modul', 'lt' => 'Modulis', 'pl' => 'Moduł', 'de' => 'Modul', 'sv' => 'Modul', 'ua' => 'Модуль'],
    'UPDATE2'  => ['en' => 'Update', 'no' => 'Oppdatering', 'lt' => 'Atnaujinimas', 'pl' => 'Aktualizacja', 'de' => 'Update', 'sv' => 'Uppdatering', 'ua' => 'Оновлення'],
    'LAUNCH'   => ['en' => 'Launch', 'no' => 'Lansering', 'lt' => 'Paleidimas', 'pl' => 'Premiera', 'de' => 'Launch', 'sv' => 'Lansering', 'ua' => 'Запуск'],
    'RELEASE'  => ['en' => 'Release', 'no' => 'Utgivelse', 'lt' => 'Leidimas', 'pl' => 'Wydanie', 'de' => 'Release', 'sv' => 'Lansering', 'ua' => 'Реліз'],
    'NEWS'     => ['en' => 'News', 'no' => 'Nyhet', 'lt' => 'Naujiena', 'pl' => 'Aktualność', 'de' => 'News', 'sv' => 'Nyhet', 'ua' => 'Новина'],
    'TEMPLATE' => ['en' => 'Template', 'no' => 'Mal', 'lt' => 'Šablonas', 'pl' => 'Szablon', 'de' => 'Vorlage', 'sv' => 'Mall', 'ua' => 'Шаблон'],
    'SITE'     => ['en' => 'Site', 'no' => 'Nettsted', 'lt' => 'Svetainė', 'pl' => 'Strona', 'de' => 'Website', 'sv' => 'Webbplats', 'ua' => 'Сайт'],
];

if (!function_exists('news_badge_label')) {
    function news_badge_label(string $badge): string
    {
        global $news_badges, $lang;
        $key = strtoupper($badge);
        if ($key === 'UPDATE' && $badge !== 'UPDATE' && $badge !== 'Update') {
            $key = 'UPDATE';
        }
        if ($badge === 'Update') {
            $key = 'UPDATE2';
        }
        if (isset($news_badges[$key])) {
            return portfolio_seo_pick($news_badges[$key], $lang);
        }
        return $badge;
    }
}

if (!function_exists('news_i18n_merge')) {
    /**
     * Merge lt/pl/de/sv (and other) translations into string arrays on list items.
     *
     * @param array<int, array<string, mixed>> $items
     * @param array<int, array<string, array<string, string>>> $overlays
     */
    function news_i18n_merge(array &$items, array $overlays): void
    {
        foreach ($overlays as $idx => $fields) {
            if (!isset($items[$idx])) {
                continue;
            }
            foreach ($fields as $field => $translations) {
                if (!isset($items[$idx][$field]) || !is_array($items[$idx][$field])) {
                    continue;
                }
                $items[$idx][$field] = array_merge($items[$idx][$field], $translations);
            }
        }
    }
}

if (!function_exists('news_i18n_merge_by_key')) {
    /**
     * @param array<int, array<string, mixed>> $items
     * @param array<string, array<string, array<string, string>>> $overlays
     * @param string $keyField
     */
    function news_i18n_merge_by_key(array &$items, array $overlays, string $keyField = 'item_key'): void
    {
        $byKey = [];
        foreach ($items as $i => $item) {
            $key = (string) ($item[$keyField] ?? '');
            if ($key !== '') {
                $byKey[$key] = $i;
            }
        }
        foreach ($overlays as $key => $fields) {
            if (!isset($byKey[$key])) {
                continue;
            }
            $idx = $byKey[$key];
            foreach ($fields as $field => $translations) {
                if (!isset($items[$idx][$field]) || !is_array($items[$idx][$field])) {
                    continue;
                }
                $items[$idx][$field] = array_merge($items[$idx][$field], $translations);
            }
        }
    }
}

if (!function_exists('news_url_with_lang')) {
    /** Append ?lang= for internal news links (static .html uses uk for ua). */
    function news_url_with_lang(string $url, ?string $lang = null): string
    {
        $lang = $lang ?? ($GLOBALS['lang'] ?? 'en');
        if ($url === '' || str_starts_with($url, 'http') || str_starts_with($url, '//')) {
            return $url;
        }
        if ($lang === 'en') {
            return $url;
        }
        $param = ($lang === 'ua' && preg_match('/\.html(\?|$)/', $url)) ? 'uk' : $lang;
        $sep = str_contains($url, '?') ? '&' : '?';
        return $url . $sep . 'lang=' . rawurlencode($param);
    }
}