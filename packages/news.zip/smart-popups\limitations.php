<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('limitations_title');
$page_description = t('limitations_intro');
$page_keywords = t('meta_keywords');
include 'header.php';
?>
<div class="max-w-screen-xl mx-auto px-6 py-16 max-w-3xl">
    <h1 class="text-3xl font-semibold tracking-tighter mb-4"><?php echo t('limitations_title'); ?></h1>
    <p class="text-lg text-slate-600 mb-8"><?php echo t('limitations_intro'); ?></p>
    <p class="text-sm mb-4">This plugin is designed and tested for <strong>WordPress 6.4, 6.5, 6.6, 6.7 and 7.0+</strong> (including latest Gutenberg, Classic Editor, Elementor, Divi, Bricks and most popular themes). The free version includes the core popup builder with 6 templates and essential targeting.</p>

    <div class="prose prose-slate max-w-none bg-white border rounded-3xl p-8">
        <ul class="space-y-3">
            <li><strong><?php echo t('limitation_no_priority_support'); ?></strong></li>
            <li><strong><?php echo t('limitation_no_extra_templates'); ?></strong></li>
            <li><strong><?php echo t('limitation_no_advanced_segmentation'); ?></strong></li>
            <li><strong><?php echo t('limitation_no_whitelabel'); ?></strong></li>
            <li><strong><?php echo t('limitation_no_analytics'); ?></strong></li>
            <li><strong><?php echo t('limitation_no_early_access'); ?></strong></li>
        </ul>

        <p class="mt-6 text-sm text-slate-600"><?php echo t('limitations_note'); ?></p>
    </div>

    <div class="mt-8 text-center">
        <a href="download.php" class="inline-flex items-center px-6 py-3 bg-violet-600 text-white rounded-3xl text-sm font-semibold hover:bg-violet-700"><?php echo t('download_back_to_download'); ?></a>
    </div>
</div>
<?php include 'footer.php'; ?>
