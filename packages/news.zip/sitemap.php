<?php
/**
 * XML sitemap for /news/ — all locale alternates.
 */
declare(strict_types=1);

header('Content-Type: application/xml; charset=utf-8');

require_once dirname(__DIR__) . '/includes/portfolio-seo.php';

$base = rtrim(portfolio_seo_base_url(), '/');
$newsRoot = dirname(__DIR__);

function news_lastmod(string $path, string $newsRoot): string
{
    $file = $newsRoot . $path;
    if (is_file($file)) {
        return gmdate('Y-m-d', (int) filemtime($file));
    }
    return gmdate('Y-m-d');
}

$urls = [
    '/news/',
    '/news/hosting.html',
    '/news/lending-creator.html',
    '/news/faktura-cms.html',
    '/news/tavle.html',
    '/news/pizza-cms.html',
    '/news/booking-cms.html',
    '/news/auction-cms.html',
    '/news/shop-cms.html',
    '/news/freelance-cms.html',
    '/news/gamehub-cms.html',
    '/news/today-cms.html',
    '/news/3d-cms.html',
    '/news/wordpress.html',
    '/news/ai-norway-chat.html',
    '/news/smart-popups/',
    '/news/callback-request-admin/',
];

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
<?php foreach ($urls as $path) : ?>
    <url>
        <loc><?= htmlspecialchars($base . $path, ENT_XML1) ?></loc>
        <lastmod><?= news_lastmod($path, $newsRoot) ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority><?= $path === '/news/' ? '1.0' : '0.8' ?></priority>
        <?php foreach (portfolio_seo_regions() as $code => $info) : ?>
        <xhtml:link rel="alternate" hreflang="<?= htmlspecialchars($info['hreflang'], ENT_XML1) ?>" href="<?= htmlspecialchars(portfolio_seo_lang_url($code, $path), ENT_XML1) ?>"/>
        <?php endforeach; ?>
        <xhtml:link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(portfolio_seo_lang_url('en', $path), ENT_XML1) ?>"/>
    </url>
<?php endforeach; ?>
</urlset>