<?php if (defined('BH_NEWS_LANG_ASSETS')) { return; } define('BH_NEWS_LANG_ASSETS', true); ?>
<style>
.bh-lang-select-wrap {
    position: relative;
    z-index: 200;
    flex-shrink: 0;
}
.bh-lang-select-label {
    position: relative;
    display: inline-flex;
    align-items: center;
    margin: 0;
    cursor: pointer;
}
.bh-lang-select-icon {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 12px;
    pointer-events: none;
    z-index: 1;
}
.bh-lang-select-chevron {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 10px;
    pointer-events: none;
    z-index: 1;
}
.bh-lang-select {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    display: block;
    min-width: 148px;
    max-width: 200px;
    padding: 8px 28px 8px 34px;
    border: 1px solid #1e293b;
    border-radius: 12px;
    background: #0f172a;
    color: #cbd5e1;
    font-size: 13px;
    font-weight: 600;
    line-height: 1.3;
    cursor: pointer;
    transition: border-color .15s ease, color .15s ease;
}
.bh-lang-select:hover,
.bh-lang-select:focus {
    border-color: rgba(34, 211, 238, .55);
    color: #f8fafc;
    outline: none;
}
.bh-lang-select option {
    background: #0f172a;
    color: #e2e8f0;
}
#newsNav .news-nav-tools { position: relative; z-index: 200; }
.site-footer .bh-lang-select-wrap { overflow: visible; }
</style>