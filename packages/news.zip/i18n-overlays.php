<?php
/**
 * BILOHASH News — lt/pl/de/sv overlays keyed by item_key (not numeric index)
 */

$news_i18n_cms = [
    'hosting' => [
        'desc' => [
            'lt' => 'v2.7.0 — hPanel lygio PHP panelė: 40+ įrankių, MySQL 2.0, 15 ekosistemos planetų, malware skeneris, BILOHASH Webmail, 60 WebP ekrano nuotraukų ir 30 dienų NEMOKAMA demo licencija.',
            'pl' => 'v2.7.0 — panel PHP na poziomie hPanel: 40+ narzędzi, MySQL 2.0, 15 planet ekosystemu, skaner malware, BILOHASH Webmail, 60 zrzutów WebP i 30-dniowa DARMOWA licencja demo.',
            'de' => 'v2.7.0 — PHP-Panel auf hPanel-Niveau: 40+ Tools, MySQL 2.0, 15 Ökosystem-Planeten, Malware-Scanner, BILOHASH Webmail, 60 WebP-Screenshots und 30 Tage KOSTENLOSE Demo-Lizenz.',
            'sv' => 'v2.7.0 — PHP-panel på hPanel-nivå: 40+ verktyg, MySQL 2.0, 15 ekosystemplaneter, malware-skanner, BILOHASH Webmail, 60 WebP-skärmdumpar och 30 dagars GRATIS demolicens.',
        ],
    ],
    'lending' => [
        'desc' => [
            'lt' => 'v1.2 — Chart.js grafikai, mokyklos naujienos su AI ir SEO, demo sąskaitos ir užklausos, 4 kalbos (LT pagal nutylėjimą). Demo — jokių realių paslaugų.',
            'pl' => 'v1.2 — wykresy Chart.js, wiadomości szkoły z AI i SEO, demo faktury i zapytania, 4 języki (LT domyślnie). Tylko demo — fikcyjna szkoła jazdy.',
            'de' => 'v1.2 — Chart.js-Dashboards, Schulnews mit KI & SEO, Demo-Rechnungen, 4 Sprachen (LT Standard). Nur Demo — fiktive Fahrschule.',
            'sv' => 'v1.2 — Chart.js-grafer, skolnyheter med AI och SEO, demofakturor, 4 språk (LT standard). Endast demo — fiktiv körskola.',
        ],
    ],
    'shop' => [
        'desc' => [
            'lt' => 'v1.7.1 — 6 kalbos (NO/EN/SV/UA/RU/LT), Grok xAI ir OpenAI produktams/SEO/pokalbiams, ekosistemos prenumerata ir laukimo sąrašas, 30 d. demo ZIP, licencijų kabinetas. Katalogas, krepšelis, Schema.org Product SEO.',
            'pl' => 'v1.7.1 — 6 języków (NO/EN/SV/UA/RU/LT), Grok xAI i OpenAI dla produktów/SEO/czatu, subskrypcja ekosystemu i lista oczekujących, 30-dniowy ZIP demo, panel licencji. Katalog, koszyk, Schema.org Product SEO.',
            'de' => 'v1.7.1 — 6 Sprachen (NO/EN/SV/UA/RU/LT), Grok xAI & OpenAI für Produkte/SEO/Chat, Ökosystem-Abo & Warteliste, 30-Tage-Demo-ZIP, Lizenz-Cabinet. Katalog, Warenkorb, Schema.org Product SEO.',
            'sv' => 'v1.7.1 — 6 språk (NO/EN/SV/UA/RU/LT), Grok xAI och OpenAI för produkter/SEO/chatt, ekosystemprenumeration och väntelista, 30-dagars demo-ZIP, licenskabinett. Katalog, varukorg, Schema.org Product SEO.',
        ],
    ],
    'faktura' => [
        'desc' => [
            'lt' => 'Mobilios sąskaitos — 2 paspaudimai, klientų bazė, SMTP, AI pastabos, QR mokėjimai, Pay mygtukai, 12 spausdinimo dizainų, 7 kalbos.',
            'pl' => 'Mobilne faktury — 2 kliknięcia, baza klientów, SMTP, notatki AI, płatności QR, przyciski Pay, 12 wzorów druku, 7 języków.',
            'de' => 'Mobile Rechnungen — 2 Klicks, Kundendatenbank, SMTP, KI-Notizen, QR-Zahlung, Pay-Buttons, 12 Druckdesigns, 7 Sprachen.',
            'sv' => 'Mobila fakturor — 2 klick, kunddatabas, SMTP, AI-anteckningar, QR-betalning, Pay-knappar, 12 utskriftsdesign, 7 språk.',
        ],
    ],
    'booking' => [
        'desc' => [
            'lt' => '5 kalbos, demo PayPal/Stripe/Vipps, svečių atsiliepimai, 8 vertikalūs SEO puslapiai, mokesčiai ir mokėjimai admin. Geo produkto puslapis 6 rinkiams.',
            'pl' => '5 języków, demo PayPal/Stripe/Vipps, opinie gości, 8 pionowych stron SEO, podatki i płatności w adminie. Geo strona produktu dla 6 rynków.',
            'de' => '5 Sprachen, Demo PayPal/Stripe/Vipps, Gästebewertungen, 8 vertikale SEO-Seiten, Steuern & Zahlungen im Admin. Geo-Produktseite für 6 Märkte.',
            'sv' => '5 språk, demo PayPal/Stripe/Vipps, gästrecensioner, 8 vertikala SEO-sidor, skatter och betalning i admin. Geoproduktsida för 6 marknader.',
        ],
    ],
    'tavle' => [
        'desc' => [
            'lt' => 'PHP automobilių turgus — lipnūs Pirkimas/Lizingas filtrai, 18 demo skelbimų, foto karuselė, prekės ženklo SEO, Schema.org Car, SQLite admin. 4 kalbos.',
            'pl' => 'PHP giełda samochodowa — przyklejone filtry Kupno/Leasing, 18 demo ogłoszeń, karuzela zdjęć, SEO marek, Schema.org Car, admin SQLite. 4 języki.',
            'de' => 'PHP-Automarktplatz — fixierte Kauf/Leasing-Filter, 18 Demo-Inserate, Foto-Karussell, Marken-SEO, Schema.org Car, SQLite-Admin. 4 Sprachen.',
            'sv' => 'PHP bilmarknadsplats — klibbiga Köp/Leasing-filter, 18 demoannonser, bildkarusell, märkes-SEO, Schema.org Car, SQLite-admin. 4 språk.',
        ],
    ],
    'gamehub' => [
        'desc' => [
            'lt' => 'PHP žaidimų serverių monitorius — CS2 hub, žemėlapių peržiūros, live statistika, filtrai, GameServer schema, admin. 4 kalbos.',
            'pl' => 'PHP monitor serwerów gier — hub CS2, podglądy map, statystyki na żywo, filtry, schema GameServer, admin. 4 języki.',
            'de' => 'PHP-Spielserver-Monitor — CS2-Hub, Kartenvorschau, Live-Statistiken, Filter, GameServer-Schema, Admin. 4 Sprachen.',
            'sv' => 'PHP spelservermonitor — CS2-hub, kartförhandsvisning, live-statistik, filter, GameServer-schema, admin. 4 språk.',
        ],
    ],
    'auction' => [
        'desc' => [
            'lt' => 'PHP internetinis aukcionas — 14 demo lotų, statymai, atgalinis skaičiavimas, admin skydelis, CSV eksportas. 3 kalbos, Schema.org SEO.',
            'pl' => 'PHP aukcja online — 14 demo licytacji, licytacje, odliczanie, panel admina, eksport CSV. 3 języki, Schema.org SEO.',
            'de' => 'PHP-Online-Auktion — 14 Demo-Lose, Gebote, Countdown, Admin-Dashboard, CSV-Export. 3 Sprachen, Schema.org SEO.',
            'sv' => 'PHP onlineauktion — 14 demoobjekt, bud, nedräkning, admin-dashboard, CSV-export. 3 språk, Schema.org SEO.',
        ],
    ],
    'freelance' => [
        'desc' => [
            'lt' => 'PHP laisvai samdomų platforma — 12 projektų, pasiūlymai, 8 sprendimai, 9 SEO regionai, 4 kalbos, Upwork/Fiverr stilius.',
            'pl' => 'PHP marketplace freelancerski — 12 projektów, oferty, 8 rozwiązań, 9 regionów SEO, 4 języki, styl Upwork/Fiverr.',
            'de' => 'PHP-Freelance-Marktplatz — 12 Projekte, Angebote, 8 Lösungen, 9 SEO-Regionen, 4 Sprachen, Upwork/Fiverr-Stil.',
            'sv' => 'PHP frilansmarknadsplats — 12 projekt, förslag, 8 lösningar, 9 SEO-regioner, 4 språk, Upwork/Fiverr-stil.',
        ],
    ],
    'pizza' => [
        'desc' => [
            'lt' => 'PHP restorano skriptas — daugiakalbis meniu, staliukų rezervacija, terasa #solaskinner, Schema.org Restaurant SEO ir admin.',
            'pl' => 'PHP skrypt restauracji — wielojęzyczne menu, rezerwacja stolików, taras #solaskinner, Schema.org Restaurant SEO i admin.',
            'de' => 'PHP-Restaurant-Skript — mehrsprachiges Menü, Tischreservierung, Terrasse #solaskinner, Schema.org Restaurant SEO und Admin.',
            'sv' => 'PHP restaurantskript — flerspråkig meny, bordsbokning, terrass #solaskinner, Schema.org Restaurant SEO och admin.',
        ],
    ],
    'today' => [
        'desc' => [
            'lt' => 'PHP naujienų CMS demo — 10 pavyzdinių straipsnių, žurnalistų profiliai, kategorijos, laikraščio UI, NewsArticle schema. 4 kalbos.',
            'pl' => 'PHP news CMS demo — 10 przykładowych artykułów, profile dziennikarzy, kategorie, UI gazety, schema NewsArticle. 4 języki.',
            'de' => 'PHP-News-CMS-Demo — 10 Beispielartikel, Journalistenprofile, Kategorien, Zeitungs-UI, NewsArticle-Schema. 4 Sprachen.',
            'sv' => 'PHP nyhets-CMS — 10 exempelartiklar, journalistprofiler, kategorier, tidnings-UI, NewsArticle-schema. 4 språk.',
        ],
    ],
    '3d' => [
        'desc' => [
            'lt' => '3D spausdinimo užsakymai — figūrėlės iš nuotraukų, STL/OBJ įkėlimas, PayPal ir Vipps NOK, daugiakalbis svetainė ir užsakymų admin.',
            'pl' => 'Zamówienia druku 3D — figurki ze zdjęć, upload STL/OBJ, PayPal i Vipps w NOK, wielojęzyczna strona i admin zamówień.',
            'de' => '3D-Druckbestellungen — Fotofiguren, STL/OBJ-Upload, PayPal & Vipps in NOK, mehrsprachige Seite und Bestell-Admin.',
            'sv' => '3D-utskriftsbeställningar — fotofigurer, STL/OBJ-uppladdning, PayPal och Vipps i NOK, flerspråkig sida och orderadmin.',
        ],
    ],
];

$news_i18n_modules = [
    'wordpress-ai' => [
        'desc' => [
            'lt' => 'Oficialus WordPress.org įskiepis — Grok xAI + OpenAI, Telegram įspėjimai, pilnas pritaikymas.',
            'pl' => 'Oficjalna wtyczka WordPress.org — Grok xAI + OpenAI, alerty Telegram, pełna personalizacja.',
            'de' => 'Offizielles WordPress.org-Plugin — Grok xAI + OpenAI, Telegram-Benachrichtigungen, volle Anpassung.',
            'sv' => 'Officiellt WordPress.org-plugin — Grok xAI + OpenAI, Telegram-varningar, full anpassning.',
        ],
    ],
    'ai-platform' => [
        'title' => ['lt' => 'AI platforma', 'pl' => 'Platforma AI', 'de' => 'KI-Plattform', 'sv' => 'AI-plattform'],
        'desc' => [
            'lt' => 'AI pokalbių sprendimų centras, CRM konsultantas, WordPress demo ir daugiakanaliai botai.',
            'pl' => 'Hub rozwiązań AI chat, konsultant CRM, demo WordPress i boty wielokanałowe.',
            'de' => 'Hub für KI-Chat-Lösungen, CRM-Berater, WordPress-Demo und Multikanal-Bots.',
            'sv' => 'Hub för AI-chatlösningar, CRM-konsult, WordPress-demo och multikanalsbotar.',
        ],
    ],
    'smart-popups' => [
        'desc' => [
            'lt' => 'Išmaniosios iššokančios sistemos konversijoms — taisyklės, šablonai, trigeriai, WordPress integracija.',
            'pl' => 'Inteligentne popupy do konwersji — reguły, szablony, wyzwalacze, integracja WordPress.',
            'de' => 'Intelligentes Pop-up-System für Conversions — Regeln, Vorlagen, Trigger, WordPress-Integration.',
            'sv' => 'Smart popup-system för konverteringar — regler, mallar, triggers, WordPress-integration.',
        ],
    ],
    'callback-admin' => [
        'title' => ['lt' => 'Callback užklausų admin', 'pl' => 'Admin zapytań callback', 'de' => 'Callback-Anfragen Admin', 'sv' => 'Callback-förfrågan admin'],
        'desc' => [
            'lt' => 'Callback ir prenumeratų admin WordPress — reCAPTCHA, masinė siuntimas, Telegram.',
            'pl' => 'Admin callback i subskrypcji dla WordPress — reCAPTCHA, masowa wysyłka, Telegram.',
            'de' => 'Callback- & Abo-Admin für WordPress — reCAPTCHA, Massenversand, Telegram.',
            'sv' => 'Callback- och prenumerationsadmin för WordPress — reCAPTCHA, massutskick, Telegram.',
        ],
    ],
];

$news_i18n_feed = [
    'hosting-launch' => [
        'title' => ['lt' => 'Hosting CMS v2.7.0 — paleista', 'pl' => 'Hosting CMS v2.7.0 — uruchomione', 'de' => 'Hosting CMS v2.7.0 — live', 'sv' => 'Hosting CMS v2.7.0 — lanserad'],
        'desc' => ['lt' => 'hPanel lygio panelė, 40+ įrankių, 15 planetų ekosistemoje, malware skeneris, BILOHASH Webmail, 30 d. nemokama demo.', 'pl' => 'Panel na poziomie hPanel, 40+ narzędzi, 15 planet ekosystemu, skaner malware, BILOHASH Webmail, 30-dniowe demo.', 'de' => 'hPanel-Level-Panel, 40+ Tools, 15 Ökosystem-Planeten, Malware-Scanner, BILOHASH Webmail, 30 Tage Demo.', 'sv' => 'hPanel-nivåpanel, 40+ verktyg, 15 ekosystemplaneter, malware-skanner, BILOHASH Webmail, 30 dagars demo.'],
    ],
    'shop-171' => [
        'title' => ['lt' => 'Shop CMS v1.7.1 — ekosistemos prenumerata ir AI', 'pl' => 'Shop CMS v1.7.1 — subskrypcja ekosystemu i AI', 'de' => 'Shop CMS v1.7.1 — Ökosystem-Abo & KI', 'sv' => 'Shop CMS v1.7.1 — ekosystemprenumeration och AI'],
        'desc' => ['lt' => '6 kalbos, Grok xAI ir OpenAI agentai, 30 d. demo atsisiuntimas, licencijų kabinetas — waitlist per ecosystem/join.php.', 'pl' => '6 języków, agenci Grok xAI i OpenAI, pobieranie 30-dniowego demo, panel licencji — lista oczekujących na ecosystem/join.php.', 'de' => '6 Sprachen, Grok xAI & OpenAI-Agenten, 30-Tage-Demo-Download, Lizenz-Cabinet — Warteliste unter ecosystem/join.php.', 'sv' => '6 språk, Grok xAI och OpenAI-agenter, 30-dagars demonedladdning, licenskabinett — väntelista via ecosystem/join.php.'],
    ],
    'lending-12' => [
        'title' => ['lt' => 'Business Landing CMS v1.2 veikia', 'pl' => 'Business Landing CMS v1.2 na żywo', 'de' => 'Business Landing CMS v1.2 live', 'sv' => 'Business Landing CMS v1.2 live'],
        'desc' => ['lt' => 'Grafikai, naujienos AI, SEO, sąskaitos, 4 kalbos. Tik demo — fiktyvi autoškola.', 'pl' => 'Wykresy, wiadomości AI, SEO, faktury, 4 języki. Tylko demo.', 'de' => 'Charts, News-KI, SEO, Rechnungen, 4 Sprachen. Nur Demo.', 'sv' => 'Grafer, nyheter AI, SEO, fakturor, 4 språk. Endast demo.'],
    ],
    'faktura-update' => [
        'title' => ['lt' => 'Faktura CMS — mobilios sąskaitos, AI ir QR', 'pl' => 'Faktura CMS — mobilne faktury, AI i QR', 'de' => 'Faktura CMS — mobile Rechnungen, KI & QR', 'sv' => 'Faktura CMS — mobila fakturor, AI och QR'],
        'desc' => ['lt' => '2 paspaudimai iš telefono, klientai, SMTP, AI pastabos, QR mokėjimai, 12 dizainų, 7 kalbos.', 'pl' => '2 kliknięcia z telefonu, klienci, SMTP, notatki AI, płatności QR, 12 wzorów, 7 języków.', 'de' => '2 Klicks vom Handy, Kunden, SMTP, KI-Notizen, QR-Zahlung, 12 Designs, 7 Sprachen.', 'sv' => '2 klick från mobil, kunder, SMTP, AI-anteckningar, QR-betalning, 12 design, 7 språk.'],
    ],
    'bilen-launch' => [
        'title' => ['lt' => 'Bilen CMS — automobilių turgus veikia', 'pl' => 'Bilen CMS — giełda samochodowa na żywo', 'de' => 'Bilen CMS — Automarktplatz live', 'sv' => 'Bilen CMS — bilmarknadsplats live'],
        'desc' => ['lt' => '18 demo automobilių, lipnūs filtrai, prekės ženklo SEO, Schema.org Car, SQLite admin, 4 kalbos.', 'pl' => '18 demo aut, przyklejone filtry, SEO marek, Schema.org Car, admin SQLite, 4 języki.', 'de' => '18 Demo-Autos, fixierte Filter, Marken-SEO, Schema.org Car, SQLite-Admin, 4 Sprachen.', 'sv' => '18 demobilar, klibbiga filter, märkes-SEO, Schema.org Car, SQLite-admin, 4 språk.'],
    ],
    'gamehub-launch' => [
        'title' => ['lt' => 'GameHub CMS — CS2 serverių monitorius veikia', 'pl' => 'GameHub CMS — monitor CS2 na żywo', 'de' => 'GameHub CMS — CS2-Servermonitor live', 'sv' => 'GameHub CMS — CS2-servermonitor live'],
        'desc' => ['lt' => 'Žemėlapių peržiūros, live statistika, serverių filtrai, GameServer SEO, admin panelė, 4 kalbos.', 'pl' => 'Podglądy map, statystyki na żywo, filtry serwerów, GameServer SEO, panel admina, 4 języki.', 'de' => 'Kartenvorschau, Live-Statistiken, Serverfilter, GameServer SEO, Admin-Panel, 4 Sprachen.', 'sv' => 'Kartförhandsvisning, live-statistik, serverfilter, GameServer SEO, adminpanel, 4 språk.'],
    ],
    'booking-geo' => [
        'title' => ['lt' => 'Booking CMS — mokėjimai, 5 kalbos ir geo puslapis', 'pl' => 'Booking CMS — płatności, 5 języków i geo', 'de' => 'Booking CMS — Zahlungen, 5 Sprachen & Geo', 'sv' => 'Booking CMS — betalning, 5 språk och geo'],
        'desc' => ['lt' => 'Demo PayPal/Stripe/Vipps, švedų kalba, atsiliepimai, vertikalus SEO, mokesčiai admin, geo kainos.', 'pl' => 'Demo PayPal/Stripe/Vipps, szwedzki, opinie, SEO pionowe, podatki w adminie, geo ceny.', 'de' => 'Demo PayPal/Stripe/Vipps, Schwedisch, Bewertungen, vertikales SEO, Steuern im Admin, Geo-Preise.', 'sv' => 'Demo PayPal/Stripe/Vipps, svenska, recensioner, vertikalt SEO, skatter i admin, geopriser.'],
    ],
    'pizza-launch' => [
        'title' => ['lt' => 'Pizza CMS — restorano demo veikia', 'pl' => 'Pizza CMS — demo restauracji na żywo', 'de' => 'Pizza CMS — Restaurant-Demo live', 'sv' => 'Pizza CMS — restaurantdemo live'],
        'desc' => ['lt' => 'Forno Romano picerijos demo — 14 patiekalų, rezervacijos, terasos animacija, 4 kalbos.', 'pl' => 'Demo pizzerii Forno Romano — 14 pozycji menu, rezerwacje, animacja tarasu, 4 języki.', 'de' => 'Forno Romano Pizzeria-Demo — 14 Menüpunkte, Reservierungen, Terrassen-Animation, 4 Sprachen.', 'sv' => 'Forno Romano pizzeria-demo — 14 menyrätter, bokning, terrassanimation, 4 språk.'],
    ],
    'freelance-release' => [
        'title' => ['lt' => 'Freelance CMS — platformos leidimas', 'pl' => 'Freelance CMS — premiera marketplace', 'de' => 'Freelance CMS — Marktplatz-Release', 'sv' => 'Freelance CMS — marknadsplatslansering'],
        'desc' => ['lt' => '12 demo projektų, pasiūlymai, 8 sprendimai, 9 SEO regionai, 4 kalbos.', 'pl' => '12 demo projektów, oferty, 8 rozwiązań, 9 regionów SEO, 4 języki.', 'de' => '12 Demo-Projekte, Angebote, 8 Lösungen, 9 SEO-Regionen, 4 Sprachen.', 'sv' => '12 demoprojekt, förslag, 8 lösningar, 9 SEO-regioner, 4 språk.'],
    ],
    'auction-release' => [
        'title' => ['lt' => 'Auction CMS — internetinio aukciono leidimas', 'pl' => 'Auction CMS — premiera aukcji online', 'de' => 'Auction CMS — Online-Auktion Release', 'sv' => 'Auction CMS — onlineauktionslansering'],
        'desc' => ['lt' => '14 demo lotų, statymai, atgalinis skaičiavimas, admin skydelis, CSV eksportas.', 'pl' => '14 demo licytacji, licytacje, odliczanie, panel admina, eksport CSV.', 'de' => '14 Demo-Lose, Gebote, Countdown, Admin-Dashboard, CSV-Export.', 'sv' => '14 demoobjekt, bud, nedräkning, admin-dashboard, CSV-export.'],
    ],
    'booking-release' => [
        'title' => ['lt' => 'Booking CMS — rezervacijų platformos leidimas', 'pl' => 'Booking CMS — premiera platformy rezerwacji', 'de' => 'Booking CMS — Buchungsplattform Release', 'sv' => 'Booking CMS — bokningsplattformslansering'],
        'desc' => ['lt' => 'Viešbučiai, apartamentai, kotedžai — paieška, objektų puslapiai, pilnas admin.', 'pl' => 'Hotele, apartamenty, domki — wyszukiwanie, strony obiektów, pełny admin.', 'de' => 'Hotels, Apartments, Hütten — Suche, Objektseiten, volles Admin.', 'sv' => 'Hotell, lägenheter, stugor — sök, objektsidor, fullt admin.'],
    ],
    'shop-launch' => [
        'title' => ['lt' => 'Shop CMS — e-commerce demo veikia', 'pl' => 'Shop CMS — demo e-commerce na żywo', 'de' => 'Shop CMS — E-Commerce-Demo live', 'sv' => 'Shop CMS — e-handelsdemo live'],
        'desc' => ['lt' => 'Katalogas, krepšelis, Schema.org Product SEO, admin skydelis, 4 kalbos.', 'pl' => 'Katalog, koszyk, Schema.org Product SEO, panel admina, 4 języki.', 'de' => 'Katalog, Warenkorb, Schema.org Product SEO, Admin-Dashboard, 4 Sprachen.', 'sv' => 'Katalog, varukorg, Schema.org Product SEO, admin-dashboard, 4 språk.'],
    ],
    'today-launch' => [
        'title' => ['lt' => 'Today CMS — naujienų platformos demo', 'pl' => 'Today CMS — demo platformy news', 'de' => 'Today CMS — News-Plattform-Demo', 'sv' => 'Today CMS — nyhetsplattformsdemo'],
        'desc' => ['lt' => '10 pavyzdinių straipsnių, žurnalistai, kategorijos, laikraščio UI, 4 kalbos.', 'pl' => '10 przykładowych artykułów, dziennikarze, kategorie, UI gazety, 4 języki.', 'de' => '10 Beispielartikel, Journalisten, Kategorien, Zeitungs-UI, 4 Sprachen.', 'sv' => '10 exempelartiklar, journalister, kategorier, tidnings-UI, 4 språk.'],
    ],
    'wordpress-official' => [
        'title' => ['lt' => 'AI Chat Consultant — WordPress.org paleidimas', 'pl' => 'AI Chat Consultant — premiera na WordPress.org', 'de' => 'AI Chat Consultant — WordPress.org Launch', 'sv' => 'AI Chat Consultant — WordPress.org-lansering'],
        'desc' => ['lt' => 'Oficialus įskiepių katalogo leidimas — Grok xAI + OpenAI, Telegram įspėjimai.', 'pl' => 'Oficjalne wydanie w katalogu wtyczek — Grok xAI + OpenAI, alerty Telegram.', 'de' => 'Offizielles Plugin-Verzeichnis — Grok xAI + OpenAI, Telegram-Benachrichtigungen.', 'sv' => 'Officiell plugin-katalog — Grok xAI + OpenAI, Telegram-varningar.'],
    ],
    'ai-norway' => [
        'title' => ['lt' => 'AI Chat Consultant Norvegijai', 'pl' => 'AI Chat Consultant dla Norwegii', 'de' => 'AI Chat Consultant für Norwegen', 'sv' => 'AI Chat Consultant för Norge'],
        'desc' => ['lt' => 'AI sprendimo detalės Norvegijos verslui — Grok, GPT, Telegram, WordPress.', 'pl' => 'Szczegóły rozwiązania AI dla firm w Norwegii — Grok, GPT, Telegram, WordPress.', 'de' => 'KI-Lösungsdetails für norwegische Unternehmen — Grok, GPT, Telegram, WordPress.', 'sv' => 'AI-lösningsdetaljer för norska företag — Grok, GPT, Telegram, WordPress.'],
    ],
    '3d-live' => [
        'title' => ['lt' => '3D Gallery CMS — 3D spausdinimo platforma', 'pl' => '3D Gallery CMS — platforma zamówień druku 3D', 'de' => '3D Gallery CMS — 3D-Druckbestellplattform', 'sv' => '3D Gallery CMS — 3D-utskriftsplattform'],
        'desc' => ['lt' => 'Figūrėlės iš nuotraukų, STL/OBJ įkėlimas, PayPal ir Vipps NOK, užsakymų admin.', 'pl' => 'Figurki ze zdjęć, upload STL/OBJ, PayPal i Vipps w NOK, admin zamówień.', 'de' => 'Fotofiguren, STL/OBJ-Upload, PayPal & Vipps in NOK, Bestell-Admin.', 'sv' => 'Fotofigurer, STL/OBJ-uppladdning, PayPal och Vipps i NOK, orderadmin.'],
    ],
    'smart-popups-module' => [
        'title' => ['lt' => 'Smart Popups — konversijų popupai', 'pl' => 'Smart Popups — popupy do konwersji', 'de' => 'Smart Popups — Conversion-Pop-ups', 'sv' => 'Smart Popups — konverteringspopups'],
        'desc' => ['lt' => 'Taisyklės, šablonai, trigeriai, WordPress įskiepis, atsisiuntimas ir dokumentacija.', 'pl' => 'Reguły, szablony, wyzwalacze, wtyczka WordPress, pobieranie i dokumentacja.', 'de' => 'Regeln, Vorlagen, Trigger, WordPress-Plugin, Download & Docs.', 'sv' => 'Regler, mallar, triggers, WordPress-plugin, nedladdning och docs.'],
    ],
    'callback-module' => [
        'title' => ['lt' => 'Callback Request Admin — leadai ir callback', 'pl' => 'Callback Request Admin — leady i callback', 'de' => 'Callback Request Admin — Leads & Callbacks', 'sv' => 'Callback Request Admin — leads och callbacks'],
        'desc' => ['lt' => 'WordPress įskiepis — reCAPTCHA, masinė siuntimas, Telegram, prenumeratos formos.', 'pl' => 'Wtyczka WordPress — reCAPTCHA, masowa wysyłka, Telegram, formularze subskrypcji.', 'de' => 'WordPress-Plugin — reCAPTCHA, Massenversand, Telegram, Abo-Formulare.', 'sv' => 'WordPress-plugin — reCAPTCHA, massutskick, Telegram, prenumerationsformulär.'],
    ],
    'crm-ai' => [
        'desc' => ['lt' => 'Daugiakanalis AI — Telegram, WhatsApp, Viber, web. Pilnas PHP+MySQL šaltinis.', 'pl' => 'Wielokanałowe AI — Telegram, WhatsApp, Viber, web. Pełne źródło PHP+MySQL.', 'de' => 'Multikanal-KI — Telegram, WhatsApp, Viber, Web. Vollständiger PHP+MySQL-Quellcode.', 'sv' => 'Multikanals-AI — Telegram, WhatsApp, Viber, web. Full PHP+MySQL-källkod.'],
    ],
    'ai-hub' => [
        'title' => ['lt' => 'AI platformos centras ir WordPress demo', 'pl' => 'Hub platformy AI i demo WordPress', 'de' => 'KI-Plattform-Hub & WordPress-Demo', 'sv' => 'AI-plattformshub och WordPress-demo'],
        'desc' => ['lt' => 'Centrinis AI įrankių centras — Grok xAI, OpenAI, live WordPress įskiepio demo.', 'pl' => 'Centralny hub narzędzi AI — Grok xAI, OpenAI, live demo wtyczki WordPress.', 'de' => 'Zentraler KI-Tools-Hub — Grok xAI, OpenAI, Live WordPress-Plugin-Demo.', 'sv' => 'Central AI-verktygshub — Grok xAI, OpenAI, live WordPress-plugindemo.'],
    ],
    'horizon-template' => [
        'title' => ['lt' => 'Horizon Admin šablonas', 'pl' => 'Szablon Horizon Admin', 'de' => 'Horizon Admin-Vorlage', 'sv' => 'Horizon Admin-mall'],
        'desc' => ['lt' => 'Šiuolaikiškas adaptyvus admin panelės šablonas — paruoštas greitam diegimui.', 'pl' => 'Nowoczesny responsywny szablon panelu admina — gotowy do szybkiego wdrożenia.', 'de' => 'Modernes responsives Admin-Panel-Template — bereit für schnelles Deployment.', 'sv' => 'Modern responsiv adminpanelmall — redo för snabb driftsättning.'],
    ],
    'medibook-template' => [
        'title' => ['lt' => 'MediBook Clinic — medicininės rezervacijos', 'pl' => 'MediBook Clinic — rezerwacje medyczne', 'de' => 'MediBook Clinic — medizinische Buchung', 'sv' => 'MediBook Clinic — medicinsk bokning'],
        'desc' => ['lt' => 'Klinikos valdymas — vizitai, pacientai, admin panelė.', 'pl' => 'Zarządzanie kliniką — wizyty, pacjenci, panel admina.', 'de' => 'Klinikverwaltung — Termine, Patienten, Admin-Panel.', 'sv' => 'Klinikhantering — tider, patienter, adminpanel.'],
    ],
    'developer-site' => [
        'title' => ['lt' => 'Kūrėjo svetainės CMS', 'pl' => 'CMS strony dewelopera', 'de' => 'Entwickler-Website-CMS', 'sv' => 'Utvecklarwebbplats CMS'],
        'desc' => ['lt' => 'Portfolio ir kūrėjo svetainės skriptas — paslaugos, kontaktas, daugiakalbystė.', 'pl' => 'Skrypt strony portfolio i dewelopera — usługi, kontakt, wielojęzyczność.', 'de' => 'Portfolio- & Entwicklerseiten-Skript — Services, Kontakt, Mehrsprachigkeit.', 'sv' => 'Portfolio- och utvecklarskript — tjänster, kontakt, flerspråkighet.'],
    ],
];