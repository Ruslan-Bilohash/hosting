<?php
require_once __DIR__ . '/lang/lang.php';

// All header-modifying code (setcookie) MUST be before ANY output, i.e. before include header.php
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['clear'])) {
        setcookie('site_lang', '', time()-3600, '/');
        setcookie('cookie_consent', '', time()-3600, '/');
        $message = t('cookie_saved');
    } else {
        $consent = $_POST['consent'] ?? 'accepted';
        setcookie('cookie_consent', $consent, time() + 365*24*60*60, '/');
        $message = t('cookie_saved');
    }
}

// Set page meta BEFORE including header (so title/description/keywords work)
$page_title = t('cookie_settings_title');
$page_description = t('meta_description');
$page_keywords = t('meta_keywords');

include __DIR__ . '/header.php';
?>
<div class="max-w-screen-xl mx-auto px-6 py-14 max-w-2xl">
<h1 class="text-3xl font-semibold tracking-tighter mb-2"><?php echo t('cookie_settings_title'); ?></h1>
    <p class="text-slate-600 mb-8"><?php echo t('cookie_settings_intro'); ?></p>

    <?php if ($message): ?>
        <div class="mb-6 p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl text-sm"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="bg-white border rounded-3xl p-8 space-y-8 text-sm">
        <div>
            <h3 class="font-semibold mb-1"><?php echo t('cookie_lang_title'); ?></h3>
            <p class="text-slate-600"><?php echo t('cookie_lang_desc'); ?></p>
            <div class="mt-2 text-xs bg-slate-100 px-3 py-1.5 rounded-2xl inline-block">
                Current value: <span class="font-mono font-semibold"><?php echo htmlspecialchars($_COOKIE['site_lang'] ?? 'not set (defaults to en)'); ?></span>
            </div>
        </div>
        <div>
            <h3 class="font-semibold mb-1"><?php echo t('cookie_consent_title'); ?></h3>
            <p class="text-slate-600"><?php echo t('cookie_consent_desc'); ?></p>
        </div>
        <div class="pt-4 border-t text-slate-600">
            <?php echo t('cookie_no_other'); ?>
        </div>
    </div>

    <form method="post" class="mt-6 flex flex-wrap gap-3">
        <button type="submit" name="save" class="px-6 py-2.5 bg-violet-600 text-white rounded-3xl text-sm font-semibold"><?php echo t('save_preferences'); ?></button>
        <button type="submit" name="clear" class="px-6 py-2.5 border rounded-3xl text-sm"><?php echo t('clear_cookies'); ?></button>
        <input type="hidden" name="consent" value="accepted">
    </form>

    <div class="mt-8 text-xs text-slate-500">
        For the actual plugin on your WordPress site: the plugin itself does not set marketing cookies. All popup display rules and preferences are stored in the browser (localStorage) or your own database.
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
