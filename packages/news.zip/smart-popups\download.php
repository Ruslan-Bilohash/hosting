<?php 
// DEBUG - remove later
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/lang/lang.php'; 
$page_title = t('download_title') . ' — Free WordPress Plugin';
$page_description = t('meta_description_download');
$page_keywords = t('meta_keywords_download');

if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/header.php'; 
}


// Load counters
$counterFile = __DIR__ . '/data/download-counts.json';
$counts = ['en' => 312, 'ua' => 187, 'ru' => 129, 'no' => 54, 'total' => 682];
if (file_exists($counterFile)) {
    $loaded = json_decode(file_get_contents($counterFile), true);
    if (is_array($loaded)) $counts = array_merge($counts, $loaded);
}
?>

<div class="max-w-screen-xl mx-auto px-6 py-16">
    <div class="text-center mb-10">
        <h1 class="section-title"><?php echo t('download_title'); ?></h1>
        <p class="text-slate-600 mt-3 max-w-md mx-auto"><?php echo t('download_desc'); ?></p>
    </div>

    <div class="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
        
        <!-- English version -->
        <div class="bg-white border border-slate-200 rounded-3xl p-7 hover:border-violet-200 transition-colors">
            <div class="flex justify-between items-start">
                <div>
                    <div class="font-semibold text-lg"><?php echo t('language_en'); ?> Version</div>
                    <div class="text-sm text-emerald-600 font-medium">Recommended for most users</div>
                </div>
                <div class="text-xs px-3 py-1 bg-emerald-100 text-emerald-700 rounded-2xl font-medium">v1.2.0</div>
            </div>
            
            <div class="my-6 text-sm text-slate-600">
                <?php echo t('download_en_full'); ?>
            </div>
            
            <a href="get-download.php?file=smart-popups-en.zip" 
               class="flex items-center justify-center w-full bg-slate-900 hover:bg-black transition-colors text-white font-semibold h-12 rounded-3xl text-sm">
                <i class="fa-solid fa-download mr-2"></i>
                <span><?php echo t('download_en'); ?></span>
            </a>
            <div class="mt-1 text-center text-[11px] text-emerald-600 font-medium">
                <?php echo t('download_counter_en'); ?>: <strong><?php echo number_format($counts['en'] ?? 0); ?></strong> <?php echo t('downloads'); ?>
            </div>
            <div class="mt-2 text-[10px] text-center text-slate-500">
                Full features: live preview, multi-popup, 6 templates, advanced triggers, device/page targeting, countdown timer.
            </div>
        </div>
        
        <!-- Ukrainian version -->
        <div class="bg-white border border-slate-200 rounded-3xl p-7 hover:border-violet-200 transition-colors">
            <div class="flex justify-between items-start">
                <div>
                    <div class="font-semibold text-lg">Українська версія</div>
                    <div class="text-sm text-emerald-600 font-medium">Повністю українською</div>
                </div>
                <div class="text-xs px-3 py-1 bg-emerald-100 text-emerald-700 rounded-2xl font-medium">v1.2.0</div>
            </div>
            
            <div class="my-6 text-sm text-slate-600">
                <?php echo t('download_ua_full'); ?>
            </div>
            
            <a href="get-download.php?file=smart-popups-ua.zip" 
               class="flex items-center justify-center w-full bg-slate-900 hover:bg-black transition-colors text-white font-semibold h-12 rounded-3xl text-sm">
                <i class="fa-solid fa-download mr-2"></i>
                <span><?php echo t('download_ua'); ?></span>
            </a>
            <div class="mt-1 text-center text-[11px] text-emerald-600 font-medium">
                <?php echo t('download_counter_ua'); ?>: <strong><?php echo number_format($counts['ua'] ?? 0); ?></strong> <?php echo t('downloads'); ?>
            </div>
            <div class="mt-2 text-[10px] text-center text-slate-500">
                Повний функціонал: живий прев'ю, кілька попапів, 6 шаблонів, тригери, таргетинг, таймер зворотного відліку.
            </div>
        </div>
    </div>
    
    <div class="mt-12 max-w-2xl mx-auto">
        <div class="bg-white border rounded-3xl p-8">
            <h3 class="font-semibold text-lg mb-4"><?php echo t('included_features'); ?></h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-sm">
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_triggers'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_countdown'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_icons'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_design'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_targeting'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_multi'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_preview'); ?></span>
                </div>
                <div class="flex items-start gap-x-2">
                    <i class="fa-solid fa-check text-emerald-500 mt-1"></i>
                    <span><?php echo t('feature_translations'); ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-8 text-xs text-slate-500">
        <?php echo t('both_versions_note'); ?>
    </div>

    <div class="mt-6 text-center text-sm text-slate-600">
        <strong>Compatible with WordPress 6.4, 6.5, 6.6, 6.7 and 7.0+</strong> (Gutenberg, Classic Editor, all popular page builders and themes).
    </div>

    <!-- FREE + PRO upsell (SEO + conversion) -->
    <div class="mt-12 max-w-3xl mx-auto">
        <div class="grid md:grid-cols-5 gap-4">
            <!-- Free reminder -->
            <div class="md:col-span-2 bg-white border rounded-3xl p-6">
                <div class="font-semibold text-lg mb-1"><?php echo t('download_free_version'); ?></div>
                <div class="text-emerald-600 text-sm font-medium mb-3"><?php echo t('download_everything_no_limits'); ?></div>
                <ul class="text-xs space-y-1 text-slate-600">
                    <li>✓ Unlimited popups + live preview</li>
                    <li>✓ 6 professional templates (basic)</li>
                    <li>✓ Time/scroll/exit triggers + countdown</li>
                    <li>✓ Device &amp; page targeting</li>
                    <li>✓ 18 languages • Any WP theme</li>
                </ul>
                <div class="mt-3 text-[10px]">
                    <a href="limitations.php" class="text-amber-600 hover:underline font-medium">→ <?php echo t('download_read_limitations'); ?></a>
                </div>
            </div>

            <!-- PRO -->
            <div class="md:col-span-3 bg-gradient-to-br from-slate-900 to-black text-white rounded-3xl p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="font-semibold text-lg"><?php echo t('pro_version'); ?></div>
                        <div class="text-emerald-400 text-sm"><?php echo t('pro_one_time'); ?></div>
                    </div>
                    <div class="text-right">
                        <div class="text-3xl font-semibold"><?php echo t('pro_price'); ?></div>
                        <div class="text-[10px] text-emerald-400 -mt-0.5"><?php echo t('pro_price_label'); ?></div>
                    </div>
                </div>

                <div class="my-4 text-sm opacity-80"><?php echo t('pro_features_title'); ?>:</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-xs mb-5">
                    <div>• <?php echo t('pro_feature_1'); ?></div>
                    <div>• <?php echo t('pro_feature_2'); ?></div>
                    <div>• <?php echo t('pro_feature_3'); ?></div>
                    <div>• <?php echo t('pro_feature_4'); ?></div>
                    <div>• <?php echo t('pro_feature_5'); ?></div>
                    <div>• <?php echo t('pro_feature_6'); ?></div>
                </div>

                <a href="https://www.paypal.com/ncp/payment/CPDZL6J8GVXNW" target="_blank"
                   class="block w-full text-center bg-white text-slate-900 hover:bg-amber-50 font-semibold py-3 rounded-3xl text-sm transition">
                    <?php echo t('buy_pro'); ?> →
                </a>
                <p class="text-[10px] text-center mt-2 opacity-60"><?php echo t('pro_note'); ?></p>
            </div>
        </div>
    </div>
</div>

<?php 
if (!defined('LANDING_PAGE')) {
    include __DIR__ . '/footer.php'; 
}
?>
