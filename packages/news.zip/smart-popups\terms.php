<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('terms_of_service');
$page_description = t('meta_description');
$page_keywords = t('meta_keywords');
?>
<?php include 'header.php'; ?>

<div class="max-w-screen-xl mx-auto px-6 py-16 max-w-3xl">
    <h1 class="section-title mb-8"><?php echo t('terms_of_service'); ?></h1>
    
    <div class="prose prose-slate max-w-none">
        <p><?php echo t('terms_intro'); ?></p>
        
        <h3><?php echo t('terms_license'); ?></h3>
        <p><?php echo t('terms_license_desc'); ?></p>
        
        <h3><?php echo t('terms_responsibility'); ?></h3>
        <p><?php echo t('terms_responsibility_desc'); ?></p>
        
        <h3><?php echo t('terms_no_warranty'); ?></h3>
        <p><?php echo t('terms_no_warranty_desc'); ?></p>
        
        <h3><?php echo t('terms_contact'); ?></h3>
        <p><?php echo t('terms_contact_desc'); ?></p>
        
        <p class="mt-8 text-sm text-slate-500">
            Contact: <a href="mailto:email@bilohash.com">email@bilohash.com</a> &nbsp;·&nbsp; 
            <a href="https://github.com/Ruslan-Bilohash/smart-popups/issues" target="_blank" class="text-violet-600 hover:underline">Open issue on GitHub</a>
        </p>
    </div>
</div>

<?php include 'footer.php'; ?>
