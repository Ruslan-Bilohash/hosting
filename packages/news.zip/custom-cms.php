<?php
// /website/news/custom-cms.php — Повна версія з правильною шапкою та футером
$lang = isset($_GET['lang']) ? strtolower($_GET['lang']) : 'ua';
if (!in_array($lang, ['en', 'no', 'ua', 'ru'], true)) {
    $lang = 'ua';
}

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https' : 'http';
$base_url = $protocol . '://' . $_SERVER['HTTP_HOST'];
$canonical_url = $base_url . '/website/news/custom-cms.php' . ($lang !== 'ua' ? '?lang=' . urlencode($lang) : '');

$t = [
    'ua' => [
        'title' => 'Кастомна архітектура CMS — розробка під ключ | Норвегія та Європа',
        'desc' => 'Кастомні CMS системи від Руслана Білогаша. Модульна архітектура, висока продуктивність, безпека та масштабованість.',
        'h1' => 'Кастомна архітектура CMS'
    ],
    'ru' => [
        'title' => 'Кастомная архитектура CMS — разработка под ключ | Норвегия и Европа',
        'desc' => 'Кастомные CMS системы от Руслана Билогаша.',
        'h1' => 'Кастомная архитектура CMS'
    ],
    'en' => [
        'title' => 'Custom CMS Architecture — Development from Scratch | Norway & Europe',
        'desc' => 'Custom CMS systems by Ruslan Bilohash.',
        'h1' => 'Custom CMS Architecture'
    ],
    'no' => [
        'title' => 'Tilpasset CMS-arkitektur — utvikling fra bunnen | Norge og Europa',
        'desc' => 'Tilpassede CMS-systemer fra Ruslan Bilohash.',
        'h1' => 'Tilpasset CMS-arkitektur'
    ]
];
?>

<!DOCTYPE html>
<html lang="<?= $lang === 'ua' ? 'uk' : $lang ?>" itemscope itemtype="https://schema.org/Article">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($t[$lang]['title']) ?></title>
    <meta name="description" content="<?= htmlspecialchars($t[$lang]['desc']) ?>">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_url) ?>">

    <!-- Hreflang -->
    <link rel="alternate" hreflang="uk" href="<?= $base_url ?>/website/news/custom-cms.php?lang=ua">
    <link rel="alternate" hreflang="ru" href="<?= $base_url ?>/website/news/custom-cms.php?lang=ru">
    <link rel="alternate" hreflang="en" href="<?= $base_url ?>/website/news/custom-cms.php?lang=en">
    <link rel="alternate" hreflang="nb" href="<?= $base_url ?>/website/news/custom-cms.php?lang=no">
    <link rel="alternate" hreflang="x-default" href="<?= $base_url ?>/website/news/custom-cms.php">

    <meta property="og:title" content="<?= htmlspecialchars($t[$lang]['title']) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($t[$lang]['desc']) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_url) ?>">
    <meta property="og:image" content="https://bilohash.com/ruslan_cub.jpg">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <?php include __DIR__ . '/../includes/portfolio-footer-css.php'; ?>
</head>
<body class="bg-slate-950 text-slate-200">

<!-- === ШАПКА (як у about.php) === -->
<nav class="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/95 backdrop-blur-xl">
    <div class="max-w-screen-2xl mx-auto px-6 md:px-10 h-16 flex items-center justify-between">
        <a href="/" class="flex items-center gap-x-3 group">
            <div class="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-400 to-teal-400 flex items-center justify-center">
                <span class="text-slate-950 font-bold text-sm">BH</span>
            </div>
            <div class="font-semibold text-lg tracking-tight group-hover:text-cyan-400 transition-colors">BILOHASH.com</div>
        </a>

        <div class="hidden md:flex items-center gap-x-8 text-sm">
            <a href="/website/" class="nav-link text-slate-300 hover:text-white">Послуги</a>
            <a href="/website/news/" class="nav-link text-slate-300 hover:text-white">Новини</a>
        </div>

        <div class="flex items-center gap-x-3">
            <div class="hidden sm:flex items-center bg-slate-900 border border-slate-800 rounded-full p-1 text-xs font-medium">
                <a href="?lang=ua" class="lang-btn px-3 py-1 rounded-full <?= $lang === 'ua' ? 'active bg-slate-800 border border-cyan-400/30' : 'hover:bg-slate-800 text-slate-400' ?>">UA</a>
                <a href="?lang=no" class="lang-btn px-3 py-1 rounded-full <?= $lang === 'no' ? 'active bg-slate-800 border border-cyan-400/30' : 'hover:bg-slate-800 text-slate-400' ?>">NO</a>
                <a href="?lang=en" class="lang-btn px-3 py-1 rounded-full <?= $lang === 'en' ? 'active bg-slate-800 border border-cyan-400/30' : 'hover:bg-slate-800 text-slate-400' ?>">EN</a>
                <a href="?lang=ru" class="lang-btn px-3 py-1 rounded-full <?= $lang === 'ru' ? 'active bg-slate-800 border border-cyan-400/30' : 'hover:bg-slate-800 text-slate-400' ?>">RU</a>
            </div>
        </div>
    </div>
</nav>

<div class="max-w-screen-2xl mx-auto px-6 md:px-10 py-16">
    <h1 class="text-5xl md:text-6xl font-bold leading-tight"><?= htmlspecialchars($t[$lang]['h1']) ?></h1>
    <p class="text-2xl text-cyan-400 mt-6 max-w-3xl"><?= htmlspecialchars($t[$lang]['desc']) ?></p>

    <div class="mt-12 grid md:grid-cols-2 gap-10">
        <div>
            <h2 class="text-2xl font-semibold mb-6">Чому бізнес у Норвегії обирає кастомну CMS?</h2>
            <ul class="space-y-4 text-lg">
                <li>✅ Повна відповідність норвезьким стандартам (GDPR, Altinn, etc.)</li>
                <li>✅ Швидка робота навіть при великій кількості користувачів</li>
                <li>✅ Легке інтегрування з lokalbank, Vipps, PowerOffice</li>
                <li>✅ Багатомовність (норвезька + англійська + інші)</li>
                <li>✅ Масштабування під зростання компанії</li>
            </ul>
        </div>
        <div>
            <h2 class="text-2xl font-semibold mb-6">Що ви отримуєте</h2>
            <p class="text-slate-400 leading-relaxed">
                Індивідуальну систему управління контентом, яка працює швидше за WordPress, безпечніша за Shopify і повністю під ваші бізнес-процеси.
            </p>
            <a href="#contact" class="mt-8 inline-block bg-cyan-400 text-slate-950 font-semibold px-10 py-4 rounded-2xl text-lg">
                Отримати консультацію та кошторис
            </a>
        </div>
    </div>

<div class="max-w-4xl mx-auto px-6 pb-20 prose prose-invert">
    <p>Детальний текст про кастомну CMS...</p>

    <!-- Посилання на інші проєкти -->
    <div class="my-12">
        <h3 class="text-xl font-semibold mb-4">Інші наші рішення:</h3>
        <a href="/website/news/ai-chatbots.php" class="text-cyan-400 hover:underline block mb-2">→ AI-чатботи та асистенти</a>
        <a href="/website/news/booking-platforms.php" class="text-cyan-400 hover:underline block mb-2">→ Платформи бронювання</a>
    </div>
</div>

<!-- === ФУТЕР === -->
<?php 
$footer_home = '/';
require __DIR__ . '/../includes/portfolio-footer-i18n.php';
include __DIR__ . '/../includes/portfolio-footer.php'; 
?>

<?php
$gdpr_lang = $lang === 'ua' ? 'uk' : ($lang === 'no' ? 'no' : ($lang === 'ru' ? 'ru' : 'en'));
include __DIR__ . '/../includes/gdpr-consent.php';
?>
</body>
</html>