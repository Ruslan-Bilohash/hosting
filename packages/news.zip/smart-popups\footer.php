<!-- Footer -->
<footer class="bg-slate-900 text-slate-300 pt-16 pb-8">
    <div class="max-w-screen-xl mx-auto px-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-x-8 gap-y-12">
            <div>
                <div class="flex items-center gap-x-3 mb-4">
                    <div class="w-9 h-9 bg-violet-500 rounded-2xl flex items-center justify-center">
                        <i class="fa-solid fa-window-restore text-white"></i>
                    </div>
                    <span class="font-display text-2xl font-semibold text-white tracking-tighter">Smart Popups</span>
                </div>
                <p class="text-sm max-w-[220px]"><?php echo t('professional_popups'); ?></p>
                <div class="mt-6 flex gap-x-4 text-xl">
                    <a href="https://github.com/Ruslan-Bilohash/smart-popups" class="hover:text-white transition-colors"><i class="fa-brands fa-github"></i></a>
                    <a href="https://bilohash.com" class="hover:text-white transition-colors"><i class="fa-solid fa-globe"></i></a>
                </div>
            </div>
            
            <div>
                <div class="font-semibold text-white mb-4 text-sm tracking-wider"><?php echo t('resources'); ?></div>
                <div class="space-y-2.5 text-sm">
                    <a href="instruction.php" class="block hover:text-white transition-colors"><?php echo t('documentation'); ?></a>
                    <a href="wordpress.php" class="block hover:text-white transition-colors">WordPress Integration</a>
                    <a href="changelog.php" class="block hover:text-white transition-colors"><?php echo t('changelog'); ?></a>
                    <a href="feedback.php" class="block hover:text-white transition-colors"><?php echo t('developer'); ?></a>
                    <a href="limitations.php" class="block hover:text-white transition-colors text-amber-400"><?php echo t('limitations_title'); ?></a>
                </div>
            </div>
            
            <div>
                <div class="font-semibold text-white mb-4 text-sm tracking-wider"><?php echo t('legal'); ?></div>
                <div class="space-y-2.5 text-sm">
                    <a href="privacy.php" class="block hover:text-white transition-colors"><?php echo t('privacy'); ?></a>
                    <a href="terms.php" class="block hover:text-white transition-colors"><?php echo t('terms'); ?></a>
                    <a href="cookie-settings.php" class="block hover:text-white transition-colors"><?php echo t('cookie_settings'); ?></a>
                    <a href="https://bilohash.com/donate.php" class="block hover:text-white transition-colors"><?php echo t('donate'); ?></a>
                </div>
            </div>
            
            <div>
                <div class="font-semibold text-white mb-4 text-sm tracking-wider"><?php echo t('developer'); ?></div>
                <div class="space-y-[9px] text-sm">
                    <a href="feedback.php" class="block hover:text-white transition-colors"><?php echo t('developer'); ?> (form)</a>
                    <a href="mailto:email@bilohash.com" class="block hover:text-white transition-colors text-xs opacity-75">email@bilohash.com</a>
                    <a href="https://github.com/Ruslan-Bilohash/smart-popups/issues" target="_blank" class="block hover:text-white transition-colors text-xs opacity-75">GitHub Issues</a>
                    <a href="https://bilohash.com" target="_blank" class="block hover:text-white transition-colors">bilohash.com</a>
                    <a href="https://github.com/Ruslan-Bilohash/smart-popups" target="_blank" class="block hover:text-white transition-colors">GitHub</a>
                </div>
            </div>
        </div>
        
        <div class="mt-16 pt-8 border-t border-white/10 text-xs flex flex-col md:flex-row gap-y-3 items-center justify-between text-slate-400">
            <div>&copy; <?php echo date('Y'); ?> BILOHASH. <?php echo t('footer_all_rights'); ?></div>
            <div class="flex gap-x-5">
                <a href="privacy.php" class="hover:text-white"><?php echo t('privacy'); ?></a>
                <a href="terms.php" class="hover:text-white"><?php echo t('terms'); ?></a>
            </div>
        </div>
    </div>
</footer>

<!-- Cookie Consent Banner (for best SEO / compliance) -->
<div id="cookie-banner" class="hidden fixed bottom-0 inset-x-0 z-[200] bg-white/95 backdrop-blur border-t shadow-xl">
    <div class="max-w-screen-xl mx-auto px-6 py-4">
        <div class="flex flex-col md:flex-row md:items-center gap-4 text-sm">
            <div class="flex-1 text-slate-700">
                <?php echo t('cookie_banner_text'); ?> 
                <a href="cookie-settings.php" class="underline hover:no-underline"><?php echo t('cookie_settings'); ?></a>
            </div>
            <div class="flex items-center gap-x-2 flex-shrink-0">
                <button onclick="acceptCookies()" class="px-5 py-2 bg-violet-600 hover:bg-violet-700 text-white text-sm font-semibold rounded-3xl"><?php echo t('accept_all'); ?></button>
                <button onclick="rejectCookies()" class="px-5 py-2 border border-slate-300 hover:bg-slate-50 rounded-3xl text-sm"><?php echo t('reject'); ?></button>
                <button onclick="window.location.href='cookie-settings.php'" class="px-4 py-2 text-sm text-violet-600 hover:underline"><?php echo t('cookie_settings'); ?></button>
            </div>
        </div>
    </div>
</div>

<script>
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }
    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + (days*24*60*60*1000));
        document.cookie = name + "=" + value + ";path=/;expires=" + d.toUTCString();
    }
    function showCookieBanner() {
        const banner = document.getElementById('cookie-banner');
        if (banner && !getCookie('cookie_consent')) {
            banner.classList.remove('hidden');
        }
    }
    function acceptCookies() {
        setCookie('cookie_consent', 'accepted', 365);
        const b = document.getElementById('cookie-banner');
        if (b) b.classList.add('hidden');
    }
    function rejectCookies() {
        setCookie('cookie_consent', 'rejected', 365);
        const b = document.getElementById('cookie-banner');
        if (b) b.classList.add('hidden');
    }
    // Show banner if needed
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', showCookieBanner);
    } else {
        showCookieBanner();
    }
    console.log('%c[Smart Popups Site] Fully responsive multilingual landing page ready with cookie language persistence.', 'color:#64748b');
</script>
</body>
</html>
