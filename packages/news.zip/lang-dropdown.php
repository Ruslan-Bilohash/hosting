<?php
/**
 * News language switcher — native <select> (works without JS).
 */
if (!function_exists('news_lang_url')) {
    function news_lang_url(string $code): string
    {
        if (function_exists('portfolio_seo_lang_url')) {
            return portfolio_seo_lang_url($code, '/news/');
        }
        $code = function_exists('portfolio_seo_normalize_lang')
            ? portfolio_seo_normalize_lang($code)
            : $code;
        if ($code === 'en') {
            return '/news/';
        }
        return '/news/?lang=' . rawurlencode($code);
    }

    function news_lang_options(): array
    {
        if (function_exists('portfolio_seo_regions')) {
            $out = [];
            foreach (portfolio_seo_regions() as $code => $info) {
                $out[$code] = [
                    'flag'  => $info['flag'],
                    'label' => $info['label'],
                    'name'  => $info['name'],
                ];
            }
            return $out;
        }
        return [
            'en' => ['flag' => '🇬🇧', 'label' => 'EN', 'name' => 'English (UK)'],
            'no' => ['flag' => '🇳🇴', 'label' => 'NO', 'name' => 'Norsk'],
            'ua' => ['flag' => '🇺🇦', 'label' => 'UA', 'name' => 'Українська'],
        ];
    }
}

$bh_lang_dropdown_id = $bh_lang_dropdown_id ?? 'bhLang';
$bh_lang_dropdown_variant = $bh_lang_dropdown_variant ?? '';
$available_langs = news_lang_options();
$current_lang = $available_langs[$lang] ?? $available_langs['en'];
$lang_menu_labels = [
    'en' => 'Language', 'no' => 'Språk', 'lt' => 'Kalba', 'pl' => 'Język',
    'de' => 'Sprache', 'sv' => 'Språk', 'ua' => 'Мова',
];
$lang_menu_label = $lang_menu_labels[$lang] ?? $lang_menu_labels['en'];
$wrap_classes = 'bh-lang-select-wrap';
if ($bh_lang_dropdown_variant === 'footer') {
    $wrap_classes .= ' bh-lang-select-wrap--footer';
}
$select_id = $bh_lang_dropdown_id . 'Select';
?>
<div class="<?= $wrap_classes ?>" id="<?= htmlspecialchars($bh_lang_dropdown_id) ?>Wrap">
    <label class="bh-lang-select-label" for="<?= htmlspecialchars($select_id) ?>">
        <span class="bh-lang-select-icon" aria-hidden="true"><i class="fas fa-globe"></i></span>
        <select id="<?= htmlspecialchars($select_id) ?>"
                class="bh-lang-select"
                aria-label="<?= htmlspecialchars($lang_menu_label) ?>"
                autocomplete="off"
                onchange="if(this.value){window.location.href=this.value;}">
            <?php foreach ($available_langs as $code => $info): ?>
            <option value="<?= htmlspecialchars(news_lang_url($code)) ?>"
                    <?= $lang === $code ? 'selected' : '' ?>>
                <?= $info['flag'] ?> <?= htmlspecialchars($info['name']) ?>
            </option>
            <?php endforeach; ?>
        </select>
        <span class="bh-lang-select-chevron" aria-hidden="true"><i class="fas fa-chevron-down"></i></span>
    </label>
</div>