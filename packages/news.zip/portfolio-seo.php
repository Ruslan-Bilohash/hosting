<?php
/**
 * Portfolio SEO — UK, Norway, Lithuania, Poland, Germany, Sweden, Ukraine.
 *
 * @package Bilohash
 */

if (!function_exists('portfolio_seo_regions')) {
    /**
     * @return array<string, array<string, string>>
     */
    function portfolio_seo_regions(): array
    {
        return [
            'en' => [
                'hreflang'   => 'en-GB',
                'html_lang'  => 'en',
                'locale'     => 'en_GB',
                'og_locale'  => 'en_GB',
                'country'    => 'United Kingdom',
                'country_en' => 'United Kingdom',
                'geo_region' => 'GB',
                'flag'       => '🇬🇧',
                'label'      => 'EN',
                'name'       => 'English (UK)',
            ],
            'no' => [
                'hreflang'   => 'nb-NO',
                'html_lang'  => 'no',
                'locale'     => 'nb_NO',
                'og_locale'  => 'nb_NO',
                'country'    => 'Norway',
                'country_en' => 'Norway',
                'geo_region' => 'NO-06',
                'flag'       => '🇳🇴',
                'label'      => 'NO',
                'name'       => 'Norsk',
            ],
            'lt' => [
                'hreflang'   => 'lt-LT',
                'html_lang'  => 'lt',
                'locale'     => 'lt_LT',
                'og_locale'  => 'lt_LT',
                'country'    => 'Lithuania',
                'country_en' => 'Lithuania',
                'geo_region' => 'LT',
                'flag'       => '🇱🇹',
                'label'      => 'LT',
                'name'       => 'Lietuvių',
            ],
            'pl' => [
                'hreflang'   => 'pl-PL',
                'html_lang'  => 'pl',
                'locale'     => 'pl_PL',
                'og_locale'  => 'pl_PL',
                'country'    => 'Poland',
                'country_en' => 'Poland',
                'geo_region' => 'PL',
                'flag'       => '🇵🇱',
                'label'      => 'PL',
                'name'       => 'Polski',
            ],
            'de' => [
                'hreflang'   => 'de-DE',
                'html_lang'  => 'de',
                'locale'     => 'de_DE',
                'og_locale'  => 'de_DE',
                'country'    => 'Germany',
                'country_en' => 'Germany',
                'geo_region' => 'DE',
                'flag'       => '🇩🇪',
                'label'      => 'DE',
                'name'       => 'Deutsch',
            ],
            'sv' => [
                'hreflang'   => 'sv-SE',
                'html_lang'  => 'sv',
                'locale'     => 'sv_SE',
                'og_locale'  => 'sv_SE',
                'country'    => 'Sweden',
                'country_en' => 'Sweden',
                'geo_region' => 'SE',
                'flag'       => '🇸🇪',
                'label'      => 'SV',
                'name'       => 'Svenska',
            ],
            'ua' => [
                'hreflang'   => 'uk-UA',
                'html_lang'  => 'uk',
                'locale'     => 'uk_UA',
                'og_locale'  => 'uk_UA',
                'country'    => 'Ukraine',
                'country_en' => 'Ukraine',
                'geo_region' => 'UA',
                'flag'       => '🇺🇦',
                'label'      => 'UA',
                'name'       => 'Українська',
            ],
        ];
    }
}

if (!function_exists('portfolio_seo_default_lang')) {
    function portfolio_seo_default_lang(): string
    {
        return 'en';
    }
}

if (!function_exists('portfolio_seo_normalize_lang')) {
    function portfolio_seo_normalize_lang(?string $raw): string
    {
        $raw = strtolower(trim((string) $raw));
        $map = [
            'uk' => 'ua',
            'nb' => 'no',
            'en-gb' => 'en',
            'en_gb' => 'en',
            'ru' => 'en',
        ];
        if (isset($map[$raw])) {
            $raw = $map[$raw];
        }
        $regions = portfolio_seo_regions();
        return isset($regions[$raw]) ? $raw : portfolio_seo_default_lang();
    }
}

if (!function_exists('portfolio_seo_base_url')) {
    function portfolio_seo_base_url(): string
    {
        $protocol = (
            (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443)
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        ) ? 'https' : 'http';
        return $protocol . '://' . ($_SERVER['HTTP_HOST'] ?? 'bilohash.com');
    }
}

if (!function_exists('portfolio_seo_lang_url')) {
    function portfolio_seo_lang_url(string $code, ?string $path = null): string
    {
        $code = portfolio_seo_normalize_lang($code);
        $path = $path ?? (strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/');
        $path = '/' . ltrim($path, '/');
        if ($code === portfolio_seo_default_lang()) {
            return rtrim(portfolio_seo_base_url(), '/') . $path;
        }
        $sep = str_contains($path, '?') ? '&' : '?';
        return rtrim(portfolio_seo_base_url(), '/') . $path . $sep . 'lang=' . rawurlencode($code);
    }
}

if (!function_exists('portfolio_seo_pick')) {
    /**
     * @param array<string, string> $strings
     */
    function portfolio_seo_pick(array $strings, string $lang): string
    {
        $lang = portfolio_seo_normalize_lang($lang);
        if (!empty($strings[$lang])) {
            return (string) $strings[$lang];
        }
        return (string) ($strings['en'] ?? reset($strings) ?: '');
    }
}

if (!function_exists('portfolio_seo_render_head')) {
    /**
     * @param array<string, mixed> $args
     */
    function portfolio_seo_render_head(array $args): void
    {
        $lang = portfolio_seo_normalize_lang($args['lang'] ?? 'en');
        $region = portfolio_seo_regions()[$lang];
        $title = (string) ($args['title'] ?? 'BILOHASH');
        $description = (string) ($args['description'] ?? '');
        $canonical = (string) ($args['canonical'] ?? portfolio_seo_lang_url($lang));
        $path = (string) ($args['path'] ?? strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/');
        $og_image = (string) ($args['og_image'] ?? (portfolio_seo_base_url() . '/favicon.ico'));
        $og_type = (string) ($args['og_type'] ?? 'website');
        $robots = (string) ($args['robots'] ?? 'index, follow, max-image-preview:large, max-snippet:-1');
        $keywords = (string) ($args['keywords'] ?? '');
        $schema = $args['schema'] ?? null;
        $twitter_site = (string) ($args['twitter_site'] ?? '@bilohash');
        $areas = array_map(static function (array $r): string {
            return $r['country'];
        }, portfolio_seo_regions());

        echo '<title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "</title>\n";
        echo '<meta name="description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . "\">\n";
        if ($keywords !== '') {
            echo '<meta name="keywords" content="' . htmlspecialchars($keywords, ENT_QUOTES, 'UTF-8') . "\">\n";
        }
        echo '<meta name="author" content="Ruslan Bilohash / BILOHASH">' . "\n";
        echo '<meta name="robots" content="' . htmlspecialchars($robots, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta name="geo.region" content="NO">' . "\n";
        echo '<meta name="geo.placename" content="Drammen, Norway">' . "\n";
        echo '<link rel="canonical" href="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . "\">\n";

        foreach (portfolio_seo_regions() as $code => $info) {
            echo '<link rel="alternate" hreflang="' . htmlspecialchars($info['hreflang'], ENT_QUOTES, 'UTF-8')
                . '" href="' . htmlspecialchars(portfolio_seo_lang_url($code, $path), ENT_QUOTES, 'UTF-8') . "\">\n";
        }
        echo '<link rel="alternate" hreflang="x-default" href="' . htmlspecialchars(portfolio_seo_lang_url('en', $path), ENT_QUOTES, 'UTF-8') . "\">\n";

        echo '<meta property="og:type" content="' . htmlspecialchars($og_type, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta property="og:title" content="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta property="og:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta property="og:url" content="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta property="og:site_name" content="BILOHASH">' . "\n";
        echo '<meta property="og:image" content="' . htmlspecialchars($og_image, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta property="og:locale" content="' . htmlspecialchars($region['og_locale'], ENT_QUOTES, 'UTF-8') . "\">\n";
        foreach (portfolio_seo_regions() as $code => $info) {
            if ($code === $lang) {
                continue;
            }
            echo '<meta property="og:locale:alternate" content="' . htmlspecialchars($info['og_locale'], ENT_QUOTES, 'UTF-8') . "\">\n";
        }

        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:site" content="' . htmlspecialchars($twitter_site, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta name="twitter:title" content="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta name="twitter:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta name="twitter:image" content="' . htmlspecialchars($og_image, ENT_QUOTES, 'UTF-8') . "\">\n";
        echo '<meta name="theme-color" content="#22d3ee">' . "\n";

        if ($schema === null) {
            $schema = [
                '@context' => 'https://schema.org',
                '@graph' => [
                    [
                        '@type' => 'Organization',
                        '@id' => portfolio_seo_base_url() . '/#organization',
                        'name' => 'BILOHASH',
                        'url' => portfolio_seo_base_url() . '/',
                        'logo' => portfolio_seo_base_url() . '/favicon.ico',
                        'email' => 'rbilohash@gmail.com',
                        'areaServed' => $areas,
                        'knowsLanguage' => array_values(array_map(static function (array $r): string {
                            return $r['hreflang'];
                        }, portfolio_seo_regions())),
                    ],
                    [
                        '@type' => 'WebSite',
                        '@id' => portfolio_seo_base_url() . '/#website',
                        'name' => 'BILOHASH',
                        'url' => portfolio_seo_base_url() . '/',
                        'publisher' => ['@id' => portfolio_seo_base_url() . '/#organization'],
                        'inLanguage' => array_values(array_map(static function (array $r): string {
                            return $r['hreflang'];
                        }, portfolio_seo_regions())),
                    ],
                    [
                        '@type' => 'WebPage',
                        '@id' => $canonical . '#webpage',
                        'url' => $canonical,
                        'name' => $title,
                        'description' => $description,
                        'isPartOf' => ['@id' => portfolio_seo_base_url() . '/#website'],
                        'inLanguage' => $region['hreflang'],
                    ],
                ],
            ];
        }

        echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
    }
}