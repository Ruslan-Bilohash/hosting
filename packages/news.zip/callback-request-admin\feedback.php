<?php
require_once __DIR__ . '/lang/lang.php';
$page_title = t('feedback_title');
$page_description = t('meta_description_feedback');
$page_keywords = t('meta_keywords_feedback');
include 'header.php';

// === PHPMailer from domain root ===
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/src/Exception.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/src/PHPMailer.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// === НАЛАШТУВАННЯ ===
$to_email = "rbilohash@gmail.com";
$site_name = "BILOHASH";
$from_email = "email@bilohash.com";

// SMTP (from user)
$smtpHost      = "smtp.hostinger.com";
$smtpPort      = 465;
$smtpUsername  = "email@bilohash.com";
$smtpPassword  = "Odifarka78@";
$smtpSecure    = "ssl";

// Google reCAPTCHA v2 (use your keys)
$recaptcha_site_key   = '6LdEdcosAAAAAD80bEr40Jhk2pquDQyUApONukMj';
$recaptcha_secret_key = '6LdEdcosAAAAAIgVKDlLXrD08v5m8hYn-KiXHMz2';
$recaptcha_enabled = true;

$lang = isset($_GET['lang']) ? strtolower($_GET['lang']) : 'ua';

$texts = $texts ?? [
    'ua' => [
        'title' => 'Зворотній зв\'язок',
        'name' => 'Ваше ім\'я',
        'email' => 'Ваш Email',
        'subject' => 'Тема повідомлення',
        'message' => 'Ваше повідомлення',
        'submit' => 'Надіслати повідомлення',
        'success' => '✅ Дякуємо! Ваше повідомлення успішно надіслано.',
        'error' => '❌ Помилка. Перевірте всі поля.',
        'recaptcha_error' => '❌ Перевірку reCAPTCHA не пройдено. Спробуйте ще раз.'
    ],
    'en' => [
        'title' => 'Contact Form',
        'name' => 'Your Name',
        'email' => 'Your Email',
        'subject' => 'Subject',
        'message' => 'Your Message',
        'submit' => 'Send Message',
        'success' => '✅ Thank you! Your message has been sent.',
        'error' => '❌ Error. Please check all fields.',
        'recaptcha_error' => '❌ reCAPTCHA verification failed. Try again.'
    ],
    'no' => [
        'title' => 'Kontaktskjema',
        'name' => 'Ditt navn',
        'email' => 'Din e-post',
        'subject' => 'Emne',
        'message' => 'Din melding',
        'submit' => 'Send melding',
        'success' => '✅ Takk! Meldingen din er sendt.',
        'error' => '❌ Feil. Sjekk alle feltene.',
        'recaptcha_error' => '❌ reCAPTCHA-sjekk mislyktes. Prøv igjen.'
    ]
];

$t = $texts[$lang] ?? $texts['ua'];

// CSRF + HONEYPOT
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$status = '';
$name = $email = $subject = $message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $status = '<div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm mb-4">❌ Security error. Please refresh and try again.</div>';
    } elseif (!empty($_POST['website'])) {
        $status = '<div class="p-4 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl text-sm mb-4">' . $t['success'] . '</div>';
    } else {
        $name    = trim(strip_tags($_POST['name'] ?? ''));
        $email   = trim($_POST['email'] ?? '');
        $subject = trim(strip_tags($_POST['subject'] ?? ''));
        $message = trim($_POST['message'] ?? '');

        $captcha_valid = true;
        if ($recaptcha_enabled) {
            $recaptcha_response = $_POST['g-recaptcha-response'] ?? '';
            if (empty($recaptcha_response)) {
                $captcha_valid = false;
            } else {
                $url = 'https://www.google.com/recaptcha/api/siteverify';
                $data = [
                    'secret'   => $recaptcha_secret_key,
                    'response' => $recaptcha_response,
                    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
                ];
                $options = ['http' => ['header' => "Content-type: application/x-www-form-urlencoded\r\n", 'method' => 'POST', 'content' => http_build_query($data)]];
                $context = stream_context_create($options);
                $verify = @file_get_contents($url, false, $context);
                if ($verify === false) {
                    $captcha_valid = false;
                } else {
                    $captcha_success = json_decode($verify);
                    $captcha_valid = isset($captcha_success->success) && $captcha_success->success === true;
                }
            }
        }

        if (!$captcha_valid) {
            $status = '<div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm mb-4">' . $t['recaptcha_error'] . '</div>';
        } elseif (empty($name) || empty($email) || empty($subject) || empty($message)) {
            $status = '<div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm mb-4">' . $t['error'] . '</div>';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $status = '<div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm mb-4">❌ Invalid email format.</div>';
        } elseif (strlen($message) < 20 || strlen($message) > 5000) {
            $status = '<div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm mb-4">❌ Message must be 20-5000 characters.</div>';
        } else {
            $lang_title = match($lang) {
                'en' => 'New message from the site',
                'no' => 'Ny melding fra nettstedet',
                default => 'Нове повідомлення з сайту'
            };

            $html_body = '
            <!DOCTYPE html>
            <html>
            <head><meta charset="utf-8"><title>' . $lang_title . '</title></head>
            <body style="font-family: system-ui, Arial, sans-serif; background:#f4f7fa; padding:30px;">
                <div style="max-width:600px; margin:0 auto; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,0.1);">
                    <div style="background:linear-gradient(135deg, #0056b3, #0077cc); color:#fff; padding:25px; text-align:center;">
                        <h1 style="margin:0; font-size:28px;">📩 ' . $lang_title . '</h1>
                        <p style="margin:8px 0 0; opacity:0.9;">from ' . htmlspecialchars($site_name) . '</p>
                    </div>
                    <div style="padding:30px; color:#333; line-height:1.7;">
                        <p><strong>Name:</strong> ' . htmlspecialchars($name) . '</p>
                        <p><strong>Email:</strong> <a href="mailto:' . htmlspecialchars($email) . '">' . htmlspecialchars($email) . '</a></p>
                        <p><strong>Subject:</strong> ' . htmlspecialchars($subject) . '</p>
                        <hr style="border:none; border-top:1px solid #eee; margin:20px 0;">
                        <p style="white-space:pre-wrap;">' . nl2br(htmlspecialchars($message)) . '</p>
                    </div>
                    <div style="background:#f8f9fa; padding:20px; text-align:center; font-size:12px; color:#666;">
                        Sent: ' . date('d.m.Y H:i:s') . ' | BILOHASH
                    </div>
                </div>
            </body>
            </html>';

            $mail_subject = "[$site_name] " . $subject;

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = $smtpHost;
                $mail->SMTPAuth   = true;
                $mail->Username   = $smtpUsername;
                $mail->Password   = $smtpPassword;
                $mail->SMTPSecure = $smtpSecure;
                $mail->Port       = $smtpPort;

                $mail->setFrom($from_email, $site_name);
                $mail->addAddress($to_email);
                $mail->addReplyTo($email, $name);
                $mail->isHTML(true);
                $mail->Subject = $mail_subject;
                $mail->Body = $html_body;
                $mail->send();

                $status = '<div class="p-4 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl text-sm mb-4">' . $t['success'] . '</div>';
                $name = $email = $subject = $message = '';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } catch (Exception $e) {
                error_log("PHPMailer Error: " . $mail->ErrorInfo);
                $status = '<div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm mb-4">❌ Send error. Try later or email directly to rbilohash@gmail.com</div>';
            }
        }
    }
}
?>
<div class="max-w-screen-xl mx-auto px-6 py-14">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-3xl font-semibold tracking-tighter mb-2"><?php echo $t['title']; ?></h1>
        <p class="text-slate-600 mb-8">Write to me — I'll reply as soon as possible.</p>

        <?php echo $status; ?>

        <form method="POST" autocomplete="off" novalidate class="bg-white border rounded-3xl p-8 space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <input type="text" name="website" class="hidden" autocomplete="off" tabindex="-1">

            <div>
                <label class="block text-sm font-medium mb-1"><?php echo $t['name']; ?></label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required class="w-full border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
            </div>

            <div>
                <label class="block text-sm font-medium mb-1"><?php echo $t['email']; ?></label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required class="w-full border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
            </div>

            <div>
                <label class="block text-sm font-medium mb-1"><?php echo $t['subject']; ?></label>
                <input type="text" name="subject" value="<?php echo htmlspecialchars($subject); ?>" required class="w-full border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500">
            </div>

            <div>
                <label class="block text-sm font-medium mb-1"><?php echo $t['message']; ?></label>
                <textarea name="message" required rows="6" class="w-full border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500"><?php echo htmlspecialchars($message); ?></textarea>
            </div>

            <?php if ($recaptcha_enabled): ?>
            <div>
                <div class="g-recaptcha" data-sitekey="<?php echo $recaptcha_site_key; ?>"></div>
            </div>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            <?php endif; ?>

            <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-3xl text-sm transition flex items-center justify-center gap-2">
                <i class="fas fa-paper-plane"></i> <?php echo $t['submit']; ?>
            </button>

            <p class="text-[10px] text-center text-slate-500">Your message goes directly to rbilohash@gmail.com. We respect your privacy.</p>
        </form>
    </div>
</div>
<?php include 'footer.php'; ?>