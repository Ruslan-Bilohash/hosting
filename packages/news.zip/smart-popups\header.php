<?php
require_once __DIR__ . '/lang/lang.php';
$current = get_current_lang();
?>
<!DOCTYPE html>
<html lang="<?php echo $current; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="<?php echo isset($page_keywords) ? htmlspecialchars($page_keywords) : t('meta_keywords'); ?>">
    <meta name="description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : t('meta_description'); ?>">
    <meta property="og:description" content="<?php echo isset($page_description) ? htmlspecialchars($page_description) : t('meta_description'); ?>">
    <meta property="og:title" content="<?php echo isset($page_title) ? htmlspecialchars($page_title) : t('site_title'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://bilohash.com/news/smart-popups/">
    <meta property="og:image" content="https://bilohash.com/news/smart-popups/screen/general.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) : t('site_title'); ?></title>

    <!-- Performance: preconnect to CDNs -->
    <link rel="preconnect" href="https://cdn.tailwindcss.com" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="dns-prefetch" href="https://cdn.tailwindcss.com">
    <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">

    <!-- Preload hero image for better LCP -->
    <link rel="preload" as="image" href="screen/general.jpg" fetchpriority="high">

    <!-- Preload Google Fonts -->
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Space+Grotesk:wght@500;600&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Space+Grotesk:wght@500;600&display=swap"></noscript>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" media="print" onload="this.media='all'">
    <style>
        body { font-family: 'Inter', system_ui, sans-serif; }
        .font-display { font-family: 'Space Grotesk', 'Inter', sans-serif; font-weight: 600; }

        .nav-link { transition: color 0.2s ease; }
        .nav-link:hover { color: #2563eb; }

        .section-title { font-size: 2.25rem; line-height: 2.5rem; font-weight: 700; letter-spacing: -0.03em; }
        @media (max-width: 768px) { .section-title { font-size: 1.875rem; line-height: 2.25rem; } }

        .screenshot { transition: transform 0.3s ease, box-shadow 0.3s ease; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1); }
        .screenshot:hover { transform: scale(1.02); box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1); }
        .screenshot img { display: block; width: 100%; height: auto; }

        .email-demo { box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25); border: 1px solid #e2e8f0; }

        .lang-dropdown { position: relative; }
        .lang-menu { display: none; position: absolute; right: 0; top: 100%; background: white; border: 1px solid #e5e7eb; border-radius: 12px; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1); z-index: 50; min-width: 180px; }
        .lang-dropdown:hover .lang-menu { display: block; }
        .lang-option { padding: 8px 12px; display: flex; align-items: center; gap: 8px; font-size: 13px; }
        .lang-option:hover { background: #f8fafc; }

        .nav-scrolled { box-shadow: 0 1px 0 0 #e2e8f0; background: rgba(255,255,255,0.98); backdrop-filter: blur(12px); }

        .popup-preview {
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-900">
    <!-- Header -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-50 transition-all" id="navbar">
        <div class="max-w-screen-xl mx-auto px-6">
            <div class="flex items-center justify-between h-16">
                <!-- Logo -->
                <div class="flex items-center gap-x-3">
                    <div class="w-9 h-9 bg-violet-600 rounded-2xl flex items-center justify-center shadow-inner">
                        <i class="fa-solid fa-window-restore text-white text-xl"></i>
                    </div>
                    <div>
                        <span class="font-display text-2xl font-semibold tracking-tighter">Smart</span>
                        <span class="font-display text-2xl font-semibold tracking-tighter text-violet-600">Popups</span>
                    </div>
                </div>

                <!-- Desktop Nav -->
                <nav class="hidden md:flex items-center gap-x-8 text-sm font-medium">
                    <a href="index.php#features" class="nav-link text-slate-600 hover:text-slate-900"><?php echo t('nav_features'); ?></a>
                    <a href="index.php#screenshots" class="nav-link text-slate-600 hover:text-slate-900"><?php echo t('nav_screenshots'); ?></a>
                    <a href="index.php#templates" class="nav-link text-slate-600 hover:text-slate-900"><?php echo t('nav_templates'); ?></a>
                    <a href="index.php#instructions" class="nav-link text-slate-600 hover:text-slate-900"><?php echo t('nav_instructions'); ?></a>
                    <a href="index.php#download" class="nav-link text-slate-600 hover:text-slate-900"><?php echo t('nav_download'); ?></a>
                </nav>

                <div class="flex items-center gap-x-3">
                    <!-- Language Dropdown with Flags (4 languages) -->
                    <div class="lang-dropdown relative">
                        <button class="flex items-center gap-x-2 px-3 py-1.5 text-sm font-medium bg-white border border-slate-300 rounded-3xl hover:bg-slate-50">
                            <span><?php echo get_lang_flag($current); ?> <?php echo get_lang_name($current); ?></span>
                            <i class="fa-solid fa-chevron-down text-xs"></i>
                        </button>
                        <div class="lang-menu rounded-2xl py-1 text-sm shadow-lg">
                            <?php 
                            $all_langs = ['en' => '🇬🇧 English', 'ru' => '🇷🇺 Русский', 'ua' => '🇺🇦 Українська', 'no' => '🇳🇴 Norsk'];
                            foreach ($all_langs as $code => $name) {
                                $flag = get_lang_flag($code);
                                echo "<a href=\"?lang=$code\" class=\"lang-option flex items-center gap-x-2 px-4 hover:bg-slate-100\">$flag $name</a>";
                            }
                            ?>
                        </div>
                    </div>

                    <a href="https://github.com/Ruslan-Bilohash/smart-popups" target="_blank" class="hidden md:flex items-center px-4 py-2 text-sm font-semibold rounded-3xl border border-slate-300 hover:bg-slate-50 transition-all">
                        <i class="fa-brands fa-github mr-2"></i>
                        <span>GitHub</span>
                    </a>

                    <a href="https://bilohash.com/donate.php" target="_blank" class="hidden md:flex items-center px-4 py-2 text-sm font-semibold rounded-3xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white hover:from-violet-700 hover:to-indigo-700 transition-all shadow-md">
                        <i class="fa-solid fa-heart mr-2"></i>
                        <span><?php echo t('donate'); ?></span>
                    </a>

                    <!-- Mobile menu -->
                    <button onclick="toggleMobileMenu()" class="md:hidden w-10 h-10 flex items-center justify-center text-slate-600 hover:text-slate-900">
                        <i class="fa-solid fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation -->
        <div id="mobile-menu" class="hidden md:hidden border-t bg-white">
            <div class="px-6 py-4 flex flex-col gap-y-1 text-sm">
                <a href="index.php#features" class="py-2.5 text-slate-600"><?php echo t('nav_features'); ?></a>
                <a href="index.php#screenshots" class="py-2.5 text-slate-600"><?php echo t('nav_screenshots'); ?></a>
                <a href="index.php#templates" class="py-2.5 text-slate-600"><?php echo t('nav_templates'); ?></a>
                <a href="index.php#instructions" class="py-2.5 text-slate-600"><?php echo t('nav_instructions'); ?></a>
                <a href="index.php#download" class="py-2.5 text-slate-600"><?php echo t('nav_download'); ?></a>
                
                <div class="pt-3 mt-2 border-t flex gap-x-2">
                    <a href="https://github.com/Ruslan-Bilohash/smart-popups" class="flex-1 text-center py-2.5 text-sm font-medium rounded-2xl border">GitHub</a>
                    <a href="https://bilohash.com/donate.php" class="flex-1 text-center py-2.5 text-sm font-semibold rounded-2xl bg-violet-600 text-white"><?php echo t('donate'); ?></a>
                </div>
            </div>
        </div>
    </header>

    <script>
        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        }
        
        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 20) {
                navbar.classList.add('nav-scrolled');
            } else {
                navbar.classList.remove('nav-scrolled');
            }
        });
        
        // Keyboard support
        document.addEventListener('keydown', function(e) {
            if (e.key === "/" && document.activeElement.tagName === "BODY") {
                e.preventDefault();
                const download = document.getElementById('download');
                if (download) download.scrollIntoView({ behavior: 'smooth' });
            }
        });
    </script>
