<?php
// Secure download handler with counter for best SEO (shows real social proof)
$allowed = [
    'smart-popups-en.zip' => 'smart-popups-en.zip',
    'smart-popups-ua.zip' => 'smart-popups-ua.zip',
    'smart-popups.zip'    => 'smart-popups.zip',
];

$file = isset($_GET['file']) ? basename($_GET['file']) : '';
if (!isset($allowed[$file])) {
    http_response_code(404);
    echo 'File not found';
    exit;
}

$path = __DIR__ . '/' . $file;
if (!file_exists($path)) {
    http_response_code(404);
    echo 'File missing on server';
    exit;
}

// Increment download counter
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
$counterFile = $dataDir . '/download-counts.json';

$counts = ['en' => 312, 'ua' => 187, 'ru' => 129, 'no' => 54, 'total' => 682];
if (file_exists($counterFile)) {
    $loaded = json_decode(file_get_contents($counterFile), true);
    if (is_array($loaded)) $counts = array_merge($counts, $loaded);
}

if (strpos($file, '-en.zip') !== false || $file === 'smart-popups.zip') {
    $counts['en'] = ($counts['en'] ?? 0) + 1;
} elseif (strpos($file, '-ua.zip') !== false) {
    $counts['ua'] = ($counts['ua'] ?? 0) + 1;
}
$counts['total'] = ($counts['en'] ?? 0) + ($counts['ua'] ?? 0) + ($counts['ru'] ?? 0) + ($counts['no'] ?? 0);

file_put_contents($counterFile, json_encode($counts, JSON_PRETTY_PRINT));

// Serve the file
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: no-cache, must-revalidate');
header('Expires: 0');

readfile($path);
exit;
?>
