<?php
header('Content-Type: text/html; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$bh_portfolio_seo_paths = [
    __DIR__ . '/../includes/portfolio-seo.php',
    __DIR__ . '/portfolio-seo.php',
];
foreach ($bh_portfolio_seo_paths as $bh_portfolio_seo_path) {
    if (is_file($bh_portfolio_seo_path)) {
        require_once $bh_portfolio_seo_path;
        break;
    }
}
if (!function_exists('portfolio_seo_normalize_lang')) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'BILOHASH news: missing portfolio-seo.php. Upload includes/portfolio-seo.php or news/portfolio-seo.php.';
    exit;
}

$lang = portfolio_seo_normalize_lang($_GET['lang'] ?? 'en');

if (!function_exists('news_txt')) {
    function news_txt(array $strings): string
    {
        return portfolio_seo_pick($strings, $GLOBALS['lang']);
    }
}

if (!function_exists('news_icon_class')) {
    function news_icon_class(string $icon): string
    {
        if (str_starts_with($icon, 'fab ') || str_starts_with($icon, 'fas ') || str_starts_with($icon, 'far ')) {
            return $icon;
        }
        return 'fas ' . $icon;
    }
}

require __DIR__ . '/i18n.php';

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https' : 'http';
$base_url = $protocol . '://' . $_SERVER['HTTP_HOST'];
$canonical_url = $base_url . '/news/' . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');

function news_shot(string $path): string
{
    global $base_url;
    if ($path === '' || str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return rtrim($base_url, '/') . (str_starts_with($path, '/') ? $path : '/' . $path);
}

$location = 'Drammen, Norway';
$phone = '+4746255885';
$email = 'rbilohash@gmail.com';

$og_titles = [
    'en' => 'BILOHASH News — WordPress & CMS Releases UK, Norway, Europe',
    'no' => 'BILOHASH Nyheter — WordPress og CMS-utgivelser Norge og Europa',
    'lt' => 'BILOHASH Naujienos — WordPress ir CMS sprendimai Lietuvai ir ES',
    'pl' => 'BILOHASH Aktualności — WordPress i CMS dla Polski i UE',
    'de' => 'BILOHASH News — WordPress & CMS Releases für Deutschland und EU',
    'sv' => 'BILOHASH Nyheter — WordPress och CMS-lanseringar Sverige och EU',
    'ua' => 'BILOHASH News — релізи WordPress і CMS для України та Європи',
];

$og_descriptions = [
    'en' => 'Official BILOHASH release hub for the UK, Norway, Lithuania, Poland, Germany, Sweden and Ukraine: CMS scripts, WordPress plugins, AI tools, live demos, admin panels and SEO-ready product pages.',
    'no' => 'Offisiell BILOHASH-utgivelseshub for Storbritannia, Norge, Litauen, Polen, Tyskland, Sverige og Ukraina: CMS-skript, WordPress-plugins, AI-verktøy, live demoer og SEO-klare produktsider.',
    'lt' => 'Oficialus BILOHASH naujienų centras JK, Norvegijai, Lietuvai, Lenkijai, Vokietijai, Švedijai ir Ukrainai: CMS skriptai, WordPress įskiepiai, AI įrankiai, live demo ir SEO puslapiai.',
    'pl' => 'Oficjalny hub wydań BILOHASH dla Wielkiej Brytanii, Norwegii, Litwy, Polski, Niemiec, Szwecji i Ukrainy: skrypty CMS, wtyczki WordPress, narzędzia AI, demo na żywo i strony SEO.',
    'de' => 'Offizielle BILOHASH-Release-Seite für UK, Norwegen, Litauen, Polen, Deutschland, Schweden und Ukraine: CMS-Skripte, WordPress-Plugins, KI-Tools, Live-Demos und SEO-Produktseiten.',
    'sv' => 'Officiell BILOHASH-nyhetshub för Storbritannien, Norge, Litauen, Polen, Tyskland, Sverige och Ukraina: CMS-skript, WordPress-plugins, AI-verktyg, live-demo och SEO-sidor.',
    'ua' => 'Офіційний хаб релізів BILOHASH для Великої Британії, Норвегії, Литви, Польщі, Німеччини, Швеції та України: CMS, WordPress-плагіни, AI, live demo та SEO-сторінки.',
];

$seo_keywords = [
    'en' => 'WordPress plugins UK, CMS Norway, PHP scripts Europe, Bilohash news, live demo, technical SEO',
    'no' => 'WordPress plugin Norge, CMS skript, PHP Europa, Bilohash nyheter, live demo, teknisk SEO',
    'lt' => 'WordPress įskiepiai Lietuva, CMS skriptai, PHP Europa, BILOHASH naujienos, SEO',
    'pl' => 'wtyczki WordPress Polska, skrypty CMS, PHP Europa, aktualności Bilohash, SEO',
    'de' => 'WordPress Plugins Deutschland, CMS Skripte, PHP Europa, Bilohash News, technisches SEO',
    'sv' => 'WordPress plugins Sverige, CMS skript, PHP Europa, Bilohash nyheter, teknisk SEO',
    'ua' => 'WordPress плагіни Україна, CMS скрипти, PHP Європа, новини Bilohash, технічне SEO',
];

$cms_products = [
    [
        'item_key' => 'hosting',
        'icon' => 'fa-server', 'tone' => 'cyan', 'badge' => 'NEW',
        'date' => '2026-07-10',
        'title' => ['en' => 'Hosting CMS v2.7.0', 'no' => 'Hosting CMS v2.7.0', 'lt' => 'Hosting CMS v2.7.0', 'ua' => 'Hosting CMS v2.7.0', 'ru' => 'Hosting CMS v2.7.0'],
        'desc' => [
            'en' => 'v2.7.0 — hPanel-grade PHP panel with 40+ tools, MySQL 2.0, 15 ecosystem planets installer, malware scanner (severity badges), BILOHASH Webmail (IMAP/SMTP), 60 WebP screenshots and 30-day FREE demo license. Live on bilohash.com.',
            'no' => 'v2.7.0 — PHP-panel på hPanel-nivå med 40+ verktøy, MySQL 2.0, 15 økosystem-planeter, malware-skanner, BILOHASH Webmail (IMAP/SMTP), 60 WebP-skjermbilder og 30 dagers GRATIS demo. Live på bilohash.com.',
            'lt' => 'v2.7.0 — hPanel lygio PHP panelė: 40+ įrankių, MySQL 2.0, 15 ekosistemos planetų, malware skeneris, BILOHASH Webmail, 60 WebP ekrano nuotraukų ir 30 dienų NEMOKAMA demo licencija.',
            'ua' => 'v2.7.0 — PHP-панель рівня hPanel: 40+ інструментів, MySQL 2.0, 15 планет екосистеми, сканер malware, BILOHASH Webmail (IMAP/SMTP), 60 WebP-скриншотів і **30-денна безкоштовна demo-ліцензія**. Live на bilohash.com.',
            'ru' => 'v2.7.0 — PHP-панель уровня hPanel: 40+ инструментов, MySQL 2.0, 15 планет экосистемы, сканер malware, BILOHASH Webmail, 60 WebP-скриншотов и 30-дневная бесплатная demo-лицензия.',
        ],
        'demo' => 'https://bilohash.com/hosting/',
        'admin_url' => 'https://bilohash.com/hosting/login.php',
        'admin_cred' => 'demo / demo',
        'site_url' => 'https://webmail.bilohash.com/',
        'release_url' => '/news/hosting.html',
        'screenshot' => 'https://bilohash.com/hosting/docs/screenshots/dashboard.webp',
        'screenshot_admin' => 'https://bilohash.com/hosting/docs/screenshots/clients.webp',
    ],
    [
        'item_key' => 'lending',
        'icon' => 'fa-store', 'tone' => 'emerald', 'badge' => 'NEW',
        'date' => '2026-07-08',
        'title' => ['en' => 'Business Landing CMS v1.2', 'no' => 'Business Landing CMS v1.2', 'lt' => 'Business Landing CMS v1.2', 'ua' => 'Business Landing CMS v1.2', 'ru' => 'Business Landing CMS v1.2'],
        'desc' => [
            'en' => 'v1.2 — Chart.js dashboard, school news with AI + SEO, demo invoices & leads, 4 languages (LT default). Demo driving school — no real services.',
            'no' => 'v1.2 — Chart.js dashboard, skolenyheter med AI + SEO, demo-fakturaer, 4 språk (LT standard). Demo — ingen ekte tjenester.',
            'lt' => 'v1.2 — Chart.js grafikai, mokyklos naujienos su AI ir SEO, demo sąskaitos ir užklausos, 4 kalbos (LT pagal nutylėjimą). Demo — jokių realių paslaugų.',
            'ua' => 'v1.2 — графіки Chart.js, новини школи з AI та SEO, демо-рахунки, 4 мови (LT за замовч.). Демо — без реальних послуг.',
            'ru' => 'v1.2 — графики Chart.js, новости школы с AI и SEO, демо-счета, 4 языка (LT по умолч.). Демо — без реальных услуг.',
        ],
        'demo' => 'https://bilohash.com/lending/',
        'admin_url' => 'https://bilohash.com/lending/admin/login.php',
        'admin_cred' => 'demo / bilolending2026',
        'site_url' => 'https://bilohash.com/ecosystem/join.php',
        'release_url' => '/news/lending-creator.html',
        'screenshot' => 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=800&h=500&fit=crop',
        'screenshot_admin' => 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800&h=500&fit=crop',
    ],
    [
        'item_key' => 'shop',
        'icon' => 'fa-shopping-bag', 'tone' => 'emerald', 'badge' => 'UPDATE',
        'date' => '2026-07-08',
        'title' => ['en' => 'Shop CMS v1.7.1', 'no' => 'Shop CMS v1.7.1', 'ua' => 'Shop CMS v1.7.1', 'ru' => 'Shop CMS v1.7.1'],
        'desc' => [
            'en' => 'v1.7.1 — 6 languages (NO/EN/SV/UA/RU/LT), Grok xAI & OpenAI for products/SEO/chat, ecosystem subscription & waitlist, 30-day demo ZIP, license cabinet. Catalog, cart, Schema.org Product SEO.',
            'no' => 'v1.7.1 — 6 språk (NO/EN/SV/UA/RU/LT), Grok xAI og OpenAI for produkter/SEO/chat, økosystemabonnement og venteliste, 30-dagers demo-ZIP, lisenskabinett. Katalog, handlekurv, Schema.org Product SEO.',
            'ua' => 'v1.7.1 — 6 мов (NO/EN/SV/UA/RU/LT), Grok xAI та OpenAI для товарів/SEO/чату, підписка на екосистему та waitlist, 30-денний demo ZIP, кабінет ліцензій. Каталог, кошик, Schema.org Product SEO.',
            'ru' => 'v1.7.1 — 6 языков (NO/EN/SV/UA/RU/LT), Grok xAI и OpenAI для товаров/SEO/чата, подписка на экосистему и waitlist, 30-дневный demo ZIP, кабинет лицензий. Каталог, корзина, Schema.org Product SEO.',
        ],
        'demo' => 'https://bilohash.com/shop/',
        'admin_url' => 'https://bilohash.com/shop/admin/login.php',
        'admin_cred' => 'demo / demo2026',
        'site_url' => 'https://bilohash.com/shop/site/',
        'release_url' => '/news/shop-cms.html',
        'screenshot' => '/news/screen/shop-home.svg',
        'screenshot_admin' => '/news/screen/shop-admin.svg',
    ],
    [
        'item_key' => 'faktura',
        'icon' => 'fa-file-invoice-dollar', 'tone' => 'violet', 'badge' => 'UPDATE',
        'date' => '2026-07-04',
        'title' => ['en' => 'Faktura CMS', 'no' => 'Faktura CMS', 'ua' => 'Faktura CMS', 'ru' => 'Faktura CMS'],
        'desc' => [
            'en' => 'Mobile invoice script — 2-click send, client database, SMTP email, AI notes, QR pay links, Pay buttons, 12 print designs, 7 languages.',
            'no' => 'Mobil faktura — 2 klikk, kundedatabase, SMTP, AI-notater, QR-betaling, Betal-knapper, 12 utskriftsdesign, 7 språk.',
            'ua' => 'Мобільні рахунки — 2 кліки, база клієнтів, SMTP, AI, QR оплата, кнопки Pay, 12 дизайнів друку, 7 мов.',
            'ru' => 'Мобильные счета — 2 клика, база клиентов, SMTP, AI, QR оплата, кнопки Pay, 12 дизайнов печати, 7 языков.',
        ],
        'demo' => 'https://bilohash.com/faktura/',
        'admin_url' => 'https://bilohash.com/faktura/admin/login.php',
        'admin_cred' => 'demo / bilofaktura2026',
        'site_url' => 'https://bilohash.com/faktura/',
        'release_url' => '/news/faktura-cms.html',
        'screenshot' => '/news/screen/faktura-home.svg',
        'screenshot_admin' => '/news/screen/faktura-admin.svg',
    ],
    [
        'item_key' => 'booking',
        'icon' => 'fa-calendar-check', 'tone' => 'sky', 'badge' => 'UPDATE',
        'date' => '2026-07-05',
        'title' => ['en' => 'Booking CMS', 'no' => 'Booking CMS', 'ua' => 'Booking CMS', 'ru' => 'Booking CMS'],
        'desc' => [
            'en' => '5 languages, demo PayPal/Stripe/Vipps checkout, guest reviews, 8 vertical SEO pages, taxes & payments in admin. Geo product page for 6 markets.',
            'no' => '5 språk, demo PayPal/Stripe/Vipps, gjesteanmeldelser, 8 vertikale SEO-sider, avgifter og betaling i admin. Geo-produktside for 6 markeder.',
            'ua' => '5 мов, демо PayPal/Stripe/Vipps, відгуки гостей, 8 вертикальних SEO-сторінок, податки й платежі в адмінці. Гео-сторінка продукту для 6 ринків.',
            'ru' => '5 языков, демо PayPal/Stripe/Vipps, отзывы гостей, 8 вертикальных SEO-страниц, налоги и платежи в админке. Гео-страница продукта для 6 рынков.',
        ],
        'demo' => 'https://bilohash.com/booking/',
        'admin_url' => 'https://bilohash.com/booking/admin/login.php',
        'admin_cred' => 'demo / bilobook2026',
        'site_url' => 'https://bilohash.com/booking/site/',
        'release_url' => '/news/booking-cms.html',
        'screenshot' => 'https://bilohash.com/booking/screen/home.svg',
        'screenshot_admin' => 'https://bilohash.com/booking/screen/admin-dashboard.svg',
    ],
    [
        'item_key' => 'tavle',
        'icon' => 'fa-car', 'tone' => 'red', 'badge' => 'NEW',
        'date' => '2026-07-02',
        'title' => ['en' => 'Bilen CMS', 'no' => 'Bilen CMS', 'ua' => 'Bilen CMS', 'ru' => 'Bilen CMS'],
        'desc' => [
            'en' => 'PHP car marketplace — sticky Buy/Leasing filters, 18 demo listings, photo carousel, brand/model SEO, Schema.org Car, SQLite admin. 4 languages.',
            'no' => 'PHP bilmarkedsplass — klebrige Kjøp/Leasing-filtre, 18 demoannonser, bildekarusell, merke-/modell-SEO, Schema.org Car, SQLite-admin. 4 språk.',
            'ua' => 'PHP автомайданчик — липкі вкладки Купівля/Лізинг, 18 демо-оголошень, карусель фото, SEO брендів/моделей, Schema.org Car, SQLite-адмін. 4 мови.',
            'ru' => 'PHP автоплощадка — липкие вкладки Покупка/Лизинг, 18 демо-объявлений, карусель фото, SEO брендов/моделей, Schema.org Car, SQLite-админ. 4 языка.',
        ],
        'demo' => 'https://bilohash.com/tavle/',
        'admin_url' => 'https://bilohash.com/tavle/site/admin/',
        'admin_cred' => 'admin / admin123',
        'site_url' => 'https://bilohash.com/tavle/site/',
        'release_url' => '/news/tavle.html',
        'screenshot' => 'https://bilohash.com/tavle/assets/images/screens/screen-catalog.svg',
        'screenshot_admin' => 'https://bilohash.com/tavle/assets/images/screens/screen-admin.svg',
    ],
    [
        'item_key' => 'gamehub',
        'icon' => 'fa-gamepad', 'tone' => 'cyan', 'badge' => 'NEW',
        'date' => '2026-06-27',
        'title' => ['en' => 'GameHub CMS', 'no' => 'GameHub CMS', 'ua' => 'GameHub CMS', 'ru' => 'GameHub CMS'],
        'desc' => [
            'en' => 'PHP game server monitor — CS2 hub, map previews, live player stats, filters, GameServer schema, admin. 4 languages.',
            'no' => 'PHP spillserver-monitor — CS2-hub, kartforhåndsvisning, live spillerstatistikk, filtre, GameServer schema, admin. 4 språk.',
            'ua' => 'PHP монітор ігрових серверів — CS2 hub, превʼю карт, live-статистика, фільтри, GameServer schema, адмін. 4 мови.',
            'ru' => 'PHP монитор игровых серверов — CS2 hub, превью карт, live-статистика, фильтры, GameServer schema, админ. 4 языка.',
        ],
        'demo' => 'https://bilohash.com/gamehub/',
        'admin_url' => 'https://bilohash.com/gamehub/admin/login.php',
        'admin_cred' => 'demo / bilogamehub2026',
        'site_url' => 'https://bilohash.com/gamehub/site/',
        'release_url' => '/news/gamehub-cms.html',
        'screenshot' => '/news/screen/gamehub-home.svg',
        'screenshot_admin' => '/news/screen/gamehub-admin.svg',
    ],
    [
        'item_key' => 'auction',
        'icon' => 'fa-gavel', 'tone' => 'sky', 'badge' => 'NEW',
        'date' => '2026-06-26',
        'title' => ['en' => 'Auction CMS', 'no' => 'Auction CMS', 'ua' => 'Auction CMS', 'ru' => 'Auction CMS'],
        'desc' => [
            'en' => 'PHP online auction — 14 demo lots, bidding, countdown, dashboard admin, CSV export. 3 languages, Schema.org SEO.',
            'no' => 'PHP online auksjon — 14 demo-objekter, bud, nedtelling, dashbord-admin, CSV-eksport. 3 språk, Schema.org SEO.',
            'ua' => 'PHP онлайн-аукціон — 14 демо-лотів, ставки, таймер, адмін-дашборд, CSV-експорт. 3 мови, Schema.org SEO.',
            'ru' => 'PHP онлайн-аукцион — 14 демо-лотов, ставки, таймер, админ-дашборд, экспорт CSV. 3 языка, Schema.org SEO.',
        ],
        'demo' => 'https://bilohash.com/auction/',
        'admin_url' => 'https://bilohash.com/auction/admin/login.php',
        'admin_cred' => 'demo / biloauction2026',
        'site_url' => 'https://bilohash.com/auction/site/',
        'release_url' => '/news/auction-cms.html',
        'screenshot' => '/news/screen/auction-home.svg',
        'screenshot_admin' => '/news/screen/auction-admin.svg',
    ],
    [
        'item_key' => 'freelance',
        'icon' => 'fa-briefcase', 'tone' => 'teal', 'badge' => 'NEW',
        'date' => '2026-06-26',
        'title' => ['en' => 'Freelance CMS', 'no' => 'Freelance CMS', 'ua' => 'Freelance CMS', 'ru' => 'Freelance CMS'],
        'desc' => [
            'en' => 'PHP freelance marketplace — 12 projects, proposals, 8 solutions, 9 SEO regions, 4 languages, Upwork/Fiverr style.',
            'no' => 'PHP frilans-markedsplass — 12 prosjekter, tilbud, 8 løsninger, 9 SEO-regioner, 4 språk, Upwork/Fiverr-stil.',
            'ua' => 'PHP фріланс-маркетплейс — 12 проєктів, пропозиції, 8 сценаріїв, 9 SEO-регіонів, 4 мови, стиль Upwork/Fiverr.',
            'ru' => 'PHP фриланс-маркетплейс — 12 проектов, предложения, 8 сценариев, 9 SEO-регионов, 4 языка, стиль Upwork/Fiverr.',
        ],
        'demo' => 'https://bilohash.com/freelance/',
        'admin_url' => 'https://bilohash.com/freelance/admin/login.php',
        'admin_cred' => 'demo / bilofreelance2026',
        'site_url' => 'https://bilohash.com/freelance/site/',
        'release_url' => '/news/freelance-cms.html',
        'screenshot' => 'https://bilohash.com/freelance/screen/home.svg',
        'screenshot_admin' => 'https://bilohash.com/freelance/screen/admin-dashboard.svg',
    ],
    [
        'item_key' => 'pizza',
        'icon' => 'fa-pizza-slice', 'tone' => 'rose', 'badge' => 'NEW',
        'date' => '2026-06-27',
        'title' => ['en' => 'Pizza CMS', 'no' => 'Pizza CMS', 'ua' => 'Pizza CMS', 'ru' => 'Pizza CMS'],
        'desc' => [
            'en' => 'PHP restaurant script — multilingual menu, table reservations, terrace #solaskinner, Schema.org Restaurant SEO and admin.',
            'no' => 'PHP restaurant-skript — flerspråklig meny, bordreservasjon, terrasse #solaskinner, Schema.org Restaurant SEO og admin.',
            'ua' => 'PHP restaurant скрипт — багатомовне меню, бронювання, тераса #solaskinner, Schema.org Restaurant SEO та адмін.',
            'ru' => 'PHP restaurant-скрипт — многоязычное меню, бронирование столиков, терраса #solaskinner, Schema.org Restaurant SEO и админка.',
        ],
        'demo' => 'https://bilohash.com/pizza/',
        'admin_url' => 'https://bilohash.com/pizza/admin/login.php',
        'admin_cred' => 'demo / pizza2026',
        'site_url' => 'https://bilohash.com/pizza/site/',
        'release_url' => '/news/pizza-cms.html',
        'screenshot' => '/news/screen/pizza-home.svg',
        'screenshot_admin' => '/news/screen/pizza-admin.svg',
    ],
    [
        'item_key' => 'today',
        'icon' => 'fa-newspaper', 'tone' => 'rose', 'badge' => 'NEW',
        'date' => '2026-06-10',
        'title' => ['en' => 'Today CMS', 'no' => 'Today CMS', 'ua' => 'Today CMS', 'ru' => 'Today CMS'],
        'desc' => [
            'en' => 'PHP news CMS demo — 10 sample articles, journalist profiles, categories, newspaper UI, NewsArticle schema. 4 languages.',
            'no' => 'PHP nyhets-CMS — 10 eksempelartikler, journalistprofiler, kategorier, avis-UI, NewsArticle schema. 4 språk.',
            'ua' => 'PHP news CMS — 10 зразкових статей, профілі журналістів, категорії, газетний UI, NewsArticle schema. 4 мови.',
            'ru' => 'PHP news CMS — 10 образцовых статей, профили журналистов, категории, газетный UI, NewsArticle schema. 4 языка.',
        ],
        'demo' => 'https://bilohash.com/today/',
        'admin_url' => 'https://bilohash.com/today/admin/login.php',
        'admin_cred' => 'demo / pilotoday2026',
        'site_url' => 'https://bilohash.com/today/about.php',
        'release_url' => '/news/today-cms.html',
        'screenshot' => 'https://bilohash.com/today/assets/images/og-default.svg',
        'screenshot_admin' => 'https://bilohash.com/today/assets/images/articles/art-03-admin.svg',
    ],
    [
        'item_key' => '3d',
        'icon' => 'fa-cube', 'tone' => 'cyan', 'badge' => 'Live',
        'date' => '2026-05-01',
        'title' => ['en' => '3D Gallery CMS', 'no' => '3D Gallery CMS', 'ua' => '3D Gallery CMS', 'ru' => '3D Gallery CMS'],
        'desc' => [
            'en' => '3D print orders — photo figurines, STL/OBJ upload, PayPal & Vipps in NOK, multilingual site and order admin.',
            'no' => '3D-print bestillinger — foto-figurer, STL/OBJ-opplasting, PayPal og Vipps i NOK, flerspråklig side og ordreadmin.',
            'ua' => '3D-друк — фігурки з фото, завантаження STL/OBJ, PayPal і Vipps у NOK, багатомовний сайт та адмін замовлень.',
            'ru' => '3D-печать — фигурки по фото, загрузка STL/OBJ, PayPal и Vipps в NOK, многоязычный сайт и админ заказов.',
        ],
        'demo' => 'https://bilohash.com/3d/',
        'admin_url' => 'https://bilohash.com/3d/admin.php',
        'admin_cred' => null,
        'site_url' => 'https://bilohash.com/3d/',
        'release_url' => '/news/3d-cms.html',
        'screenshot' => '/news/screen/3d-home.svg',
        'screenshot_admin' => '/news/screen/3d-admin.svg',
    ],
];

$modules = [
    [
        'item_key' => 'wordpress-ai',
        'icon' => 'fab fa-wordpress', 'tone' => 'emerald', 'badge' => 'OFFICIAL',
        'title' => ['en' => 'AI Chat Consultant', 'no' => 'AI Chat Consultant', 'ua' => 'AI Chat Consultant', 'ru' => 'AI Chat Consultant'],
        'desc' => [
            'en' => 'Official WordPress.org plugin — Grok xAI + OpenAI, Telegram alerts, full customization.',
            'no' => 'Offisiell WordPress.org-plugin — Grok xAI + OpenAI, Telegram-varsler, full tilpasning.',
            'ua' => 'Офіційний плагін WordPress.org — Grok xAI + OpenAI, сповіщення Telegram, повна кастомізація.',
            'ru' => 'Официальный плагин WordPress.org — Grok xAI + OpenAI, уведомления Telegram, полная кастомизация.',
        ],
        'demo' => 'https://wordpress.org/plugins/bilohash-ai-chat-consultant/',
        'release_url' => '/news/wordpress.html',
    ],
    [
        'item_key' => 'ai-platform',
        'icon' => 'fa-robot', 'tone' => 'cyan', 'badge' => 'AI',
        'title' => ['en' => 'AI Platform', 'no' => 'AI-plattform', 'ua' => 'AI Платформа', 'ru' => 'AI Платформа'],
        'desc' => [
            'en' => 'Hub for AI chat solutions, CRM consultant, WordPress demo and multichannel bots.',
            'no' => 'Hub for AI-chat-løsninger, CRM-konsulent, WordPress-demo og multikanal-boter.',
            'ua' => 'Хаб AI-чат рішень, CRM-консультант, WordPress demo та мультиканальні боти.',
            'ru' => 'Хаб AI-чат решений, CRM-консультант, WordPress demo и мультиканальные боты.',
        ],
        'demo' => 'https://bilohash.com/ai/',
        'release_url' => '/news/ai-norway-chat.html',
    ],
    [
        'item_key' => 'smart-popups',
        'icon' => 'fa-window-maximize', 'tone' => 'cyan', 'badge' => 'Module',
        'title' => ['en' => 'Smart Popups', 'no' => 'Smart Popups', 'ua' => 'Smart Popups', 'ru' => 'Smart Popups'],
        'desc' => [
            'en' => 'Smart pop-up system for conversions — rules, templates, triggers, WordPress integration.',
            'no' => 'Smart pop-up-system for konverteringer — regler, maler, triggere, WordPress-integrasjon.',
            'ua' => 'Розумні спливаючі вікна для конверсій — правила, шаблони, тригери, інтеграція з WordPress.',
            'ru' => 'Умные всплывающие окна для конверсий — правила, шаблоны, триггеры, интеграция с WordPress.',
        ],
        'demo' => '/news/smart-popups/',
        'release_url' => '/news/smart-popups/',
    ],
    [
        'item_key' => 'callback-admin',
        'icon' => 'fa-phone-volume', 'tone' => 'cyan', 'badge' => 'Module',
        'title' => ['en' => 'Callback Request Admin', 'no' => 'Callback Request Admin', 'ua' => 'Callback Request Admin', 'ru' => 'Callback Request Admin'],
        'desc' => [
            'en' => 'Callback & subscription admin for WordPress — reCAPTCHA, mass mailing, Telegram.',
            'no' => 'Callback- og abonnementsadmin for WordPress — reCAPTCHA, masseutsendelse, Telegram.',
            'ua' => 'Адмін callback та підписок для WordPress — reCAPTCHA, масові розсилки, Telegram.',
            'ru' => 'Админ callback и подписок для WordPress — reCAPTCHA, массовые рассылки, Telegram.',
        ],
        'demo' => '/news/callback-request-admin/',
        'release_url' => '/news/callback-request-admin/',
    ],
];

$demo_gallery = [];
foreach ($cms_products as $p) {
    if (empty($p['screenshot'])) {
        continue;
    }
    $demo_gallery[] = [
        'title' => news_txt($p['title']),
        'demo'  => $p['demo'],
        'tone'  => $p['tone'],
        'shots' => array_values(array_filter([
            ['src' => news_shot($p['screenshot']), 'label' => news_txt($shot_labels['frontend']), 'type' => 'frontend'],
            !empty($p['screenshot_admin']) ? ['src' => news_shot($p['screenshot_admin']), 'label' => news_txt($shot_labels['admin']), 'type' => 'admin'] : null,
        ])),
    ];
}
$demo_gallery = array_merge($demo_gallery, [
    [
        'title' => news_txt($modules[0]['title']),
        'demo'  => $modules[0]['demo'],
        'tone'  => 'emerald',
        'shots' => [
            ['src' => news_shot('https://bilohash.com/ai/wordpress/screen/wigets.jpg'), 'label' => news_txt($shot_labels['frontend']), 'type' => 'frontend'],
            ['src' => news_shot('https://bilohash.com/ai/wordpress/screen/admin_general.jpg'), 'label' => news_txt($shot_labels['admin']), 'type' => 'admin'],
        ],
    ],
    [
        'title' => news_txt($modules[1]['title']),
        'demo'  => $modules[1]['demo'],
        'tone'  => 'cyan',
        'shots' => [
            ['src' => news_shot('https://bilohash.com/ai/crm/screen/wigets.jpg'), 'label' => news_txt($shot_labels['frontend']), 'type' => 'frontend'],
            ['src' => news_shot('https://bilohash.com/ai/crm/screen/admin_site.jpg'), 'label' => news_txt($shot_labels['admin']), 'type' => 'admin'],
        ],
    ],
    [
        'title' => news_txt($modules[2]['title']),
        'demo'  => $modules[2]['demo'],
        'tone'  => 'cyan',
        'shots' => [
            ['src' => news_shot('/news/smart-popups/screen/general.jpg'), 'label' => news_txt($shot_labels['frontend']), 'type' => 'frontend'],
            ['src' => news_shot('/news/smart-popups/screen/design.jpg'), 'label' => news_txt($shot_labels['admin']), 'type' => 'admin'],
        ],
    ],
    [
        'title' => news_txt($modules[3]['title']),
        'demo'  => $modules[3]['demo'],
        'tone'  => 'cyan',
        'shots' => [
            ['src' => news_shot('/news/callback-request-admin/screen/general.jpg'), 'label' => news_txt($shot_labels['frontend']), 'type' => 'frontend'],
            ['src' => news_shot('/news/callback-request-admin/screen/messages.jpg'), 'label' => news_txt($shot_labels['admin']), 'type' => 'admin'],
        ],
    ],
]);

// Chronological feed — every ecosystem release, launch and product news
$all_news = [
    [
        'item_key' => 'hosting-launch',
        'date' => '2026-07-10', 'tone' => 'cyan', 'badge' => 'NEW', 'icon' => 'fa-server',
        'title' => [
            'en' => 'Hosting CMS v2.7.0 — hPanel-grade panel live',
            'no' => 'Hosting CMS v2.7.0 — hPanel-panel live',
            'ua' => 'Hosting CMS v2.7.0 — панель рівня hPanel в продакшні',
            'ru' => 'Hosting CMS v2.7.0 — панель уровня hPanel в продакшене',
        ],
        'desc' => [
            'en' => '40+ tools, MySQL 2.0, 15 ecosystem planets installer, malware scanner, BILOHASH Webmail, 30-day FREE demo license.',
            'no' => '40+ verktøy, MySQL 2.0, 15 økosystem-planeter, malware-skanner, BILOHASH Webmail, 30 dagers GRATIS demo.',
            'ua' => '40+ інструментів, MySQL 2.0, інсталятор 15 планет екосистеми, сканер malware, BILOHASH Webmail, 30-денна безкоштовна demo.',
            'ru' => '40+ инструментов, MySQL 2.0, установщик 15 планет экосистемы, сканер malware, BILOHASH Webmail, 30-дневная бесплатная demo.',
        ],
        'url' => '/news/hosting.html', 'demo' => 'https://bilohash.com/hosting/', 'product' => 'https://bilohash.com/hosting/',
    ],
    [
        'item_key' => 'shop-171',
        'date' => '2026-07-08', 'tone' => 'emerald', 'badge' => 'Update', 'icon' => 'fa-shopping-bag',
        'title' => [
            'en' => 'Shop CMS v1.7.1 — ecosystem subscription & AI',
            'no' => 'Shop CMS v1.7.1 — økosystemabonnement og AI',
            'ua' => 'Shop CMS v1.7.1 — підписка на екосистему та AI',
            'ru' => 'Shop CMS v1.7.1 — подписка на экосистему и AI',
        ],
        'desc' => [
            'en' => '6 languages, Grok xAI & OpenAI agents, 30-day demo download, license cabinet — join waitlist at ecosystem/join.php.',
            'no' => '6 språk, Grok xAI og OpenAI-agenter, 30-dagers demo-nedlasting, lisenskabinett — bli med på venteliste via ecosystem/join.php.',
            'ua' => '6 мов, агенти Grok xAI та OpenAI, завантаження 30-денного демо, кабінет ліцензій — waitlist на ecosystem/join.php.',
            'ru' => '6 языков, агенты Grok xAI и OpenAI, загрузка 30-дневного демо, кабинет лицензий — waitlist на ecosystem/join.php.',
        ],
        'url' => '/news/shop-cms.html', 'demo' => 'https://bilohash.com/shop/', 'product' => 'https://bilohash.com/ecosystem/join.php',
    ],
    [
        'item_key' => 'lending-12',
        'date' => '2026-07-08', 'tone' => 'emerald', 'badge' => 'Launch', 'icon' => 'fa-store',
        'title' => ['en' => 'Business Landing CMS v1.2 live', 'no' => 'Business Landing CMS v1.2 live', 'lt' => 'Business Landing CMS v1.2', 'ua' => 'Business Landing CMS v1.2 в продакшні', 'ru' => 'Business Landing CMS v1.2 в продакшене'],
        'desc' => ['en' => 'Charts, news AI, SEO, invoices, 4 langs, LT default. Demo only — fictional driving school.', 'no' => 'Grafikk, nyheter AI, SEO, fakturaer, 4 språk. Kun demo.', 'lt' => 'Grafikai, naujienos, AI, SEO, sąskaitos, 4 kalbos. Tik demo — fiktyvi autoškola.', 'ua' => 'Графіки, AI новини, SEO, рахунки, 4 мови. Лише демо.', 'ru' => 'Графики, AI новости, SEO, счета, 4 языка. Только демо.'],
        'url' => '/news/lending-creator.html', 'demo' => 'https://bilohash.com/lending/', 'product' => 'https://bilohash.com/ecosystem/join.php',
    ],
    [
        'item_key' => 'faktura-update',
        'date' => '2026-07-04', 'tone' => 'violet', 'badge' => 'Update', 'icon' => 'fa-file-invoice-dollar',
        'title' => ['en' => 'Faktura CMS — mobile invoices, AI & QR', 'no' => 'Faktura CMS — mobil faktura, AI og QR', 'ua' => 'Faktura CMS — мобільні рахунки, AI та QR', 'ru' => 'Faktura CMS — мобильные счета, AI и QR'],
        'desc' => ['en' => '2-click send from phone, clients, SMTP, AI notes, QR pay links, 12 designs, 7 languages.', 'no' => '2 klikk fra mobil, kunder, SMTP, AI-notater, QR-betaling, 12 design, 7 språk.', 'ua' => '2 кліки з телефону, клієнти, SMTP, AI, QR оплата, 12 дизайнів, 7 мов.', 'ru' => '2 клика с телефона, клиенты, SMTP, AI, QR оплата, 12 дизайнов, 7 языков.'],
        'url' => '/news/faktura-cms.html', 'demo' => 'https://bilohash.com/faktura/', 'product' => 'https://bilohash.com/faktura/',
    ],
    [
        'item_key' => 'bilen-launch',
        'date' => '2026-07-02', 'tone' => 'red', 'badge' => 'Launch', 'icon' => 'fa-car',
        'title' => ['en' => 'Bilen CMS — car marketplace live', 'no' => 'Bilen CMS — bilmarkedsplass live', 'ua' => 'Bilen CMS — автомайданчик в продакшні', 'ru' => 'Bilen CMS — автоплощадка в продакшене'],
        'desc' => ['en' => '18 demo cars, sticky filters, brand SEO pages, Schema.org Car markup, SQLite admin, 4 languages.', 'no' => '18 demobiler, klebrige filtre, merke-SEO, Schema.org Car, SQLite-admin, 4 språk.', 'ua' => '18 демо-авто, липкі фільтри, SEO брендів, Schema.org Car, SQLite-адмін, 4 мови.', 'ru' => '18 демо-авто, липкие фильтры, SEO брендов, Schema.org Car, SQLite-админ, 4 языка.'],
        'url' => '/news/tavle.html', 'demo' => 'https://bilohash.com/tavle/', 'product' => 'https://bilohash.com/tavle/site/',
    ],
    [
        'item_key' => 'gamehub-launch',
        'date' => '2026-06-27', 'tone' => 'cyan', 'badge' => 'Launch', 'icon' => 'fa-gamepad',
        'title' => ['en' => 'GameHub CMS — CS2 server monitor live', 'no' => 'GameHub CMS — CS2 servermonitor live', 'ua' => 'GameHub CMS — монітор CS2 в продакшні', 'ru' => 'GameHub CMS — монитор CS2 в продакшене'],
        'desc' => ['en' => 'Map previews, live stats, server filters, GameServer SEO, admin panel, 4 languages.', 'no' => 'Kartforhåndsvisning, live statistikk, serverfiltre, GameServer SEO, adminpanel, 4 språk.', 'ua' => 'Превʼю карт, live-статистика, фільтри серверів, GameServer SEO, адмін-панель, 4 мови.', 'ru' => 'Превью карт, live-статистика, фильтры серверов, GameServer SEO, админ-панель, 4 языка.'],
        'url' => '/news/gamehub-cms.html', 'demo' => 'https://bilohash.com/gamehub/', 'product' => 'https://bilohash.com/gamehub/site/',
    ],
    [
        'item_key' => 'booking-geo',
        'date' => '2026-07-05', 'tone' => 'sky', 'badge' => 'Update', 'icon' => 'fa-calendar-check',
        'title' => ['en' => 'Booking CMS — payments, 5 languages & geo product page', 'no' => 'Booking CMS — betaling, 5 språk og geo-produktside', 'ua' => 'Booking CMS — оплата, 5 мов і гео-сторінка продукту', 'ru' => 'Booking CMS — оплата, 5 языков и гео-страница продукта'],
        'desc' => ['en' => 'Demo PayPal/Stripe/Vipps checkout, Swedish language, guest reviews, vertical SEO, taxes in admin, geo pricing on product page.', 'no' => 'Demo PayPal/Stripe/Vipps, svensk språk, gjesteanmeldelser, vertikal SEO, avgifter i admin, geo-priser på produktsiden.', 'ua' => 'Демо PayPal/Stripe/Vipps, шведська мова, відгуки гостей, вертикальне SEO, податки в адмінці, гео-ціни на сторінці продукту.', 'ru' => 'Демо PayPal/Stripe/Vipps, шведский язык, отзывы гостей, вертикальное SEO, налоги в админке, гео-цены на странице продукта.'],
        'url' => '/news/booking-cms.html', 'demo' => 'https://bilohash.com/booking/', 'product' => 'https://bilohash.com/booking/site/',
    ],
    [
        'item_key' => 'pizza-launch',
        'date' => '2026-06-27', 'tone' => 'rose', 'badge' => 'Launch', 'icon' => 'fa-pizza-slice',
        'title' => ['en' => 'Pizza CMS — restaurant demo live', 'no' => 'Pizza CMS — restaurant demo live', 'ua' => 'Pizza CMS — restaurant demo в продакшні', 'ru' => 'Pizza CMS — restaurant demo в продакшене'],
        'desc' => ['en' => 'Forno Romano pizzeria demo — 14 menu items, reservations, terrace animation, 4 languages.', 'no' => 'Forno Romano pizzeria-demo — 14 menyretter, reservasjon, terrasse-animasjon, 4 språk.', 'ua' => 'Демо піцерії Forno Romano — 14 страв, бронювання, анімація тераси, 4 мови.', 'ru' => 'Демо пиццерии Forno Romano — 14 блюд, бронирование, анимация террасы, 4 языка.'],
        'url' => '/news/pizza-cms.html', 'demo' => 'https://bilohash.com/pizza/', 'product' => 'https://bilohash.com/pizza/site/',
    ],
    [
        'item_key' => 'freelance-release',
        'date' => '2026-06-26', 'tone' => 'teal', 'badge' => 'Release', 'icon' => 'fa-briefcase',
        'title' => ['en' => 'Freelance CMS — marketplace release', 'no' => 'Freelance CMS — markedsplass-lansering', 'ua' => 'Freelance CMS — реліз маркетплейсу', 'ru' => 'Freelance CMS — релиз маркетплейса'],
        'desc' => ['en' => '12 demo projects, proposals, 8 solutions, 9 SEO regions, 4 languages.', 'no' => '12 demo-prosjekter, tilbud, 8 løsninger, 9 SEO-regioner, 4 språk.', 'ua' => '12 демо-проєктів, пропозиції, 8 сценаріїв, 9 SEO-регіонів, 4 мови.', 'ru' => '12 демо-проектов, предложения, 8 сценариев, 9 SEO-регионов, 4 языка.'],
        'url' => '/news/freelance-cms.html', 'demo' => 'https://bilohash.com/freelance/', 'product' => 'https://bilohash.com/freelance/site/',
    ],
    [
        'item_key' => 'auction-release',
        'date' => '2026-06-26', 'tone' => 'sky', 'badge' => 'Release', 'icon' => 'fa-gavel',
        'title' => ['en' => 'Auction CMS — online auction release', 'no' => 'Auction CMS — auksjonslansering', 'ua' => 'Auction CMS — реліз онлайн-аукціону', 'ru' => 'Auction CMS — релиз онлайн-аукциона'],
        'desc' => ['en' => '14 demo lots, bidding, countdown, dashboard admin, CSV export.', 'no' => '14 demo-objekter, bud, nedtelling, dashbord-admin, CSV-eksport.', 'ua' => '14 демо-лотів, ставки, таймер, адмін-дашборд, CSV-експорт.', 'ru' => '14 демо-лотов, ставки, таймер, админ-дашборд, экспорт CSV.'],
        'url' => '/news/auction-cms.html', 'demo' => 'https://bilohash.com/auction/', 'product' => 'https://bilohash.com/auction/site/',
    ],
    [
        'item_key' => 'booking-release',
        'date' => '2026-06-20', 'tone' => 'sky', 'badge' => 'Release', 'icon' => 'fa-calendar-check',
        'title' => ['en' => 'Booking CMS — reservation platform release', 'no' => 'Booking CMS — reservasjonsplattform', 'ua' => 'Booking CMS — реліз платформи бронювання', 'ru' => 'Booking CMS — релиз платформы бронирования'],
        'desc' => ['en' => 'Hotels, apartments, cabins — search, property pages, full admin.', 'no' => 'Hotell, leiligheter, hytter — søk, eiendomssider, fullt admin.', 'ua' => 'Готелі, апартаменти, котеджі — пошук, сторінки об\'єктів, повна адмінка.', 'ru' => 'Отели, апартаменты, коттеджи — поиск, страницы объектов, полная админка.'],
        'url' => '/news/booking-cms.html', 'demo' => 'https://bilohash.com/booking/', 'product' => 'https://bilohash.com/booking/site/',
    ],
    [
        'item_key' => 'shop-launch',
        'date' => '2026-06-15', 'tone' => 'emerald', 'badge' => 'Launch', 'icon' => 'fa-shopping-bag',
        'title' => ['en' => 'Shop CMS — e-commerce demo live', 'no' => 'Shop CMS — e-handel demo live', 'ua' => 'Shop CMS — e-commerce demo в продакшні', 'ru' => 'Shop CMS — e-commerce demo в продакшене'],
        'desc' => ['en' => 'Catalog, cart, Schema.org Product SEO, MySQL admin, 4 languages.', 'no' => 'Katalog, handlekurv, Schema.org Product SEO, MySQL-admin, 4 språk.', 'ua' => 'Каталог, кошик, Schema.org Product SEO, MySQL-адмін, 4 мови.', 'ru' => 'Каталог, корзина, Schema.org Product SEO, MySQL-админ, 4 языка.'],
        'url' => '/news/shop-cms.html', 'demo' => 'https://bilohash.com/shop/', 'product' => 'https://bilohash.com/shop/site/',
    ],
    [
        'item_key' => 'today-launch',
        'date' => '2026-06-10', 'tone' => 'rose', 'badge' => 'Launch', 'icon' => 'fa-newspaper',
        'title' => ['en' => 'Today CMS — news platform demo', 'no' => 'Today CMS — nyhetsplattform demo', 'ua' => 'Today CMS — news CMS demo', 'ru' => 'Today CMS — news CMS demo'],
        'desc' => ['en' => '10 sample articles, journalists, categories, newspaper UI, 4 languages.', 'no' => '10 eksempelartikler, journalister, kategorier, avis-UI, 4 språk.', 'ua' => '10 зразкових статей, журналісти, категорії, газетний UI, 4 мови.', 'ru' => '10 образцовых статей, журналисты, категории, газетный UI, 4 языка.'],
        'url' => '/news/today-cms.html', 'demo' => 'https://bilohash.com/today/', 'product' => 'https://bilohash.com/today/about.php',
    ],
    [
        'item_key' => 'wordpress-official',
        'date' => '2026-05-20', 'tone' => 'emerald', 'badge' => 'OFFICIAL', 'icon' => 'fab fa-wordpress',
        'title' => ['en' => 'AI Chat Consultant — WordPress.org launch', 'no' => 'AI Chat Consultant — WordPress.org lansering', 'ua' => 'AI Chat Consultant — запуск на WordPress.org', 'ru' => 'AI Chat Consultant — запуск на WordPress.org'],
        'desc' => ['en' => 'Official plugin directory release — Grok xAI + OpenAI, Telegram alerts.', 'no' => 'Offisiell plugin-katalog — Grok xAI + OpenAI, Telegram-varsler.', 'ua' => 'Офіційний каталог плагінів — Grok xAI + OpenAI, сповіщення Telegram.', 'ru' => 'Официальный каталог плагинов — Grok xAI + OpenAI, уведомления Telegram.'],
        'url' => '/news/wordpress.html', 'demo' => 'https://wordpress.org/plugins/bilohash-ai-chat-consultant/', 'product' => 'https://bilohash.com/ai/wordpress/',
    ],
    [
        'item_key' => 'ai-norway',
        'date' => '2026-05-15', 'tone' => 'cyan', 'badge' => 'News', 'icon' => 'fa-robot',
        'title' => ['en' => 'AI Chat Consultant for Norway', 'no' => 'AI Chat Consultant for Norge', 'ua' => 'AI-чат для норвезького ринку', 'ru' => 'AI-чат для норвежского рынка'],
        'desc' => ['en' => 'AI solution details for Norwegian businesses — Grok, GPT, Telegram, WordPress.', 'no' => 'AI-løsning for norske bedrifter — Grok, GPT, Telegram, WordPress.', 'ua' => 'AI-рішення для бізнесу в Норвегії — Grok, GPT, Telegram, WordPress.', 'ru' => 'AI-решение для бизнеса в Норвегии — Grok, GPT, Telegram, WordPress.'],
        'url' => '/news/ai-norway-chat.html', 'demo' => 'https://bilohash.com/ai/', 'product' => null,
    ],
    [
        'item_key' => '3d-live',
        'date' => '2026-05-01', 'tone' => 'cyan', 'badge' => 'Live', 'icon' => 'fa-cube',
        'title' => ['en' => '3D Gallery CMS — print orders platform', 'no' => '3D Gallery CMS — printbestillinger', 'ua' => '3D Gallery CMS — платформа 3D-друку', 'ru' => '3D Gallery CMS — платформа 3D-печати'],
        'desc' => ['en' => 'Photo figurines, STL/OBJ upload, PayPal & Vipps in NOK, order admin.', 'no' => 'Foto-figurer, STL/OBJ, PayPal og Vipps i NOK, ordreadmin.', 'ua' => 'Фігурки з фото, STL/OBJ, PayPal і Vipps у NOK, адмін замовлень.', 'ru' => 'Фигурки по фото, STL/OBJ, PayPal и Vipps в NOK, админ заказов.'],
        'url' => 'https://bilohash.com/3d/', 'demo' => 'https://bilohash.com/3d/', 'product' => 'https://bilohash.com/3d/',
    ],
    [
        'item_key' => 'smart-popups-module',
        'date' => '2026-04-10', 'tone' => 'cyan', 'badge' => 'Module', 'icon' => 'fa-window-maximize',
        'title' => ['en' => 'Smart Popups — conversion pop-ups', 'no' => 'Smart Popups — konverterings-popups', 'ua' => 'Smart Popups — спливаючі вікна для конверсій', 'ru' => 'Smart Popups — всплывающие окна для конверсий'],
        'desc' => ['en' => 'Rules, templates, triggers, WordPress plugin, download & docs.', 'no' => 'Regler, maler, triggere, WordPress-plugin, nedlasting og docs.', 'ua' => 'Правила, шаблони, тригери, WordPress-плагін, завантаження та документація.', 'ru' => 'Правила, шаблоны, триггеры, WordPress-плагин, загрузка и документация.'],
        'url' => '/news/smart-popups/', 'demo' => '/news/smart-popups/', 'product' => '/news/smart-popups/changelog.php',
    ],
    [
        'item_key' => 'callback-module',
        'date' => '2026-03-20', 'tone' => 'cyan', 'badge' => 'Module', 'icon' => 'fa-phone-volume',
        'title' => ['en' => 'Callback Request Admin — leads & callbacks', 'no' => 'Callback Request Admin — leads og callbacks', 'ua' => 'Callback Request Admin — ліди та callback', 'ru' => 'Callback Request Admin — лиды и callback'],
        'desc' => ['en' => 'WordPress plugin — reCAPTCHA, mass mailing, Telegram, subscription forms.', 'no' => 'WordPress-plugin — reCAPTCHA, masseutsendelse, Telegram, abonnement.', 'ua' => 'WordPress-плагін — reCAPTCHA, масові розсилки, Telegram, підписки.', 'ru' => 'WordPress-плагин — reCAPTCHA, массовые рассылки, Telegram, подписки.'],
        'url' => '/news/callback-request-admin/', 'demo' => '/news/callback-request-admin/', 'product' => '/news/callback-request-admin/changelog.php',
    ],
    [
        'item_key' => 'crm-ai',
        'date' => '2026-02-15', 'tone' => 'cyan', 'badge' => 'AI', 'icon' => 'fa-users-cog',
        'title' => ['en' => 'CRM AI Consultant 4.0', 'no' => 'CRM AI Consultant 4.0', 'ua' => 'CRM AI Consultant 4.0', 'ru' => 'CRM AI Consultant 4.0'],
        'desc' => ['en' => 'Multichannel AI — Telegram, WhatsApp, Viber, web. Full PHP+MySQL source.', 'no' => 'Multikanal AI — Telegram, WhatsApp, Viber, web. Full PHP+MySQL kilde.', 'ua' => 'Мультиканальний AI — Telegram, WhatsApp, Viber, web. Повний PHP+MySQL код.', 'ru' => 'Мультиканальный AI — Telegram, WhatsApp, Viber, web. Полный исходный код PHP+MySQL.'],
        'url' => 'https://bilohash.com/ai/crm/index.html', 'demo' => 'https://bilohash.com/ai/crm/index.html', 'product' => 'https://bilohash.com/ai/crm/documentation-en.html',
    ],
    [
        'item_key' => 'ai-hub',
        'date' => '2026-01-20', 'tone' => 'cyan', 'badge' => 'Demo', 'icon' => 'fa-robot',
        'title' => ['en' => 'AI Platform hub & WordPress demo', 'no' => 'AI-plattform hub og WordPress demo', 'ua' => 'AI Платформа та WordPress demo', 'ru' => 'AI Платформа и WordPress demo'],
        'desc' => ['en' => 'Central AI tools hub — Grok xAI, OpenAI, live WordPress plugin demo.', 'no' => 'Sentral AI-hub — Grok xAI, OpenAI, live WordPress plugin demo.', 'ua' => 'Центральний AI-хаб — Grok xAI, OpenAI, live demo WordPress-плагіна.', 'ru' => 'Центральный AI-хаб — Grok xAI, OpenAI, live demo WordPress-плагина.'],
        'url' => 'https://bilohash.com/ai/', 'demo' => 'https://bilohash.com/ai/wordpress/', 'product' => null,
    ],
    [
        'item_key' => 'horizon-template',
        'date' => '2025-12-01', 'tone' => 'cyan', 'badge' => 'Template', 'icon' => 'fa-palette',
        'title' => ['en' => 'Horizon Admin Template', 'no' => 'Horizon Admin-mal', 'ua' => 'Horizon Admin Template', 'ru' => 'Horizon Admin Template'],
        'desc' => ['en' => 'Modern responsive admin panel template — rapid deployment ready.', 'no' => 'Moderne responsiv admin-mal — klar for rask utrulling.', 'ua' => 'Сучасний адаптивний шаблон адмін-панелі — готовий до швидкого впровадження.', 'ru' => 'Современный адаптивный шаблон админ-панели — готов к быстрому внедрению.'],
        'url' => 'https://bilohash.com/themeforest/horizon', 'demo' => 'https://bilohash.com/themeforest/horizon', 'product' => null,
    ],
    [
        'item_key' => 'medibook-template',
        'date' => '2025-11-01', 'tone' => 'sky', 'badge' => 'Template', 'icon' => 'fa-hospital',
        'title' => ['en' => 'MediBook Clinic — medical booking', 'no' => 'MediBook Clinic — medisinsk booking', 'ua' => 'MediBook Clinic — медичне бронювання', 'ru' => 'MediBook Clinic — медицинское бронирование'],
        'desc' => ['en' => 'Clinic management — appointments, patients, admin panel.', 'no' => 'Klinikkstyring — timer, pasienter, adminpanel.', 'ua' => 'Керування клінікою — записи, пацієнти, адмін-панель.', 'ru' => 'Управление клиникой — записи, пациенты, админ-панель.'],
        'url' => 'https://bilohash.com/themeforest/MediBookClinic', 'demo' => 'https://bilohash.com/themeforest/MediBookClinic', 'product' => null,
    ],
    [
        'item_key' => 'developer-site',
        'date' => '2025-10-01', 'tone' => 'cyan', 'badge' => 'Site', 'icon' => 'fa-code',
        'title' => ['en' => 'Developer Website CMS', 'no' => 'Utvikler-nettside CMS', 'ua' => 'Сайт розробника CMS', 'ru' => 'Сайт разработчика CMS'],
        'desc' => ['en' => 'Portfolio & developer site script — services, contact, multilingual.', 'no' => 'Portefølje- og utviklernettsted — tjenester, kontakt, flerspråklig.', 'ua' => 'Скрипт сайту розробника — послуги, контакт, багатомовність.', 'ru' => 'Скрипт сайта разработчика — услуги, контакт, многоязычность.'],
        'url' => 'https://bilohash.com/website/', 'demo' => 'https://bilohash.com/website/', 'product' => null,
    ],
];

if (defined('BH_NEWS_EXPORT_DATA')) {
    return ['cms_products' => $cms_products, 'modules' => $modules, 'all_news' => $all_news];
}

require_once __DIR__ . '/../includes/portfolio-news-hub.php';
$hubData = portfolio_news_hub_load();
if ($hubData !== null) {
    $cms_products = $hubData['cms_products'];
    $modules = $hubData['modules'];
    $all_news = $hubData['all_news'];
}

/** Keep auction/pizza off amber-orange even when hub JSON still has legacy tones. */
$news_tone_overrides = [
    'auction' => 'sky',
    'auction-release' => 'sky',
    'pizza' => 'rose',
    'pizza-launch' => 'rose',
];
$news_tone_remap = ['amber' => 'sky', 'orange' => 'rose'];
$news_tone_patch = static function (array &$rows) use ($news_tone_overrides, $news_tone_remap): void {
    foreach ($rows as &$row) {
        $key = (string) ($row['item_key'] ?? '');
        if ($key !== '' && isset($news_tone_overrides[$key])) {
            $row['tone'] = $news_tone_overrides[$key];
            continue;
        }
        $icon = (string) ($row['icon'] ?? '');
        if ($icon === 'fa-gavel' || str_contains($icon, 'gavel')) {
            $row['tone'] = 'sky';
            continue;
        }
        if ($icon === 'fa-pizza-slice' || str_contains($icon, 'pizza')) {
            $row['tone'] = 'rose';
            continue;
        }
        $tone = (string) ($row['tone'] ?? '');
        if (isset($news_tone_remap[$tone])) {
            $row['tone'] = $news_tone_remap[$tone];
        }
    }
    unset($row);
};
$news_tone_patch($cms_products);
$news_tone_patch($modules);
$news_tone_patch($all_news);

require __DIR__ . '/i18n-overlays.php';
news_i18n_merge_by_key($cms_products, $news_i18n_cms);
news_i18n_merge_by_key($modules, $news_i18n_modules);
news_i18n_merge_by_key($all_news, $news_i18n_feed);

$html_lang = portfolio_seo_regions()[$lang]['html_lang'] ?? 'en';

$lang_q = $lang !== 'en' ? '?lang=' . urlencode($lang) : '';
$home_url = portfolio_seo_lang_url($lang, '/');
$footer_home = '/news/' . $lang_q;
require __DIR__ . '/../includes/portfolio-footer-i18n.php';
if (is_file(__DIR__ . '/../includes/portfolio-brand.php')) {
    require_once __DIR__ . '/../includes/portfolio-brand.php';
}
$bh_site_nav_icon = defined('BH_SITE_NAV_ICON') ? BH_SITE_NAV_ICON : 'fas fa-hexagon-nodes';
foreach ($ft['nav_links'] as &$nav_link) {
    if (str_starts_with($nav_link['url'], '/#')) {
        $nav_link['url'] = '/' . $lang_q . substr($nav_link['url'], 1);
    } elseif (in_array($nav_link['url'], ['/contact.php', '/about.php', '/resume.php', '/ecosystem/submit.php', '/ecosystem/join.php'], true)) {
        $nav_link['url'] = $nav_link['url'] . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');
    }
}
unset($nav_link);
require_once __DIR__ . '/../includes/portfolio-contact.php';

$pf_contact_alert = '';
$pf_contact_alert_type = '';
$pf_contact_values = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['portfolio_contact'])) {
    $pf_result = portfolio_contact_handle_post($lang, 'https://bilohash.com/news/#contact');
    $pf_contact_alert = $pf_result['alert'];
    $pf_contact_alert_type = $pf_result['alert_type'];
    $pf_contact_values = $pf_result['values'];
}
$pf_csrf = portfolio_contact_ensure_csrf();
$pf_form_action = '/news/' . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');
$pf_section_contact = news_txt($section['contact']);

$tone_map = [
    'red' => ['border' => 'border-red-900/50 hover:border-red-400/60', 'text' => 'text-red-400', 'bg' => 'bg-red-500 hover:bg-red-400', 'badge' => 'bg-red-400/10 text-red-400'],
    'amber' => ['border' => 'border-sky-900/50 hover:border-sky-400/60', 'text' => 'text-sky-400', 'bg' => 'bg-sky-500 hover:bg-sky-400', 'badge' => 'bg-sky-400/10 text-sky-400'],
    'sky' => ['border' => 'border-sky-900/50 hover:border-sky-400/60', 'text' => 'text-sky-400', 'bg' => 'bg-sky-500 hover:bg-sky-400', 'badge' => 'bg-sky-400/10 text-sky-400'],
    'teal' => ['border' => 'border-teal-900/50 hover:border-teal-400/60', 'text' => 'text-teal-400', 'bg' => 'bg-teal-500 hover:bg-teal-400', 'badge' => 'bg-teal-400/10 text-teal-400'],
    'emerald' => ['border' => 'border-emerald-900/50 hover:border-emerald-400/60', 'text' => 'text-emerald-400', 'bg' => 'bg-emerald-500 hover:bg-emerald-400', 'badge' => 'bg-emerald-400/10 text-emerald-400'],
    'rose' => ['border' => 'border-rose-900/50 hover:border-rose-400/60', 'text' => 'text-rose-400', 'bg' => 'bg-rose-500 hover:bg-rose-400', 'badge' => 'bg-rose-400/10 text-rose-400'],
    'cyan' => ['border' => 'border-cyan-900/50 hover:border-cyan-400/60', 'text' => 'text-cyan-400', 'bg' => 'bg-cyan-500 hover:bg-cyan-400', 'badge' => 'bg-cyan-400/10 text-cyan-400'],
    'orange' => ['border' => 'border-rose-900/50 hover:border-rose-400/60', 'text' => 'text-rose-400', 'bg' => 'bg-rose-500 hover:bg-rose-400', 'badge' => 'bg-rose-400/10 text-rose-400'],
];

$news_schema_items = [];
foreach ($all_news as $n) {
    $news_schema_items[] = [
        '@type'    => 'ListItem',
        'position' => count($news_schema_items) + 1,
        'url'      => str_starts_with($n['url'], 'http') ? $n['url'] : 'https://bilohash.com' . $n['url'],
        'name'     => portfolio_seo_pick($n['title'], $lang),
    ];
}
$news_schema = [
    '@context' => 'https://schema.org',
    '@type'    => 'CollectionPage',
    'name'     => portfolio_seo_pick($og_titles, $lang),
    'description' => portfolio_seo_pick($og_descriptions, $lang),
    'url'      => $canonical_url,
    'inLanguage' => portfolio_seo_regions()[$lang]['hreflang'],
    'isPartOf' => ['@type' => 'WebSite', 'name' => 'BILOHASH', 'url' => 'https://bilohash.com'],
    'publisher' => [
        '@type' => 'Organization',
        'name'  => 'BILOHASH',
        'url'   => 'https://bilohash.com',
        'areaServed' => array_column(portfolio_seo_regions(), 'country'),
    ],
    'mainEntity' => [
        '@type' => 'ItemList',
        'numberOfItems' => count($news_schema_items),
        'itemListElement' => $news_schema_items,
    ],
];
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($html_lang) ?>" itemscope itemtype="https://schema.org/CollectionPage">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    portfolio_seo_render_head([
        'lang'        => $lang,
        'title'       => portfolio_seo_pick($og_titles, $lang),
        'description' => portfolio_seo_pick($og_descriptions, $lang),
        'keywords'    => portfolio_seo_pick($seo_keywords, $lang),
        'canonical'   => $canonical_url,
        'path'        => '/news/',
        'og_image'    => news_shot('https://bilohash.com/tavle/assets/images/og-landing.svg'),
        'schema'      => $news_schema,
    ]);
    ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&amp;family=Space+Grotesk:wght@500;600&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="/includes/portfolio-contact.css?v=4">
    <?php include dirname(__DIR__) . '/includes/ecosystem-hub-css.php'; ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        .font-display { font-family: 'Space Grotesk', 'Inter', system-ui, sans-serif; }
        .section-header { font-size: 1.875rem; line-height: 1.1; font-weight: 700; letter-spacing: -.025em; }
        .modern-card { background: #0f172a; border: 1px solid #1e2937; }
        .nav-link:hover { color: #22d3ee; }
        .lang-btn.active { background: #164e63; color: #67e8f9; border-color: #22d3ee; }
        .news-nav-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            min-height: 3.5rem;
        }
        @media (min-width: 1024px) {
            .news-nav-inner { min-height: 4rem; }
        }
        .news-brand-wrap {
            min-width: 0;
            flex-shrink: 0;
        }
        .news-brand-text { display: none; }
        @media (min-width: 400px) {
            .news-brand-text { display: inline; }
        }
        .news-nav-desktop {
            display: none;
            align-items: center;
            justify-content: center;
            flex: 1 1 auto;
            min-width: 0;
            margin: 0 .25rem;
            gap: .15rem .35rem;
            font-size: .75rem;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .news-nav-desktop::-webkit-scrollbar { display: none; }
        @media (min-width: 1024px) {
            .news-nav-desktop { display: flex; }
        }
        @media (min-width: 1280px) {
            .news-nav-desktop {
                gap: .25rem .85rem;
                font-size: .8125rem;
            }
        }
        @media (min-width: 1536px) {
            .news-nav-desktop {
                gap: .35rem 1.25rem;
                font-size: .875rem;
            }
        }
        .news-nav-desktop a {
            padding: .35rem .45rem;
            border-radius: .5rem;
            transition: color .15s, background .15s;
            white-space: nowrap;
            flex-shrink: 0;
        }
        @media (min-width: 1280px) {
            .news-nav-desktop a { padding: .35rem .55rem; }
        }
        .news-nav-desktop a:hover {
            background: rgba(34, 211, 238, .08);
        }
        .news-nav-tools {
            display: flex;
            align-items: center;
            gap: .5rem;
            flex-shrink: 0;
        }
        .news-nav-cta {
            display: none;
            align-items: center;
            background: #fff;
            color: #020617;
            font-weight: 600;
            font-size: .8125rem;
            padding: 0 .9rem;
            height: 2.35rem;
            border-radius: 1rem;
        }
        .news-nav-cta:hover { background: #f1f5f9; }
        @media (min-width: 640px) {
            .news-nav-cta { display: inline-flex; }
        }
        @media (min-width: 1024px) and (max-width: 1279px) {
            .news-nav-cta { display: none; }
        }
        .news-menu-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 2.5rem;
            height: 2.5rem;
            border-radius: .75rem;
            border: 1px solid #334155;
            background: #0f172a;
            color: #e2e8f0;
            cursor: pointer;
        }
        .news-menu-btn:hover { border-color: #22d3ee; color: #22d3ee; }
        @media (min-width: 1024px) {
            .news-menu-btn { display: none !important; }
            .news-mobile-panel { display: none !important; }
        }
        .news-mobile-panel {
            border-top: 1px solid #1e293b;
            background: rgba(2, 6, 23, .98);
            padding: 1rem 1.25rem 1.25rem;
        }
        .news-mobile-panel[hidden] { display: none !important; }
        .news-mobile-nav {
            display: flex;
            flex-direction: column;
            gap: .15rem;
        }
        .news-mobile-nav a {
            display: flex;
            align-items: center;
            gap: .65rem;
            padding: .75rem .85rem;
            border-radius: .75rem;
            color: #cbd5e1;
            font-weight: 500;
            font-size: .95rem;
            text-decoration: none;
        }
        .news-mobile-nav a:hover,
        .news-mobile-nav a:focus-visible {
            background: rgba(34, 211, 238, .08);
            color: #22d3ee;
        }
        .news-mobile-nav a i { width: 1.1rem; text-align: center; opacity: .75; font-size: .85rem; }
        .news-mobile-lang {
            display: flex;
            flex-wrap: wrap;
            gap: .4rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #1e293b;
        }
        @media (min-width: 480px) {
            .news-mobile-lang { display: none; }
        }
        .news-mobile-lang .lang-btn {
            padding: .45rem .85rem;
            border-radius: 999px;
            border: 1px solid #334155;
            color: #94a3b8;
            font-size: .8rem;
            font-weight: 600;
            text-decoration: none;
        }
        .news-mobile-cta {
            display: flex;
            margin-top: .85rem;
        }
        .news-mobile-cta a {
            flex: 1;
            text-align: center;
            background: #22d3ee;
            color: #020617;
            font-weight: 700;
            padding: .75rem 1rem;
            border-radius: .85rem;
            text-decoration: none;
        }
        @media (min-width: 640px) {
            .news-mobile-cta { display: none; }
        }
        body.news-nav-open { overflow: hidden; }
        #newsNav { overflow: visible; }
        .news-nav-inner, .news-nav-tools { overflow: visible; }
        .news-mobile-panel { overflow: visible; }

        .product-card { transition: transform .25s ease, border-color .25s ease; }
        .product-card:hover { transform: translateY(-4px); }
        .news-feed-item { transition: border-color .2s ease, background .2s ease; }
        .news-feed-item:hover { border-color: rgba(34, 211, 238, .35); background: rgba(15, 23, 42, .6); }
        .product-shot {
            display: block;
            border-radius: 1rem;
            overflow: hidden;
            border: 1px solid #1e2937;
            margin: -0.25rem -0.25rem 1rem;
            aspect-ratio: 16 / 10;
            background: #020617;
            cursor: zoom-in;
            padding: 0;
        }
        .product-shot img,
        .demo-shot-btn img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: top center;
            transition: transform .35s ease;
        }
        .product-shot img[src$=".svg"],
        .demo-shot-btn img[src$=".svg"] {
            object-fit: contain;
            background: #020617;
            padding: .35rem;
        }
        .product-card:hover .product-shot img { transform: scale(1.03); }
        .demo-shot-btn {
            cursor: zoom-in;
            border: 1px solid #1e2937;
            border-radius: .85rem;
            overflow: hidden;
            background: #020617;
            transition: border-color .2s ease, transform .2s ease;
        }
        .demo-shot-btn:hover { border-color: rgba(34, 211, 238, .45); transform: translateY(-2px); }
        .demo-shot-btn img { width: 100%; height: auto; display: block; aspect-ratio: 16 / 10; }
        .demo-gallery-grid {
            display: grid;
            gap: 1.25rem;
            grid-template-columns: 1fr;
        }
        @media (min-width: 768px) {
            .demo-gallery-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (min-width: 1280px) {
            .demo-gallery-grid { grid-template-columns: repeat(3, 1fr); }
        }
        .demo-gallery-card {
            background: #0f172a;
            border: 1px solid #1e2937;
            border-radius: 1.25rem;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: .75rem;
        }
        .demo-gallery-shots {
            display: grid;
            gap: .5rem;
            grid-template-columns: 1fr 1fr;
        }
        .demo-gallery-shots.single { grid-template-columns: 1fr; }
        #shotLightbox[hidden] { display: none !important; }
        #shotLightbox {
            position: fixed; inset: 0; z-index: 200;
            background: rgba(2, 6, 23, .92);
            display: flex; align-items: center; justify-content: center;
            padding: 1.5rem;
        }
        #shotLightbox img {
            max-width: min(1200px, 100%);
            max-height: 90vh;
            border-radius: .75rem;
            border: 1px solid #334155;
            box-shadow: 0 25px 60px rgba(0,0,0,.5);
        }
        #shotLightboxClose {
            position: absolute; top: 1rem; right: 1rem;
            width: 2.5rem; height: 2.5rem; border-radius: 999px;
            border: 1px solid #334155; background: #0f172a; color: #e2e8f0;
            cursor: pointer; font-size: 1.25rem;
        }
    </style>
    <?php include __DIR__ . '/../includes/portfolio-footer-css.php'; ?>
    <?php require __DIR__ . '/lang-dropdown-assets.php'; ?>
</head>
<body class="bg-slate-950 text-slate-200">
    <nav class="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/95 backdrop-blur-xl" id="newsNav" aria-label="<?= htmlspecialchars(news_txt($labels['menu'])) ?>">
        <div class="max-w-screen-2xl mx-auto px-5 sm:px-6 md:px-10">
            <div class="news-nav-inner">
                <a href="<?= htmlspecialchars($home_url) ?>" class="news-brand-wrap flex items-center gap-2 sm:gap-3 group min-w-0">
                    <div class="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-400 to-teal-400 flex items-center justify-center shrink-0">
                        <span class="text-slate-950 font-bold text-sm">BH</span>
                    </div>
                    <span class="news-brand-text font-semibold text-base sm:text-lg group-hover:text-cyan-400 transition-colors truncate">BILOHASH.com</span>
                </a>

                <div class="news-nav-desktop" aria-label="<?= htmlspecialchars(news_txt($labels['menu'])) ?>">
                    <a href="<?= htmlspecialchars($home_url) ?>#projects" class="nav-link text-slate-300 font-medium"><?= news_txt($labels['home']) ?></a>
                    <a href="#demos" class="nav-link text-slate-300 font-medium"><?= news_txt($section['demos']) ?></a>
                    <a href="#cms" class="nav-link text-slate-300 font-medium"><?= news_txt($section['cms']) ?></a>
                    <a href="#modules" class="nav-link text-slate-300 font-medium"><?= news_txt($section['modules']) ?></a>
                    <a href="#all-news" class="nav-link text-slate-300 font-medium"><?= news_txt($section['all_news']) ?></a>

                    <a href="/about.php<?= $lang !== 'en' ? '?lang=' . urlencode($lang) : '' ?>" class="nav-link text-slate-300 font-medium"><?= news_txt($labels['developer']) ?></a>
                    <a href="#contact" class="nav-link text-slate-300 font-medium"><?= news_txt($section['contact']) ?></a>
                </div>

                <div class="news-nav-tools">
                    <?php require __DIR__ . '/lang-dropdown.php'; ?>
                    <a href="#contact" class="news-nav-cta whitespace-nowrap"><?= news_txt($section['contact']) ?></a>
                    <button type="button" class="news-menu-btn" id="newsMenuBtn"
                            aria-expanded="false" aria-controls="newsMobilePanel"
                            aria-label="<?= htmlspecialchars(news_txt($labels['menu'])) ?>">
                        <i class="fas fa-bars" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </div>

        <div class="news-mobile-panel max-w-screen-2xl mx-auto px-5 sm:px-6 md:px-10" id="newsMobilePanel" hidden>
            <nav class="news-mobile-nav" aria-label="<?= htmlspecialchars(news_txt($labels['menu'])) ?>">
                <a href="<?= htmlspecialchars($home_url) ?>#projects"><i class="fas fa-rocket"></i> <?= news_txt($labels['home']) ?></a>
                <a href="#demos"><i class="fas fa-images"></i> <?= news_txt($section['demos']) ?></a>
                <a href="#cms"><i class="fas fa-code"></i> <?= news_txt($section['cms']) ?></a>
                <a href="#modules"><i class="fas fa-puzzle-piece"></i> <?= news_txt($section['modules']) ?></a>
                <a href="#all-news"><i class="fas fa-newspaper"></i> <?= news_txt($section['all_news']) ?></a>

                <a href="/about.php<?= $lang !== 'en' ? '?lang=' . urlencode($lang) : '' ?>"><i class="<?= htmlspecialchars($bh_site_nav_icon) ?>"></i> <?= news_txt($labels['developer']) ?></a>
                <a href="#contact"><i class="fas fa-comments"></i> <?= news_txt($section['contact']) ?></a>
            </nav>
            <div class="news-mobile-lang px-1">
                <?php
                $bh_lang_dropdown_id = 'bhLangMobile';
                require __DIR__ . '/lang-dropdown.php';
                ?>
            </div>
            <div class="news-mobile-cta">
                <a href="#contact"><?= news_txt($section['contact']) ?></a>
            </div>
        </div>
    </nav>

    <header class="max-w-screen-2xl mx-auto px-6 md:px-10 pt-14 pb-12 border-b border-slate-800">
        <div class="grid md:grid-cols-12 gap-x-10 gap-y-10 items-center">
            <div class="md:col-span-6">
                <a href="<?= htmlspecialchars($home_url) ?>" class="inline-flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 mb-6">
                    <i class="fas fa-arrow-left text-xs"></i> <?= htmlspecialchars(news_txt($ecosystem)) ?>
                </a>
                <p class="text-xs uppercase tracking-[.2em] text-cyan-400 font-semibold mb-3"><?= news_txt($section['releases']) ?></p>
                <h1 class="font-display text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight mb-4">
                    <?= htmlspecialchars(news_txt($hero_h1)) ?>
                </h1>
                <p class="text-xl text-cyan-400/90 font-semibold mb-4"><?= htmlspecialchars(news_txt($hero_sub)) ?></p>
                <p class="text-lg text-slate-400 max-w-3xl leading-relaxed mb-8"><?= htmlspecialchars(news_txt($hero_tagline)) ?></p>
                <div class="flex flex-wrap gap-3">
                    <a href="#all-news" class="inline-flex items-center gap-2 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold px-7 h-11 rounded-2xl">
                        <?= news_txt($section['all_news']) ?> <i class="fas fa-arrow-down text-xs"></i>
                    </a>
                    <a href="#demos" class="inline-flex items-center gap-2 border border-slate-700 hover:border-cyan-400 font-medium px-6 h-11 rounded-2xl">
                        <i class="fas fa-images"></i> <?= news_txt($section['demos']) ?>
                    </a>
                    <a href="#cms" class="inline-flex items-center gap-2 border border-slate-700 hover:border-cyan-400 font-medium px-6 h-11 rounded-2xl">
                        <?= news_txt($section['cms']) ?>
                    </a>

                    <a href="<?= htmlspecialchars($home_url) ?>" class="inline-flex items-center gap-2 border border-slate-700 hover:border-cyan-400 font-medium px-6 h-11 rounded-2xl">
                        <i class="fas fa-rocket"></i> <?= news_txt($labels['home']) ?>
                    </a>
                </div>
            </div>
            <div class="md:col-span-6">
                <?php
                $eco_hub_caption = news_txt($hero_hub_caption);
                include dirname(__DIR__) . '/includes/ecosystem-hub-visual.php';
                ?>
            </div>
        </div>
    </header>

    <section id="demos" class="bg-slate-900 py-14 border-b border-slate-800">
        <div class="max-w-screen-2xl mx-auto px-6 md:px-10">
            <div class="mb-10">
                <p class="text-xs uppercase tracking-[.2em] text-cyan-400 font-semibold mb-2"><?= news_txt($section['demos']) ?></p>
                <h2 class="section-header">
                    <?= htmlspecialchars(news_txt($section_h2['demos'])) ?>
                </h2>
                <p class="text-slate-400 mt-2 max-w-2xl"><?= htmlspecialchars(news_txt($demo_gallery_intro)) ?></p>
            </div>
            <div class="demo-gallery-grid">
                <?php foreach ($demo_gallery as $g):
                    $gt = $tone_map[$g['tone']] ?? $tone_map['cyan'];
                    $shot_count = count($g['shots']);
                ?>
                <article class="demo-gallery-card border <?= $gt['border'] ?>">
                    <div class="flex items-center justify-between gap-2">
                        <h3 class="font-semibold text-base <?= $gt['text'] ?>"><?= htmlspecialchars($g['title']) ?></h3>
                        <a href="<?= htmlspecialchars($g['demo']) ?>" target="_blank" rel="noopener"
                           class="text-xs font-medium text-slate-500 hover:text-cyan-400 shrink-0">
                            <?= news_txt($labels['demo']) ?> →
                        </a>
                    </div>
                    <div class="demo-gallery-shots<?= $shot_count === 1 ? ' single' : '' ?>">
                        <?php foreach ($g['shots'] as $shot): ?>
                        <figure>
                            <button type="button" class="demo-shot-btn w-full text-left"
                                    data-shot-src="<?= htmlspecialchars($shot['src']) ?>"
                                    data-shot-alt="<?= htmlspecialchars($g['title'] . ' — ' . $shot['label']) ?>">
                                <img src="<?= htmlspecialchars($shot['src']) ?>"
                                     alt="<?= htmlspecialchars($g['title'] . ' — ' . $shot['label']) ?>"
                                     loading="lazy" width="640" height="400">
                            </button>
                            <figcaption class="text-[10px] text-slate-500 mt-1.5 px-0.5 uppercase tracking-wide"><?= htmlspecialchars($shot['label']) ?></figcaption>
                        </figure>
                        <?php endforeach; ?>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section id="cms" class="max-w-screen-2xl mx-auto px-6 md:px-10 py-14">
        <div class="mb-8">
            <p class="text-xs uppercase tracking-[.2em] text-cyan-400 font-semibold mb-2"><?= news_txt($section['cms']) ?></p>
            <h2 class="section-header"><?= htmlspecialchars(news_txt($section_h2['cms'])) ?></h2>
        </div>
        <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
            <?php foreach ($cms_products as $p):
                $t = $tone_map[$p['tone']] ?? $tone_map['cyan'];
            ?>
            <article class="product-card modern-card rounded-3xl p-7 border <?= $t['border'] ?> flex flex-col overflow-hidden">
                <?php if (!empty($p['screenshot'])): ?>
                <button type="button" class="product-shot w-full text-left"
                        data-shot-src="<?= htmlspecialchars(news_shot($p['screenshot'])) ?>"
                        data-shot-alt="<?= htmlspecialchars(news_txt($p['title']) . ' — ' . news_txt($shot_labels['frontend'])) ?>"
                        title="<?= htmlspecialchars(news_txt($p['title'])) ?>">
                    <img src="<?= htmlspecialchars(news_shot($p['screenshot'])) ?>" alt="<?= htmlspecialchars(news_txt($p['title'])) ?> demo" loading="lazy" width="640" height="400">
                </button>
                <?php endif; ?>
                <div class="flex items-start justify-between mb-4">
                    <i class="fas <?= $p['icon'] ?> text-3xl <?= $t['text'] ?>"></i>
                    <span class="text-[10px] font-semibold px-2.5 py-0.5 rounded-full <?= $t['badge'] ?>"><?= htmlspecialchars(news_badge_label($p['badge'])) ?></span>
                </div>
                <h3 class="font-semibold text-2xl mb-1 group-hover:<?= $t['text'] ?>"><?= htmlspecialchars(news_txt($p['title'])) ?></h3>
                <?php if (!empty($p['date'])): ?>
                <p class="text-xs text-slate-500 mb-3"><?= htmlspecialchars($p['date']) ?></p>
                <?php endif; ?>
                <p class="text-sm text-slate-400 leading-relaxed mb-5 flex-1"><?= htmlspecialchars(news_txt($p['desc'])) ?></p>
                <?php $product_btn = 'inline-flex items-center gap-1.5 border border-slate-700 hover:border-current ' . $t['text'] . ' text-sm font-medium px-4 h-9 rounded-xl transition hover:bg-slate-900/60'; ?>
                <div class="flex flex-wrap gap-2 mb-3">
                    <a href="<?= htmlspecialchars($p['demo']) ?>" target="_blank" rel="noopener"
                       class="<?= $product_btn ?>">
                        <i class="fas fa-globe text-xs"></i> <?= news_txt($labels['demo']) ?>
                    </a>
                    <?php if (!empty($p['admin_url'])): ?>
                    <a href="<?= htmlspecialchars($p['admin_url']) ?>" target="_blank" rel="noopener"
                       class="<?= $product_btn ?>">
                        <i class="fas fa-user-shield text-xs"></i> <?= news_txt($labels['admin']) ?>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($p['site_url'])): ?>
                    <a href="<?= htmlspecialchars($p['site_url']) ?>" target="_blank" rel="noopener"
                       class="<?= $product_btn ?>">
                        <i class="fas fa-book text-xs"></i> <?= news_txt($labels['product']) ?>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($p['release_url'])): ?>
                    <a href="<?= htmlspecialchars(news_url_with_lang($p['release_url'])) ?>"
                       class="<?= $product_btn ?>">
                        <i class="fas fa-newspaper text-xs"></i> <?= news_txt($labels['release']) ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php if (!empty($p['admin_cred'])): ?>
                <p class="text-xs text-slate-500 font-mono"><?= htmlspecialchars($p['admin_cred']) ?></p>
                <?php endif; ?>
            </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="modules" class="bg-slate-950 py-14 border-b border-slate-800">
        <div class="max-w-screen-2xl mx-auto px-6 md:px-10">
            <div class="mb-8">
                <p class="text-xs uppercase tracking-[.2em] text-emerald-400 font-semibold mb-2"><?= news_txt($section['modules']) ?></p>
                <h2 class="section-header"><?= htmlspecialchars(news_txt($section_h2['modules'])) ?></h2>
            </div>
            <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                <?php foreach ($modules as $m):
                    $t = $tone_map[$m['tone']] ?? $tone_map['cyan'];
                ?>
                <article class="product-card modern-card rounded-3xl p-6 border border-slate-800 <?= $t['border'] ?> flex flex-col h-full">
                    <div class="flex items-center justify-between mb-4">
                        <i class="<?= htmlspecialchars(news_icon_class($m['icon'])) ?> text-2xl <?= $t['text'] ?>"></i>
                        <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full <?= $t['badge'] ?>"><?= htmlspecialchars(news_badge_label($m['badge'])) ?></span>
                    </div>
                    <h3 class="font-semibold text-lg mb-2"><?= htmlspecialchars(news_txt($m['title'])) ?></h3>
                    <p class="text-sm text-slate-400 flex-1 mb-4"><?= htmlspecialchars(news_txt($m['desc'])) ?></p>
                    <div class="flex flex-wrap gap-2 mt-auto">
                        <a href="<?= htmlspecialchars($m['demo']) ?>" target="_blank" rel="noopener"
                           class="text-sm font-medium <?= $t['text'] ?> hover:underline"><?= news_txt($labels['demo']) ?> →</a>
                        <?php if (!empty($m['release_url']) && $m['release_url'] !== $m['demo']): ?>
                        <a href="<?= htmlspecialchars(news_url_with_lang($m['release_url'])) ?>"
                           class="text-sm font-medium text-slate-400 hover:text-cyan-400"><?= news_txt($labels['release']) ?> →</a>
                        <?php endif; ?>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section id="all-news" class="max-w-screen-2xl mx-auto px-6 md:px-10 py-14 border-b border-slate-800">
        <div class="mb-8">
            <p class="text-xs uppercase tracking-[.2em] text-cyan-400 font-semibold mb-2"><?= news_txt($section['all_news']) ?></p>
            <h2 class="section-header">
                <?= htmlspecialchars(news_txt($section_h2['timeline_title'])) ?>
            </h2>
            <p class="text-slate-400 mt-2 max-w-2xl">
                <?= htmlspecialchars(news_txt($section_h2['timeline_desc'])) ?>
            </p>
        </div>
        <div class="space-y-3">
            <?php foreach ($all_news as $n):
                $t = $tone_map[$n['tone']] ?? $tone_map['cyan'];
                $feed_url = news_url_with_lang($n['url']);
                $is_external = str_starts_with($n['url'], 'http');
            ?>
            <article class="news-feed-item modern-card rounded-2xl p-5 md:p-6 border border-slate-800 flex flex-col md:flex-row md:items-center gap-4">
                <div class="flex items-start gap-4 flex-1 min-w-0">
                    <div class="w-11 h-11 shrink-0 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center <?= $t['text'] ?>">
                        <i class="<?= htmlspecialchars(news_icon_class($n['icon'])) ?>"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="flex flex-wrap items-center gap-2 mb-1">
                            <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full <?= $t['badge'] ?>"><?= htmlspecialchars(news_badge_label($n['badge'])) ?></span>
                            <span class="text-xs text-slate-500"><?= htmlspecialchars($n['date']) ?></span>
                        </div>
                        <h3 class="font-semibold text-lg tracking-tight mb-1"><?= htmlspecialchars(news_txt($n['title'])) ?></h3>
                        <p class="text-sm text-slate-400 leading-relaxed"><?= htmlspecialchars(news_txt($n['desc'])) ?></p>
                    </div>
                </div>
                <?php $feed_btn = 'inline-flex items-center gap-1.5 border border-slate-700 hover:border-current ' . $t['text'] . ' text-sm font-medium px-4 h-9 rounded-xl transition hover:bg-slate-900/60'; ?>
                <div class="flex flex-wrap gap-2 shrink-0 md:justify-end">
                    <a href="<?= htmlspecialchars($feed_url) ?>" <?= $is_external ? 'target="_blank" rel="noopener"' : '' ?>
                       class="<?= $feed_btn ?>">
                        <i class="fas fa-newspaper text-xs"></i> <?= news_txt($labels['read']) ?>
                    </a>
                    <?php if (!empty($n['demo']) && $n['demo'] !== $n['url']): ?>
                    <a href="<?= htmlspecialchars($n['demo']) ?>" target="_blank" rel="noopener"
                       class="<?= $feed_btn ?>">
                        <i class="fas fa-globe text-xs"></i> <?= news_txt($labels['demo']) ?>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($n['product']) && $n['product'] !== $n['url']): ?>
                    <a href="<?= htmlspecialchars($n['product']) ?>" target="_blank" rel="noopener"
                       class="<?= $feed_btn ?>">
                        <i class="fas fa-book text-xs"></i>
                        <?= str_contains($n['product'], 'changelog') ? news_txt($labels['changelog']) : news_txt($labels['product']) ?>
                    </a>
                    <?php endif; ?>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="contact" class="max-w-screen-2xl mx-auto px-6 md:px-10 py-20">
        <?php
        $pf_contact_cta = news_txt($contact_cta);
        include __DIR__ . '/../includes/portfolio-contact-section.php';
        ?>
    </section>

    <?php
    $bh_lang_dropdown_include = __DIR__ . '/lang-dropdown.php';
    include __DIR__ . '/../includes/portfolio-footer.php';
    ?>

    <?php
    $gdpr_lang_map = ['en' => 'en', 'no' => 'no', 'ua' => 'uk', 'lt' => 'lt', 'pl' => 'pl', 'de' => 'de', 'sv' => 'sv'];
    $gdpr_lang = $gdpr_lang_map[$lang] ?? 'en';
    $gdpr_privacy_url = '/website/privacy-policy.php';
    $gdpr_cookies_url = '/website/cookies.php';
    $gdpr_storage_key = 'news_gdpr_consent';
    include __DIR__ . '/../includes/gdpr-consent.php';
    ?>

    <div id="shotLightbox" hidden role="dialog" aria-modal="true" aria-label="Screenshot preview">
        <button type="button" id="shotLightboxClose" aria-label="Close">&times;</button>
        <img src="" alt="" id="shotLightboxImg">
    </div>
    <script>
    (function () {
        var menuBtn = document.getElementById('newsMenuBtn');
        var mobilePanel = document.getElementById('newsMobilePanel');
        if (menuBtn && mobilePanel) {
            var icon = menuBtn.querySelector('i');
            function setMenuOpen(open) {
                mobilePanel.hidden = !open;
                menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
                menuBtn.setAttribute('aria-label', open ? <?= json_encode(news_txt($labels['close'])) ?> : <?= json_encode(news_txt($labels['menu'])) ?>);
                document.body.classList.toggle('news-nav-open', open);
                if (icon) {
                    icon.className = open ? 'fas fa-times' : 'fas fa-bars';
                }
            }
            menuBtn.addEventListener('click', function () {
                setMenuOpen(mobilePanel.hidden);
            });
            mobilePanel.querySelectorAll('.news-mobile-nav a').forEach(function (link) {
                link.addEventListener('click', function () { setMenuOpen(false); });
            });
            window.addEventListener('resize', function () {
                if (window.innerWidth >= 1024) setMenuOpen(false);
            });
        }

        var lb = document.getElementById('shotLightbox');
        var img = document.getElementById('shotLightboxImg');
        var closeBtn = document.getElementById('shotLightboxClose');
        if (!lb || !img) return;
        function openShot(src, alt) {
            img.src = src;
            img.alt = alt || '';
            lb.hidden = false;
            document.body.style.overflow = 'hidden';
        }
        function closeShot() {
            lb.hidden = true;
            img.removeAttribute('src');
            document.body.style.overflow = '';
        }
        document.querySelectorAll('[data-shot-src]').forEach(function (btn) {
            btn.style.cursor = 'zoom-in';
            btn.addEventListener('click', function () {
                openShot(btn.getAttribute('data-shot-src'), btn.getAttribute('data-shot-alt'));
            });
        });
        closeBtn && closeBtn.addEventListener('click', closeShot);
        lb.addEventListener('click', function (e) { if (e.target === lb) closeShot(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !lb.hidden) closeShot(); });
    })();
    </script>
</body>
</html>