<?php
/**
 * CRM AI Consultant — Налаштування Grok (xAI)
 * Version: 4.2 — Розширений реєстр моделей
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die($ta['access_denied'] ?? 'Access denied');
}

$grok_model = crm_ai_resolve_channel_model('grok', $edit_site ?? []);
?>

<div id="settings_grok" class="channel-settings <?= ($edit_site['default_channel'] ?? '') === 'grok' ? '' : 'hidden' ?>">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fas fa-robot text-orange-400 text-2xl"></i>
        <?= htmlspecialchars($ta['settings_grok']['title']) ?>
    </h3>

    <div class="space-y-8">

        <div>
            <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_grok']['api_key']) ?></label>
            <input type="text" name="grok_api_key"
                   value="<?= htmlspecialchars($edit_site['grok_api_key'] ?? '') ?>"
                   class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono text-sm"
                   placeholder="gsk_xxxxxxxxxxxxxxxxxxxxxxxx">
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-3">
                <?= htmlspecialchars($ta['settings_grok']['main_system_prompt']) ?>
            </label>
            <textarea name="system_prompt" rows="12"
                      class="w-full bg-zinc-900 border border-zinc-700 rounded-3xl px-7 py-6 font-mono text-sm leading-relaxed"
                      placeholder="<?= htmlspecialchars($ta['defaults']['grok_system_placeholder']) ?>"><?= htmlspecialchars($edit_site['system_prompt'] ?? $edit_site['grok_system_prompt'] ?? '') ?></textarea>
            <p class="text-xs text-emerald-400 mt-3">
                <?= htmlspecialchars($ta['settings_grok']['main_system_prompt_hint']) ?>
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_grok']['model']) ?></label>
                <?php crm_ai_render_model_select('grok', 'grok_ai_model', $grok_model, $ta); ?>
            </div>

            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_grok']['temperature']) ?></label>
                <select name="grok_temperature" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="0.7" <?= ($edit_site['grok_temperature'] ?? '0.7') === '0.7' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_grok']['temp_balanced']) ?></option>
                    <option value="0.5" <?= ($edit_site['grok_temperature'] ?? '0.7') === '0.5' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_grok']['temp_precise']) ?></option>
                    <option value="1.0" <?= ($edit_site['grok_temperature'] ?? '0.7') === '1.0' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_grok']['temp_creative']) ?></option>
                </select>
                <p class="text-xs text-zinc-500 mt-2"><?= htmlspecialchars($ta['settings_grok']['temperature_hint'] ?? '') ?></p>
            </div>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_grok']['extra_system_prompt']) ?></label>
            <textarea name="grok_system_prompt" rows="6"
                      class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono text-sm"
                      placeholder="<?= htmlspecialchars($ta['defaults']['grok_extra_placeholder']) ?>"><?= htmlspecialchars($edit_site['grok_system_prompt'] ?? '') ?></textarea>
        </div>

    </div>
</div>