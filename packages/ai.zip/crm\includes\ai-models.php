<?php
/**
 * CRM AI Consultant — Chat model registry (Grok / OpenAI)
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

function crm_ai_model_registry(): array
{
    static $registry = null;
    if ($registry !== null) {
        return $registry;
    }

    $registry = [
        'grok' => [
            ['id' => 'grok-4.5', 'group' => 'recommended', 'label_key' => 'grok_45', 'default' => true],
            ['id' => 'grok-4.3', 'group' => 'recommended', 'label_key' => 'grok_43'],
            ['id' => 'grok-4.20', 'group' => 'recommended', 'label_key' => 'grok_420'],
            ['id' => 'grok-4.20-latest', 'group' => 'recommended', 'label_key' => 'grok_420_latest'],
            ['id' => 'grok-4.20-0309-non-reasoning', 'group' => 'fast', 'label_key' => 'grok_420_nr_0309'],
            ['id' => 'grok-4.20-non-reasoning', 'group' => 'fast', 'label_key' => 'grok_420_nr'],
            ['id' => 'grok-4.20-0309-reasoning', 'group' => 'reasoning', 'label_key' => 'grok_420_r_0309', 'no_temperature' => true],
            ['id' => 'grok-4.20-reasoning', 'group' => 'reasoning', 'label_key' => 'grok_420_r', 'no_temperature' => true],
            ['id' => 'grok-4.20-multi-agent-0309', 'group' => 'reasoning', 'label_key' => 'grok_420_multi', 'no_temperature' => true],
        ],
        'openai' => [
            ['id' => 'gpt-5.6', 'group' => 'recommended', 'label_key' => 'gpt_56_sol', 'default' => true],
            ['id' => 'gpt-5.6-sol', 'group' => 'recommended', 'label_key' => 'gpt_56_sol_full'],
            ['id' => 'gpt-5.6-terra', 'group' => 'recommended', 'label_key' => 'gpt_56_terra'],
            ['id' => 'gpt-5.6-luna', 'group' => 'recommended', 'label_key' => 'gpt_56_luna'],
            ['id' => 'gpt-4o', 'group' => 'legacy', 'label_key' => 'gpt_4o'],
            ['id' => 'gpt-4o-mini', 'group' => 'fast', 'label_key' => 'gpt_4o_mini'],
            ['id' => 'o4-mini', 'group' => 'reasoning', 'label_key' => 'o4_mini', 'no_temperature' => true],
            ['id' => 'o3-mini', 'group' => 'reasoning', 'label_key' => 'o3_mini', 'no_temperature' => true],
            ['id' => 'o1', 'group' => 'reasoning', 'label_key' => 'o1', 'no_temperature' => true],
            ['id' => 'o1-preview', 'group' => 'legacy', 'label_key' => 'o1_preview', 'no_temperature' => true],
        ],
    ];

    return $registry;
}

function crm_ai_models_for_provider(string $provider): array
{
    $registry = crm_ai_model_registry();
    return $registry[$provider] ?? [];
}

function crm_ai_model_find(string $provider, string $model_id): ?array
{
    $model_id = trim($model_id);
    if ($model_id === '') {
        return null;
    }
    foreach (crm_ai_models_for_provider($provider) as $model) {
        if ($model['id'] === $model_id) {
            return $model;
        }
    }
    return null;
}

function crm_ai_default_model(string $provider): string
{
    foreach (crm_ai_models_for_provider($provider) as $model) {
        if (!empty($model['default'])) {
            return $model['id'];
        }
    }
    $models = crm_ai_models_for_provider($provider);
    return $models[0]['id'] ?? '';
}

function crm_ai_normalize_model(string $provider, ?string $model_id): string
{
    $model_id = trim((string)$model_id);
    if ($model_id !== '' && crm_ai_model_find($provider, $model_id) !== null) {
        return $model_id;
    }
    return crm_ai_default_model($provider);
}

function crm_ai_model_supports_temperature(string $provider, string $model_id): bool
{
    $model = crm_ai_model_find($provider, $model_id);
    if ($model === null) {
        return true;
    }
    return empty($model['no_temperature']);
}

function crm_ai_model_group_labels(array $ta): array
{
    $labels = $ta['ai_models'] ?? [];
    return [
        'recommended' => $labels['group_recommended'] ?? 'Recommended',
        'fast'        => $labels['group_fast'] ?? 'Fast',
        'reasoning'   => $labels['group_reasoning'] ?? 'Reasoning',
        'legacy'      => $labels['group_legacy'] ?? 'Legacy',
    ];
}

function crm_ai_model_label(array $model, array $ta): string
{
    $key = $model['label_key'] ?? '';
    if ($key !== '' && !empty($ta['ai_models'][$key])) {
        return (string)$ta['ai_models'][$key];
    }
    return $model['id'];
}

function crm_ai_render_model_select(string $provider, string $field_name, ?string $selected, array $ta): void
{
    $selected = crm_ai_normalize_model($provider, $selected);
    $groups = crm_ai_model_group_labels($ta);
    $by_group = [];
    foreach (crm_ai_models_for_provider($provider) as $model) {
        $group = $model['group'] ?? 'recommended';
        $by_group[$group][] = $model;
    }

    echo '<select name="' . htmlspecialchars($field_name) . '" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">';

    $group_order = ['recommended', 'fast', 'reasoning', 'legacy'];
    foreach ($group_order as $group) {
        if (empty($by_group[$group])) {
            continue;
        }
        echo '<optgroup label="' . htmlspecialchars($groups[$group] ?? $group) . '">';
        foreach ($by_group[$group] as $model) {
            $id = $model['id'];
            $sel = $selected === $id ? ' selected' : '';
            echo '<option value="' . htmlspecialchars($id) . '"' . $sel . '>'
                . htmlspecialchars(crm_ai_model_label($model, $ta))
                . '</option>';
        }
        echo '</optgroup>';
    }

    if ($selected !== '' && crm_ai_model_find($provider, $selected) === null) {
        echo '<option value="' . htmlspecialchars($selected) . '" selected>'
            . htmlspecialchars($selected . ' (' . ($ta['ai_models']['custom_saved'] ?? 'saved') . ')')
            . '</option>';
    }

    echo '</select>';
}

function crm_ai_resolve_channel_model(string $provider, array $settings): string
{
    $field = $provider . '_ai_model';
    $saved = $settings[$field] ?? $settings['ai_model'] ?? '';
    return crm_ai_normalize_model($provider, $saved);
}