<?php
/**
 * CRM AI Consultant — Канал Viber
 * Version: 4.0 — Повністю адаптовано під MySQL
 * 
 * Пропонує користувачу написати безпосередньо в Viber через пряме посилання
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

/**
 * Обробка повідомлення через Viber
 * 
 * @param string $site_id       ID сайту
 * @param string $session       ID сесії користувача
 * @param string $user_message  Повідомлення від користувача
 * @return array                ['success' => bool, 'message' => string]
 */
function crm_ai_send_to_viber($site_id, $session, $user_message) {
    
    // 1. Отримуємо налаштування сайту з бази даних MySQL
    $settings = crm_ai_get_site_settings($site_id);

    if (!$settings) {
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    // 2. Витягуємо номер Viber
    $secrets = crm_ai_get_secrets($site_id);
    $viber_number = trim($secrets['viber_number'] ?? '');

    // 3. Зберігаємо повідомлення користувача в базу
    crm_ai_save_message($site_id, $session, $user_message, 'client');

    if (!empty($viber_number)) {
        // Очищаємо номер від зайвих символів
        $clean_number = preg_replace('/[^0-9]/', '', $viber_number);
        
        // Створюємо пряме посилання на чат у Viber
        $viber_link = "viber://chat?number=" . $clean_number;

        $reply = "✅ Я отримав ваше повідомлення!\n\n"
               . "Найшвидше я відповідаю в **Viber**.\n\n"
               . "👉 [Написати мені в Viber](" . $viber_link . ")\n\n"
               . "Мій номер: " . $viber_number;

        // Зберігаємо відповідь бота
        crm_ai_save_message($site_id, $session, $reply, 'bot');

        return ['success' => true, 'message' => $reply];
    } 
    else {
        // Якщо номер Viber не налаштований
        $reply = "Viber канал ще налаштовується.\n\n"
               . "Напишіть мені в **Telegram** — я відповім швидко.";

        crm_ai_save_message($site_id, $session, $reply, 'bot');

        return ['success' => true, 'message' => $reply];
    }
}
?>