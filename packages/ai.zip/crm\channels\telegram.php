<?php
/**
 * CRM AI Consultant — Канал Telegram
 * Version: 4.0 — Повністю адаптовано під MySQL
 * 
 * Надсилає повідомлення користувача в Telegram-чат адміністратора
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

/**
 * Відправка повідомлення через Telegram
 * 
 * @param string $site_id     ID сайту
 * @param string $session     ID сесії користувача
 * @param string $message     Повідомлення від користувача
 * @param string $user_name   Ім'я користувача (за замовчуванням "Користувач")
 * @return array              ['success' => bool, 'message' => string]
 */
function crm_ai_send_to_telegram($site_id, $session, $message, $user_name = 'Користувач') {
    
    // 1. Отримуємо налаштування сайту з бази даних (MySQL)
    $settings = crm_ai_get_site_settings($site_id);

    if (!$settings) {
        error_log("Telegram: Site settings not found - " . $site_id);
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    $secrets = crm_ai_get_secrets($site_id);
    $token   = trim($secrets['telegram_token'] ?? '');
    $chat_id = trim($secrets['telegram_chat_id'] ?? '');

    // 3. Перевіряємо, чи налаштований Telegram
    if (empty($token) || empty($chat_id)) {
        error_log("Telegram: Token or Chat ID empty for site " . $site_id);
        return ['success' => false, 'message' => 'Telegram не налаштовано'];
    }

    // Формуємо текст повідомлення для адміністратора
    $text = "🔔 Нове повідомлення з сайту\n\n";
    $text .= "🌐 Сайт: " . ($settings['name'] ?? $site_id) . "\n";
    $text .= "👤 Користувач: " . $user_name . "\n";
    $text .= "💬 Повідомлення:\n" . $message . "\n\n";
    $text .= "🕒 " . date('d.m.Y H:i:s');

    $url = "https://api.telegram.org/bot{$token}/sendMessage";

    $postData = [
        'chat_id'    => $chat_id,
        'text'       => $text,
        'parse_mode' => 'Markdown'
    ];

    // Виконуємо запит через cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        error_log("Telegram cURL error: " . $curl_error . " | Site: " . $site_id);
        return ['success' => false, 'message' => 'Помилка з\'єднання з Telegram'];
    }

    $result = json_decode($response, true);

    if ($http_code === 200 && !empty($result['ok'])) {
        // Зберігаємо повідомлення в базу даних
        crm_ai_save_message($site_id, $session, $message, 'client');
        crm_ai_save_message($site_id, $session, "✅ Повідомлення надіслано в Telegram", 'bot');
        
        return ['success' => true, 'message' => 'Повідомлення надіслано в Telegram'];
    } else {
        $error = $result['description'] ?? 'Unknown error';
        error_log("Telegram API Error: " . $error . " | Site: " . $site_id);
        return ['success' => false, 'message' => 'Помилка Telegram API'];
    }
}
?>