<?php
require_once __DIR__ . '/../config.php';

define('WP_LANG_COOKIE', 'wp_plugin_lang');

$WP_LANGS = [
    'en' => ['label' => 'EN', 'name' => 'English', 'flag' => '🇬🇧', 'locale' => 'en_GB', 'html' => 'en', 'hreflang' => 'en'],
    'no' => ['label' => 'NO', 'name' => 'Norsk', 'flag' => '🇳🇴', 'locale' => 'nb-NO', 'html' => 'no', 'hreflang' => 'no'],
    'ua' => ['label' => 'UA', 'name' => 'Українська', 'flag' => '🇺🇦', 'locale' => 'uk_UA', 'html' => 'uk', 'hreflang' => 'uk'],
    'ru' => ['label' => 'RU', 'name' => 'Русский', 'flag' => '🇷🇺', 'locale' => 'ru_RU', 'html' => 'ru', 'hreflang' => 'ru'],
];

function wp_langs(): array
{
    global $WP_LANGS;
    return $WP_LANGS;
}

function wp_detect_lang(): string
{
    global $wp_base_path, $WP_LANGS;
    $codes = array_keys($WP_LANGS);

    if (!empty($_GET['lang']) && in_array($_GET['lang'], $codes, true)) {
        $chosen = $_GET['lang'];
        setcookie(WP_LANG_COOKIE, $chosen, [
            'expires' => time() + 365 * 86400,
            'path'    => rtrim($wp_base_path, '/') . '/' ?: '/',
            'secure'  => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'samesite'=> 'Lax',
        ]);
        if ($chosen === 'en') {
            $uri = $_SERVER['REQUEST_URI'] ?? '/';
            $parts = parse_url($uri);
            parse_str($parts['query'] ?? '', $q);
            unset($q['lang']);
            $clean = ($parts['path'] ?? '/') . ($q ? '?' . http_build_query($q) : '');
            if ($clean !== $uri) {
                header('Location: ' . $clean, true, 302);
                exit;
            }
        }
        return $chosen;
    }
    if (!empty($_COOKIE[WP_LANG_COOKIE]) && in_array($_COOKIE[WP_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[WP_LANG_COOKIE];
    }
    return 'en';
}

$lang      = wp_detect_lang();
$lang_meta = $WP_LANGS[$lang] ?? $WP_LANGS['en'];
$lang_file = __DIR__ . '/../lang/' . $lang . '.php';
if (!is_file($lang_file)) {
    $lang_file = __DIR__ . '/../lang/en.php';
}
$t = require $lang_file;

require_once dirname(__DIR__, 3) . '/includes/ecosystem-i18n.php';
$t = bh_apply_ecosystem_translations($t, $lang, 'wordpress');

require_once __DIR__ . '/helpers.php';