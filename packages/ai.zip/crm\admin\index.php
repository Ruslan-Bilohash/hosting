<?php
/**
 * CRM AI Consultant — Головна адмін-панель (список сайтів)
 * Version: 4.5 — Повністю виправлено роботу з сесією + MySQL
 */

require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_require_login();
$is_demo = crm_ai_is_demo();

// ====================== ДІЇ ======================
// Видалення сайту
if (isset($_GET['delete'])) {
    crm_ai_require_write_access();
    $site_id = crm_ai_sanitize_id($_GET['delete']);
    if ($site_id === '') {
        header('Location: index.php');
        exit;
    }
    crm_ai_delete_site($site_id);
    
    header("Location: index.php");
    exit;
}

// Перевірка підключення віджету на сайті
if (isset($_GET['check'])) {
    crm_ai_require_write_access();
    $site_id = crm_ai_sanitize_id($_GET['check']);
    if ($site_id === '') {
        header('Location: index.php');
        exit;
    }
    $settings = crm_ai_get_site_settings($site_id);
    
    if ($settings) {
        $domain = $settings['domain'] ?? '';
        $is_connected = checkWidgetInstalled($domain, $site_id);
        
        crm_ai_update_site($site_id, [
            'is_connected' => $is_connected ? 1 : 0,
            'last_check'   => date('Y-m-d H:i:s'),
        ]);
    }
    
    header("Location: index.php");
    exit;
}

/**
 * Перевірка наявності скрипту віджету на сайті клієнта
 */
function checkWidgetInstalled($domain, $site_id) {
    if (empty($domain)) return false;
    
    $url = (strpos($domain, 'http') === 0 ? '' : 'https://') . $domain;
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 12);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'CRM-AI-Checker/4.5');
    
    $html = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200 || empty($html)) return false;
    
    $script = 'https://bilohash.com/ai/crm/index.php?site=' . $site_id;
    return stripos($html, $script) !== false;
}
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ta['index']['title']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <?php require_once __DIR__ . '/includes/theme.php'; crm_admin_theme_head(); ?>
    <style>
        .site-card {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .site-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 30px 60px -15px rgb(0 0 0 / 0.35);
        }
    </style>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen">

<?php include 'navigation.php'; ?>

<?php if ($is_demo || isset($_GET['demo_readonly'])): ?>
<div class="max-w-7xl mx-auto px-6 pt-6">
    <div class="bg-amber-500/15 border border-amber-500/40 text-amber-200 rounded-2xl px-5 py-4 text-sm flex items-center gap-3">
        <i class="fas fa-eye"></i>
        <?= htmlspecialchars($ta['login']['demo_readonly'] ?? 'Demo account: read-only mode.') ?>
    </div>
</div>
<?php endif; ?>

<div class="max-w-7xl mx-auto p-6 lg:p-10">

    <div class="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6 mb-12">
        <div>
            <h1 class="text-5xl font-bold tracking-tight"><?= htmlspecialchars($ta['index']['my_sites']) ?></h1>
            <p class="text-zinc-400 mt-3"><?= htmlspecialchars($ta['index']['subtitle']) ?></p>
        </div>
        <?php if (!$is_demo): ?>
        <a href="sites.php" 
           class="bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-500 px-6 sm:px-8 py-3.5 sm:py-4 rounded-3xl flex items-center gap-3 font-semibold shadow-xl transition">
            <i class="fas fa-plus"></i> <?= htmlspecialchars($ta['index']['add_new_site']) ?>
        </a>
        <?php endif; ?>
    </div>

    <?php
    $sites = crm_ai_list_sites();
    ?>

    <?php if (empty($sites)): ?>
        <div class="bg-zinc-900 rounded-3xl p-24 text-center">
            <div class="text-8xl mb-8">📭</div>
            <h3 class="text-3xl font-medium mb-4"><?= htmlspecialchars($ta['index']['no_sites']) ?></h3>
            <p class="text-zinc-400"><?= htmlspecialchars($ta['index']['no_sites_hint']) ?></p>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            <?php foreach ($sites as $site):
                $is_enabled = !empty($site['enable_chat']);
                $is_connected = !empty($site['is_connected']);
                $last_check = $site['last_check'] ?? null;
                $channel = strtoupper($site['default_channel'] ?? 'TELEGRAM');
                $bot_icon = $site['bot_icon'] ?? '🤖';
            ?>
                <div class="site-card bg-white text-zinc-900 border border-zinc-200 rounded-3xl overflow-hidden shadow-lg">
                   
                    <div class="h-2 <?= $is_enabled ? 'bg-emerald-500' : 'bg-red-500' ?>"></div>
                   
                    <div class="p-8">
                        <div class="flex items-start justify-between">
                            <div class="text-5xl"><?= htmlspecialchars($bot_icon) ?></div>
                            <span class="px-5 py-2 text-sm font-medium rounded-3xl <?= $is_enabled ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' ?>">
                                <?= $is_enabled ? htmlspecialchars($ta['common']['enabled']) : htmlspecialchars($ta['common']['disabled']) ?>
                            </span>
                        </div>

                        <h3 class="text-3xl font-semibold mt-5"><?= htmlspecialchars($site['name']) ?></h3>
                        <p class="text-sky-600 font-mono text-sm"><?= htmlspecialchars($site['domain']) ?></p>

                        <?php if (!empty($site['description'])): ?>
                            <p class="text-zinc-600 mt-6 line-clamp-3"><?= htmlspecialchars($site['description']) ?></p>
                        <?php endif; ?>

                        <!-- Міні-іконка каналу -->
                        <div class="mt-8">
                            <span class="inline-flex items-center gap-2 px-5 py-2 bg-zinc-100 text-zinc-700 text-sm font-medium rounded-3xl">
                                <?php
                                $channel_icon = match($channel) {
                                    'TELEGRAM' => 'fab fa-telegram',
                                    'GROK'     => 'fas fa-robot',
                                    'OPENAI'   => 'fas fa-brain',
                                    'WHATSAPP' => 'fab fa-whatsapp',
                                    'VIBER'    => 'fab fa-viber',
                                    default    => 'fas fa-comment-dots'
                                };
                                ?>
                                <i class="<?= $channel_icon ?>"></i>
                                <?= $channel ?>
                            </span>
                        </div>

                        <!-- Код для вставки -->
                        <div class="mt-8 bg-zinc-950 text-emerald-300 text-sm font-mono p-5 rounded-2xl border border-zinc-800 overflow-x-auto">
                            &lt;script src="https://bilohash.com/ai/crm/index.php?site=<?= htmlspecialchars($site['id']) ?>"&gt;&lt;/script&gt;
                        </div>

                        <div class="mt-6 flex justify-end">
                            <button onclick="copyCode(this, '<?= htmlspecialchars($site['id']) ?>')"
                                    class="flex items-center gap-2 px-7 py-3 bg-zinc-900 hover:bg-zinc-800 text-white rounded-3xl text-sm font-medium transition">
                                <i class="fas fa-copy"></i> <?= htmlspecialchars($ta['index']['copy_code']) ?>
                            </button>
                        </div>

                        <!-- Перевірка підключення -->
                        <div class="mt-8 flex items-center justify-between text-sm">
                            <div class="text-zinc-500">
                                <?= $last_check ? htmlspecialchars(sprintf($ta['index']['checked_at'], date('d.m H:i', strtotime($last_check)))) : '<span class="text-amber-400">' . htmlspecialchars($ta['index']['not_checked']) . '</span>' ?>
                            </div>
                            <button onclick="window.location.href='?check=<?= urlencode($site['id']) ?>'"
                                    class="px-6 py-2.5 text-xs rounded-2xl <?= $is_connected ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white' ?>">
                                <?= $is_connected ? htmlspecialchars($ta['index']['code_present']) : htmlspecialchars($ta['index']['code_absent']) ?>
                            </button>
                        </div>
                    </div>

                    <div class="border-t border-zinc-100 grid <?= $is_demo ? 'grid-cols-2' : 'grid-cols-3' ?> text-sm font-medium">
                        <?php if (!$is_demo): ?>
                        <a href="sites.php?edit=<?= urlencode($site['id']) ?>" 
                           class="py-5 sm:py-6 text-center hover:bg-sky-50 text-sky-600 flex items-center justify-center gap-2">
                            <i class="fas fa-edit"></i> <?= htmlspecialchars($ta['common']['edit']) ?>
                        </a>
                        <?php endif; ?>
                        <a href="conversations.php?site=<?= urlencode($site['id']) ?>" 
                           class="py-5 sm:py-6 text-center hover:bg-zinc-100 flex items-center justify-center gap-2 <?= $is_demo ? '' : 'border-x' ?>">
                            <i class="fas fa-clock"></i> <?= htmlspecialchars($ta['common']['history']) ?>
                        </a>
                        <?php if (!$is_demo): ?>
                        <a href="?delete=<?= urlencode($site['id']) ?>" 
                           onclick="return confirm(<?= json_encode($ta['index']['delete_confirm'], JSON_UNESCAPED_UNICODE) ?>)"
                           class="py-5 sm:py-6 text-center hover:bg-red-50 text-red-500 flex items-center justify-center gap-2">
                            <i class="fas fa-trash"></i> <?= htmlspecialchars($ta['common']['delete']) ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

<script>
const CRM_I18N = <?= json_encode([
    'copied' => $ta['index']['copied'],
    'copy_code' => $ta['index']['copy_code'],
], JSON_UNESCAPED_UNICODE) ?>;

function copyCode(btn, siteId) {
    const code = `<script src="https://bilohash.com/ai/crm/index.php?site=${siteId}"><\/script>`;
    navigator.clipboard.writeText(code).then(() => {
        const original = btn.innerHTML;
        btn.innerHTML = `<i class="fas fa-check"></i> ${CRM_I18N.copied}`;
        setTimeout(() => { btn.innerHTML = original; }, 2200);
    });
}
</script>
</body>
</html>