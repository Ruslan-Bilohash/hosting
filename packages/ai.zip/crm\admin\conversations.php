<?php
/**
 * CRM AI Consultant — Історія розмов
 * Version: 4.0 — Повністю на MySQL + сучасний дизайн
 * 
 * Показує всі розмови з бази даних, згруповані по сайту та сесії
 */

require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_require_login();

$filter_site = isset($_GET['site']) ? crm_ai_sanitize_id($_GET['site']) : null;
$conversations = crm_ai_list_conversations($filter_site ?: null);
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ta['conversations']['title']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <?php require_once __DIR__ . '/includes/theme.php'; crm_admin_theme_head(); ?>
    <style>
        .conversation-row:hover { 
            background-color: #1f2937; 
            transition: background-color 0.2s ease;
        }
        .modal { 
            display: none; 
            position: fixed; 
            inset: 0; 
            background: rgba(0,0,0,0.92); 
            z-index: 10000; 
            align-items: center; 
            justify-content: center; 
        }
        .modal-content { 
            background: #18181b; 
            width: 95%; 
            max-width: 880px; 
            max-height: 92vh; 
            border-radius: 24px; 
            overflow: hidden; 
            box-shadow: 0 25px 70px rgba(0,0,0,0.8);
        }
    </style>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen">

<?php include 'navigation.php'; ?>

<div class="max-w-7xl mx-auto p-6 lg:p-10">

    <div class="flex justify-between items-end mb-10">
        <div>
            <h1 class="text-4xl font-bold tracking-tight"><?= htmlspecialchars($ta['conversations']['heading']) ?></h1>
            <p class="text-zinc-400 mt-2"><?= htmlspecialchars($ta['conversations']['subtitle']) ?></p>
        </div>
        <div class="text-sm text-zinc-500 bg-zinc-900 px-5 py-2 rounded-2xl">
            <?= htmlspecialchars($ta['conversations']['total']) ?> <strong><?= count($conversations) ?></strong>
        </div>
    </div>

    <?php if (empty($conversations)): ?>
        <div class="bg-zinc-900 rounded-3xl p-24 text-center">
            <div class="text-8xl mb-8">📭</div>
            <h3 class="text-3xl font-medium mb-4"><?= htmlspecialchars($ta['conversations']['no_conversations']) ?></h3>
            <p class="text-zinc-400"><?= htmlspecialchars($ta['conversations']['no_conversations_hint']) ?></p>
        </div>
    <?php else: ?>
        <div class="bg-zinc-900 rounded-3xl overflow-hidden border border-zinc-700">
            <table class="w-full">
                <thead class="bg-zinc-950">
                    <tr>
                        <th class="px-8 py-6 text-left font-medium"><?= htmlspecialchars($ta['common']['site']) ?></th>
                        <th class="px-8 py-6 text-left font-medium"><?= htmlspecialchars($ta['common']['session']) ?></th>
                        <th class="px-8 py-6 text-center font-medium"><?= htmlspecialchars($ta['conversations']['col_messages']) ?></th>
                        <th class="px-8 py-6 text-left font-medium"><?= htmlspecialchars($ta['conversations']['col_last_message']) ?></th>
                        <th class="px-8 py-6 text-left font-medium"><?= htmlspecialchars($ta['conversations']['col_time']) ?></th>
                        <th class="w-44"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($conversations as $conv): ?>
                    <tr class="conversation-row border-t border-zinc-800 hover:bg-zinc-800 cursor-pointer" 
                        onclick="loadConversation('<?= htmlspecialchars($conv['site_id']) ?>', '<?= htmlspecialchars($conv['session_id']) ?>')">
                        
                        <td class="px-8 py-6 font-medium">
                            <?= htmlspecialchars($conv['site_name'] ?? $conv['site_id']) ?>
                        </td>
                        <td class="px-8 py-6 font-mono text-sm text-zinc-400">
                            <?= htmlspecialchars($conv['session_id']) ?>
                        </td>
                        <td class="px-8 py-6 text-center font-semibold"><?= $conv['message_count'] ?></td>
                        <td class="px-8 py-6 text-sm text-zinc-300 truncate max-w-md">
                            <?= htmlspecialchars(mb_substr($conv['last_message'] ?? '', 0, 85)) ?>...
                        </td>
                        <td class="px-8 py-6 text-sm text-zinc-500">
                            <?= date('d.m.Y H:i', strtotime($conv['last_time'])) ?>
                        </td>
                        <td class="px-8 py-6 text-right">
                            <button onclick="event.stopImmediatePropagation(); loadConversation('<?= htmlspecialchars($conv['site_id']) ?>', '<?= htmlspecialchars($conv['session_id']) ?>')" 
                                    class="bg-sky-600 hover:bg-sky-500 px-7 py-3 rounded-2xl text-sm font-medium transition">
                                <?= htmlspecialchars($ta['conversations']['view']) ?>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Модальне вікно перегляду розмови -->
<div id="modal" class="modal">
    <div class="modal-content">
        <div class="bg-zinc-800 px-8 py-5 flex justify-between items-center border-b border-zinc-700">
            <h2 class="text-xl font-semibold flex items-center gap-3">
                <i class="fas fa-comments text-sky-400"></i>
                <?= htmlspecialchars($ta['conversations']['modal_title']) ?>
            </h2>
            <button onclick="closeModal()" class="text-4xl leading-none text-zinc-400 hover:text-white">×</button>
        </div>
        
        <div id="modal-body" class="p-8 overflow-y-auto bg-zinc-950" style="max-height: 68vh;">
            <!-- AJAX завантажить повідомлення сюди -->
        </div>
        
        <div class="p-5 bg-zinc-900 text-xs text-center text-zinc-500 border-t border-zinc-700">
            <?= htmlspecialchars($ta['conversations']['modal_site']) ?> <span id="modal-site" class="font-mono"></span> | 
            <?= htmlspecialchars($ta['conversations']['modal_session']) ?> <span id="modal-session" class="font-mono"></span>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
const CRM_CONV_I18N = <?= json_encode([
    'loading' => $ta['conversations']['loading'],
    'load_error' => $ta['conversations']['load_error'],
], JSON_UNESCAPED_UNICODE) ?>;

function loadConversation(siteId, sessionId) {
    const modal = document.getElementById('modal');
    const body = document.getElementById('modal-body');
    const siteSpan = document.getElementById('modal-site');
    const sessionSpan = document.getElementById('modal-session');

    siteSpan.textContent = siteId;
    sessionSpan.textContent = sessionId;

    body.innerHTML = `
        <div class="text-center py-20">
            <i class="fas fa-spinner fa-spin text-5xl text-zinc-500"></i>
            <p class="mt-6 text-zinc-400">${CRM_CONV_I18N.loading}</p>
        </div>`;

    modal.style.display = 'flex';

    fetch('get-conversation.php?site_id=' + encodeURIComponent(siteId) + '&session=' + encodeURIComponent(sessionId))
        .then(response => response.text())
        .then(html => {
            body.innerHTML = html;
        })
        .catch(() => {
            body.innerHTML = `<p class="text-red-400 text-center py-12">${CRM_CONV_I18N.load_error}</p>`;
        });
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}
</script>

</body>
</html>