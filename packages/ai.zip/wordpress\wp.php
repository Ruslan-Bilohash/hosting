<?php
header('Location: /ai/wordpress/', true, 301);
exit;