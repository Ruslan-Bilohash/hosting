
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Купити Bilohash GPT Chat Assistant Pro</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body {
            background: linear-gradient(135deg, #0a0a1f 0%, #1a1a4d 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            color: #fff;
            min-height: 100vh;
        }
        .pricing-card {
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(0,245,255,0.25);
            border-radius: 20px;
            backdrop-filter: blur(12px);
            transition: all 0.4s ease;
        }
        .pricing-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 25px 50px rgba(0, 245, 255, 0.3);
        }
        .pricing-card.popular {
            border: 2px solid #00f5ff;
            transform: scale(1.05);
        }
        .price {
            font-size: 3.2rem;
            font-weight: 700;
            color: #00f5ff;
        }
        .btn-buy {
            padding: 14px 40px;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 50px;
        }
        .feature { padding: 10px 0; }
    </style>
</head>
<body class="d-flex align-items-center py-5">

    <div class="container">
        <div class="text-center mb-5">
            <h1 class="display-5 fw-bold">Оберіть тариф</h1>
            <p class="lead text-light">Bilohash GPT Chat Assistant Pro</p>
        </div>

        <div class="row g-4 justify-content-center">

            <!-- Тариф 1 домен -->
            <div class="col-lg-4 col-md-6">
                <div class="pricing-card h-100 text-center p-4">
                    <h4 class="mb-3">1 Домен</h4>
                    <div class="price">$10</div>
                    <p class="text-light">за місяць</p>
                    
                    <ul class="list-unstyled my-4">
                        <li class="feature">✓ GPT-4o / GPT-4o-mini</li>
                        <li class="feature">✓ Необмежена кількість повідомлень</li>
                        <li class="feature">✓ Telegram сповіщення</li>
                        <li class="feature">✓ Повна кастомізація</li>
                        <li class="feature">✓ Історія розмов</li>
                    </ul>
                    
                    <a href="https://www.paypal.com/ncp/payment/N2ATUZFBT5JY2" onclick="selectPlan(1)" class="btn btn-primary btn-buy w-100">Купити за $10</a>
                </div>
            </div>

            <!-- Тариф 3 домени (Популярний) -->
            <div class="col-lg-4 col-md-6">
                <div class="pricing-card popular h-100 text-center p-4 position-relative">
                    <span class="badge bg-warning text-dark position-absolute top-0 start-50 translate-middle">Найвигідніше</span>
                    <h4 class="mb-3">3 Домени</h4>
                    <div class="price">$21</div>
                    <p class="text-light">за місяць</p>
                    
                    <ul class="list-unstyled my-4">
                        <li class="feature">✓ 3 сайти одночасно</li>
                        <li class="feature">✓ GPT-4o / GPT-4o-mini</li>
                        <li class="feature">✓ Telegram сповіщення</li>
                        <li class="feature">✓ Повна кастомізація</li>
                        <li class="feature">✓ Пріоритетна підтримка</li>
                    </ul>
                    
                    <a href="https://www.paypal.com/ncp/payment/SWFRQA22QB6XY" onclick="selectPlan(3)" class="btn btn-success btn-buy w-100">Купити за $21</a>
                </div>
            </div>

            <!-- Тариф 10 доменів -->
            <div class="col-lg-4 col-md-6">
                <div class="pricing-card h-100 text-center p-4">
                    <h4 class="mb-3">10 Доменів</h4>
                    <div class="price">$49</div>
                    <p class="text-light">за місяць</p>
                    
                    <ul class="list-unstyled my-4">
                        <li class="feature">✓ 10 сайтів одночасно</li>
                        <li class="feature">✓ GPT-4o / GPT-4o-mini</li>
                        <li class="feature">✓ Telegram сповіщення</li>
                        <li class="feature">✓ Повна кастомізація</li>
                        <li class="feature">✓ Пріоритетна підтримка</li>
                    </ul>
                    
                    <a href="https://www.paypal.com/ncp/payment/QRMDUSWAC2RH2" onclick="selectPlan(10)" class="btn btn-primary btn-buy w-100">Купити за $49</a>
                </div>
            </div>

        </div>

        <div class="text-center mt-5 text-light">
            <small>Після оплати ви отримаєте ліцензійний ключ на email.<br>
            Ключ прив'язується до вказаних доменів.</small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function selectPlan(domains) {
        let price = 0;
        if (domains === 1) price = 10;
        else if (domains === 3) price = 21;
        else if (domains === 10) price = 49;

        if (confirm(`Оплатити тариф на ${domains} ${domains === 1 ? 'домен' : 'доменів'} за $${price} / місяць?`)) {
            alert('✅ Файл буде надіслано на вашу пошту. \n\n Напишіть нам на email@bilohash.com! ');
        }
    }
    </script>
</body>
</html>