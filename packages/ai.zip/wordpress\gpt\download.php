<?php
/**
 * Bilohash GPT Chat Assistant Pro - Free Download Page
 */
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-8">

            <div class="text-center mb-5">
                <h1 class="display-5 fw-bold text-white">Завантажити Free версію</h1>
                <p class="lead text-light">Спробуйте потужний GPT-чатбот безкоштовно</p>
            </div>

            <!-- Main Download Card -->
            <div class="mx-auto" style="max-width: 620px;">
                <div class="card shadow-lg" style="background: rgba(255,255,255,0.09); border: 1px solid rgba(0,245,255,0.35); border-radius: 24px; backdrop-filter: blur(16px);">
                    <div class="card-body p-5 p-md-5 text-center">

                        <div class="mb-4">
                            <i class="bi bi-download fs-1 text-info"></i>
                        </div>
                        
                        <h3 class="fw-bold text-white mb-4">Bilohash GPT Chat Assistant Pro — Free</h3>
                        
                        <div class="bg-white bg-opacity-10 rounded-3 py-3 mb-4">
                            <h2 class="text-info fw-bold mb-1">повністю безкоштовно</h2>
                            <p class="text-light mb-0"></p>
                        </div>

                        <p class="text-light opacity-90 mb-4">
                            Ознайомтеся з усіма можливостями плагіну протягом 3 днів.<br>
                            Після закінчення тріалу чат автоматично вимкнеться.
                        </p>

                        <!-- Виправлений список з кращим контрастом -->
                        <ul class="list-unstyled text-start mx-auto mb-4" style="max-width: 420px;">
                            <li class="d-flex align-items-start gap-3 mb-3">
                                <i class="bi bi-check-circle-fill text-success mt-1"></i>
                                <span class="text-white">GPT-4o та GPT-4o-mini</span>
                            </li>
                            <li class="d-flex align-items-start gap-3 mb-3">
                                <i class="bi bi-check-circle-fill text-success mt-1"></i>
                                <span class="text-white">Telegram сповіщення в реальному часі</span>
                            </li>
                            <li class="d-flex align-items-start gap-3 mb-3">
                                <i class="bi bi-check-circle-fill text-success mt-1"></i>
                                <span class="text-white">Повна кастомізація дизайну</span>
                            </li>
                            <li class="d-flex align-items-start gap-3 mb-3">
                                <i class="bi bi-check-circle-fill text-success mt-1"></i>
                                <span class="text-white">Збереження історії розмов</span>
                            </li>
                            <li class="d-flex align-items-start gap-3">
                                <i class="bi bi-check-circle-fill text-success mt-1"></i>
                                <span class="text-white">Підтримка української, англійської та норвезької</span>
                            </li>
                        </ul>

                        <a href="bilohash-gpt-chat-assistant-pro_1.0.zip" onclick="downloadFree()" class="btn btn-success btn-lg w-100" 
                           style="padding: 16px 40px; font-size: 1.2rem; font-weight: 600; border-radius: 50px;">
                            <i class="bi bi-download me-2"></i>
                            Завантажити Free версію
                        </a>

                        <p class="text-light small mt-4">
                            Після завантаження у вас буде <strong>3 дні</strong> повного доступу
                        </p>
                    </div>
                </div>
            </div>

            <!-- Call to Action -->
            <div class="text-center mt-5">
                <p class="text-light">Хочете користуватися без обмежень?</p>
                <a href="pay.php" class="btn btn-outline-light btn-lg px-5 py-3">
                    Переглянути тарифи від $10/місяць →
                </a>
            </div>

        </div>
    </div>
</div>

<script>
function downloadFree() {
    if (confirm('Завантажити Free версію Bilohash GPT Chat Assistant Pro?\n\nПісля активації у вас буде 3 дні повного доступу. Далі ви маєте купити повну версію у розробника або видалити наш плагін')) {
        alert('✅ Free версія завантажується...\n\n(дякуємо за використання)');
    }
}
</script>