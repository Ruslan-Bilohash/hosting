<?php
/**
 * CRM AI Consultant — Загальні налаштування бота
 * Привітання, інструкції для бота, автовідкриття тощо
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die($ta['access_denied'] ?? 'Access denied');
}
?>

<div id="settings_general" class="channel-settings">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fas fa-cog text-sky-400 text-2xl"></i>
        <?= htmlspecialchars($ta['settings_general']['title']) ?>
    </h3>

    <!-- Привітання при першому відкритті -->
    <div class="mb-8">
        <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_general']['welcome_label']) ?></label>
        <textarea name="welcome_text" rows="3" 
                  class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4"><?= htmlspecialchars($edit_site['welcome_text'] ?? $ta['defaults']['welcome_text']) ?></textarea>
        <p class="text-xs text-zinc-500 mt-1"><?= htmlspecialchars($ta['settings_general']['welcome_hint']) ?></p>
    </div>

    <!-- Інструкції для бота (System Prompt) -->
    <div class="mb-8">
        <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_general']['system_prompt_label']) ?></label>
        <textarea name="bot_system_prompt" rows="6" 
                  class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono text-sm"><?= htmlspecialchars($edit_site['bot_system_prompt'] ?? $ta['defaults']['bot_system_prompt']) ?></textarea>
        <p class="text-xs text-zinc-500 mt-1">
            <?= htmlspecialchars($ta['settings_general']['system_prompt_hint']) ?>
        </p>
    </div>

    <!-- Автовідкриття чату -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
            <label class="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" name="auto_open" value="1" 
                       <?= !empty($edit_site['auto_open']) ? 'checked' : '' ?>>
                <span class="text-sm font-medium"><?= htmlspecialchars($ta['settings_general']['auto_open']) ?></span>
            </label>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_general']['auto_open_delay']) ?></label>
            <div class="flex items-center gap-3">
                <input type="number" name="auto_open_delay" min="1000" max="30000" step="500"
                       value="<?= (int)($edit_site['auto_open_delay'] ?? 7000) ?>" 
                       class="w-32 bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 text-center">
                <span class="text-zinc-400"><?= htmlspecialchars($ta['settings_general']['milliseconds']) ?></span>
            </div>
            <p class="text-xs text-zinc-500 mt-1"><?= htmlspecialchars($ta['settings_general']['auto_open_recommended']) ?></p>
        </div>
    </div>

    <!-- Додаткові налаштування бота -->
    <div class="mt-10 pt-8 border-t border-zinc-700">
        <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_general']['max_history']) ?></label>
        <input type="number" name="max_history_messages" min="10" max="200" 
               value="<?= (int)($edit_site['max_history_messages'] ?? 50) ?>" 
               class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
    </div>

</div>