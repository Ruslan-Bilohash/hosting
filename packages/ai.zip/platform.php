<?php
require_once __DIR__ . '/includes/i18n.php';
require_once __DIR__ . '/includes/platform-lib.php';

$slug = trim($_GET['slug'] ?? '');
$platform = ai_platform_by_slug($slug);
if (!$platform) {
    header('Location: ' . ai_url('index.php'), true, 302);
    exit;
}

$GLOBALS['platform_slug'] = $slug;
$p = ai_platform_lang($platform, $lang);
$page_title = $p['title'] ?? $t['meta']['title'];
$page_desc  = $p['description'] ?? $t['meta']['description'];
$canonical  = ai_platform_canonical($slug);
$canon_abs  = ai_absolute_url($canonical);

require __DIR__ . '/includes/platform-template.php';