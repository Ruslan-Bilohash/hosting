<?php
require_once dirname(__DIR__, 2) . '/includes/bh-mail.php';

function ai_handle_contact_form(array $t, string $lang): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    if (!isset($_SESSION['captcha_num1'], $_SESSION['captcha_num2'])) {
        $_SESSION['captcha_num1'] = random_int(5, 20);
        $_SESSION['captcha_num2'] = random_int(5, 20);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['order_form'])) {
        return '';
    }
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        return '<div class="ai-alert ai-alert--error">Security error. Refresh the page.</div>';
    }

    $name    = trim(strip_tags($_POST['name'] ?? ''));
    $email   = trim($_POST['email'] ?? '');
    $message = trim(strip_tags($_POST['message'] ?? ''));
    $captcha = (int)($_POST['captcha'] ?? 0);
    $correct = (int)$_SESSION['captcha_num1'] + (int)$_SESSION['captcha_num2'];

    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $message && $captcha === $correct) {
        $body = "AI Consultant request\nName: $name\nEmail: $email\nMessage: $message\nLang: $lang\nTime: " . date('c');
        $html = '<pre style="font-family:system-ui,sans-serif;white-space:pre-wrap">' . htmlspecialchars($body) . '</pre>';
        if (!bh_send_mail(AI_CONTACT_EMAIL, 'AI Consultant — installation request', $html, $email, $name, $body)) {
            return '<div class="ai-alert ai-alert--error">' . htmlspecialchars($t['contact']['error']) . '</div>';
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['captcha_num1'] = random_int(5, 20);
        $_SESSION['captcha_num2'] = random_int(5, 20);
        return '<div class="ai-alert ai-alert--success">' . htmlspecialchars($t['contact']['success']) . '</div>';
    }

    $msg = $captcha !== $correct ? $t['contact']['captcha_error'] : $t['contact']['error'];
    return '<div class="ai-alert ai-alert--error">' . htmlspecialchars($msg) . '</div>';
}