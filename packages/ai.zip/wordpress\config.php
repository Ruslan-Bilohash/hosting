<?php
$wp_base_path = '/ai/wordpress/';
$wp_site_url  = 'https://bilohash.com/ai/wordpress';
$wp_version   = '2.8.0';
$wp_paypal    = 'https://www.paypal.com/ncp/payment/4EQ5ESFGWMCT6';
$wp_wporg     = 'https://wordpress.org/plugins/bilohash-ai-chat-consultant/';
$wp_order_email = 'rbilohash@gmail.com';