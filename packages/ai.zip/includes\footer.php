
<footer class="ai-footer">
    <div class="ai-container">
        <div class="ai-footer-grid">
            <div class="ai-footer-brand">
                <div class="ai-logo ai-logo--footer">
                    <a href="https://bilohash.com/" class="ai-logo ai-logo--footer" style="text-decoration:none;color:inherit">
                        <span class="ai-logo-icon"><i class="fas fa-brain"></i></span>
                        <span class="ai-logo-text">bilohash AI</span>
                    </a>
                </div>
                <p><?= htmlspecialchars($t['footer']['tagline']) ?></p>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['products']) ?></h4>
                <ul>
                    <li><a href="<?= ai_url('index.php') ?>">AI Consultant Grok xAI</a></li>
                    <li><a href="https://bilohash.com/ai/wordpress/">WordPress Plugin</a></li>
                    <li><a href="https://bilohash.com/ai/crm/">CRM AI 4.0</a></li>
                    <li><a href="https://wordpress.org/plugins/bilohash-ai-chat-consultant/">WordPress.org</a></li>
                </ul>
            </div>
            <?php require dirname(__DIR__, 2) . '/includes/ecosystem-footer-column.php'; ?>
            <div>
                <h4><?= htmlspecialchars($t['footer']['legal']) ?></h4>
                <ul>
                    <li><a href="/website/privacy-policy.php"><?= htmlspecialchars($t['footer']['privacy']) ?></a></li>
                    <li><a href="/website/cookies.php"><?= htmlspecialchars($t['footer']['cookies']) ?></a></li>
                    <li><a href="https://bilohash.com/resume.php">Resume</a></li>
                    <li><a href="https://bilohash.com/contact.php">Contact</a></li>
                    <li><a href="<?= ai_url('sitemap.xml') ?>">Sitemap</a></li>
                    <?php require_once dirname(__DIR__, 2) . '/includes/bh-cms-links.php'; bh_footer_cms_links('ai', $t['footer']['news'] ?? 'Release notes'); ?>
                </ul>
            </div>
        </div>
        <?php require dirname(__DIR__, 2) . '/includes/ecosystem-footer-pills.php'; ?>
        <div class="ai-footer-bottom">
            <p><?= htmlspecialchars($t['footer']['copy']) ?></p>
            <?php if (is_file(__DIR__ . '/../counter.php')) { include __DIR__ . '/../counter.php'; } ?>
        </div>
    </div>
</footer>
<?php
$gdpr_lang = match ($lang) {
    'ua' => 'uk', 'ru' => 'ru', 'en' => 'en', 'no' => 'no', 'sv' => 'no', 'lt' => 'en', default => 'uk',
};
$gdpr_privacy_url = '/website/privacy-policy.php';
$gdpr_cookies_url = '/website/cookies.php';
$gdpr_storage_key = 'ai_gdpr_consent';
include dirname(__DIR__, 2) . '/includes/gdpr-consent.php';
?>
<script src="<?= htmlspecialchars(ai_asset('js/landing.js')) ?>?v=2" defer></script>
<?php
$bh_chat_lang = $lang === 'ua' ? 'ua' : ($lang === 'no' ? 'no' : ($lang === 'ru' ? 'ru' : 'en'));
$bh_chat_variant = 'ai';
$bh_chat_require_consent = false;
include dirname(__DIR__, 2) . '/includes/bh-chat-widget.php';
?>
</body>
</html>