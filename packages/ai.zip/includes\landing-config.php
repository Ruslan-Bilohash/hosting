<?php
define('AI_BASE_PATH', '/ai');
define('AI_DOMAIN', 'bilohash.com');
define('AI_CONTACT_EMAIL', 'rbilohash@gmail.com');
define('AI_OG_IMAGE', 'https://bilohash.com/ai/wordpress/images/01-frontend-widget.jpg');

$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$ai_base_path = (strpos($host, AI_DOMAIN) !== false) ? AI_BASE_PATH : ($detected ?: AI_BASE_PATH);

$ai_protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$ai_site_url = rtrim($ai_protocol . '://' . $host . $ai_base_path, '/');
$ai_assets_url = $ai_base_path . '/assets';

function ai_url(string $path = '', ?string $lang = null): string
{
    global $ai_base_path;
    $base = rtrim($ai_base_path, '/') . '/' . ltrim($path, '/');
    if ($lang !== null && $lang !== 'ua') {
        $base .= (strpos($base, '?') !== false ? '&' : '?') . 'lang=' . $lang;
    }
    return $base;
}

function ai_asset(string $file): string
{
    global $ai_assets_url;
    return $ai_assets_url . '/' . ltrim($file, '/');
}

function ai_lang_url(string $code, bool $for_hreflang = false): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: ai_url('index.php');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);
    if ($code === 'ua' && $for_hreflang) {
        unset($q['lang']);
    } else {
        $q['lang'] = $code;
    }
    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}

function ai_absolute_url(string $relative): string
{
    global $ai_site_url, $ai_protocol, $host;
    if (preg_match('#^https?://#i', $relative)) {
        return $relative;
    }
    if ($relative !== '' && $relative[0] === '/') {
        return rtrim($ai_protocol . '://' . $host, '/') . $relative;
    }
    return rtrim($ai_site_url, '/') . '/' . ltrim($relative, '/');
}

/** Normalize icon name to full Font Awesome 6 class string (e.g. house → fas fa-house). */
function ai_fa_icon(string $name): string
{
    $name = trim($name);
    if ($name === '') {
        return 'fas fa-circle';
    }
    if (preg_match('/\b(fas|far|fab|fal|fad|fa-solid|fa-regular|fa-brands)\s+fa-/', $name)) {
        return $name;
    }
    $bare = ltrim($name, 'fa-');
    $brands = ['wordpress', 'shopify', 'wix', 'telegram', 'paypal', 'facebook', 'instagram'];
    if (in_array($bare, $brands, true)) {
        return 'fab fa-' . $bare;
    }
    if (str_starts_with($name, 'fa-')) {
        return 'fas ' . $name;
    }
    return 'fas fa-' . $bare;
}