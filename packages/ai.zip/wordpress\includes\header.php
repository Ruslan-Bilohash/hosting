<?php
require_once __DIR__ . '/seo.php';
global $wp_version, $wp_paypal, $wp_wporg;
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? wp_canonical($lang);
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_render_seo_head($page_title, $page_desc, $canonical, $t['faq']['items'] ?? []); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(wp_asset('css/style.css')) ?>?v=2">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%230a0a1f' width='100' height='100' rx='12'/><text x='50' y='62' font-size='36' text-anchor='middle' fill='%2300f5ff' font-family='sans-serif' font-weight='bold'>WP</text></svg>">
</head>
<body>
<header class="wp-header" id="wpHeader">
    <div class="wp-header-inner">
        <a href="<?= htmlspecialchars(wp_url('')) ?>" class="wp-logo">
            <i class="fab fa-wordpress" aria-hidden="true"></i>
            <span>AI Consultant <small>GROK</small></span>
        </a>
        <nav class="wp-nav" id="wpNav" aria-label="Main">
            <a href="#features"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="#screenshots"><?= htmlspecialchars($t['nav']['screenshots']) ?></a>
            <a href="#comparison"><?= htmlspecialchars($t['nav']['comparison']) ?></a>
            <a href="#install"><?= htmlspecialchars($t['nav']['install']) ?></a>
            <a href="#whatsnew"><?= htmlspecialchars($t['nav']['whatsnew']) ?></a>
            <a href="#ecosystem"><?= htmlspecialchars($t['footer']['ecosystem']) ?></a>
            <a href="#faq"><?= htmlspecialchars($t['nav']['faq']) ?></a>
            <a href="#contact"><?= htmlspecialchars($t['nav']['contact']) ?></a>
        </nav>
        <div class="wp-header-actions">
            <div class="wp-lang" id="wpLang">
                <button type="button" class="wp-lang-btn" id="wpLangBtn" aria-expanded="false">
                    <?= $lang_meta['flag'] ?> <?= htmlspecialchars($lang_meta['label']) ?>
                    <i class="fas fa-chevron-down" aria-hidden="true"></i>
                </button>
                <ul class="wp-lang-menu" id="wpLangMenu" hidden>
                    <?php foreach (wp_langs() as $code => $info): ?>
                    <li><a href="<?= htmlspecialchars(wp_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['flag'] ?> <?= htmlspecialchars($info['name']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <a href="<?= htmlspecialchars($wp_paypal) ?>" class="wp-btn-buy wp-btn-sm" target="_blank" rel="noopener"><?= htmlspecialchars($t['nav']['buy']) ?></a>
            <button type="button" class="wp-burger" id="wpBurger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
        </div>
    </div>
</header>
<div class="wp-overlay" id="wpOverlay" hidden></div>