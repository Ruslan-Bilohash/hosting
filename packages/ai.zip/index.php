<?php
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://www.google.com https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: https:; frame-src https://www.google.com; connect-src 'self' https:;");

session_start();
require_once __DIR__ . '/includes/i18n.php';
require_once __DIR__ . '/includes/form-handler.php';
require_once __DIR__ . '/includes/projects-data.php';
require_once __DIR__ . '/includes/platform-lib.php';
$ai_projects = ai_ecosystem_projects($lang);
$ai_platforms = ai_integration_cards($lang);

$feedback = ai_handle_contact_form($t, $lang);
$num1 = $_SESSION['captcha_num1'] ?? random_int(5, 20);
$num2 = $_SESSION['captcha_num2'] ?? random_int(5, 20);

$page_title = $t['meta']['title'];
$page_desc  = $t['meta']['description'];
$canonical  = ai_lang_url($lang, true);

require __DIR__ . '/includes/header.php';
?>

<section class="ai-hero">
    <div class="ai-hero-mesh"></div>
    <div class="ai-hero-grid"></div>
    <div class="ai-hero-inner">
        <div>
            <div class="ai-hero-badge"><i class="fas fa-bolt"></i> <?= htmlspecialchars($t['hero']['badge']) ?></div>
            <h1><?= htmlspecialchars($t['hero']['h1']) ?></h1>
            <p class="ai-hero-lead"><?= htmlspecialchars($t['hero']['p']) ?></p>
            <p class="ai-hero-install-note"><?= htmlspecialchars($t['hero']['install_note']) ?></p>
            <div class="ai-hero-ctas">
                <a href="<?= htmlspecialchars(ai_subscription_url()) ?>" class="ai-btn-primary" <?= ai_subscription_external_attrs() ?>><?= htmlspecialchars($t['hero']['cta_subscribe'] ?? $t['hero']['cta_contact']) ?></a>
                <a href="<?= htmlspecialchars(ai_license_cabinet_url()) ?>" class="ai-btn-secondary" <?= ai_subscription_external_attrs() ?>><?= htmlspecialchars($t['hero']['cta_cabinet'] ?? $t['hero']['cta_demo']) ?></a>
            </div>
            <div class="ai-trust-strip">
                <?php foreach ($t['trust'] as $pill): ?>
                <span class="ai-trust-pill"><?= htmlspecialchars($pill) ?></span>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="ai-hero-visual">
            <div class="ai-mockup">
                <img src="/ai/wordpress/images/01-frontend-widget.jpg" alt="Grok xAI chat widget on website" width="640" height="400" loading="eager">
            </div>
            <div class="ai-chat-widget" role="presentation" aria-hidden="true">
                <div class="ai-chat-header">
                    <div class="ai-chat-avatar"><i class="fas fa-bolt"></i></div>
                    <div class="ai-chat-meta">
                        <strong><?= htmlspecialchars($t['hero']['chat_name']) ?></strong>
                        <span class="ai-chat-status"><span class="ai-chat-dot"></span> <?= htmlspecialchars($t['hero']['chat_online']) ?></span>
                    </div>
                    <span class="ai-chat-minimize"><i class="fas fa-minus"></i></span>
                </div>
                <div class="ai-chat-body">
                    <div class="ai-chat-msg ai-chat-msg--bot">
                        <span class="ai-chat-msg-icon"><i class="fas fa-robot"></i></span>
                        <div class="ai-chat-bubble"><?= htmlspecialchars($t['hero']['chat_bubble']) ?></div>
                    </div>
                    <div class="ai-chat-msg ai-chat-msg--user">
                        <div class="ai-chat-bubble"><?= htmlspecialchars($t['hero']['chat_user']) ?></div>
                    </div>
                    <div class="ai-chat-typing" aria-hidden="true">
                        <span></span><span></span><span></span>
                    </div>
                </div>
                <div class="ai-chat-footer">
                    <span class="ai-chat-input-fake"><?= htmlspecialchars($t['hero']['chat_input']) ?></span>
                    <span class="ai-chat-send"><i class="fas fa-paper-plane"></i></span>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="ai-container">
    <div class="ai-stats">
        <div class="ai-stat"><b>99.9%</b><span><?= htmlspecialchars($t['stats']['uptime']) ?></span></div>
        <div class="ai-stat"><b>6+</b><span><?= htmlspecialchars($t['stats']['langs']) ?></span></div>
        <div class="ai-stat"><b>1–2</b><span><?= htmlspecialchars($t['stats']['setup']) ?></span></div>
        <div class="ai-stat"><b>+70%</b><span><?= htmlspecialchars($t['stats']['conv']) ?></span></div>
    </div>
</div>

<section class="ai-section" id="products">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['products']['title']) ?></h2>
        <p class="ai-section-sub"><?= htmlspecialchars($t['products']['sub']) ?></p>
        <div class="ai-products-grid">
            <article class="ai-product-card ai-product-card--featured">
                <span class="ai-product-tag"><?= htmlspecialchars($t['products']['basic']['tag']) ?></span>
                <h3><?= htmlspecialchars($t['products']['basic']['title']) ?></h3>
                <p><?= htmlspecialchars($t['products']['basic']['desc']) ?></p>
                <div class="ai-product-price"><?= htmlspecialchars($t['products']['basic']['price']) ?></div>
                <a href="<?= htmlspecialchars(ai_subscription_url()) ?>" class="ai-btn-primary" <?= ai_subscription_external_attrs() ?>><?= htmlspecialchars($t['products']['basic']['cta']) ?></a>
            </article>
            <article class="ai-product-card">
                <span class="ai-product-tag"><?= htmlspecialchars($t['products']['wp']['tag']) ?></span>
                <h3><?= htmlspecialchars($t['products']['wp']['title']) ?></h3>
                <p><?= htmlspecialchars($t['products']['wp']['desc']) ?></p>
                <div class="ai-product-price"><?= htmlspecialchars($t['products']['wp']['price']) ?></div>
                <a href="/ai/wordpress/" class="ai-btn-secondary"><?= htmlspecialchars($t['products']['wp']['cta']) ?></a>
            </article>
            <article class="ai-product-card">
                <span class="ai-product-tag"><?= htmlspecialchars($t['products']['crm']['tag']) ?></span>
                <h3><?= htmlspecialchars($t['products']['crm']['title']) ?></h3>
                <p><?= htmlspecialchars($t['products']['crm']['desc']) ?></p>
                <div class="ai-product-price"><?= htmlspecialchars($t['products']['crm']['price']) ?></div>
                <a href="/ai/crm/" class="ai-btn-secondary"><?= htmlspecialchars($t['products']['crm']['cta']) ?></a>
            </article>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight" id="features" style="background: rgba(255,255,255,.02);">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['features']['title']) ?></h2>
        <div class="ai-features-grid">
            <?php foreach ($t['features']['items'] as $f): ?>
            <div class="ai-feature">
                <i class="fas fa-<?= htmlspecialchars($f['icon']) ?>"></i>
                <h3><?= htmlspecialchars($f['title']) ?></h3>
                <p><?= htmlspecialchars($f['text']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section" id="how">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['how']['title']) ?></h2>
        <div class="ai-steps">
            <?php foreach ($t['how']['steps'] as $i => $step): ?>
            <div class="ai-step">
                <div class="ai-step-num"><?= $i + 1 ?></div>
                <div>
                    <h3><?= htmlspecialchars($step['title']) ?></h3>
                    <p><?= htmlspecialchars($step['text']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight" id="integrations">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['integrations']['title']) ?></h2>
        <?php if (!empty($t['integrations']['sub'])): ?>
        <p class="ai-section-sub"><?= htmlspecialchars($t['integrations']['sub']) ?></p>
        <?php endif; ?>
        <div class="ai-integrations-grid">
            <?php foreach ($ai_platforms as $card): ?>
            <a href="<?= htmlspecialchars($card['url']) ?>" class="ai-integration-card">
                <span class="ai-integration-card-icon" style="--platform-color: <?= htmlspecialchars($card['color']) ?>">
                    <i class="<?= htmlspecialchars(ai_fa_icon($card['icon'])) ?>" aria-hidden="true"></i>
                </span>
                <span class="ai-integration-card-name"><?= htmlspecialchars($card['name']) ?></span>
                <span class="ai-integration-card-desc"><?= htmlspecialchars($card['desc']) ?></span>
                <span class="ai-integration-card-arrow"><i class="fas fa-arrow-right"></i></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section" id="pricing">
    <div class="ai-container">
        <?php if (!empty($t['subscription']['title'])): ?>
        <div class="ai-subscription-banner">
            <div class="ai-subscription-copy">
                <h2 class="ai-subscription-title"><?= htmlspecialchars($t['subscription']['title']) ?></h2>
                <p class="ai-subscription-sub"><?= htmlspecialchars($t['subscription']['sub']) ?></p>
            </div>
            <a href="<?= htmlspecialchars(ai_subscription_url()) ?>" class="ai-btn-primary" <?= ai_subscription_external_attrs() ?>>
                <?= htmlspecialchars($t['subscription']['cta']) ?>
            </a>
        </div>
        <?php endif; ?>
        <h2 class="ai-section-title"><?= htmlspecialchars($t['pricing']['title']) ?></h2>
        <?php if (!empty($t['pricing']['subtitle'])): ?>
        <p class="ai-section-sub"><?= htmlspecialchars($t['pricing']['subtitle']) ?></p>
        <?php endif; ?>
        <div class="ai-pricing-tiers">
            <?php foreach ($t['pricing']['tiers'] as $tier): ?>
            <div class="ai-pricing-tier<?= !empty($tier['featured']) ? ' ai-pricing-tier--featured' : '' ?>">
                <?php if (!empty($tier['tag'])): ?>
                <span class="ai-pricing-tier-tag"><?= htmlspecialchars($tier['tag']) ?></span>
                <?php endif; ?>
                <h3 class="ai-pricing-tier-title"><?= htmlspecialchars($tier['title']) ?></h3>
                <div class="ai-pricing-tier-price">
                    <div class="ai-pricing-tier-price-row">
                        <strong><?= htmlspecialchars($tier['price']) ?></strong>
                        <?php if (!empty($tier['price_alt'])): ?>
                        <span><?= htmlspecialchars($tier['price_alt']) ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($tier['price_yearly'])): ?>
                    <div class="ai-pricing-tier-price-row ai-pricing-tier-price-row--annual">
                        <strong><?= htmlspecialchars($tier['price_yearly']) ?></strong>
                        <?php if (!empty($tier['price_yearly_alt'])): ?>
                        <span><?= htmlspecialchars($tier['price_yearly_alt']) ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <p class="ai-pricing-tier-desc"><?= htmlspecialchars($tier['desc']) ?></p>
                <a href="<?= htmlspecialchars(ai_subscription_url()) ?>" class="ai-btn-primary" <?= ai_subscription_external_attrs() ?>><?= htmlspecialchars($tier['cta']) ?></a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if (!empty($t['pricing']['fx_note']) || !empty($t['pricing']['payments_notice'])): ?>
        <p class="ai-pricing-note">
            <?= htmlspecialchars($t['pricing']['fx_note'] ?? '') ?>
            <?php if (!empty($t['pricing']['payments_notice'])): ?>
            <span class="ai-pricing-note-muted"><?= htmlspecialchars($t['pricing']['payments_notice']) ?></span>
            <?php endif; ?>
        </p>
        <?php endif; ?>
        <p class="ai-pricing-cabinet">
            <a href="<?= htmlspecialchars(ai_license_cabinet_url()) ?>" <?= ai_subscription_external_attrs() ?>>
                <?= htmlspecialchars($t['pricing']['cabinet_cta'] ?? 'Customer cabinet') ?> <i class="fas fa-external-link-alt" aria-hidden="true"></i>
            </a>
        </p>
        <div class="ai-pricing-box">
            <p class="ai-pricing-includes-title"><?= htmlspecialchars($t['pricing']['includes_title'] ?? '') ?></p>
            <ul class="ai-pricing-list">
                <?php foreach ($t['pricing']['includes'] as $inc): ?>
                <li><?= htmlspecialchars($inc) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight" id="install" style="background: rgba(0,229,255,.03);">
    <div class="ai-container">
        <div class="ai-paypal-card">
            <h2><?= htmlspecialchars($t['install']['title']) ?></h2>
            <p class="sub"><?= htmlspecialchars($t['install']['subtitle']) ?></p>
            <ul class="ai-install-list">
                <?php foreach ($t['install']['items'] as $item): ?>
                <li><?= htmlspecialchars($item) ?></li>
                <?php endforeach; ?>
            </ul>
            <a href="<?= htmlspecialchars(ai_subscription_url()) ?>" class="ai-btn-primary" <?= ai_subscription_external_attrs() ?>><?= htmlspecialchars($t['install']['cta']) ?></a>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['advantages']['title']) ?></h2>
        <div class="ai-adv-grid">
            <?php foreach ($t['advantages']['items'] as $adv): ?>
            <div class="ai-adv-item"><?= htmlspecialchars($adv) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section" id="faq">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['faq']['title']) ?></h2>
        <div class="ai-faq">
            <?php foreach ($t['faq']['items'] as $item): ?>
            <div class="ai-faq-item">
                <button type="button" class="ai-faq-q">
                    <?= htmlspecialchars($item['q']) ?>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <div class="ai-faq-a"><?= htmlspecialchars($item['a']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section" id="ecosystem">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['ecosystem']['title']) ?></h2>
        <p class="ai-section-sub"><?= htmlspecialchars($t['ecosystem']['sub']) ?></p>
        <div class="ai-eco-grid">
            <?php foreach ($ai_projects as $proj): ?>
            <a href="<?= htmlspecialchars($proj['url']) ?>" class="ai-eco-card" target="_blank" rel="noopener">
                <span class="ai-eco-badge"><?= htmlspecialchars($proj['badge']) ?></span>
                <span class="ai-eco-icon" aria-hidden="true"><i class="<?= htmlspecialchars(ai_fa_icon($proj['icon'])) ?>"></i></span>
                <h3><?= htmlspecialchars($proj['title']) ?></h3>
                <p><?= htmlspecialchars($proj['desc']) ?></p>
                <span class="ai-eco-link"><?= htmlspecialchars($t['ecosystem']['visit']) ?> →</span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight ai-seo-text">
    <div class="ai-container">
        <article class="ai-seo-article">
            <h2><?= htmlspecialchars($t['seo_block']['title']) ?></h2>
            <p><?= htmlspecialchars($t['seo_block']['p1']) ?></p>
            <p><?= htmlspecialchars($t['seo_block']['p2']) ?></p>
            <nav class="ai-seo-links" aria-label="bilohash projects">
                <?php foreach ($ai_projects as $proj): ?>
                <a href="<?= htmlspecialchars($proj['url']) ?>"><?= htmlspecialchars($proj['title']) ?></a>
                <?php endforeach; ?>
            </nav>
        </article>
    </div>
</section>

<section class="ai-section ai-section--tight">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($t['developer']['title']) ?></h2>
        <div class="ai-dev-box"><?= $t['developer']['text'] ?></div>
    </div>
</section>

<section class="ai-section" id="contacthouse">
    <span id="contact" tabindex="-1" aria-hidden="true" style="position:absolute;margin-top:-5rem"></span>
    <div class="ai-container">
        <div class="ai-contact-grid">
            <div>
                <h2 class="ai-section-title" style="text-align:left;margin-bottom:16px"><?= htmlspecialchars($t['contact']['title']) ?></h2>
                <p style="color:var(--ai-muted);margin-bottom:16px;line-height:1.7"><?= htmlspecialchars($t['hero']['install_note']) ?></p>
                <ul class="ai-install-list ai-install-list--contact">
                    <?php foreach ($t['install']['items'] as $item): ?>
                    <li><?= htmlspecialchars($item) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="ai-form">
                <?= $feedback ?>
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                    <input type="text" name="name" placeholder="<?= htmlspecialchars($t['contact']['name']) ?>" required autocomplete="name">
                    <input type="email" name="email" placeholder="<?= htmlspecialchars($t['contact']['email']) ?>" required autocomplete="email">
                    <textarea name="message" rows="5" placeholder="<?= htmlspecialchars($t['contact']['message']) ?>" required></textarea>
                    <div class="ai-captcha-row">
                        <span><?= (int)$num1 ?> + <?= (int)$num2 ?> =</span>
                        <input type="number" name="captcha" placeholder="<?= htmlspecialchars($t['contact']['captcha']) ?>" required>
                    </div>
                    <button type="submit" name="order_form" class="ai-btn-primary" style="width:100%"><?= htmlspecialchars($t['contact']['send']) ?></button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>