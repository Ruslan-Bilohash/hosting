<?php
require_once __DIR__ . '/projects-data.php';

function ai_schema_price_offer(
    string $price,
    string $currency,
    string $name,
    string $url,
    string $valid_until = '2026-12-31'
): array {
    return [
        '@type' => 'Offer',
        'name' => $name,
        'price' => $price,
        'priceCurrency' => $currency,
        'availability' => 'https://schema.org/InStock',
        'itemCondition' => 'https://schema.org/NewCondition',
        'url' => $url,
        'priceValidUntil' => $valid_until,
        'seller' => ['@type' => 'Organization', 'name' => 'bilohash.com', 'url' => 'https://bilohash.com/'],
        'priceSpecification' => [
            '@type' => 'UnitPriceSpecification',
            'price' => $price,
            'priceCurrency' => $currency,
            'valueAddedTaxIncluded' => false,
        ],
    ];
}

function ai_schema_product_reviews(): array
{
    return [
        'aggregateRating' => [
            '@type' => 'AggregateRating',
            'ratingValue' => '5',
            'reviewCount' => '3',
            'bestRating' => '5',
            'worstRating' => '1',
        ],
        'review' => [
            [
                '@type' => 'Review',
                'author' => ['@type' => 'Person', 'name' => 'Ole K.'],
                'datePublished' => '2025-11-12',
                'reviewRating' => [
                    '@type' => 'Rating',
                    'ratingValue' => '5',
                    'bestRating' => '5',
                    'worstRating' => '1',
                ],
                'reviewBody' => 'Installed the Grok xAI widget on our dealership site in one evening. Telegram notifications for new leads work perfectly.',
            ],
            [
                '@type' => 'Review',
                'author' => ['@type' => 'Person', 'name' => 'Anna M.'],
                'datePublished' => '2026-01-08',
                'reviewRating' => [
                    '@type' => 'Rating',
                    'ratingValue' => '5',
                    'bestRating' => '5',
                    'worstRating' => '1',
                ],
                'reviewBody' => 'Clear setup guide and responsive support. The chat consultant answers visitors in Norwegian and English around the clock.',
            ],
            [
                '@type' => 'Review',
                'author' => ['@type' => 'Person', 'name' => 'Dmytro S.'],
                'datePublished' => '2026-03-22',
                'reviewRating' => [
                    '@type' => 'Rating',
                    'ratingValue' => '5',
                    'bestRating' => '5',
                    'worstRating' => '1',
                ],
                'reviewBody' => 'Professional installation on WordPress took one day. Grok replies feel natural and we already capture more contact requests.',
            ],
        ],
    ];
}

function ai_render_seo_head(string $title, string $desc, string $canonical, array $faq_items = []): void
{
    global $lang, $lang_meta, $t, $ai_site_url;
    $og_title = $t['meta']['og_title'] ?? $title;
    $keywords = $t['meta']['keywords'] ?? '';
    $og_image = AI_OG_IMAGE;
    $canon_abs = ai_absolute_url($canonical);
    $projects = ai_ecosystem_projects($lang);
    $contact_url = ai_absolute_url(ai_url('index.php') . '#contact');
    $pricing_url = ai_absolute_url(ai_url('index.php') . '#pricing');
    $subscribe_url = 'https://bilohash.com/ecosystem/join.php';
    $product_reviews = ai_schema_product_reviews();
    if (!function_exists('ecosystem_pricing_schema')) {
        require_once dirname(__DIR__, 2) . '/includes/ecosystem-pricing.php';
    }
    $ecoLang = match ($lang) {
        'no' => 'no',
        'ua' => 'ua',
        'ru' => 'ru',
        default => 'en',
    };
    $pricing_schema = ecosystem_pricing_schema($ecoLang);
    $pricing_schema['url'] = $subscribe_url;
    $pricing_schema['availability'] = 'https://schema.org/PreOrder';

    $schemas = [
        [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => 'bilohash.com AI Platform',
            'url' => $ai_site_url . '/',
            'description' => $desc,
            'inLanguage' => $lang_meta['html'],
            'publisher' => ['@type' => 'Organization', 'name' => 'bilohash.com', 'url' => 'https://bilohash.com/'],
            'potentialAction' => [
                '@type' => 'SearchAction',
                'target' => 'https://bilohash.com/?q={search_term_string}',
                'query-input' => 'required name=search_term_string',
            ],
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'WebPage',
            '@id' => $canon_abs . '#webpage',
            'name' => $title,
            'description' => $desc,
            'url' => $canon_abs,
            'inLanguage' => $lang_meta['html'],
            'isPartOf' => ['@id' => $ai_site_url . '/#website'],
            'about' => ['@type' => 'Thing', 'name' => 'Grok xAI chat consultant'],
            'primaryImageOfPage' => ['@type' => 'ImageObject', 'url' => $og_image],
        ],
        array_merge([
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => 'AI Consultant Grok xAI',
            'description' => $desc,
            'image' => [$og_image],
            'url' => $canon_abs,
            'sku' => 'ai-consultant-grok',
            'category' => 'Software > Business Software > Chatbot',
            'brand' => ['@type' => 'Brand', 'name' => 'bilohash.com'],
            'manufacturer' => ['@type' => 'Organization', 'name' => 'bilohash.com'],
            'offers' => array_merge($pricing_schema, ['url' => $subscribe_url]),
        ], $product_reviews),
        array_merge([
            '@context' => 'https://schema.org',
            '@type' => 'SoftwareApplication',
            'name' => 'AI Consultant Grok xAI',
            'applicationCategory' => 'BusinessApplication',
            'operatingSystem' => 'Web, WordPress, PHP',
            'description' => $desc,
            'url' => $canon_abs,
            'image' => $og_image,
            'softwareVersion' => '2026',
            'author' => ['@type' => 'Person', 'name' => 'Ruslan Bilohash', 'url' => 'https://bilohash.com/resume.php'],
            'offers' => $pricing_schema['offers'][0] ?? $pricing_schema,
            'featureList' => 'Grok xAI, Telegram notifications, lead capture, multilingual, BILOHASH subscription',
        ], $product_reviews),
        [
            '@context' => 'https://schema.org',
            '@type' => 'Service',
            'name' => 'AI Consultant installation service',
            'description' => 'Grok xAI chat consultant — unified BILOHASH subscription, one domain, one-click install',
            'provider' => ['@type' => 'Organization', 'name' => 'bilohash.com', 'url' => 'https://bilohash.com/'],
            'areaServed' => ['NO', 'UA', 'EU', 'GB', 'LT', 'SE'],
            'offers' => $pricing_schema,
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            '@id' => 'https://bilohash.com/#organization',
            'name' => 'bilohash.com',
            'url' => 'https://bilohash.com/',
            'logo' => ['@type' => 'ImageObject', 'url' => 'https://bilohash.com/bilohash.jpg'],
            'founder' => ['@type' => 'Person', 'name' => 'Ruslan Bilohash', 'url' => 'https://bilohash.com/resume.php'],
            'sameAs' => [
                'https://bilohash.com/',
                'https://wordpress.org/plugins/bilohash-ai-chat-consultant/',
            ],
            'contactPoint' => [
                '@type' => 'ContactPoint',
                'contactType' => 'sales',
                'email' => AI_CONTACT_EMAIL,
                'availableLanguage' => ['Ukrainian', 'English', 'Norwegian', 'Russian'],
            ],
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'Person',
            'name' => 'Ruslan Bilohash',
            'url' => 'https://bilohash.com/resume.php',
            'jobTitle' => 'AI & CMS Developer',
            'worksFor' => ['@id' => 'https://bilohash.com/#organization'],
            'sameAs' => ['https://bilohash.com/'],
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                ['@type' => 'ListItem', 'position' => 1, 'name' => 'bilohash.com', 'item' => 'https://bilohash.com/'],
                ['@type' => 'ListItem', 'position' => 2, 'name' => 'AI Platform', 'item' => $canon_abs],
            ],
        ],
        [
            '@context' => 'https://schema.org',
            '@type' => 'ItemList',
            'name' => 'bilohash.com ecosystem',
            'itemListElement' => array_map(static function ($p, $i) {
                return [
                    '@type' => 'ListItem',
                    'position' => $i + 1,
                    'name' => $p['title'],
                    'url' => $p['url'],
                ];
            }, $projects, array_keys($projects)),
        ],
    ];

    if ($faq_items) {
        $entities = [];
        foreach ($faq_items as $item) {
            $entities[] = [
                '@type' => 'Question',
                'name' => $item['q'],
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $item['a']],
            ];
        }
        $schemas[] = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $entities];
    }
    ?>
    <title><?= htmlspecialchars($title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($desc) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <meta name="author" content="Ruslan Bilohash">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="googlebot" content="index, follow">
    <meta name="language" content="<?= htmlspecialchars($lang_meta['html']) ?>">
    <meta name="geo.region" content="NO">
    <meta name="geo.placename" content="Norway">
    <link rel="canonical" href="<?= htmlspecialchars($canon_abs) ?>">
    <link rel="sitemap" type="application/xml" title="Sitemap" href="<?= htmlspecialchars(ai_absolute_url(ai_url('sitemap.xml'))) ?>">

    <?php
    require_once dirname(__DIR__, 2) . '/includes/bh-open-graph.php';
    bh_render_open_graph([
        'title' => $og_title,
        'description' => $desc,
        'url' => $canon_abs,
        'image' => $og_image,
        'site_name' => 'bilohash.com AI',
        'type' => 'website',
        'locale' => $lang_meta['locale'],
        'locale_alternates' => bh_og_locales_from_lang_meta(ai_langs(), $lang),
        'image_alt' => 'Grok xAI chat widget on website',
    ]);
    ?>
    <meta name="theme-color" content="#00e5ff">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(ai_absolute_url(ai_lang_url('no', true))) ?>">
    <?php foreach (ai_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= htmlspecialchars($info['hreflang']) ?>" href="<?= htmlspecialchars(ai_absolute_url(ai_lang_url($code, true))) ?>">
    <?php endforeach; ?>

    <?php foreach ($schemas as $schema): ?>
    <script type="application/ld+json"><?= json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
    <?php endforeach; ?>
    <?php
}

function ai_render_platform_seo_head(
    string $title,
    string $desc,
    string $canonical,
    array $schema_graphs = [],
    ?string $keywords = null
): void {
    global $lang_meta, $lang;
    require_once __DIR__ . '/platform-lib.php';
    $canonical_abs = ai_absolute_url($canonical);
    $og_image = AI_OG_IMAGE;
    $slug = $GLOBALS['platform_slug'] ?? '';
    $primary_langs = ['ua', 'ru', 'en', 'no'];
    ?>
    <title><?= htmlspecialchars($title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($desc) ?>">
    <?php if ($keywords): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
    <meta name="author" content="Ruslan Bilohash">
    <meta name="language" content="<?= htmlspecialchars($lang_meta['html']) ?>">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(ai_absolute_url(ai_platform_lang_url_for($slug, 'no'))) ?>">
    <?php foreach ($primary_langs as $code):
        $info = ai_langs()[$code] ?? null;
        if (!$info) continue;
    ?>
    <link rel="alternate" hreflang="<?= htmlspecialchars($info['hreflang']) ?>" href="<?= htmlspecialchars(ai_absolute_url(ai_platform_lang_url_for($slug, $code))) ?>">
    <?php endforeach; ?>
    <?php foreach (['lt', 'sv'] as $code):
        $info = ai_langs()[$code] ?? null;
        if (!$info) continue;
    ?>
    <link rel="alternate" hreflang="<?= htmlspecialchars($info['hreflang']) ?>" href="<?= htmlspecialchars(ai_absolute_url(ai_platform_lang_url_for($slug, $code))) ?>">
    <?php endforeach; ?>
    <?php
    require_once dirname(__DIR__, 2) . '/includes/bh-open-graph.php';
    bh_render_open_graph([
        'title' => $title,
        'description' => $desc,
        'url' => $canonical_abs,
        'image' => $og_image,
        'site_name' => 'bilohash.com AI',
        'type' => 'website',
        'locale' => $lang_meta['locale'],
        'locale_alternates' => bh_og_locales_from_lang_meta(ai_langs(), $lang),
        'image_alt' => $title,
    ]);
    ?>
    <meta name="theme-color" content="#00e5ff">
    <?php if ($schema_graphs): ?>
    <?php foreach ($schema_graphs as $schema): ?>
    <script type="application/ld+json"><?= json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
    <?php endforeach; ?>
    <?php endif;
}