<?php
// 404.php - Кастомная страница ошибки для bilohash.com
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Страница не найдена | Руслан Билохаш</title>
    <meta name="description" content="Извините, страница, которую вы ищете, не существует. Давайте найдём лучшее решение.">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', system-ui, sans-serif;
        }
        
        .code-bg {
            background: linear-gradient(45deg, #0f172a, #1e2937);
        }
        
        .glitch {
            animation: glitch 0.8s infinite alternate;
        }
        
        @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-3px, 3px); }
            40% { transform: translate(3px, -3px); }
            60% { transform: translate(-2px, 2px); }
            80% { transform: translate(2px, -2px); }
            100% { transform: translate(0); }
        }
        
        .terminal {
            font-family: ui-monospace, monospace;
            background: rgba(15, 23, 42, 0.95);
        }
    </style>
</head>
<body class="bg-slate-950 text-slate-200 min-h-screen flex items-center justify-center code-bg overflow-hidden">
    <div class="max-w-2xl mx-auto px-6 py-12 text-center relative z-10">
        <!-- 404 Header -->
        <div class="mb-8">
            <div class="inline-flex items-center gap-3 bg-slate-900 border border-red-500/30 rounded-2xl px-6 py-3 mb-6">
                <i class="fa-solid fa-bug text-red-400 text-2xl"></i>
                <span class="text-red-400 font-mono text-xl font-bold tracking-widest">ERROR 404</span>
            </div>
            
            <h1 class="text-8xl md:text-9xl font-bold text-white mb-2 glitch">404</h1>
            <p class="text-3xl md:text-4xl font-semibold text-slate-400">Страница не найдена</p>
        </div>

        <!-- Terminal Style Message -->
        <div class="terminal border border-slate-700 rounded-3xl p-8 mb-10 text-left max-w-md mx-auto">
            <div class="flex items-center gap-2 mb-4 text-emerald-400">
                <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                <div class="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div class="w-3 h-3 bg-emerald-500 rounded-full"></div>
            </div>
            <p class="text-emerald-400 font-mono text-sm leading-relaxed">
                $ ls /BILOHASH.COM<br>
                <span class="text-red-400">page_not_found.php: No such file or directory</span><br><br>
                Возможно, вы открыли старую ссылку?<br>
                Или я только что обновил сайт 😊
            </p>
        </div>

        <div class="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <!-- Back to Home -->
            <a href="https://bilohash.com/website" 
               class="group flex items-center justify-center gap-3 bg-white hover:bg-slate-100 text-slate-900 font-semibold px-8 py-4 rounded-2xl transition-all duration-300 w-full sm:w-auto">
                <i class="fa-solid fa-house group-active:scale-90 transition-transform"></i>
                Вернуться на главную
            </a>
            
            <!-- Contact -->
            <a href="https://bilohash.com/website#contact" 
               class="group flex items-center justify-center gap-3 border border-slate-600 hover:border-slate-400 font-medium px-8 py-4 rounded-2xl transition-all duration-300 w-full sm:w-auto">
                <i class="fa-solid fa-paper-plane"></i>
                Связаться со мной
            </a>
        </div>

        <div class="mt-12 text-slate-500 text-sm">
            Руслан Билохаш • Профессиональный PHP-разработчик в Драммене, Норвегия<br>
            <a href="https://bilohash.com/website" class="hover:text-slate-300 underline">bilohash.com</a>
        </div>
    </div>

    <!-- Background Decor -->
    <div class="absolute inset-0 opacity-10 pointer-events-none">
        <div class="absolute top-20 left-10 text-[180px] font-mono font-black text-white/5 select-none">PHP</div>
        <div class="absolute bottom-20 right-10 text-[160px] font-mono font-black text-white/5 select-none rotate-12">404</div>
    </div>

    <script>
        // Простая анимация
        setTimeout(() => {
            document.querySelectorAll('.glitch').forEach(el => {
                el.style.animation = 'glitch 400ms infinite';
            });
        }, 1200);
    </script>
</body>
</html>