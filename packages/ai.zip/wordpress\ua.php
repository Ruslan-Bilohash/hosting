<?php
header('Location: /ai/wordpress/?lang=ua', true, 301);
exit;