<?php
/**
 * CRM AI Consultant — Performance debugger (v5.1)
 * JSON storage benchmarks, chat pipeline tests, migration status
 */

require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_require_login();

if (crm_ai_is_demo()) {
    header('Location: index.php?demo_readonly=1');
    exit;
}

$sites = crm_ai_list_sites();
$site_ids = array_column($sites, 'id');
$selected_site = crm_ai_sanitize_id($_POST['site_id'] ?? $_GET['site_id'] ?? ($site_ids[0] ?? ''));
if ($selected_site === '' && !empty($site_ids)) {
    $selected_site = $site_ids[0];
}

$stats = crm_storage_stats();
$log = crm_perf_read_log();
$benchmark_results = null;
$chat_test_result = null;
$migrate_report = null;
$notice = '';
$error = '';

$migration_pending = count(crm_storage_list_site_ids()) === 0 && isset($pdo) && $pdo instanceof PDO;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!crm_ai_verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = $ta['debug']['csrf_error'] ?? 'Invalid security token.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'benchmark' && $selected_site !== '') {
            $t0 = microtime(true);
            $benchmark_results = crm_perf_benchmark($selected_site);
            $entry = [
                'type'      => 'benchmark',
                'site_id'   => $selected_site,
                'total_ms'  => round((microtime(true) - $t0) * 1000, 2),
                'tests'     => $benchmark_results,
                'timestamp' => date('Y-m-d H:i:s'),
                'admin'     => $_SESSION['crm_ai_admin_username'] ?? 'admin',
            ];
            crm_perf_save_log($entry);
            $log = crm_perf_read_log();
            $notice = $ta['debug']['benchmark_done'] ?? 'Benchmark completed.';
        }

        if ($action === 'chat_test' && $selected_site !== '') {
            $_POST['crm_perf'] = '1';
            $t0 = microtime(true);
            $chat_test_result = crm_ai_process_message($selected_site, 'debug_perf_' . time(), 'ping');
            $total_ms = round((microtime(true) - $t0) * 1000, 2);
            $entry = [
                'type'      => 'chat_test',
                'site_id'   => $selected_site,
                'total_ms'  => $total_ms,
                'success'   => !empty($chat_test_result['success']),
                'perf'      => $chat_test_result['_perf'] ?? [],
                'timestamp' => date('Y-m-d H:i:s'),
                'admin'     => $_SESSION['crm_ai_admin_username'] ?? 'admin',
            ];
            crm_perf_save_log($entry);
            $log = crm_perf_read_log();
            $notice = $ta['debug']['chat_test_done'] ?? 'Chat pipeline test completed.';
        }

        if ($action === 'migrate') {
            crm_ai_require_write_access();
            if (isset($pdo) && $pdo instanceof PDO) {
                $migrate_report = crm_migrate_mysql_to_json($pdo);
                $stats = crm_storage_stats();
                if (!empty($migrate_report['skipped'])) {
                    $notice = $ta['debug']['migrate_skipped'] ?? 'Migration skipped — JSON data already exists.';
                } else {
                    $notice = sprintf(
                        $ta['debug']['migrate_done'] ?? 'Migrated %d sites, %d messages.',
                        (int)($migrate_report['sites'] ?? 0),
                        (int)($migrate_report['messages'] ?? 0)
                    );
                }
            } else {
                $error = $ta['debug']['migrate_no_db'] ?? 'MySQL connection unavailable.';
            }
        }
    }
}

$data_htaccess = is_file(dirname(__DIR__) . '/data/.htaccess');
$data_writable = is_writable(CRM_DATA_DIR);
$secrets_writable = is_writable(CRM_SECRETS_DIR);

function crm_debug_bar_width(float $ms, float $max): int
{
    if ($max <= 0) {
        return 0;
    }
    return (int)min(100, round(($ms / $max) * 100));
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ta['debug']['title'] ?? 'Debug / Performance') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <?php require_once __DIR__ . '/includes/theme.php'; crm_admin_theme_head(); ?>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen flex flex-col">

<?php include 'navigation.php'; ?>

<div class="max-w-7xl mx-auto p-6 lg:p-10 flex-1 w-full">

    <div class="mb-10">
        <h1 class="text-4xl font-bold tracking-tight flex items-center gap-3">
            <i class="fas fa-gauge-high text-sky-400"></i>
            <?= htmlspecialchars($ta['debug']['heading'] ?? 'Debug / Performance') ?>
        </h1>
        <p class="text-zinc-400 mt-2"><?= htmlspecialchars($ta['debug']['subtitle'] ?? '') ?></p>
    </div>

    <?php if ($notice): ?>
    <div class="mb-6 px-5 py-4 bg-emerald-900/40 border border-emerald-700 rounded-2xl text-emerald-300">
        <?= htmlspecialchars($notice) ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="mb-6 px-5 py-4 bg-red-900/40 border border-red-700 rounded-2xl text-red-300">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
            <div class="text-zinc-400 text-sm mb-1"><?= htmlspecialchars($ta['debug']['stat_sites'] ?? 'Sites (JSON)') ?></div>
            <div class="text-3xl font-bold text-sky-400"><?= (int)$stats['sites'] ?></div>
        </div>
        <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
            <div class="text-zinc-400 text-sm mb-1"><?= htmlspecialchars($ta['debug']['stat_conversations'] ?? 'Conversation files') ?></div>
            <div class="text-3xl font-bold text-indigo-400"><?= (int)$stats['conversation_files'] ?></div>
        </div>
        <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
            <div class="text-zinc-400 text-sm mb-1"><?= htmlspecialchars($ta['debug']['stat_data_size'] ?? 'Data size') ?></div>
            <div class="text-3xl font-bold text-amber-400"><?= htmlspecialchars((string)$stats['data_size_kb']) ?> <span class="text-lg"><?= htmlspecialchars($ta['debug']['data_unit_kb']) ?></span></div>
        </div>
        <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
            <div class="text-zinc-400 text-sm mb-1"><?= htmlspecialchars($ta['debug']['stat_storage'] ?? 'Storage engine') ?></div>
            <div class="text-xl font-bold text-emerald-400"><?= htmlspecialchars($ta['debug']['storage_version']) ?></div>
            <div class="text-xs text-zinc-500 mt-1"><?= htmlspecialchars($ta['debug']['mysql_admins_only']) ?></div>
        </div>
    </div>

    <!-- Security -->
    <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6 mb-10">
        <h2 class="text-xl font-semibold mb-4 flex items-center gap-2">
            <i class="fas fa-shield-halved text-amber-400"></i>
            <?= htmlspecialchars($ta['debug']['security_heading'] ?? 'Security checks') ?>
        </h2>
        <div class="grid sm:grid-cols-3 gap-4 text-sm">
            <div class="flex items-center gap-3 px-4 py-3 bg-zinc-800 rounded-xl">
                <i class="fas <?= $data_htaccess ? 'fa-check-circle text-emerald-400' : 'fa-times-circle text-red-400' ?>"></i>
                <span><?= htmlspecialchars($ta['debug']['sec_htaccess']) ?></span>
            </div>
            <div class="flex items-center gap-3 px-4 py-3 bg-zinc-800 rounded-xl">
                <i class="fas <?= $data_writable ? 'fa-check-circle text-emerald-400' : 'fa-times-circle text-red-400' ?>"></i>
                <span><?= htmlspecialchars($ta['debug']['sec_data_writable']) ?></span>
            </div>
            <div class="flex items-center gap-3 px-4 py-3 bg-zinc-800 rounded-xl">
                <i class="fas <?= $secrets_writable ? 'fa-check-circle text-emerald-400' : 'fa-times-circle text-red-400' ?>"></i>
                <span><?= htmlspecialchars($ta['debug']['sec_secrets_writable']) ?></span>
            </div>
        </div>
    </div>

    <!-- Tests -->
    <div class="grid lg:grid-cols-2 gap-8 mb-10">
        <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
            <h2 class="text-xl font-semibold mb-4"><?= htmlspecialchars($ta['debug']['benchmark_heading'] ?? 'Storage benchmark') ?></h2>
            <p class="text-zinc-400 text-sm mb-6"><?= htmlspecialchars($ta['debug']['benchmark_hint'] ?? '') ?></p>

            <?php if (empty($site_ids)): ?>
            <p class="text-amber-400"><?= htmlspecialchars($ta['debug']['no_sites'] ?? 'Add a site first.') ?></p>
            <?php else: ?>
            <form method="post" class="space-y-4">
                <?= crm_ai_csrf_field() ?>
                <input type="hidden" name="action" value="benchmark">
                <label class="block text-sm text-zinc-400"><?= htmlspecialchars($ta['debug']['select_site'] ?? 'Site') ?></label>
                <select name="site_id" class="w-full bg-zinc-800 border border-zinc-600 rounded-xl px-4 py-3 text-white">
                    <?php foreach ($sites as $s): ?>
                    <option value="<?= htmlspecialchars($s['id']) ?>" <?= $selected_site === $s['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['name'] ?? $s['id']) ?> (<?= htmlspecialchars($s['id']) ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="w-full py-3 bg-sky-600 hover:bg-sky-500 rounded-xl font-medium transition">
                    <i class="fas fa-play mr-2"></i><?= htmlspecialchars($ta['debug']['run_benchmark'] ?? 'Run benchmark') ?>
                </button>
            </form>

            <?php if ($benchmark_results): ?>
            <?php $max_ms = max(array_column($benchmark_results, 'ms')); ?>
            <div class="mt-6 space-y-3">
                <?php foreach ($benchmark_results as $row): ?>
                <div>
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-zinc-300"><?= htmlspecialchars($row['name']) ?></span>
                        <span class="font-mono <?= crm_perf_speed_class((float)$row['ms']) ?>"><?= $row['ms'] ?> ms</span>
                    </div>
                    <div class="h-2 bg-zinc-800 rounded-full overflow-hidden">
                        <div class="h-full bg-gradient-to-r from-sky-500 to-indigo-500 rounded-full" style="width:<?= crm_debug_bar_width((float)$row['ms'], (float)$max_ms) ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
            <h2 class="text-xl font-semibold mb-4"><?= htmlspecialchars($ta['debug']['chat_test_heading'] ?? 'Full chat pipeline') ?></h2>
            <p class="text-zinc-400 text-sm mb-6"><?= htmlspecialchars($ta['debug']['chat_test_hint'] ?? '') ?></p>

            <?php if (empty($site_ids)): ?>
            <p class="text-amber-400"><?= htmlspecialchars($ta['debug']['no_sites'] ?? 'Add a site first.') ?></p>
            <?php else: ?>
            <form method="post" class="space-y-4">
                <?= crm_ai_csrf_field() ?>
                <input type="hidden" name="action" value="chat_test">
                <label class="block text-sm text-zinc-400"><?= htmlspecialchars($ta['debug']['select_site'] ?? 'Site') ?></label>
                <select name="site_id" class="w-full bg-zinc-800 border border-zinc-600 rounded-xl px-4 py-3 text-white">
                    <?php foreach ($sites as $s): ?>
                    <option value="<?= htmlspecialchars($s['id']) ?>" <?= $selected_site === $s['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['name'] ?? $s['id']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="w-full py-3 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-medium transition">
                    <i class="fas fa-comments mr-2"></i><?= htmlspecialchars($ta['debug']['run_chat_test'] ?? 'Test chat response') ?>
                </button>
            </form>

            <?php if ($chat_test_result): ?>
            <div class="mt-6 p-4 bg-zinc-800 rounded-xl text-sm">
                <div class="mb-3">
                    <?= !empty($chat_test_result['success'])
                        ? '<span class="text-emerald-400"><i class="fas fa-check"></i> ' . htmlspecialchars($ta['debug']['test_ok']) . '</span>'
                        : '<span class="text-red-400"><i class="fas fa-times"></i> ' . htmlspecialchars($chat_test_result['message'] ?? 'Error') . '</span>' ?>
                </div>
                <?php if (!empty($chat_test_result['_perf'])): ?>
                <table class="w-full font-mono text-xs">
                    <?php foreach ($chat_test_result['_perf'] as $p): ?>
                    <tr class="border-t border-zinc-700">
                        <td class="py-2 text-zinc-400"><?= htmlspecialchars($p['label']) ?></td>
                        <td class="py-2 text-right <?= crm_perf_speed_class((float)$p['ms']) ?>"><?= $p['ms'] ?> ms</td>
                        <td class="py-2 text-right text-zinc-500"><?= $p['mem_kb'] ?> KB</td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Migration -->
    <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6 mb-10">
        <h2 class="text-xl font-semibold mb-4 flex items-center gap-2">
            <i class="fas fa-database text-purple-400"></i>
            <?= htmlspecialchars($ta['debug']['migrate_heading'] ?? 'MySQL → JSON migration') ?>
        </h2>
        <p class="text-zinc-400 text-sm mb-4"><?= htmlspecialchars($ta['debug']['migrate_hint'] ?? '') ?></p>
        <?php if ($migration_pending): ?>
        <form method="post" class="inline">
            <?= crm_ai_csrf_field() ?>
            <input type="hidden" name="action" value="migrate">
            <button type="submit" class="px-6 py-3 bg-purple-600 hover:bg-purple-500 rounded-xl font-medium transition">
                <i class="fas fa-arrow-right-arrow-left mr-2"></i><?= htmlspecialchars($ta['debug']['run_migrate'] ?? 'Run migration') ?>
            </button>
        </form>
        <?php else: ?>
        <span class="inline-flex items-center gap-2 px-4 py-2 bg-emerald-900/30 border border-emerald-700 rounded-xl text-emerald-300 text-sm">
            <i class="fas fa-check"></i> <?= htmlspecialchars($ta['debug']['migrate_ok'] ?? 'JSON storage active') ?>
        </span>
        <?php endif; ?>
        <?php if ($migrate_report): ?>
        <p class="mt-4 text-sm text-zinc-400 font-mono"><?= htmlspecialchars(json_encode($migrate_report, JSON_UNESCAPED_UNICODE)) ?></p>
        <?php endif; ?>
    </div>

    <!-- Log history -->
    <div class="bg-zinc-900 border border-zinc-700 rounded-2xl p-6">
        <h2 class="text-xl font-semibold mb-4"><?= htmlspecialchars($ta['debug']['log_heading'] ?? 'Test history') ?></h2>
        <?php if (empty($log)): ?>
        <p class="text-zinc-500"><?= htmlspecialchars($ta['debug']['log_empty'] ?? 'No tests yet.') ?></p>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="text-zinc-400 border-b border-zinc-700">
                        <th class="text-left py-3 pr-4"><?= htmlspecialchars($ta['debug']['col_time'] ?? 'Time') ?></th>
                        <th class="text-left py-3 pr-4"><?= htmlspecialchars($ta['debug']['col_type'] ?? 'Type') ?></th>
                        <th class="text-left py-3 pr-4">site_id</th>
                        <th class="text-right py-3"><?= htmlspecialchars($ta['debug']['col_total'] ?? 'Total') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($log as $entry): ?>
                    <tr class="border-b border-zinc-800 hover:bg-zinc-800/50">
                        <td class="py-3 pr-4 font-mono text-xs text-zinc-400"><?= htmlspecialchars($entry['timestamp'] ?? '') ?></td>
                        <td class="py-3 pr-4">
                            <span class="px-2 py-1 rounded-lg text-xs <?= ($entry['type'] ?? '') === 'chat_test' ? 'bg-indigo-900 text-indigo-300' : 'bg-sky-900 text-sky-300' ?>">
                                <?= htmlspecialchars($entry['type'] ?? '') ?>
                            </span>
                        </td>
                        <td class="py-3 pr-4 font-mono"><?= htmlspecialchars($entry['site_id'] ?? '') ?></td>
                        <td class="py-3 text-right font-mono <?= crm_perf_speed_class((float)($entry['total_ms'] ?? 0)) ?>">
                            <?= htmlspecialchars((string)($entry['total_ms'] ?? 0)) ?> ms
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

</div>

<?php include 'footer.php'; ?>
</body>
</html>