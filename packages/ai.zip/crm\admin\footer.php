<?php
/**
 * admin/footer.php
 * Світлий сучасний футер адмін-панелі
 * Version: 3.3
 */
require_once dirname(__DIR__) . '/version.php';
?>

<footer class="bg-zinc-800 border-t border-zinc-600 mt-auto">
    <div class="max-w-7xl mx-auto px-6 py-16">
        
        <div class="flex flex-col lg:flex-row justify-between items-center gap-12">
          
            <!-- Логотип + опис -->
            <div class="max-w-sm">
                <div class="flex items-center gap-5 mb-6">
                    <div class="w-11 h-11 bg-gradient-to-br from-sky-400 via-blue-400 to-indigo-400 rounded-2xl flex items-center justify-center text-3xl shadow-xl shadow-sky-400/30">
                        🤖
                    </div>
                    <div>
                        <span class="font-bold text-2xl text-white tracking-tight"><?= htmlspecialchars($ta['app_name']) ?></span>
                        <span class="text-emerald-400 text-sm ml-3 font-mono">v<?= CRM_AI_VERSION ?></span>
                    </div>
                </div>
                <p class="text-zinc-200 leading-relaxed">
                    <?= htmlspecialchars($ta['footer']['description']) ?>
                </p>
            </div>

            <!-- Посилання -->
            <div class="flex flex-wrap justify-center gap-x-10 gap-y-6 text-sm">
                <a href="../documentation.html" 
                   class="flex items-center gap-2 text-zinc-200 hover:text-white transition-all hover:translate-x-1">
                    <i class="fas fa-book"></i>
                    <span><?= htmlspecialchars($ta['footer']['documentation']) ?></span>
                </a>
                
                <a href="https://github.com/Ruslan-Bilohash/crm-ai-consultant" 
                   target="_blank"
                   class="flex items-center gap-2 text-zinc-200 hover:text-white transition-all hover:translate-x-1">
                    <i class="fab fa-github"></i>
                    <span><?= htmlspecialchars($ta['footer']['github']) ?></span>
                </a>
                
                <a href="https://bilohash.com/" 
                   target="_blank"
                   class="flex items-center gap-2 text-zinc-200 hover:text-white transition-all hover:translate-x-1">
                    <i class="fas fa-globe"></i>
                    <span>bilohash.com</span>
                </a>
            </div>

            <!-- Правий блок -->
            <div class="text-right">
                <p class="text-zinc-200 text-sm">
                    © <?= date('Y') ?> Ruslan Bilohash
                </p>
                <p class="text-zinc-300 text-xs mt-2 font-mono">
                    <?= htmlspecialchars($ta['tagline']) ?>
                </p>
                <div class="mt-6 text-[10px] text-zinc-400">
                    <?= htmlspecialchars($ta['footer']['made_with']) ?>
                </div>
            </div>
        </div>

        <!-- Нижній рядок -->
        <div class="mt-16 pt-8 border-t border-zinc-600 text-center">
            <p class="text-zinc-300 text-xs leading-relaxed max-w-2xl mx-auto">
                <?= htmlspecialchars($ta['footer']['bottom_text']) ?>
            </p>
        </div>

    </div>
</footer>