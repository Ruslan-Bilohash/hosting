<?php
/**
 * CRM AI Consultant — Core functions (v5.1 JSON storage)
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/migrate-mysql-to-json.php';
require_once __DIR__ . '/ai-models.php';
require_once __DIR__ . '/performance.php';

crm_storage_init();

if (isset($pdo) && $pdo instanceof PDO) {
    crm_migrate_mysql_to_json($pdo);
}

function crm_ai_get_site_settings($site_id, bool $with_secrets = false)
{
    return crm_storage_get_site($site_id, $with_secrets);
}

function crm_ai_get_prompt($site_id)
{
    return crm_storage_get_prompt($site_id);
}

function crm_ai_get_secrets($site_id): array
{
    return crm_storage_get_secrets($site_id);
}

function crm_ai_save_message($site_id, $session, $content, $sender = 'bot')
{
    return crm_storage_save_message($site_id, $session, $content, $sender);
}

function crm_ai_get_conversation($site_id, $session, int $limit = 0)
{
    return crm_storage_get_conversation($site_id, $session, $limit);
}

function crm_ai_list_conversations(?string $site_id = null): array
{
    return crm_storage_list_conversations($site_id);
}

function crm_ai_save_site(string $site_id, array $data): bool
{
    return crm_storage_save_site($site_id, $data);
}

function crm_ai_delete_site(string $site_id): void
{
    crm_storage_delete_site($site_id);
}

function crm_ai_list_sites(): array
{
    return crm_storage_list_sites();
}

function crm_ai_update_site(string $site_id, array $patch): bool
{
    return crm_storage_update_site($site_id, $patch);
}

function crm_ai_process_message($site_id, $session, $message)
{
    $profile = !empty($_GET['crm_perf']) || !empty($_POST['crm_perf']);
    if ($profile) {
        CrmPerf::enable();
        CrmPerf::mark('start');
    }

    $settings = crm_ai_get_site_settings($site_id);
    if ($profile) {
        CrmPerf::mark('load_settings');
    }

    if (!$settings || empty($settings['enable_chat'])) {
        return ['success' => false, 'message' => 'Чат вимкнено для цього сайту'];
    }

    $channel = strtolower(trim($settings['default_channel'] ?? 'telegram'));
    $send_to_telegram_too = !empty($settings['send_to_telegram_too']);

    try {
        switch ($channel) {
            case 'openai':
                require_once __DIR__ . '/../channels/openai.php';
                $result = crm_ai_send_to_openai($site_id, $session, $message);
                break;
            case 'grok':
                require_once __DIR__ . '/../channels/grok.php';
                $result = crm_ai_send_to_grok($site_id, $session, $message);
                break;
            case 'whatsapp':
                require_once __DIR__ . '/../channels/whatsapp.php';
                $result = crm_ai_send_to_whatsapp($site_id, $session, $message);
                break;
            case 'viber':
                require_once __DIR__ . '/../channels/viber.php';
                $result = crm_ai_send_to_viber($site_id, $session, $message);
                break;
            case 'telegram':
            default:
                require_once __DIR__ . '/../channels/telegram.php';
                $result = crm_ai_send_to_telegram($site_id, $session, $message);
        }

        if ($send_to_telegram_too && $channel !== 'telegram') {
            require_once __DIR__ . '/../channels/telegram.php';
            crm_ai_send_to_telegram($site_id, $session, $message, 'Користувач (AI)');
        }

        if ($profile) {
            CrmPerf::mark('channel_done');
            $result['_perf'] = CrmPerf::report();
            CrmPerf::reset();
        }

        return $result;
    } catch (Throwable $e) {
        error_log('CRM AI ERROR: ' . $e->getMessage() . ' | Site: ' . $site_id);
        return ['success' => false, 'message' => 'Внутрішня помилка сервера'];
    }
}