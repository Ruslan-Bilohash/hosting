document.getElementById('demo-chat-btn').addEventListener('click', function() {
    document.getElementById('demo-chat-window').style.display = 'block';
    this.style.display = 'none';
});

document.getElementById('close-chat').addEventListener('click', function() {
    document.getElementById('demo-chat-window').style.display = 'none';
    document.getElementById('demo-chat-btn').style.display = 'block';
});

document.getElementById('send-btn').addEventListener('click', sendMessage);
document.getElementById('chat-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') sendMessage();
});

function sendMessage() {
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text) return;

    const messages = document.getElementById('chat-messages');

    // User message
    const userMsg = document.createElement('div');
    userMsg.style.cssText = 'align-self:flex-end; background:#00f5ff; color:#000; padding:12px 18px; border-radius:18px 18px 4px 18px; max-width:80%; margin-bottom:10px;';
    userMsg.textContent = text;
    messages.appendChild(userMsg);

    input.value = '';

    // Bot thinking
    const thinking = document.createElement('div');
    thinking.style.cssText = 'align-self:flex-start; background:#2a2a4a; padding:12px 18px; border-radius:18px 18px 18px 4px; color:#aaa; font-style:italic;';
    thinking.textContent = 'AI is thinking...';
    messages.appendChild(thinking);
    messages.scrollTop = messages.scrollHeight;

    setTimeout(() => {
        thinking.remove();

        const botMsg = document.createElement('div');
        botMsg.style.cssText = 'align-self:flex-start; background:#1f1f3a; padding:12px 18px; border-radius:18px 18px 18px 4px; max-width:80%;';
        botMsg.textContent = "Hello! I'm Bilohash AI Chat Consultant powered by Grok xAI. How can I help you today?";
        messages.appendChild(botMsg);
        messages.scrollTop = messages.scrollHeight;
    }, 1200);
}