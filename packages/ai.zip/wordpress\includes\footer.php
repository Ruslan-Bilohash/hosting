<?php
global $wp_version, $wp_paypal, $wp_wporg;
$ft = $t['footer'];
$copy_tpl = $ft['copy'] ?? '© %s Ruslan Bilohash. AI Consultant GROK %s.';
$copy = @sprintf($copy_tpl, date('Y'), $wp_version ?? '') ?: ('© ' . date('Y') . ' Ruslan Bilohash');
?>
<footer class="wp-footer">
    <div class="wp-container">
        <div class="wp-footer-grid">
            <div class="wp-footer-brand">
                <div class="wp-logo wp-logo--footer">
                    <i class="fab fa-wordpress" aria-hidden="true"></i>
                    <span>AI Consultant GROK</span>
                </div>
                <p><?= htmlspecialchars($ft['tagline']) ?></p>
            </div>
            <div>
                <h4><?= htmlspecialchars($ft['links']) ?></h4>
                <ul>
                    <li><a href="#install"><?= htmlspecialchars($ft['install_guide']) ?></a></li>
                    <li><a href="#screenshots"><?= htmlspecialchars($ft['screenshots']) ?></a></li>
                    <li><a href="<?= htmlspecialchars($wp_wporg) ?>" rel="related"><?= htmlspecialchars($t['nav']['wporg']) ?></a></li>
                    <li><a href="https://bilohash.com/news/" rel="related"><?= htmlspecialchars($ft['news']) ?></a></li>
                </ul>
            </div>
            <div>
                <h4><?= htmlspecialchars($ft['products']) ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/ai/" rel="related">AI Platform</a></li>
                    <li><a href="https://bilohash.com/ai/crm/" rel="related">CRM AI 4.0</a></li>
                    <li><a href="<?= htmlspecialchars($wp_wporg) ?>" rel="related"><?= htmlspecialchars($t['nav']['wporg']) ?></a></li>
                </ul>
            </div>
            <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-column.php'; ?>
            <div>
                <h4><?= htmlspecialchars($ft['legal']) ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/website/privacy-policy.php"><?= htmlspecialchars($ft['privacy']) ?></a></li>
                    <li><a href="https://bilohash.com/website/cookies.php"><?= htmlspecialchars($ft['cookies']) ?></a></li>
                    <li><a href="https://bilohash.com/"><?= htmlspecialchars($ft['portfolio']) ?></a></li>
                    <li><a href="https://bilohash.com/resume.php">Resume</a></li>
                </ul>
            </div>
        </div>
        <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-pills.php'; ?>
        <div class="wp-footer-bottom">
            <p><?= htmlspecialchars($copy) ?></p>
            <p class="wp-footer-author"><?= htmlspecialchars($ft['author']) ?></p>
        </div>
    </div>
</footer>
<?php
$gdpr_lang = match ($lang) {
    'ua' => 'uk', 'ru' => 'ru', 'en' => 'en', 'no' => 'no', default => 'en',
};
$gdpr_privacy_url = '/website/privacy-policy.php';
$gdpr_cookies_url = '/website/cookies.php';
$gdpr_storage_key = 'wp_plugin_gdpr_consent';
include dirname(__DIR__, 3) . '/includes/gdpr-consent.php';
?>
<script src="<?= htmlspecialchars(wp_asset('js/main.js')) ?>?v=1" defer></script>
</body>
</html>