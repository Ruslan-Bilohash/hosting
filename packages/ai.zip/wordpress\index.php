<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/i18n.php';

global $wp_version, $wp_paypal, $wp_wporg, $wp_order_email;

if (!isset($_SESSION['wp_csrf'])) {
    $_SESSION['wp_csrf'] = bin2hex(random_bytes(32));
}
if (!isset($_SESSION['wp_cap1'], $_SESSION['wp_cap2'])) {
    $_SESSION['wp_cap1'] = random_int(5, 15);
    $_SESSION['wp_cap2'] = random_int(5, 15);
}
$captcha_sum = (int)$_SESSION['wp_cap1'] + (int)$_SESSION['wp_cap2'];
$feedback = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wp_contact'])) {
    $tc = $t['contact'];
    if (!hash_equals($_SESSION['wp_csrf'] ?? '', $_POST['csrf_token'] ?? '')) {
        $feedback = 'err:' . ($tc['error'] ?? 'Error');
    } else {
        $name = trim(strip_tags($_POST['name'] ?? ''));
        $email = trim($_POST['email'] ?? '');
        $message = trim(strip_tags($_POST['message'] ?? ''));
        $user_cap = (int)($_POST['captcha'] ?? -1);
        if ($name !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) && $message !== '' && $user_cap === $captcha_sum) {
            $body = "WordPress plugin install request\nName: $name\nEmail: $email\nMessage: $message\nLang: $lang\nTime: " . date('c');
            $headers = "From: no-reply@bilohash.com\r\nReply-To: $email\r\nContent-Type: text/plain; charset=utf-8";
            @mail($wp_order_email, 'AI Consultant GROK — install request', $body, $headers);
            $feedback = 'ok:' . $tc['success'];
            $_SESSION['wp_csrf'] = bin2hex(random_bytes(32));
            $_SESSION['wp_cap1'] = random_int(5, 15);
            $_SESSION['wp_cap2'] = random_int(5, 15);
            $captcha_sum = (int)$_SESSION['wp_cap1'] + (int)$_SESSION['wp_cap2'];
        } else {
            $feedback = 'err:' . ($user_cap !== $captcha_sum ? $tc['captcha_error'] : $tc['error']);
        }
    }
}

$page_title = $t['meta']['title'];
$page_desc  = $t['meta']['description'];
$canonical  = wp_canonical($lang);

require __DIR__ . '/includes/header.php';
?>

<section class="wp-hero" id="home">
    <div class="wp-container">
        <span class="wp-badge"><?= htmlspecialchars($t['hero']['badge']) ?></span>
        <h1><?= htmlspecialchars($t['hero']['h1']) ?></h1>
        <p><?= htmlspecialchars($t['hero']['p']) ?></p>
        <div class="wp-hero-actions">
            <a href="<?= htmlspecialchars($wp_paypal) ?>" class="wp-btn wp-btn-pro" target="_blank" rel="noopener">
                <i class="fas fa-shopping-cart" aria-hidden="true"></i> <?= htmlspecialchars($t['hero']['buy']) ?>
            </a>
            <a href="<?= htmlspecialchars($wp_wporg) ?>" class="wp-btn wp-btn-outline" target="_blank" rel="noopener">
                <i class="fab fa-wordpress" aria-hidden="true"></i> <?= htmlspecialchars($t['hero']['wporg']) ?>
            </a>
            <a href="#screenshots" class="wp-btn wp-btn-outline">
                <i class="fas fa-images" aria-hidden="true"></i> <?= htmlspecialchars($t['hero']['demo']) ?>
            </a>
        </div>
        <p class="wp-hero-trust"><?= htmlspecialchars($t['hero']['trust']) ?></p>
    </div>
</section>

<section class="wp-section" id="whatsnew">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['whatsnew']['title']) ?></h2>
        <p class="wp-section-sub"><?= htmlspecialchars($t['whatsnew']['subtitle']) ?></p>
        <ul class="wp-whatsnew-list">
            <?php foreach ($t['whatsnew']['items'] as $item): ?>
            <li><?= htmlspecialchars($item) ?></li>
            <?php endforeach; ?>
        </ul>
        <p class="wp-whatsnew-cta"><?= htmlspecialchars($t['whatsnew']['cta']) ?></p>
    </div>
</section>

<section class="wp-section wp-section--alt" id="features">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['features']['title']) ?></h2>
        <div class="wp-features-grid">
            <?php foreach ($t['features']['items'] as $f): ?>
            <article class="wp-feature-card">
                <div class="wp-feature-icon">
                    <?php if (($f['icon'] ?? '') === 'wordpress'): ?>
                    <i class="fab fa-wordpress" aria-hidden="true"></i>
                    <?php else: ?>
                    <i class="fas fa-<?= htmlspecialchars($f['icon']) ?>" aria-hidden="true"></i>
                    <?php endif; ?>
                </div>
                <h3><?= htmlspecialchars($f['title']) ?></h3>
                <p><?= htmlspecialchars($f['text']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="wp-section" id="screenshots">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['screenshots']['title']) ?></h2>
        <div class="wp-screens-grid">
            <figure class="wp-screenshot-wrap">
                <img src="<?= htmlspecialchars(wp_url('screen/wigets.jpg')) ?>" alt="<?= htmlspecialchars($t['screenshots']['alt1']) ?>" class="wp-screenshot" width="531" height="883" loading="lazy">
            </figure>
            <figure class="wp-screenshot-wrap">
                <img src="<?= htmlspecialchars(wp_url('screen/wigets2.jpg')) ?>" alt="<?= htmlspecialchars($t['screenshots']['alt2']) ?>" class="wp-screenshot" width="500" height="710" loading="lazy">
            </figure>
        </div>
        <p class="wp-screens-more">
            <a href="<?= htmlspecialchars(wp_url('index.html')) ?>" target="_blank" rel="noopener">
                <i class="fas fa-expand" aria-hidden="true"></i> <?= htmlspecialchars($t['screenshots']['more']) ?>
            </a>
        </p>
    </div>
</section>

<section class="wp-section wp-section--alt" id="comparison">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['comparison']['title']) ?></h2>
        <div class="wp-table-wrap">
            <table class="wp-table">
                <thead>
                    <tr>
                        <th><?= htmlspecialchars($t['comparison']['feature']) ?></th>
                        <th><?= htmlspecialchars($t['comparison']['free']) ?></th>
                        <th><?= htmlspecialchars($t['comparison']['full']) ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($t['comparison']['rows'] as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row[0]) ?></td>
                        <td class="<?= $row[1] ? 'wp-check' : 'wp-cross' ?>"><?= $row[1] ? '✔' : '✘' ?></td>
                        <td class="<?= $row[2] ? 'wp-check' : 'wp-cross' ?>"><?= $row[2] ? '✔' : '✘' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<section class="wp-section" id="install">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['install']['title']) ?></h2>
        <div class="wp-install-box">
            <ol>
                <?php foreach ($t['install']['steps'] as $step): ?>
                <li><?= htmlspecialchars($step) ?></li>
                <?php endforeach; ?>
            </ol>
            <p class="wp-install-note"><?= htmlspecialchars($t['install']['note']) ?></p>
        </div>
    </div>
</section>

<section class="wp-section wp-section--alt" id="ecosystem">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['ecosystem']['title']) ?></h2>
        <p class="wp-section-sub"><?= htmlspecialchars($t['ecosystem']['subtitle']) ?></p>
        <div class="wp-eco-grid">
            <?php foreach ($t['ecosystem']['items'] as $eco): ?>
            <article class="wp-eco-card">
                <h3>
                    <?php if (($eco['icon'] ?? '') === 'wordpress'): ?>
                    <i class="fab fa-wordpress" aria-hidden="true"></i>
                    <?php else: ?>
                    <i class="fas fa-<?= htmlspecialchars($eco['icon']) ?>" aria-hidden="true"></i>
                    <?php endif; ?>
                    <?= htmlspecialchars($eco['name']) ?>
                </h3>
                <p><?= htmlspecialchars($eco['desc']) ?></p>
                <div class="wp-eco-links">
                    <a href="<?= htmlspecialchars($eco['url']) ?>" rel="related"><?= htmlspecialchars($t['ecosystem']['product_btn']) ?></a>
                    <a href="<?= htmlspecialchars($eco['demo']) ?>" rel="related"><?= htmlspecialchars($t['ecosystem']['demo_btn']) ?></a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="wp-section" id="faq">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['faq']['title']) ?></h2>
        <div class="wp-faq-list">
            <?php foreach ($t['faq']['items'] as $i => $item): ?>
            <details class="wp-faq-item"<?= $i === 0 ? ' open' : '' ?>>
                <summary><?= htmlspecialchars($item['q']) ?></summary>
                <p><?= htmlspecialchars($item['a']) ?></p>
            </details>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="wp-section wp-section--alt" id="contact">
    <div class="wp-container">
        <h2 class="wp-section-title"><?= htmlspecialchars($t['contact']['title']) ?></h2>
        <p class="wp-section-sub"><?= htmlspecialchars($t['contact']['sub']) ?></p>
        <div class="wp-contact-box">
            <?php if ($feedback !== ''):
                [$ftype, $ftext] = explode(':', $feedback, 2);
            ?>
            <div class="wp-feedback wp-feedback--<?= $ftype === 'ok' ? 'ok' : 'err' ?>"><?= htmlspecialchars($ftext) ?></div>
            <?php endif; ?>
            <form method="post" action="<?= htmlspecialchars(wp_lang_url($lang)) ?>#contact">
                <input type="hidden" name="wp_contact" value="1">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['wp_csrf']) ?>">
                <div class="wp-field">
                    <label for="wp_name"><?= htmlspecialchars($t['contact']['name']) ?> *</label>
                    <input type="text" id="wp_name" name="name" required maxlength="120" autocomplete="name">
                </div>
                <div class="wp-field">
                    <label for="wp_email"><?= htmlspecialchars($t['contact']['email']) ?> *</label>
                    <input type="email" id="wp_email" name="email" required maxlength="160" autocomplete="email">
                </div>
                <div class="wp-field">
                    <label for="wp_message"><?= htmlspecialchars($t['contact']['message']) ?> *</label>
                    <textarea id="wp_message" name="message" required minlength="10" maxlength="3000"></textarea>
                </div>
                <div class="wp-field">
                    <label><?= htmlspecialchars($t['contact']['captcha']) ?>: <?= (int)$_SESSION['wp_cap1'] ?> + <?= (int)$_SESSION['wp_cap2'] ?> = ?</label>
                    <div class="wp-captcha-row">
                        <input type="number" name="captcha" required style="max-width:120px">
                    </div>
                </div>
                <button type="submit" class="wp-submit"><?= htmlspecialchars($t['contact']['send']) ?></button>
            </form>
        </div>
    </div>
</section>

<section class="wp-cta-band" id="download">
    <div class="wp-container">
        <h2><?= htmlspecialchars($t['cta']['title']) ?></h2>
        <p><?= htmlspecialchars($t['cta']['sub']) ?></p>
        <div class="wp-hero-actions">
            <a href="<?= htmlspecialchars($wp_paypal) ?>" class="wp-btn wp-btn-pro" target="_blank" rel="noopener"><?= htmlspecialchars($t['cta']['buy']) ?></a>
            <a href="<?= htmlspecialchars($wp_wporg) ?>" class="wp-btn wp-btn-outline" target="_blank" rel="noopener"><?= htmlspecialchars($t['cta']['wporg']) ?></a>
        </div>
    </div>
</section>

<div class="wp-modal" id="wpModal" role="dialog" aria-modal="true">
    <img id="wpModalImg" src="" alt="">
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>