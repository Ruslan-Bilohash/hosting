<?php
/**
 * Modern Premium Footer with Icons
 */
?>
    <!-- Premium Footer -->
    <footer class="mt-auto pt-5 pb-4" style="background: linear-gradient(to top, #0a0a1f, #11112b); border-top: 1px solid rgba(0, 245, 255, 0.2);">
        <div class="container">
            <div class="row gy-5">

                <!-- Лівий блок -->
                <div class="col-lg-5">
                    <div class="d-flex align-items-center gap-3 mb-4">
                        <i class="bi bi-robot fs-1 text-info"></i>
                        <div>
                            <h4 class="fw-bold text-white mb-0">Bilohash</h4>
                            <p class="text-info mb-0">GPT Chat Assistant Pro</p>
                        </div>
                    </div>
                    <p class="text-light opacity-75">
                        Найсучасніший GPT-чатбот для WordPress.<br>
                        Швидкість, розум і стиль у кожній відповіді.
                    </p>
                    
                    <div class="mt-4">
                        <a href="#" class="text-light me-3"><i class="bi bi-telegram fs-4"></i></a>
                        <a href="#" class="text-light me-3"><i class="bi bi-instagram fs-4"></i></a>
                        <a href="#" class="text-light"><i class="bi bi-github fs-4"></i></a>
                    </div>
                </div>

                <!-- Продукт -->
                <div class="col-lg-2 col-6">
                    <h6 class="fw-bold text-white mb-3">
                        <i class="bi bi-box-seam me-2"></i>Продукт
                    </h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none opacity-75">Функції</a></li>
                        <li class="mb-2"><a href="pay.php" class="text-light text-decoration-none opacity-75">Тарифи</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none opacity-75">Приклади</a></li>
                    </ul>
                </div>

                <!-- Компанія -->
                <div class="col-lg-2 col-6">
                    <h6 class="fw-bold text-white mb-3">
                        <i class="bi bi-building me-2"></i>Хто я!
                    </h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="bilohash.com" class="text-light text-decoration-none opacity-75">Про нас</a></li>
                        <li class="mb-2"><a href="feedback.php" class="text-light text-decoration-none opacity-75">Підтримка</a></li>
                    </ul>
                </div>

                <!-- Контакти та правова інформація -->
                <div class="col-lg-3">
                    <h6 class="fw-bold text-white mb-3">
                        <i class="bi bi-headset me-2"></i>Підтримка
                    </h6>
                    <p class="small text-light opacity-75">
                        <i class="bi bi-envelope me-2"></i> email@bilohash.com
                    </p>
                  <!--  <p class="small text-light opacity-75">
                        <i class="bi bi-telegram me-2"></i> @bilohash_support
                    </p>-->
                    
                    <div class="mt-4 pt-4 border-top border-light border-opacity-10">
                        <p class="small text-light opacity-50">
                            &copy; <?= date('Y') ?> Bilohash.com<br>
                            Всі права захищені
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function selectPlan(domains) {
        let price = 0;
        if (domains === 1) price = 10;
        else if (domains === 3) price = 21;
        else if (domains === 10) price = 49;

        if (confirm(`Оплатити ${domains} ${domains === 1 ? 'домен' : 'доменів'} за $${price} / місяць?`)) {
            alert('✅ Оплата пройшла успішно (тестовий режим)!\n\nЛіцензійний ключ буде надіслано на вашу пошту.');
        }
    }
    </script>
</body>
</html>