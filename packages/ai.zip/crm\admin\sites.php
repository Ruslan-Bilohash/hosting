<?php
/**
 * CRM AI Consultant — Налаштування сайту
 * Version: 5.1 — Підтримка файлового промпту + send_to_telegram_too
 */

require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_require_login();

if (crm_ai_is_demo()) {
    header('Location: index.php?demo_readonly=1');
    exit;
}

// ====================== ЗБЕРЕЖЕННЯ ======================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_site_settings'])) {
    crm_ai_require_write_access();
    if (!crm_ai_verify_csrf($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        die($ta['common']['csrf_error']);
    }
   
    $site_id = trim($_POST['site_id'] ?? '');
    if (empty($site_id)) {
        $domain = trim($_POST['domain'] ?? '');
        $site_id = strtolower(preg_replace('/[^a-z0-9]/', '_', $domain));
        $site_id = trim($site_id, '_') ?: 'site_' . time();
    }

    $existing = crm_ai_get_site_settings($site_id, true) ?? [];

    $data = array_merge($existing, [
        'id'                     => $site_id,
        'name'                   => trim($_POST['name'] ?? ''),
        'domain'                 => trim($_POST['domain'] ?? ''),
        'description'            => trim($_POST['description'] ?? ''),
        'enable_chat'            => !empty($_POST['enable_chat']),
        'is_connected'           => $existing['is_connected'] ?? 0,
        'last_check'             => $existing['last_check'] ?? null,
        'default_channel'        => $_POST['default_channel'] ?? 'telegram',
        'chat_title'             => trim($_POST['chat_title'] ?? 'AI Consultant'),
        'chat_subtitle'          => trim($_POST['chat_subtitle'] ?? $ta['defaults']['chat_subtitle']),
        'bot_icon'               => trim($_POST['bot_icon'] ?? '🤖'),
        'position'               => $_POST['position'] ?? 'right',
        'widget_color'           => $_POST['widget_color'] ?? '#22d3ee',
        'chat_bg_color'          => $_POST['chat_bg_color'] ?? '#0f172a',
        'header_bg_color'        => $_POST['header_bg_color'] ?? '#1e2937',
        'user_bubble_color'      => $_POST['user_bubble_color'] ?? '#22d3ee',
        'bot_bubble_color'       => $_POST['bot_bubble_color'] ?? '#334155',
        'telegram_system_prompt' => trim($_POST['telegram_system_prompt'] ?? ''),
        'grok_system_prompt'     => trim($_POST['grok_system_prompt'] ?? ''),
        'openai_system_prompt'   => trim($_POST['openai_system_prompt'] ?? ''),
        'whatsapp_system_prompt' => trim($_POST['whatsapp_system_prompt'] ?? ''),
        'viber_system_prompt'    => trim($_POST['viber_system_prompt'] ?? ''),
        'welcome_text'           => trim($_POST['welcome_text'] ?? $ta['defaults']['welcome_text']),
        'auto_open'              => !empty($_POST['auto_open']),
        'auto_open_delay'        => (int)($_POST['auto_open_delay'] ?? 7000),
        'system_prompt'          => trim($_POST['system_prompt'] ?? ''),
        'telegram_token'         => trim($_POST['telegram_token'] ?? ''),
        'telegram_chat_id'       => trim($_POST['telegram_chat_id'] ?? ''),
        'grok_api_key'           => trim($_POST['grok_api_key'] ?? ''),
        'openai_api_key'         => trim($_POST['openai_api_key'] ?? ''),
        'whatsapp_number'        => trim($_POST['whatsapp_number'] ?? ''),
        'viber_number'           => trim($_POST['viber_number'] ?? ''),
        'send_to_telegram_too'   => !empty($_POST['send_to_telegram_too']),
        'grok_ai_model'          => crm_ai_normalize_model('grok', $_POST['grok_ai_model'] ?? ($existing['grok_ai_model'] ?? $existing['ai_model'] ?? '')),
        'openai_ai_model'        => crm_ai_normalize_model('openai', $_POST['openai_ai_model'] ?? ($existing['openai_ai_model'] ?? $existing['ai_model'] ?? '')),
        'grok_temperature'       => (string)($_POST['grok_temperature'] ?? ($existing['grok_temperature'] ?? '0.7')),
        'openai_temperature'     => (string)($_POST['openai_temperature'] ?? ($existing['openai_temperature'] ?? '0.7')),
    ]);

    $active_channel = $data['default_channel'] ?? 'telegram';
    if ($active_channel === 'grok') {
        $data['ai_model'] = $data['grok_ai_model'];
    } elseif ($active_channel === 'openai') {
        $data['ai_model'] = $data['openai_ai_model'];
    } else {
        $data['ai_model'] = $existing['ai_model'] ?? $data['grok_ai_model'];
    }

    crm_ai_save_site($site_id, $data);

    $success = sprintf($ta['sites']['saved'], htmlspecialchars($site_id));
}

// Завантаження для редагування
$edit_site = null;
if (isset($_GET['edit'])) {
    $edit_site = crm_ai_get_site_settings($_GET['edit'], true);
}
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ta['sites']['title']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <?php require_once __DIR__ . '/includes/theme.php'; crm_admin_theme_head(); ?>
</head>
<body class="bg-zinc-950 text-zinc-100">

<?php include 'navigation.php'; ?>

<div class="max-w-6xl mx-auto px-6 py-12">

    <h1 class="text-5xl font-bold mb-2"><?= htmlspecialchars($ta['sites']['heading']) ?></h1>
    <p class="text-zinc-400 mb-10"><?= htmlspecialchars($ta['sites']['site_id_label']) ?> <strong><?= htmlspecialchars($edit_site['id'] ?? $ta['sites']['new_site']) ?></strong></p>

    <?php if (isset($success)): ?>
        <div class="bg-emerald-900 border border-emerald-700 p-6 rounded-3xl mb-10 text-emerald-200">
            <?= $success ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="bg-zinc-900 rounded-3xl p-6 sm:p-10 lg:p-14">
        <?= crm_ai_csrf_field() ?>
        <input type="hidden" name="save_site_settings" value="1">
        <input type="hidden" name="site_id" value="<?= htmlspecialchars($edit_site['id'] ?? '') ?>">

        <!-- Статус чату -->
        <div class="flex items-center justify-between bg-zinc-800 p-6 rounded-3xl mb-10">
            <span class="text-lg font-medium"><?= htmlspecialchars($ta['sites']['chat_status']) ?></span>
            <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" name="enable_chat" value="1" <?= !empty($edit_site['enable_chat']) ? 'checked' : '' ?> class="sr-only peer">
                <div class="w-14 h-7 bg-zinc-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-500 rounded-full peer peer-checked:bg-emerald-500"></div>
                <span class="ml-4 text-lg font-medium peer-checked:text-emerald-400">
                    <?= !empty($edit_site['enable_chat']) ? htmlspecialchars($ta['common']['enabled']) : htmlspecialchars($ta['common']['disabled']) ?>
                </span>
            </label>
        </div>

        <!-- Основна інформація -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['site_name']) ?></label>
                <input type="text" name="name" value="<?= htmlspecialchars($edit_site['name'] ?? '') ?>" required class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-5">
            </div>
            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['domain']) ?></label>
                <input type="text" name="domain" value="<?= htmlspecialchars($edit_site['domain'] ?? '') ?>" required class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-5">
            </div>
        </div>

        <!-- Вибір каналу -->
        <div class="mt-12">
            <label class="block text-sm text-zinc-400 mb-4"><?= htmlspecialchars($ta['sites']['default_channel']) ?></label>
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                <?php
                $channels = [
                    'telegram' => ['icon' => 'fab fa-telegram text-blue-400', 'name' => $ta['channels']['telegram']],
                    'grok'     => ['icon' => 'fas fa-robot text-orange-400', 'name' => $ta['channels']['grok']],
                    'openai'   => ['icon' => 'fas fa-brain text-purple-400', 'name' => $ta['channels']['openai']],
                    'whatsapp' => ['icon' => 'fab fa-whatsapp text-green-400', 'name' => $ta['channels']['whatsapp']],
                    'viber'    => ['icon' => 'fab fa-viber text-purple-500', 'name' => $ta['channels']['viber']],
                ];
                foreach ($channels as $ch => $data) {
                    $checked = ($edit_site['default_channel'] ?? 'telegram') === $ch ? 'checked' : '';
                    echo "
                    <label class='channel-option flex flex-col items-center gap-3 p-6 bg-zinc-800 hover:bg-zinc-700 rounded-3xl cursor-pointer border-2 transition-all " . ($checked ? 'border-sky-500 bg-zinc-700' : 'border-transparent') . "'>
                        <i class='{$data['icon']} text-5xl'></i>
                        <span class='font-medium'>{$data['name']}</span>
                        <input type='radio' name='default_channel' value='{$ch}' class='hidden' {$checked}>
                    </label>";
                }
                ?>
            </div>
        </div>

    
        <!-- Налаштування каналів -->
        <?php
        include 'settings_telegram.php';
        include 'settings_grok.php';
        include 'settings_openai.php';
        include 'settings_whatsapp.php';
        include 'settings_viber.php';
        ?>
    <!-- Надсилати також у Telegram -->
        <div class="mt-8 p-6 bg-zinc-800 rounded-3xl">
            <label class="flex items-center gap-3 text-lg cursor-pointer">
                <input type="checkbox" name="send_to_telegram_too" value="1" 
                       <?= !empty($edit_site['send_to_telegram_too']) ? 'checked' : '' ?>>
                <span class="text-white"><?= htmlspecialchars($ta['sites']['send_to_telegram']) ?></span>
            </label>
        </div>

        <!-- Дизайн чату -->
        <div class="mt-16 pt-10 border-t border-zinc-700">
            <h3 class="text-2xl font-semibold mb-8"><?= htmlspecialchars($ta['sites']['appearance']) ?></h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['chat_title']) ?></label>
                    <input type="text" name="chat_title" value="<?= htmlspecialchars($edit_site['chat_title'] ?? $ta['defaults']['chat_title']) ?>" class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-4">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['chat_subtitle']) ?></label>
                    <input type="text" name="chat_subtitle" value="<?= htmlspecialchars($edit_site['chat_subtitle'] ?? $ta['defaults']['chat_subtitle']) ?>" class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-4">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-3"><?= htmlspecialchars($ta['sites']['bot_icon']) ?></label>
                    <div class="flex items-center gap-4">
                        <div id="selected_icon_preview" class="w-16 h-16 flex items-center justify-center text-5xl bg-zinc-800 border border-zinc-700 rounded-3xl">
                            <?= htmlspecialchars($edit_site['bot_icon'] ?? '🤖') ?>
                        </div>
                        <button type="button" onclick="openIconModal()" 
                                class="px-6 py-4 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-3xl text-sm font-medium flex items-center gap-2">
                            <i class="fas fa-icons text-sky-400"></i>
                            <span><?= htmlspecialchars($ta['sites']['choose_icon']) ?></span>
                        </button>
                    </div>
                    <input type="hidden" name="bot_icon" id="bot_icon_input" value="<?= htmlspecialchars($edit_site['bot_icon'] ?? '🤖') ?>">
                </div>

                <!-- Кольори та позиція (залишив як було) -->
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['widget_color']) ?></label>
                    <input type="color" name="widget_color" value="<?= htmlspecialchars($edit_site['widget_color'] ?? '#22d3ee') ?>" class="w-full h-12 bg-zinc-800 border border-zinc-700 rounded-3xl cursor-pointer">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['chat_bg_color']) ?></label>
                    <input type="color" name="chat_bg_color" value="<?= htmlspecialchars($edit_site['chat_bg_color'] ?? '#0f172a') ?>" class="w-full h-12 bg-zinc-800 border border-zinc-700 rounded-3xl cursor-pointer">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['header_bg_color']) ?></label>
                    <input type="color" name="header_bg_color" value="<?= htmlspecialchars($edit_site['header_bg_color'] ?? '#1e2937') ?>" class="w-full h-12 bg-zinc-800 border border-zinc-700 rounded-3xl cursor-pointer">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['user_bubble_color']) ?></label>
                    <input type="color" name="user_bubble_color" value="<?= htmlspecialchars($edit_site['user_bubble_color'] ?? '#22d3ee') ?>" class="w-full h-12 bg-zinc-800 border border-zinc-700 rounded-3xl cursor-pointer">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['bot_bubble_color']) ?></label>
                    <input type="color" name="bot_bubble_color" value="<?= htmlspecialchars($edit_site['bot_bubble_color'] ?? '#334155') ?>" class="w-full h-12 bg-zinc-800 border border-zinc-700 rounded-3xl cursor-pointer">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['sites']['widget_position']) ?></label>
                    <select name="position" class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-4">
                        <option value="right" <?= ($edit_site['position'] ?? 'right') === 'right' ? 'selected' : '' ?>><?= htmlspecialchars($ta['sites']['position_right']) ?></option>
                        <option value="left" <?= ($edit_site['position'] ?? 'left') === 'left' ? 'selected' : '' ?>><?= htmlspecialchars($ta['sites']['position_left']) ?></option>
                    </select>
                </div>
            </div>
        </div>

        <div class="mt-14 flex flex-col sm:flex-row gap-4">
            <button type="submit" class="flex-1 py-6 bg-sky-600 hover:bg-sky-500 rounded-3xl font-bold text-lg">
                <?= htmlspecialchars($ta['sites']['save_settings']) ?>
            </button>
            <a href="index.php" class="flex-1 py-6 text-center bg-zinc-800 hover:bg-zinc-700 rounded-3xl text-lg"><?= htmlspecialchars($ta['common']['cancel']) ?></a>
        </div>
    </form>
</div>

<?php include 'footer.php'; ?>
<?php include 'icon.php'; ?>

<script>
// Перемикання каналів
document.addEventListener('DOMContentLoaded', function() {
    function switchChannel(channel) {
        document.querySelectorAll('.channel-settings').forEach(block => block.classList.add('hidden'));
        const activeBlock = document.getElementById('settings_' + channel);
        if (activeBlock) activeBlock.classList.remove('hidden');
    }

    document.querySelectorAll('input[name="default_channel"]').forEach(radio => {
        radio.addEventListener('change', function() {
            switchChannel(this.value);
        });
    });

    const checked = document.querySelector('input[name="default_channel"]:checked');
    if (checked) switchChannel(checked.value);
    else switchChannel('telegram');
});
</script>
</body>
</html>