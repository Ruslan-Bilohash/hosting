<?php
/**
 * CRM AI Consultant — Security helpers (headers, validation)
 * Version: 5.0
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

function crm_ai_send_security_headers(): void
{
    if (headers_sent()) {
        return;
    }
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

function crm_ai_sanitize_id(string $value, int $max = 128): string
{
    $value = trim($value);
    if ($value === '' || strlen($value) > $max) {
        return '';
    }
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $value)) {
        return '';
    }
    return $value;
}

function crm_ai_validate_origin(?string $site_id = null): bool
{
    $origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    if ($origin === '' && $referer === '') {
        return true;
    }
    $check = $origin !== '' ? $origin : $referer;
    if (!filter_var($check, FILTER_VALIDATE_URL)) {
        return false;
    }
    $host = parse_url($check, PHP_URL_HOST);
    if (!$host) {
        return false;
    }
    if ($site_id) {
        $settings = crm_ai_get_site_settings($site_id);
        if (!$settings || empty($settings['domain'])) {
            return true;
        }
        $domain = preg_replace('#^https?://#i', '', $settings['domain']);
        $domain = rtrim(explode('/', $domain)[0], '/');
        return stripos($host, $domain) !== false || stripos($domain, $host) !== false;
    }
    return true;
}