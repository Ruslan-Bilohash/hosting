<?php
/**
 * CRM AI Consultant — Налаштування WhatsApp
 * Version: 2.6.6
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die($ta['access_denied'] ?? 'Access denied');
}
?>

<div id="settings_whatsapp" class="channel-settings <?= ($edit_site['default_channel'] ?? '') === 'whatsapp' ? '' : 'hidden' ?>">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fab fa-whatsapp text-green-400 text-2xl"></i>
        <?= htmlspecialchars($ta['settings_whatsapp']['title']) ?>
    </h3>

    <div class="space-y-8">

        <div>
            <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_whatsapp']['number']) ?></label>
            <input type="text" name="whatsapp_number" 
                   value="<?= htmlspecialchars($edit_site['whatsapp_number'] ?? '') ?>" 
                   class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono"
                   placeholder="+380671234567">
            <p class="text-xs text-zinc-500 mt-2">
                <?= htmlspecialchars($ta['settings_whatsapp']['number_hint']) ?>
            </p>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-3"><?= htmlspecialchars($ta['settings_whatsapp']['welcome_message']) ?></label>
            <textarea name="whatsapp_welcome_text" rows="5" 
                      class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4"><?= htmlspecialchars($edit_site['whatsapp_welcome_text'] ?? $ta['defaults']['whatsapp_welcome_text']) ?></textarea>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-3"><?= htmlspecialchars($ta['settings_whatsapp']['auto_reply']) ?></label>
            <textarea name="whatsapp_auto_reply" rows="3" 
                      class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4"><?= htmlspecialchars($edit_site['whatsapp_auto_reply'] ?? $ta['defaults']['whatsapp_auto_reply']) ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_whatsapp']['channel_status']) ?></label>
                <select name="whatsapp_status" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="active" <?= ($edit_site['whatsapp_status'] ?? 'active') === 'active' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_whatsapp']['status_active']) ?></option>
                    <option value="coming_soon" <?= ($edit_site['whatsapp_status'] ?? '') === 'coming_soon' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_whatsapp']['status_coming_soon']) ?></option>
                    <option value="disabled" <?= ($edit_site['whatsapp_status'] ?? '') === 'disabled' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_whatsapp']['status_disabled']) ?></option>
                </select>
            </div>

            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_whatsapp']['whatsapp_type']) ?></label>
                <select name="whatsapp_type" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="personal" <?= ($edit_site['whatsapp_type'] ?? 'personal') === 'personal' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_whatsapp']['type_personal']) ?></option>
                    <option value="business" <?= ($edit_site['whatsapp_type'] ?? '') === 'business' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_whatsapp']['type_business']) ?></option>
                    <option value="api" <?= ($edit_site['whatsapp_type'] ?? '') === 'api' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_whatsapp']['type_api']) ?></option>
                </select>
            </div>
        </div>

        <div class="p-6 bg-zinc-950 border border-green-900/30 rounded-2xl text-sm">
            <?= $ta['settings_whatsapp']['note'] ?>
        </div>

    </div>
</div>