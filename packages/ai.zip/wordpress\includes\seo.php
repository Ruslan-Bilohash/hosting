<?php

function wp_render_seo_head(string $title, string $desc, string $canonical, array $faq = []): void
{
    global $lang, $lang_meta, $WP_LANGS, $wp_version, $t;
    $og_image = 'https://bilohash.com/ai/wordpress/screen/wigets.jpg';
    ?>
    <title><?= htmlspecialchars($title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($desc) ?>">
    <?php if (!empty($t['meta']['keywords'])): ?>
    <meta name="keywords" content="<?= htmlspecialchars($t['meta']['keywords']) ?>">
    <?php endif; ?>
    <meta name="robots" content="index, follow">
    <meta name="author" content="Ruslan Bilohash">
    <meta name="theme-color" content="#00f5ff">
    <link rel="canonical" href="<?= htmlspecialchars($canonical) ?>">
    <?php foreach ($WP_LANGS as $code => $info): ?>
    <link rel="alternate" hreflang="<?= htmlspecialchars($info['hreflang']) ?>" href="<?= htmlspecialchars(wp_canonical($code)) ?>">
    <?php endforeach; ?>
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(wp_canonical('en')) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($t['meta']['og_title'] ?? $title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($desc) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical) ?>">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="<?= htmlspecialchars($lang_meta['locale']) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">
    <script type="application/ld+json"><?= json_encode([
        '@context' => 'https://schema.org',
        '@type' => 'SoftwareApplication',
        'name' => 'AI Consultant GROK',
        'version' => $wp_version,
        'applicationCategory' => 'BusinessApplication',
        'operatingSystem' => 'WordPress',
        'description' => $desc,
        'url' => $canonical,
        'softwareVersion' => $wp_version,
        'softwareRequirements' => 'WordPress 6.4 or higher',
        'author' => ['@type' => 'Person', 'name' => 'Ruslan Bilohash'],
        'brand' => ['@type' => 'Brand', 'name' => 'bilohash.com'],
        'offers' => [
            '@type' => 'Offer',
            'name' => 'Full Version',
            'price' => '50',
            'priceCurrency' => 'USD',
            'availability' => 'https://schema.org/InStock',
            'url' => $canonical,
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
    <?php if ($faq): ?>
    <script type="application/ld+json"><?= json_encode([
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => array_map(static function ($item) {
            return [
                '@type' => 'Question',
                'name' => $item['q'],
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $item['a']],
            ];
        }, $faq),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
    <?php endif; ?>
    <?php
}