<?php
/**
 * Modern Header
 */
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Купити GPT Chat Assistant Pro WORDPRESS 7</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body {
            background: linear-gradient(135deg, #0a0a1f 0%, #1a1a4d 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            color: #fff;
            min-height: 100vh;
        }
        
        /* Modern Header */
        .modern-header {
            background: rgba(10, 10, 31, 0.85);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0, 245, 255, 0.2);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .logo {
            font-size: 1.65rem;
            font-weight: 700;
            background: linear-gradient(90deg, #00f5ff, #0099ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .pricing-card {
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(0,245,255,0.25);
            border-radius: 24px;
            backdrop-filter: blur(16px);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .pricing-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 30px 60px rgba(0, 245, 255, 0.25);
        }
        .pricing-card.popular {
            border: 2px solid #00f5ff;
            transform: scale(1.06);
        }
        .price {
            font-size: 3.4rem;
            font-weight: 700;
            background: linear-gradient(90deg, #00f5ff, #00ccff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .btn-buy {
            background: linear-gradient(135deg, #00cc66, #00aa55);
            border: none;
            padding: 16px 45px;
            font-size: 1.2rem;
            font-weight: 600;
            border-radius: 50px;
            transition: all 0.4s ease;
        }
        .btn-buy:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 35px rgba(0, 204, 102, 0.5);
        }
        .feature {
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Modern Header -->
    <header class="modern-header py-4">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-3">
                    <i class="bi bi-robot fs-1 text-info"></i>
                    <div>
                        <span class="logo">GPT Chat Assistant</span>
                        <span class="text-light ms-2">1.0</span>
                    </div>
                </div>
                
                <div class="text-end">
                    <span class="badge bg-success fs-6 px-3 py-2">
                        <i class="bi bi-shield-check me-1"></i>
                        Безпечна оплата
                    </span>
                </div>
            </div>
        </div>
    </header>