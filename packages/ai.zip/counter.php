<?php
$counter_total_lbl = is_array($t ?? null) ? ($t['counter']['total'] ?? 'total') : 'total';
$counter_unique_lbl = is_array($t ?? null) ? ($t['counter']['unique'] ?? 'unique') : 'unique';
?>
<div class="simple-visitor-counter">
    <span class="icon">👁️</span>
    <span id="ai-total">0</span> <?= htmlspecialchars($counter_total_lbl) ?> •
    <span id="ai-unique">0</span> <?= htmlspecialchars($counter_unique_lbl) ?>
</div>
<?php
$counter_file = __DIR__ . '/counter.txt';
$ips_file     = __DIR__ . '/ips.txt';
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

$total = 0;
$unique = 0;
try {
    if (!file_exists($counter_file)) @file_put_contents($counter_file, '0');
    if (!file_exists($ips_file)) @file_put_contents($ips_file, '');

    $total = (int)@file_get_contents($counter_file) + 1;
    @file_put_contents($counter_file, (string)$total);

    $ips = (string)@file_get_contents($ips_file);
    $ip_list = $ips !== '' ? explode("\n", trim($ips)) : [];
    if (!in_array($ip, array_map('trim', $ip_list), true)) {
        $ip_list[] = $ip;
        @file_put_contents($ips_file, implode("\n", $ip_list));
    }
    $unique = count($ip_list);
} catch (Throwable $e) {
    $total = max(1, $total);
}
?>
<script>
document.getElementById('ai-total')?.textContent = <?= (int)$total ?>;
document.getElementById('ai-unique')?.textContent = <?= (int)$unique ?>;
</script>