(function () {
    const header = document.getElementById('aiHeader');
    const menuBtn = document.getElementById('aiMenuBtn');
    const overlay = document.getElementById('aiOverlay');
    const langBtn = document.getElementById('aiLangBtn');
    const langMenu = document.getElementById('aiLangMenu');

    function closeNav() {
        header?.classList.remove('nav-open');
        document.body.classList.remove('ai-nav-open');
        overlay?.classList.remove('is-open');
        menuBtn?.setAttribute('aria-expanded', 'false');
        if (overlay) overlay.hidden = true;
    }

    function openNav() {
        header?.classList.add('nav-open');
        document.body.classList.add('ai-nav-open');
        overlay?.classList.add('is-open');
        menuBtn?.setAttribute('aria-expanded', 'true');
        if (overlay) overlay.hidden = false;
    }

    menuBtn?.addEventListener('click', () => {
        if (header?.classList.contains('nav-open')) closeNav();
        else openNav();
    });
    overlay?.addEventListener('click', closeNav);
    document.querySelectorAll('.ai-nav a').forEach((a) => a.addEventListener('click', closeNav));

    langBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        const open = langMenu?.hasAttribute('hidden');
        if (open) {
            langMenu.removeAttribute('hidden');
            langBtn.setAttribute('aria-expanded', 'true');
        } else {
            langMenu.setAttribute('hidden', '');
            langBtn.setAttribute('aria-expanded', 'false');
        }
    });
    document.addEventListener('click', () => {
        langMenu?.setAttribute('hidden', '');
        langBtn?.setAttribute('aria-expanded', 'false');
    });

    document.querySelectorAll('.ai-faq-q').forEach((btn) => {
        btn.addEventListener('click', () => {
            const item = btn.closest('.ai-faq-item');
            const wasOpen = item?.classList.contains('is-open');
            document.querySelectorAll('.ai-faq-item').forEach((el) => el.classList.remove('is-open'));
            if (!wasOpen) item?.classList.add('is-open');
        });
    });

    const observer = new IntersectionObserver(
        (entries) => entries.forEach((e) => {
            if (e.isIntersecting) e.target.classList.add('is-visible');
        }),
        { threshold: 0.12 }
    );
    document.querySelectorAll('.ai-feature, .ai-product-card, .ai-step').forEach((el) => observer.observe(el));
})();