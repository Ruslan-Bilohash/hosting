<?php
/**
 * CRM AI Consultant — Налаштування Viber
 * Version: 2.6.6 — Повноцінний блок налаштувань
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die($ta['access_denied'] ?? 'Access denied');
}
?>

<div id="settings_viber" class="channel-settings <?= ($edit_site['default_channel'] ?? '') === 'viber' ? '' : 'hidden' ?>">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fab fa-viber text-purple-500 text-2xl"></i>
        <?= htmlspecialchars($ta['settings_viber']['title']) ?>
    </h3>

    <div class="space-y-8">

        <div>
            <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_viber']['number']) ?></label>
            <input type="text" name="viber_number" 
                   value="<?= htmlspecialchars($edit_site['viber_number'] ?? '') ?>" 
                   class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono"
                   placeholder="+380671234567">
            <p class="text-xs text-zinc-500 mt-2"><?= htmlspecialchars($ta['settings_viber']['number_hint']) ?></p>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-3"><?= htmlspecialchars($ta['settings_viber']['welcome_message']) ?></label>
            <textarea name="viber_welcome_text" rows="5" 
                      class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4"><?= htmlspecialchars($edit_site['viber_welcome_text'] ?? $ta['defaults']['viber_welcome_text']) ?></textarea>
        </div>

        <div class="p-6 bg-zinc-950 border border-purple-900/30 rounded-2xl">
            <p class="text-sm text-purple-300">
                <?= $ta['settings_viber']['important_note'] ?>
            </p>
        </div>

    </div>
</div>