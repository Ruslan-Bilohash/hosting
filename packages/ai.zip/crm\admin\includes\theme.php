<?php
/**
 * CRM AI Admin — light / dark theme (localStorage: crm_admin_theme)
 */

if (!defined('CRM_ADMIN_THEME_KEY')) {
    define('CRM_ADMIN_THEME_KEY', 'crm_admin_theme');
}

function crm_admin_theme_head(): void
{
    echo '<script>(function(){try{var t=localStorage.getItem("' . CRM_ADMIN_THEME_KEY . '");if(t==="light")document.documentElement.setAttribute("data-theme","light");}catch(e){}})();</script>' . "\n";
}

function crm_admin_theme_button(string $extra_class = ''): void
{
    global $ta;
    $label_light = htmlspecialchars($ta['theme']['switch_light'] ?? 'Light theme', ENT_QUOTES, 'UTF-8');
    $label_dark  = htmlspecialchars($ta['theme']['switch_dark'] ?? 'Dark theme', ENT_QUOTES, 'UTF-8');
    $class       = trim('crm-admin-nav__theme ' . $extra_class);
    ?>
    <button type="button"
            class="<?= htmlspecialchars($class, ENT_QUOTES, 'UTF-8') ?>"
            onclick="crmToggleTheme()"
            aria-label="<?= $label_light ?>"
            title="<?= $label_light ?>"
            data-crm-theme-toggle
            data-label-light="<?= $label_light ?>"
            data-label-dark="<?= $label_dark ?>">
        <i class="fas fa-sun crm-theme-icon crm-theme-icon--to-light" aria-hidden="true"></i>
        <i class="fas fa-moon crm-theme-icon crm-theme-icon--to-dark" aria-hidden="true"></i>
    </button>
    <?php
}

function crm_admin_theme_script(): void
{
    $key = CRM_ADMIN_THEME_KEY;
    echo <<<JS
<script>
(function () {
    var KEY = '{$key}';

    function currentTheme() {
        try {
            return localStorage.getItem(KEY) === 'light' ? 'light' : 'dark';
        } catch (e) {
            return 'dark';
        }
    }

    function syncThemeUi(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        document.querySelectorAll('[data-crm-theme-toggle]').forEach(function (btn) {
            var light = btn.getAttribute('data-label-light') || 'Light theme';
            var dark = btn.getAttribute('data-label-dark') || 'Dark theme';
            var next = theme === 'dark' ? light : dark;
            btn.setAttribute('aria-label', next);
            btn.setAttribute('title', next);
        });
    }

    window.crmToggleTheme = function () {
        var next = currentTheme() === 'dark' ? 'light' : 'dark';
        try {
            localStorage.setItem(KEY, next);
        } catch (e) {}
        syncThemeUi(next);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            syncThemeUi(currentTheme());
        });
    } else {
        syncThemeUi(currentTheme());
    }
})();
</script>
JS;
}