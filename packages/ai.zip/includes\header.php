<?php
require_once __DIR__ . '/seo.php';
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? ai_url('index.php');
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if (!empty($GLOBALS['platform_slug']) && !empty($seo_schemas)): ?>
    <?php ai_render_platform_seo_head($page_title, $page_desc, $canonical, $seo_schemas, $p['keywords'] ?? null); ?>
    <?php else: ?>
    <?php ai_render_seo_head($page_title, $page_desc, $canonical, $t['faq']['items'] ?? []); ?>
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(ai_asset('css/landing.css')) ?>?v=9">
    <?php
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    ecosystem_subscription_strip_head_link();
    ?>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%23070b14' width='100' height='100' rx='12'/><text x='50' y='62' font-size='40' text-anchor='middle' fill='%2300e5ff' font-family='sans-serif' font-weight='bold'>AI</text></svg>">
</head>
<body class="ai-has-billing-strip">
<div class="ai-top-bar">
<?php ai_render_subscription_banner($t, $lang); ?>
<header class="ai-header" id="aiHeader">
    <div class="ai-header-inner">
        <a href="<?= ai_url('index.php') ?>" class="ai-logo">
            <span class="ai-logo-icon"><i class="fas fa-brain"></i></span>
            <span class="ai-logo-text">AI Consultant <small>Grok xAI</small></span>
        </a>
        <nav class="ai-nav" id="aiNav" aria-label="Main">
            <a href="#products"><?= htmlspecialchars($t['nav']['products']) ?></a>
            <a href="#features"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="#how"><?= htmlspecialchars($t['nav']['how']) ?></a>
            <a href="#pricing"><?= htmlspecialchars($t['nav']['pricing']) ?></a>
            <a href="#ecosystem"><?= htmlspecialchars($t['footer']['ecosystem'] ?? 'Ecosystem') ?></a>
            <a href="#faq"><?= htmlspecialchars($t['nav']['faq']) ?></a>
            <a href="#contact"><?= htmlspecialchars($t['nav']['contact']) ?></a>
        </nav>
        <div class="ai-header-actions">
            <div class="ai-lang" id="aiLang">
                <button type="button" class="ai-lang-btn" id="aiLangBtn" aria-expanded="false">
                    <?= $lang_meta['flag'] ?> <?= htmlspecialchars($lang_meta['label']) ?>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <ul class="ai-lang-menu" id="aiLangMenu" hidden>
                    <?php foreach (ai_langs() as $code => $info): ?>
                    <li><a href="<?= htmlspecialchars(ai_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['flag'] ?> <?= htmlspecialchars($info['name']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <a href="<?= htmlspecialchars(ai_subscription_url()) ?>" class="ai-btn-primary ai-btn-sm" <?= ai_subscription_external_attrs() ?>><span><?= htmlspecialchars($t['hero']['cta_subscribe'] ?? $t['hero']['cta_contact']) ?></span></a>
            <button type="button" class="ai-menu-toggle" id="aiMenuBtn" aria-label="Menu" aria-expanded="false">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </div>
</header>
</div>
<div class="ai-overlay" id="aiOverlay" hidden></div>