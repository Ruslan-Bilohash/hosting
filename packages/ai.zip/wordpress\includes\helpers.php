<?php

function wp_url(string $path = ''): string
{
    global $wp_base_path;
    $base = rtrim($wp_base_path, '/');
    if ($path === '' || $path === 'index.php') {
        return $base . '/';
    }
    return $base . '/' . ltrim($path, '/');
}

function wp_asset(string $path): string
{
    return wp_url('assets/' . ltrim($path, '/'));
}

function wp_lang_url(string $code): string
{
    $base = wp_url('');
    if ($code === 'en') {
        return $base;
    }
    return $base . '?lang=' . urlencode($code);
}

function wp_canonical(string $lang): string
{
    global $wp_site_url;
    if ($lang === 'en') {
        return rtrim($wp_site_url, '/') . '/';
    }
    return rtrim($wp_site_url, '/') . '/?lang=' . urlencode($lang);
}