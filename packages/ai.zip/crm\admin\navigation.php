<?php
/**
 * admin/navigation.php — Adaptive header with category dropdowns (v5.1)
 */

require_once dirname(__DIR__) . '/version.php';

$current_page = basename($_SERVER['PHP_SELF']);

$site_pages = [
    'index.php', 'sites.php', 'settings_general.php', 'settings_grok.php',
    'settings_openai.php', 'settings_telegram.php', 'settings_whatsapp.php',
    'settings_viber.php', 'icon.php',
];
$chat_pages = ['conversations.php', 'get-conversation.php'];

$nav_groups = [
    [
        'id'     => 'manage',
        'label'  => $ta['nav']['group_manage'] ?? 'Manage',
        'icon'   => 'fa-sliders',
        'accent' => 'sky',
        'active' => in_array($current_page, array_merge($site_pages, $chat_pages), true),
        'items'  => [
            [
                'href'   => 'index.php',
                'icon'   => 'fa-house',
                'label'  => $ta['nav']['sites'],
                'active' => in_array($current_page, $site_pages, true),
            ],
            [
                'href'   => 'conversations.php',
                'icon'   => 'fa-comments',
                'label'  => $ta['nav']['chat_history'],
                'active' => in_array($current_page, $chat_pages, true),
            ],
        ],
    ],
];

if (!crm_ai_is_demo()) {
    $nav_groups[] = [
        'id'     => 'system',
        'label'  => $ta['nav']['group_system'] ?? 'System',
        'icon'   => 'fa-server',
        'accent' => 'emerald',
        'active' => in_array($current_page, ['debug.php', 'admins.php'], true),
        'items'  => [
            [
                'href'   => 'debug.php',
                'icon'   => 'fa-gauge-high',
                'label'  => $ta['nav']['debug'] ?? 'Debug',
                'active' => $current_page === 'debug.php',
            ],
            [
                'href'   => 'admins.php',
                'icon'   => 'fa-user-shield',
                'label'  => $ta['nav']['administrator'],
                'active' => $current_page === 'admins.php',
            ],
        ],
    ];
}

$nav_groups[] = [
    'id'     => 'help',
    'label'  => $ta['nav']['group_help'] ?? 'Help',
    'icon'   => 'fa-circle-question',
    'accent' => 'sky',
    'active' => false,
    'items'  => [
        [
            'href'     => '../documentation.html',
            'icon'     => 'fa-book-open',
            'label'    => $ta['nav']['documentation'],
            'active'   => false,
            'external' => true,
        ],
    ],
];

$accent_map = [
    'sky'     => 'crm-nav-pill--sky',
    'emerald' => 'crm-nav-pill--emerald',
    'amber'   => 'crm-nav-pill--amber',
];

$flat_items = [];
foreach ($nav_groups as $group) {
    foreach ($group['items'] as $item) {
        $flat_items[] = array_merge($item, ['group' => $group['id']]);
    }
}
?>

<header class="crm-admin-nav sticky top-0 z-50">
    <div class="crm-admin-nav__blur"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="crm-admin-nav__bar">

            <a href="index.php" class="crm-admin-nav__brand group shrink-0">
                <div class="crm-admin-nav__logo">
                    <span class="crm-admin-nav__logo-emoji">🤖</span>
                </div>
                <div class="crm-admin-nav__brand-text hidden sm:block">
                    <span class="crm-admin-nav__title"><?= htmlspecialchars($ta['app_name']) ?></span>
                    <span class="crm-admin-nav__tagline"><?= htmlspecialchars($ta['tagline']) ?></span>
                </div>
            </a>

            <!-- Desktop dropdown nav -->
            <nav class="crm-admin-nav__menu hidden md:flex" aria-label="Main navigation">
                <?php foreach ($nav_groups as $group):
                    $toggle_class = 'crm-nav-dropdown__toggle';
                    if ($group['active']) {
                        $toggle_class .= ' crm-nav-dropdown__toggle--active ' . ($accent_map[$group['accent']] ?? 'crm-nav-pill--sky');
                    }
                ?>
                <div class="crm-nav-dropdown" data-nav-dropdown="<?= htmlspecialchars($group['id']) ?>">
                    <button type="button"
                            class="<?= $toggle_class ?>"
                            onclick="crmToggleNavDropdown('<?= htmlspecialchars($group['id']) ?>')"
                            aria-expanded="false"
                            aria-haspopup="true">
                        <i class="fas <?= htmlspecialchars($group['icon']) ?> crm-nav-dropdown__icon"></i>
                        <span><?= htmlspecialchars($group['label']) ?></span>
                        <i class="fas fa-chevron-down crm-nav-dropdown__caret"></i>
                    </button>
                    <div class="crm-nav-dropdown__panel" role="menu">
                        <?php foreach ($group['items'] as $item):
                            $link_class = 'crm-nav-dropdown__link';
                            if ($item['active'] ?? false) {
                                $link_class .= ' crm-nav-dropdown__link--active';
                            }
                            $target = !empty($item['external']) ? ' target="_blank" rel="noopener"' : '';
                        ?>
                        <a href="<?= htmlspecialchars($item['href']) ?>" class="<?= $link_class ?>" role="menuitem"<?= $target ?>>
                            <i class="fas <?= htmlspecialchars($item['icon']) ?>"></i>
                            <span><?= htmlspecialchars($item['label']) ?></span>
                            <?php if (!empty($item['external'])): ?>
                            <i class="fas fa-arrow-up-right-from-square crm-nav-dropdown__ext"></i>
                            <?php endif; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </nav>

            <div class="crm-admin-nav__actions">
                <?php
                require_once __DIR__ . '/includes/theme.php';
                crm_admin_theme_button();
                ?>
                <div class="hidden lg:block">
                    <?= crm_admin_lang_switcher() ?>
                </div>

                <span class="crm-admin-nav__version hidden xl:inline-flex">
                    v<?= htmlspecialchars(CRM_AI_VERSION ?? '5.1') ?>
                </span>

                <a href="logout.php" class="crm-admin-nav__logout hidden sm:inline-flex" title="<?= htmlspecialchars($ta['nav']['logout']) ?>">
                    <i class="fas fa-right-from-bracket"></i>
                    <span class="hidden lg:inline"><?= htmlspecialchars($ta['nav']['logout']) ?></span>
                </a>

                <button type="button"
                        class="crm-admin-nav__burger md:hidden"
                        onclick="crmToggleMobileNav()"
                        aria-label="Menu"
                        aria-expanded="false"
                        id="crmNavBurger">
                    <span class="crm-admin-nav__burger-line"></span>
                    <span class="crm-admin-nav__burger-line"></span>
                    <span class="crm-admin-nav__burger-line"></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile drawer with categories -->
    <div id="crmMobileNav" class="crm-admin-nav__drawer md:hidden" aria-hidden="true">
        <div class="crm-admin-nav__drawer-inner">
            <?php foreach ($nav_groups as $group): ?>
            <div class="crm-admin-nav__drawer-group">
                <div class="crm-admin-nav__drawer-group-title">
                    <i class="fas <?= htmlspecialchars($group['icon']) ?>"></i>
                    <?= htmlspecialchars($group['label']) ?>
                </div>
                <?php foreach ($group['items'] as $item):
                    $active = ($item['active'] ?? false) ? ' crm-admin-nav__drawer-link--active' : '';
                    $target = !empty($item['external']) ? ' target="_blank" rel="noopener"' : '';
                ?>
                <a href="<?= htmlspecialchars($item['href']) ?>" class="crm-admin-nav__drawer-link<?= $active ?>"<?= $target ?>>
                    <span class="crm-admin-nav__drawer-icon"><i class="fas <?= htmlspecialchars($item['icon']) ?>"></i></span>
                    <span><?= htmlspecialchars($item['label']) ?></span>
                    <?php if (!empty($item['external'])): ?>
                    <i class="fas fa-arrow-up-right-from-square text-xs opacity-40 ml-auto"></i>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>

            <div class="crm-admin-nav__drawer-footer">
                <div class="flex items-center gap-2 mb-4">
                    <?php crm_admin_theme_button('crm-admin-nav__theme--drawer'); ?>
                    <span class="text-xs text-zinc-500"><?= htmlspecialchars($ta['theme']['label'] ?? 'Theme') ?></span>
                </div>
                <div class="crm-admin-nav__drawer-lang">
                    <?php foreach (crm_admin_langs() as $code => $info): ?>
                    <a href="<?= htmlspecialchars(crm_admin_lang_url($code)) ?>"
                       class="crm-admin-nav__lang-chip <?= $lang === $code ? 'crm-admin-nav__lang-chip--active' : '' ?>">
                        <?= $info['flag'] ?> <?= htmlspecialchars($info['label']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
                <div class="flex items-center justify-between pt-4 border-t border-zinc-800">
                    <span class="text-xs font-mono text-zinc-500">v<?= htmlspecialchars(CRM_AI_VERSION ?? '5.1') ?></span>
                    <a href="logout.php" class="crm-admin-nav__drawer-logout">
                        <i class="fas fa-right-from-bracket"></i>
                        <?= htmlspecialchars($ta['nav']['logout_full']) ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="crmNavOverlay" class="crm-admin-nav__overlay md:hidden" onclick="crmCloseMobileNav()"></div>
</header>

<script>
function crmToggleNavDropdown(id) {
    const all = document.querySelectorAll('[data-nav-dropdown]');
    all.forEach(function(el) {
        const open = el.dataset.navDropdown === id && !el.classList.contains('crm-nav-dropdown--open');
        el.classList.toggle('crm-nav-dropdown--open', open);
        const btn = el.querySelector('.crm-nav-dropdown__toggle');
        if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
}

function crmCloseNavDropdowns() {
    document.querySelectorAll('[data-nav-dropdown].crm-nav-dropdown--open').forEach(function(el) {
        el.classList.remove('crm-nav-dropdown--open');
        const btn = el.querySelector('.crm-nav-dropdown__toggle');
        if (btn) btn.setAttribute('aria-expanded', 'false');
    });
}

function crmToggleMobileNav() {
    const drawer = document.getElementById('crmMobileNav');
    const overlay = document.getElementById('crmNavOverlay');
    const burger = document.getElementById('crmNavBurger');
    if (!drawer || !overlay || !burger) return;

    const open = drawer.classList.toggle('crm-admin-nav__drawer--open');
    overlay.classList.toggle('crm-admin-nav__overlay--visible', open);
    burger.classList.toggle('crm-admin-nav__burger--open', open);
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('crm-nav-open', open);
    if (open) crmCloseNavDropdowns();
}

function crmCloseMobileNav() {
    const drawer = document.getElementById('crmMobileNav');
    if (!drawer || !drawer.classList.contains('crm-admin-nav__drawer--open')) return;
    crmToggleMobileNav();
}

function crmToggleLangMenu() {
    const menu = document.getElementById('crmLangMenu');
    if (menu) menu.classList.toggle('hidden');
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('[data-nav-dropdown]')) {
        crmCloseNavDropdowns();
    }

    const wrap = document.getElementById('crmLangSwitcher');
    if (wrap && !wrap.contains(e.target)) {
        const menu = document.getElementById('crmLangMenu');
        if (menu) menu.classList.add('hidden');
    }
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        crmCloseNavDropdowns();
        crmCloseMobileNav();
    }
});

window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) crmCloseMobileNav();
});
</script>
<?php crm_admin_theme_script(); ?>