<?php

/**
 * BILOHASH unified subscription — AI landing (join.php / cabinet.php).
 */

require_once dirname(__DIR__, 2) . '/includes/ecosystem-pricing.php';

function ai_ecosystem_lang(string $lang): string
{
    return match ($lang) {
        'no' => 'no',
        'ua' => 'ua',
        'ru' => 'ru',
        'sv' => 'sv',
        default => 'en',
    };
}

function ai_subscription_url(): string
{
    return 'https://bilohash.com/ecosystem/join.php';
}

function ai_license_cabinet_url(): string
{
    return 'https://bilohash.com/ecosystem/cabinet.php';
}

function ai_subscription_external_attrs(): string
{
    return 'target="_blank" rel="noopener noreferrer"';
}

function ai_subscription_tagline(string $lang): string
{
    return ecosystem_pricing_tagline(ai_ecosystem_lang($lang));
}

/** @return array{price: string, price_alt: string, price_yearly: string, price_yearly_alt: string} */
function ai_subscription_tier_prices(string $lang, string $plan): array
{
    $eco = ai_ecosystem_lang($lang);
    $monthly = $plan === 'full' ? ecosystem_full_pricing_amounts() : ecosystem_script_pricing_amounts();
    $annual = $plan === 'full' ? ecosystem_full_annual_amounts() : ecosystem_script_annual_amounts();

    return match ($eco) {
        'no' => [
            'price'           => (string) $monthly['nok'] . ' kr',
            'price_alt'       => '/mnd · 1 domene',
            'price_yearly'    => (string) $annual['nok'] . ' kr',
            'price_yearly_alt'=> '/12 mnd · 1 domene',
        ],
        'ua' => [
            'price'           => '~' . $monthly['uah'] . ' грн',
            'price_alt'       => '/міс · 1 домен',
            'price_yearly'    => '~' . $annual['uah'] . ' грн',
            'price_yearly_alt'=> '/12 міс · 1 домен',
        ],
        'ru' => [
            'price'           => (string) $monthly['nok'] . ' kr',
            'price_alt'       => '/мес · 1 домен',
            'price_yearly'    => (string) $annual['nok'] . ' kr',
            'price_yearly_alt'=> '/12 мес · 1 домен',
        ],
        'sv' => [
            'price'           => (string) $monthly['nok'] . ' kr',
            'price_alt'       => '/mån · 1 domän',
            'price_yearly'    => (string) $annual['nok'] . ' kr',
            'price_yearly_alt'=> '/12 mån · 1 domän',
        ],
        default => [
            'price'           => '~$' . $monthly['usd'],
            'price_alt'       => '/mo · 1 domain',
            'price_yearly'    => '~$' . $annual['usd'],
            'price_yearly_alt'=> '/12 mo · 1 domain',
        ],
    };
}

/** @return array<string, mixed> */
function ai_subscription_copy(string $lang): array
{
    $tagline = ai_subscription_tagline($lang);
    $scriptBadge = ecosystem_script_pricing_badge(ai_ecosystem_lang($lang));
    $fullBadge = ecosystem_full_pricing_badge(ai_ecosystem_lang($lang));
    $fxNote = ecosystem_pricing_fx_note(ai_ecosystem_lang($lang));
    $paymentsNotice = ecosystem_payments_unavailable_notice(ai_ecosystem_lang($lang));
    $scriptPrices = ai_subscription_tier_prices($lang, 'script');
    $fullPrices = ai_subscription_tier_prices($lang, 'full');

    $common = [
        'tagline'          => $tagline,
        'script_badge'     => $scriptBadge,
        'full_badge'       => $fullBadge,
        'fx_note'          => $fxNote,
        'payments_notice'  => $paymentsNotice,
        'cabinet_url'      => ai_license_cabinet_url(),
        'subscribe_url'    => ai_subscription_url(),
    ];

    return match ($lang) {
        'ua' => array_merge($common, [
            'meta_description' => 'Grok xAI чат-консультант для сайту. Єдина підписка BILOHASH: ' . $tagline . ' Telegram-ліди, 6 мов.',
            'nav_pricing'      => 'Підписка',
            'hero_install'     => $tagline,
            'cta_subscribe'    => 'Оформити підписку',
            'cta_cabinet'      => 'Кабінет клієнта',
            'billing_text'     => '{tagline}',
            'billing_cta'      => 'Єдина підписка BILOHASH',
            'subscription_title' => 'Єдина підписка BILOHASH',
            'subscription_sub'   => 'AI Consultant Grok xAI входить до екосистеми CMS-скриптів — 1 домен, 1 або 12 місяців, установка в один клік.',
            'pricing_subtitle'   => '1 домен · 1 або 12 місяців — один скрипт або вся екосистема (AI, Shop CMS, Booking та ін.)',
            'pricing_includes'   => [
                'Код AI-віджета Grok xAI + інструкція',
                'Ліцензійний ключ у кабінеті клієнта',
                'Налаштування промпту під бізнес',
                'Telegram-інтеграція та сповіщення',
                'Оновлення поки активна підписка',
                'Підтримка через ecosystem waitlist',
            ],
            'tiers' => [
                [
                    'tag'      => '1 CMS-скрипт',
                    'title'    => 'Один скрипт + AI',
                    'price'    => $scriptPrices['price'],
                    'price_alt'=> $scriptPrices['price_alt'],
                    'price_yearly' => $scriptPrices['price_yearly'],
                    'price_yearly_alt' => $scriptPrices['price_yearly_alt'],
                    'desc'     => 'Підтримка одного CMS-скрипта або AI Consultant на 1 домені — 1 місяць або 12 місяців. Код, гайд і ключ у кабінеті.',
                    'cta'      => 'Оформити підписку',
                ],
                [
                    'tag'      => 'Усі скрипти',
                    'title'    => 'Повна екосистема',
                    'price'    => $fullPrices['price'],
                    'price_alt'=> $fullPrices['price_alt'],
                    'price_yearly' => $fullPrices['price_yearly'],
                    'price_yearly_alt' => $fullPrices['price_yearly_alt'],
                    'desc'     => 'Усі CMS-скрипти BILOHASH + AI Consultant на 1 домені — 1 місяць або 12 місяців, одна підписка.',
                    'cta'      => 'Оформити підписку',
                    'featured' => true,
                ],
            ],
            'product_price' => $scriptPrices['price'] . $scriptPrices['price_alt'],
            'product_cta'   => 'Оформити підписку',
            'faq_cost_q'    => 'Скільки коштує підписка?',
            'faq_install_q' => 'Як встановити після оформлення підписки?',
            'faq_cost'      => ecosystem_pricing_faq_answer('ua') . ' Оформлення: bilohash.com/ecosystem/join.php. ' . $paymentsNotice,
            'faq_install'   => 'Після підписки отримуєте файли та інструкцію в кабінеті — встановлюєте самі, через програміста або з допомогою bilohash.',
            'install_items' => [
                'Оформіть підписку на bilohash.com/ecosystem/join.php',
                'Отримайте ключ і файли в кабінеті клієнта',
                'Встановіть самі за гайдом, через програміста або з bilohash',
            ],
        ]),
        'ru' => array_merge($common, [
            'meta_description' => 'Grok xAI чат-консультант для сайта. Единая подписка BILOHASH: ' . $tagline . ' Telegram-лиды, 6 языков.',
            'nav_pricing'      => 'Подписка',
            'hero_install'     => $tagline,
            'cta_subscribe'    => 'Оформить подписку',
            'cta_cabinet'      => 'Кабинет клиента',
            'billing_text'     => '{tagline}',
            'billing_cta'      => 'Единая подписка BILOHASH',
            'subscription_title' => 'Единая подписка BILOHASH',
            'subscription_sub'   => 'AI Consultant Grok xAI входит в экосистему CMS-скриптов — 1 домен, 1 или 12 месяцев, установка в один клик.',
            'pricing_subtitle'   => '1 домен · 1 или 12 месяцев — один скрипт или вся экосистема (AI, Shop CMS, Booking и др.)',
            'pricing_includes'   => [
                'Код AI-виджета Grok xAI + инструкция',
                'Лицензионный ключ в кабинете клиента',
                'Настройка промпта под бизнес',
                'Telegram-интеграция и уведомления',
                'Обновления пока активна подписка',
                'Поддержка через ecosystem waitlist',
            ],
            'tiers' => [
                [
                    'tag'      => '1 CMS-скрипт',
                    'title'    => 'Один скрипт + AI',
                    'price'    => $scriptPrices['price'],
                    'price_alt'=> $scriptPrices['price_alt'],
                    'price_yearly' => $scriptPrices['price_yearly'],
                    'price_yearly_alt' => $scriptPrices['price_yearly_alt'],
                    'desc'     => 'Поддержка одного CMS-скрипта или AI Consultant на 1 домене — 1 месяц или 12 месяцев.',
                    'cta'      => 'Оформить подписку',
                ],
                [
                    'tag'      => 'Все скрипты',
                    'title'    => 'Полная экосистема',
                    'price'    => $fullPrices['price'],
                    'price_alt'=> $fullPrices['price_alt'],
                    'price_yearly' => $fullPrices['price_yearly'],
                    'price_yearly_alt' => $fullPrices['price_yearly_alt'],
                    'desc'     => 'Все CMS-скрипты BILOHASH + AI Consultant на 1 домене — 1 месяц или 12 месяцев.',
                    'cta'      => 'Оформить подписку',
                    'featured' => true,
                ],
            ],
            'product_price' => $scriptPrices['price'] . $scriptPrices['price_alt'],
            'product_cta'   => 'Оформить подписку',
            'faq_cost_q'    => 'Сколько стоит подписка?',
            'faq_install_q' => 'Как установить после оформления подписки?',
            'faq_cost'      => ecosystem_pricing_faq_answer('ru') . ' Оформление: bilohash.com/ecosystem/join.php. ' . $paymentsNotice,
            'faq_install'   => 'После подписки получаете файлы и инструкцию в кабинете — устанавливаете сами, через программиста или с bilohash.',
            'install_items' => [
                'Оформите подписку на bilohash.com/ecosystem/join.php',
                'Получите ключ и файлы в кабинете клиента',
                'Установите сами по гайду, через программиста или с bilohash',
            ],
        ]),
        'no' => array_merge($common, [
            'meta_description' => 'Grok xAI chat-konsulent for nettsted. Samlet BILOHASH-abonnement: ' . $tagline . ' Telegram-varsler, 6 språk.',
            'nav_pricing'      => 'Abonnement',
            'hero_install'     => $tagline,
            'cta_subscribe'    => 'Skaff abonnement',
            'cta_cabinet'      => 'Kundekabinett',
            'billing_text'     => '{tagline}',
            'billing_cta'      => 'Samlet BILOHASH-abonnement',
            'subscription_title' => 'Samlet BILOHASH-abonnement',
            'subscription_sub'   => 'AI Consultant Grok xAI er del av CMS-økosystemet — 1 domene, 1 eller 12 mnd, ett-klikk installasjon.',
            'pricing_subtitle'   => '1 domene · 1 eller 12 mnd — ett skript eller hele økosystemet (AI, Shop CMS, Booking m.m.)',
            'pricing_includes'   => [
                'Grok xAI widget-kode + installasjonsguide',
                'Lisensnøkkel i kundekabinettet',
                'Prompt-tilpasning for bedriften',
                'Telegram-integrasjon og varsler',
                'Oppdateringer mens abonnementet er aktivt',
                'Support via ecosystem waitlist',
            ],
            'tiers' => [
                [
                    'tag'      => '1 CMS-skript',
                    'title'    => 'Ett skript + AI',
                    'price'    => $scriptPrices['price'],
                    'price_alt'=> $scriptPrices['price_alt'],
                    'price_yearly' => $scriptPrices['price_yearly'],
                    'price_yearly_alt' => $scriptPrices['price_yearly_alt'],
                    'desc'     => 'Støtte for ett CMS-skript eller AI Consultant på 1 domene — 1 eller 12 mnd.',
                    'cta'      => 'Skaff abonnement',
                ],
                [
                    'tag'      => 'Alle skript',
                    'title'    => 'Hele økosystemet',
                    'price'    => $fullPrices['price'],
                    'price_alt'=> $fullPrices['price_alt'],
                    'price_yearly' => $fullPrices['price_yearly'],
                    'price_yearly_alt' => $fullPrices['price_yearly_alt'],
                    'desc'     => 'Alle BILOHASH CMS-skript + AI Consultant på 1 domene — 1 eller 12 mnd.',
                    'cta'      => 'Skaff abonnement',
                    'featured' => true,
                ],
            ],
            'product_price' => $scriptPrices['price'] . $scriptPrices['price_alt'],
            'product_cta'   => 'Skaff abonnement',
            'faq_cost_q'    => 'Hva koster abonnementet?',
            'faq_install_q' => 'Hvordan installerer jeg etter abonnement?',
            'faq_cost'      => ecosystem_pricing_faq_answer('no') . ' Meld deg på: bilohash.com/ecosystem/join.php. ' . $paymentsNotice,
            'faq_install'   => 'Etter abonnement får du filer og guide i kabinettet — installer selv, via utvikler eller med bilohash.',
            'install_items' => [
                'Skaff abonnement på bilohash.com/ecosystem/join.php',
                'Hent nøkkel og filer i kundekabinettet',
                'Installer selv med guiden, via utvikler eller med bilohash',
            ],
        ]),
        'sv' => array_merge($common, [
            'meta_description' => 'Grok xAI chattkonsult för webbplats. Samlat BILOHASH-abonnemang: ' . $tagline . ' Telegram-leads, 6 språk.',
            'nav_pricing'      => 'Abonnemang',
            'hero_install'     => $tagline,
            'cta_subscribe'    => 'Skaffa abonnemang',
            'cta_cabinet'      => 'Kundkabinett',
            'billing_text'     => '{tagline}',
            'billing_cta'      => 'Samlat BILOHASH-abonnemang',
            'subscription_title' => 'Samlat BILOHASH-abonnemang',
            'subscription_sub'   => 'AI Consultant Grok xAI ingår i CMS-ekosystemet — 1 domän, 1 eller 12 mån, installation med ett klick.',
            'pricing_subtitle'   => '1 domän · 1 eller 12 mån — ett skript eller hela ekosystemet (AI, Shop CMS, Booking m.fl.)',
            'pricing_includes'   => [
                'Grok xAI widget-kod + installationsguide',
                'Licensnyckel i kundkabinettet',
                'Prompt-anpassning för verksamheten',
                'Telegram-integration och aviseringar',
                'Uppdateringar så länge abonnemanget är aktivt',
                'Support via ecosystem waitlist',
            ],
            'tiers' => [
                [
                    'tag'      => '1 CMS-skript',
                    'title'    => 'Ett skript + AI',
                    'price'    => $scriptPrices['price'],
                    'price_alt'=> $scriptPrices['price_alt'],
                    'price_yearly' => $scriptPrices['price_yearly'],
                    'price_yearly_alt' => $scriptPrices['price_yearly_alt'],
                    'desc'     => 'Stöd för ett CMS-skript eller AI Consultant på 1 domän — 1 eller 12 mån.',
                    'cta'      => 'Skaffa abonnemang',
                ],
                [
                    'tag'      => 'Alla skript',
                    'title'    => 'Hela ekosystemet',
                    'price'    => $fullPrices['price'],
                    'price_alt'=> $fullPrices['price_alt'],
                    'price_yearly' => $fullPrices['price_yearly'],
                    'price_yearly_alt' => $fullPrices['price_yearly_alt'],
                    'desc'     => 'Alla BILOHASH CMS-skript + AI Consultant på 1 domän — 1 eller 12 mån.',
                    'cta'      => 'Skaffa abonnemang',
                    'featured' => true,
                ],
            ],
            'product_price' => $scriptPrices['price'] . $scriptPrices['price_alt'],
            'product_cta'   => 'Skaffa abonnemang',
            'faq_cost_q'    => 'Vad kostar abonnemanget?',
            'faq_install_q' => 'Hur installerar jag efter abonnemang?',
            'faq_cost'      => ecosystem_pricing_faq_answer('sv') . ' Anmäl dig: bilohash.com/ecosystem/join.php. ' . $paymentsNotice,
            'faq_install'   => 'Efter abonnemang får du filer och guide i kabinettet — installera själv, via utvecklare eller med bilohash.',
            'install_items' => [
                'Skaffa abonnemang på bilohash.com/ecosystem/join.php',
                'Hämta nyckel och filer i kundkabinettet',
                'Installera själv med guiden, via utvecklare eller med bilohash',
            ],
        ]),
        'lt' => array_merge($common, [
            'meta_description' => 'Grok xAI pokalbių konsultantas svetainei. Vieninga BILOHASH prenumerata: ' . $tagline . ' Telegram leadai, 6 kalbos.',
            'nav_pricing'      => 'Prenumerata',
            'hero_install'     => $tagline,
            'cta_subscribe'    => 'Gauti prenumeratą',
            'cta_cabinet'      => 'Kliento kabinetas',
            'billing_text'     => '{tagline}',
            'billing_cta'      => 'Vieninga BILOHASH prenumerata',
            'subscription_title' => 'Vieninga BILOHASH prenumerata',
            'subscription_sub'   => 'AI Consultant Grok xAI įtrauktas į CMS ekosistemą — 1 domenas, 1 arba 12 mėn., diegimas vienu paspaudimu.',
            'pricing_subtitle'   => '1 domenas · 1 arba 12 mėn. — vienas skriptas ar visa ekosistema (AI, Shop CMS, Booking ir kt.)',
            'pricing_includes'   => [
                'Grok xAI valdiklio kodas + instrukcija',
                'Licencijos raktas kliento kabinete',
                'Prompt pritaikymas verslui',
                'Telegram integracija ir pranešimai',
                'Atnaujinimai kol prenumerata aktyvi',
                'Palaikymas per ecosystem waitlist',
            ],
            'tiers' => [
                [
                    'tag'      => '1 CMS skriptas',
                    'title'    => 'Vienas skriptas + AI',
                    'price'    => $scriptPrices['price'],
                    'price_alt'=> $scriptPrices['price_alt'],
                    'price_yearly' => $scriptPrices['price_yearly'],
                    'price_yearly_alt' => $scriptPrices['price_yearly_alt'],
                    'desc'     => 'Vieno CMS skripto ar AI Consultant palaikymas 1 domene — 1 arba 12 mėn.',
                    'cta'      => 'Gauti prenumeratą',
                ],
                [
                    'tag'      => 'Visi skriptai',
                    'title'    => 'Visa ekosistema',
                    'price'    => $fullPrices['price'],
                    'price_alt'=> $fullPrices['price_alt'],
                    'price_yearly' => $fullPrices['price_yearly'],
                    'price_yearly_alt' => $fullPrices['price_yearly_alt'],
                    'desc'     => 'Visi BILOHASH CMS skriptai + AI Consultant 1 domene — 1 arba 12 mėn.',
                    'cta'      => 'Gauti prenumeratą',
                    'featured' => true,
                ],
            ],
            'product_price' => $scriptPrices['price'] . $scriptPrices['price_alt'],
            'product_cta'   => 'Gauti prenumeratą',
            'faq_cost_q'    => 'Kiek kainuoja prenumerata?',
            'faq_install_q' => 'Kaip įdiegti po prenumeratos?',
            'faq_cost'      => ecosystem_pricing_faq_answer('en') . ' Registracija: bilohash.com/ecosystem/join.php. ' . $paymentsNotice,
            'faq_install'   => 'Po prenumeratos gaunate failus ir instrukciją kabinete — diegiate patys, per programuotoją arba su bilohash.',
            'install_items' => [
                'Gaukite prenumeratą bilohash.com/ecosystem/join.php',
                'Gaukite raktą ir failus kliento kabinete',
                'Įdiekite patys pagal gidą, per programuotoją arba su bilohash',
            ],
        ]),
        default => array_merge($common, [
            'meta_description' => 'Grok xAI chat consultant for websites. Unified BILOHASH subscription: ' . $tagline . ' Telegram leads, 6 languages.',
            'nav_pricing'      => 'Subscription',
            'hero_install'     => $tagline,
            'cta_subscribe'    => 'Get subscription',
            'cta_cabinet'      => 'Customer cabinet',
            'billing_text'     => '{tagline}',
            'billing_cta'      => 'Unified BILOHASH subscription',
            'subscription_title' => 'Unified BILOHASH subscription',
            'subscription_sub'   => 'AI Consultant Grok xAI is part of the BILOHASH CMS ecosystem — 1 domain, 1 or 12 months, one-click install.',
            'pricing_subtitle'   => '1 domain · 1 or 12 months — single script or full ecosystem (AI, Shop CMS, Booking & more)',
            'pricing_includes'   => [
                'Grok xAI widget code + setup guide',
                'License key in customer cabinet',
                'Business prompt tuning',
                'Telegram integration & alerts',
                'Updates while subscription is active',
                'Support via ecosystem waitlist',
            ],
            'tiers' => [
                [
                    'tag'      => '1 CMS script',
                    'title'    => 'Single script + AI',
                    'price'    => $scriptPrices['price'],
                    'price_alt'=> $scriptPrices['price_alt'],
                    'price_yearly' => $scriptPrices['price_yearly'],
                    'price_yearly_alt' => $scriptPrices['price_yearly_alt'],
                    'desc'     => 'Support for one CMS script or AI Consultant on 1 domain — 1 or 12 months.',
                    'cta'      => 'Get subscription',
                ],
                [
                    'tag'      => 'All scripts',
                    'title'    => 'Full ecosystem',
                    'price'    => $fullPrices['price'],
                    'price_alt'=> $fullPrices['price_alt'],
                    'price_yearly' => $fullPrices['price_yearly'],
                    'price_yearly_alt' => $fullPrices['price_yearly_alt'],
                    'desc'     => 'All BILOHASH CMS scripts + AI Consultant on 1 domain — 1 or 12 months.',
                    'cta'      => 'Get subscription',
                    'featured' => true,
                ],
            ],
            'product_price' => $scriptPrices['price'] . $scriptPrices['price_alt'],
            'product_cta'   => 'Get subscription',
            'faq_cost_q'    => 'How much does the subscription cost?',
            'faq_install_q' => 'How do I install after subscribing?',
            'faq_cost'      => ecosystem_pricing_faq_answer('en') . ' Join at bilohash.com/ecosystem/join.php. ' . $paymentsNotice,
            'faq_install'   => 'After subscribing you get files and guide in the cabinet — self-install, your developer, or with bilohash.',
            'install_items' => [
                'Get subscription at bilohash.com/ecosystem/join.php',
                'Receive key and files in customer cabinet',
                'Install yourself with the guide, via developer, or with bilohash',
            ],
        ]),
    };
}

function ai_apply_subscription_translations(array $t, string $lang): array
{
    $copy = ai_subscription_copy($lang);

    $t['meta']['description'] = $copy['meta_description'];
    $t['nav']['pricing'] = $copy['nav_pricing'];
    $t['hero']['install_note'] = $copy['hero_install'];
    $t['hero']['cta_contact'] = $copy['cta_subscribe'];
    $t['hero']['cta_subscribe'] = $copy['cta_subscribe'];
    $t['hero']['cta_cabinet'] = $copy['cta_cabinet'];

    $t['billing'] = [
        'enabled' => true,
        'text'    => $copy['billing_text'],
        'cta'     => $copy['billing_cta'],
        'link'    => 'subscription',
    ];

    $t['subscription'] = [
        'title' => $copy['subscription_title'],
        'sub'   => $copy['subscription_sub'],
        'cta'   => $copy['cta_subscribe'],
    ];

    $t['products']['basic']['price'] = $copy['product_price'];
    $t['products']['basic']['cta'] = $copy['product_cta'];

    $t['pricing']['title'] = $copy['nav_pricing'];
    $t['pricing']['subtitle'] = $copy['pricing_subtitle'];
    $t['pricing']['tiers'] = $copy['tiers'];
    $t['pricing']['includes'] = $copy['pricing_includes'];
    $t['pricing']['fx_note'] = $copy['fx_note'];
    $t['pricing']['payments_notice'] = $copy['payments_notice'];
    $t['pricing']['cabinet_cta'] = $copy['cta_cabinet'];
    $t['pricing']['cta'] = $copy['cta_subscribe'];

    $t['install']['items'] = $copy['install_items'];
    $t['install']['cta'] = $copy['cta_subscribe'];

    if (!empty($t['faq']['items'][0])) {
        $t['faq']['items'][0]['q'] = $copy['faq_cost_q'] ?? $t['faq']['items'][0]['q'];
        $t['faq']['items'][0]['a'] = $copy['faq_cost'];
    }
    if (!empty($t['faq']['items'][1])) {
        $t['faq']['items'][1]['q'] = $copy['faq_install_q'] ?? $t['faq']['items'][1]['q'];
        $t['faq']['items'][1]['a'] = $copy['faq_install'];
    }

    return $t;
}

function ai_subscription_banner_text(array $labels, string $lang): string
{
    $tagline = ai_subscription_tagline($lang);
    $tpl = (string) ($labels['text'] ?? '{tagline}');

    return strtr($tpl, ['{tagline}' => $tagline]);
}

function ai_render_subscription_banner(array $t, string $lang): void
{
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    $labels = is_array($t['billing'] ?? null) ? $t['billing'] : [];
    ecosystem_subscription_strip_render($lang, ecosystem_subscription_strip_enabled($labels));
}