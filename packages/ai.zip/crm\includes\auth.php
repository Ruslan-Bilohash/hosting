<?php
/**
 * CRM AI Consultant — Authentication & authorization helpers
 * Version: 5.0
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

function crm_ai_session_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Lax');
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            ini_set('session.cookie_secure', '1');
        }
        session_start();
    }
}

function crm_ai_admin_role(): string
{
    return $_SESSION['crm_ai_admin_role'] ?? 'admin';
}

function crm_ai_is_demo(): bool
{
    return crm_ai_admin_role() === 'demo';
}

function crm_ai_require_login(): void
{
    crm_ai_session_start();
    if (empty($_SESSION['crm_ai_admin_logged_in'])) {
        header('Location: login.php');
        exit;
    }
}

function crm_ai_require_write_access(): void
{
    if (crm_ai_is_demo()) {
        http_response_code(403);
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
            && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
        if ($isAjax || (isset($_GET['action']) || isset($_POST['action']))) {
            header('Content-Type: application/json; charset=utf-8');
            global $ta;
            $msg = $ta['auth']['demo_readonly_json'] ?? 'Demo account is read-only. Changes are not allowed.';
            echo json_encode([
                'success' => false,
                'message' => $msg,
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $_SESSION['crm_demo_notice'] = true;
        header('Location: index.php?demo_readonly=1');
        exit;
    }
}

function crm_ai_csrf_token(): string
{
    crm_ai_session_start();
    if (empty($_SESSION['crm_csrf_token'])) {
        $_SESSION['crm_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['crm_csrf_token'];
}

function crm_ai_csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(crm_ai_csrf_token()) . '">';
}

function crm_ai_verify_csrf(?string $token): bool
{
    crm_ai_session_start();
    return !empty($token)
        && !empty($_SESSION['crm_csrf_token'])
        && hash_equals($_SESSION['crm_csrf_token'], $token);
}

function crm_ai_resolve_admin_role(array $admin): string
{
    if (!empty($admin['role']) && in_array($admin['role'], ['admin', 'demo'], true)) {
        return $admin['role'];
    }
    return ($admin['username'] ?? '') === 'demo' ? 'demo' : 'admin';
}

function crm_ai_set_admin_session(array $admin): void
{
    $_SESSION['crm_ai_admin_logged_in'] = true;
    $_SESSION['crm_ai_admin_id']        = (int)($admin['id'] ?? 0);
    $_SESSION['crm_ai_admin_username']  = $admin['username'] ?? '';
    $_SESSION['crm_ai_admin_full_name'] = $admin['full_name'] ?? '';
    $_SESSION['crm_ai_admin_role']      = crm_ai_resolve_admin_role($admin);
}

function crm_ai_login_rate_limited(): bool
{
    crm_ai_session_start();
    $now  = time();
    $data = $_SESSION['crm_login_attempts'] ?? ['count' => 0, 'until' => 0];
    if ($data['until'] > $now) {
        return true;
    }
    if ($data['until'] <= $now && $data['count'] >= 5) {
        $_SESSION['crm_login_attempts'] = ['count' => 0, 'until' => 0];
    }
    return false;
}

function crm_ai_register_failed_login(): void
{
    crm_ai_session_start();
    $data = $_SESSION['crm_login_attempts'] ?? ['count' => 0, 'until' => 0];
    $data['count']++;
    if ($data['count'] >= 5) {
        $data['until'] = time() + 300;
        $data['count'] = 0;
    }
    $_SESSION['crm_login_attempts'] = $data;
}

function crm_ai_clear_login_attempts(): void
{
    unset($_SESSION['crm_login_attempts']);
}

function crm_ai_public_url(): string
{
    return defined('BASE_URL') ? rtrim((string) BASE_URL, '/') . '/' : '/ai/crm/';
}

function crm_ai_logout(): void
{
    crm_ai_session_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $params['path'] ?: '/',
            'domain'   => $params['domain'] ?? '',
            'secure'   => (bool) ($params['secure'] ?? false),
            'httponly' => (bool) ($params['httponly'] ?? true),
            'samesite' => $params['samesite'] ?? 'Lax',
        ]);
    }
    session_destroy();
}

function crm_ai_logout_redirect(): void
{
    crm_ai_logout();
    header('Location: ' . crm_ai_public_url(), true, 302);
    exit;
}

function crm_ai_ensure_demo_user(PDO $pdo): void
{
    $demo_password = 'demo';
    try {
        $stmt = $pdo->prepare('SELECT id FROM admins WHERE username = ? LIMIT 1');
        $stmt->execute(['demo']);
        $hash = password_hash($demo_password, PASSWORD_ARGON2ID);
        if ($stmt->fetch()) {
            $upd = $pdo->prepare('UPDATE admins SET password_hash = ? WHERE username = ?');
            $upd->execute([$hash, 'demo']);
            return;
        }
        try {
            $ins = $pdo->prepare(
                'INSERT INTO admins (username, password_hash, full_name, role, created_at) VALUES (?, ?, ?, ?, NOW())'
            );
            $ins->execute(['demo', $hash, 'Demo Viewer', 'demo']);
        } catch (PDOException $e) {
            $ins = $pdo->prepare(
                'INSERT INTO admins (username, password_hash, full_name, created_at) VALUES (?, ?, ?, NOW())'
            );
            $ins->execute(['demo', $hash, 'Demo Viewer']);
        }
    } catch (Throwable $e) {
        error_log('CRM AI demo user: ' . $e->getMessage());
    }
}