<?php
/**
 * CRM AI Consultant — AJAX завантаження розмови
 * Version: 5.0
 */

require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_require_login();

header('Content-Type: text/html; charset=utf-8');

$site_id = crm_ai_sanitize_id($_GET['site_id'] ?? '');
$session = trim($_GET['session'] ?? '');

if ($site_id === '' || $session === '' || strlen($session) > 128) {
    echo '<p class="text-red-400 text-center py-10">' . htmlspecialchars($ta['get_conversation']['missing_params']) . '</p>';
    exit;
}

$messages = crm_ai_get_conversation($site_id, $session);
?>

<div class="space-y-5">
    <?php if (empty($messages)): ?>
        <p class="text-center text-zinc-500 py-16"><?= htmlspecialchars($ta['get_conversation']['empty']) ?></p>
    <?php else: ?>
        <?php foreach ($messages as $msg):
            $isClient = ($msg['sender'] === 'client');
        ?>
            <div class="flex <?= $isClient ? 'justify-end' : 'justify-start' ?>">
                <div class="<?= $isClient
                    ? 'bg-cyan-500 text-black'
                    : 'bg-zinc-700 text-white' ?>
                    max-w-[85%] px-4 sm:px-6 py-3 sm:py-4 rounded-3xl rounded-<?= $isClient ? 'tr' : 'tl' ?>-none shadow">
                    <p class="whitespace-pre-wrap leading-relaxed">
                        <?= nl2br(htmlspecialchars($msg['message'])) ?>
                    </p>
                    <p class="text-[10px] opacity-70 mt-2 text-right">
                        <?= date('H:i', strtotime($msg['created_at'])) ?>
                    </p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>