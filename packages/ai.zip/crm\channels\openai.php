<?php
/**
 * CRM AI Consultant — Канал OpenAI (ChatGPT)
 * Version: 4.1 — Промпт з файлу + швидкий cURL + підтримка Telegram
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

/**
 * Головна функція відправки повідомлення через OpenAI
 */
function crm_ai_send_to_openai($site_id, $session, $user_message) {
   
    // Отримуємо налаштування (з кешу)
    $settings = crm_ai_get_site_settings($site_id);
    if (!$settings) {
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    $secrets = crm_ai_get_secrets($site_id);
    $api_key = trim($secrets['openai_api_key'] ?? '');
    $model = crm_ai_resolve_channel_model('openai', $settings);

    // Беремо промпт з файлу (дуже швидко)
    $system_prompt = crm_ai_get_prompt($site_id);

    if (empty($api_key)) {
        crm_ai_save_message($site_id, $session, $user_message, 'client');
        $error_msg = "❌ OpenAI API ключ не налаштовано.";
        crm_ai_save_message($site_id, $session, $error_msg, 'bot');
        return ['success' => false, 'message' => $error_msg];
    }

    // Якщо промпт порожній — використовуємо твій великий стандартний
    if (empty($system_prompt)) {
        $system_prompt = "Ти — офіційний AI-консультант продукту «CRM AI Consultant 4.0», створений БІЛОГАШ (Ruslan Bilohash). ..."; // тут твій повний промпт, який був раніше
    }

    $url = "https://api.openai.com/v1/chat/completions";

    $payload = [
        "model" => $model,
        "messages" => [
            [
                "role" => "system",
                "content" => $system_prompt
            ],
            [
                "role" => "user",
                "content" => $user_message
            ]
        ],
        "max_tokens"  => 1500
    ];

    if (crm_ai_model_supports_temperature('openai', $model)) {
        $payload["temperature"] = (float)($settings['openai_temperature'] ?? 0.7);
    }

    $headers = [
        "Content-Type: application/json",
        "Authorization: Bearer " . $api_key
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);           // зменшив для швидкості
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        error_log("OpenAI cURL error (site: $site_id): " . $curl_error);
        $reply = "❌ Помилка з'єднання з OpenAI API.";
    } elseif ($http_code !== 200) {
        error_log("OpenAI API error (site: $site_id): HTTP $http_code");
        $reply = "❌ OpenAI API помилка (код $http_code).";
    } else {
        $result = json_decode($response, true);
        $reply = $result['choices'][0]['message']['content'] 
                 ?? "Вибач, я не зміг сформувати відповідь.";
    }

    // Зберігаємо в базу
    crm_ai_save_message($site_id, $session, $user_message, 'client');
    crm_ai_save_message($site_id, $session, $reply, 'bot');

    return [
        'success' => ($http_code === 200),
        'message' => $reply
    ];
}
?>