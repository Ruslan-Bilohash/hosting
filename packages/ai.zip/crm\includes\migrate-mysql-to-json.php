<?php
/**
 * One-time migration: sites + conversations MySQL → JSON
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

function crm_migrate_mysql_to_json(PDO $pdo): array
{
    require_once __DIR__ . '/storage.php';
    crm_storage_init();

    $report = ['sites' => 0, 'messages' => 0, 'skipped' => false];

    if (count(crm_storage_list_site_ids()) > 0) {
        $report['skipped'] = true;
        return $report;
    }

    try {
        $sites = $pdo->query('SELECT * FROM sites')->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return $report;
    }

    foreach ($sites as $row) {
        $id = $row['id'] ?? '';
        if ($id === '') {
            continue;
        }
        crm_storage_save_site($id, $row);
        $report['sites']++;
    }

    try {
        $stmt = $pdo->query('SELECT site_id, session_id, message, sender, created_at FROM conversations ORDER BY created_at ASC');
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $dir = crm_storage_conv_dir($row['site_id']);
            if (!is_dir($dir)) {
                mkdir($dir, 0750, true);
            }
            $session = preg_replace('/[^a-zA-Z0-9_-]/', '', $row['session_id']);
            $path = crm_storage_conv_path($row['site_id'], $session);
            $messages = crm_storage_read_json($path, []);
            $messages[] = [
                'message'    => $row['message'],
                'sender'     => $row['sender'],
                'created_at' => $row['created_at'],
            ];
            crm_storage_write_json($path, $messages);

            $index_path = crm_storage_conv_index_path($row['site_id']);
            $index = crm_storage_read_json($index_path, ['sessions' => []]);
            $index['sessions'][$session] = [
                'message_count' => count($messages),
                'last_time'     => $row['created_at'],
                'last_message'  => mb_substr($row['message'], 0, 200),
            ];
            crm_storage_write_json($index_path, $index);
            $report['messages']++;
        }
    } catch (Throwable $e) {
        error_log('CRM migrate conversations: ' . $e->getMessage());
    }

    return $report;
}