<?php
/**
 * CRM AI Consultant — Версія системи
 * Version: 5.1
 */

if (!defined('CRM_AI_VERSION')) {
    define('CRM_AI_VERSION', '5.1');
}

if (!defined('CRM_AI_VERSION_DATE')) {
    define('CRM_AI_VERSION_DATE', '2026-07-14');
}