<?php
/**
 * CRM AI Consultant — Admin panel i18n
 * Cookie: crm_admin_lang | Languages: en, ua, ru, no, lt, sv, pl, de
 */

if (!defined('CRM_ADMIN_LANG_COOKIE')) {
    define('CRM_ADMIN_LANG_COOKIE', 'crm_admin_lang');
}

$CRM_ADMIN_LANGS = [
    'en' => ['label' => 'EN', 'name' => 'English',    'flag' => '🇬🇧', 'html' => 'en'],
    'ua' => ['label' => 'UA', 'name' => 'Українська',  'flag' => '🇺🇦', 'html' => 'uk'],
    'ru' => ['label' => 'RU', 'name' => 'Русский',    'flag' => '🇷🇺', 'html' => 'ru'],
    'no' => ['label' => 'NO', 'name' => 'Norsk',      'flag' => '🇳🇴', 'html' => 'no'],
    'lt' => ['label' => 'LT', 'name' => 'Lietuvių',   'flag' => '🇱🇹', 'html' => 'lt'],
    'sv' => ['label' => 'SV', 'name' => 'Svenska',    'flag' => '🇸🇪', 'html' => 'sv'],
    'pl' => ['label' => 'PL', 'name' => 'Polski',     'flag' => '🇵🇱', 'html' => 'pl'],
    'de' => ['label' => 'DE', 'name' => 'Deutsch',    'flag' => '🇩🇪', 'html' => 'de'],
];

function crm_admin_langs(): array
{
    global $CRM_ADMIN_LANGS;
    return $CRM_ADMIN_LANGS;
}

function crm_admin_cookie_path(): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '/ai/crm/admin/index.php';
    $dir    = str_replace('\\', '/', dirname($script));
    if (preg_match('#^(.*?/ai/crm)/#', $dir, $m)) {
        return $m[1] . '/';
    }
    if ($dir === '/' || $dir === '.') {
        return '/';
    }
    return rtrim($dir, '/') . '/';
}

function crm_admin_detect_lang(): string
{
    global $CRM_ADMIN_LANGS;
    $codes   = array_keys($CRM_ADMIN_LANGS);
    $default = 'ua';

    if (!empty($_GET['lang']) && in_array($_GET['lang'], $codes, true)) {
        $chosen = $_GET['lang'];
        setcookie(CRM_ADMIN_LANG_COOKIE, $chosen, [
            'expires'  => time() + 365 * 86400,
            'path'     => crm_admin_cookie_path(),
            'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'samesite' => 'Lax',
        ]);
        $_COOKIE[CRM_ADMIN_LANG_COOKIE] = $chosen;
        return $chosen;
    }

    if (!empty($_COOKIE[CRM_ADMIN_LANG_COOKIE]) && in_array($_COOKIE[CRM_ADMIN_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[CRM_ADMIN_LANG_COOKIE];
    }

    return $default;
}

function crm_admin_lang_url(string $code): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH)
        ?: ($_SERVER['SCRIPT_NAME'] ?? '/ai/crm/admin/index.php');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);

    $q['lang'] = $code;

    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}

function crm_admin_lang_switcher(): string
{
    global $lang, $CRM_ADMIN_LANGS, $ta;

    $current = $CRM_ADMIN_LANGS[$lang] ?? $CRM_ADMIN_LANGS['ua'];
    $label   = htmlspecialchars($ta['lang_switcher'] ?? 'Language', ENT_QUOTES, 'UTF-8');

    $html  = '<div class="relative" id="crmLangSwitcher">';
    $html .= '<button type="button" onclick="crmToggleLangMenu()" aria-label="' . $label . '" ';
    $html .= 'class="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-zinc-700 bg-zinc-50 hover:bg-zinc-100 rounded-2xl border border-zinc-200 transition-all">';
    $html .= '<span class="text-base leading-none">' . $current['flag'] . '</span>';
    $html .= '<span>' . htmlspecialchars($current['label'], ENT_QUOTES, 'UTF-8') . '</span>';
    $html .= '<i class="fas fa-chevron-down text-[10px] text-zinc-400"></i>';
    $html .= '</button>';
    $html .= '<div id="crmLangMenu" class="hidden absolute right-0 mt-2 py-2 bg-white border border-zinc-200 rounded-2xl shadow-xl z-[60] min-w-[130px]">';
    foreach (crm_admin_langs() as $code => $info) {
        $active = $code === $lang ? ' bg-sky-50 text-sky-600 font-semibold' : ' text-zinc-700 hover:bg-zinc-50';
        $html  .= '<a href="' . htmlspecialchars(crm_admin_lang_url($code), ENT_QUOTES, 'UTF-8') . '" ';
        $html  .= 'class="flex items-center gap-2.5 px-4 py-2.5 text-sm transition-colors' . $active . '">';
        $html  .= '<span>' . $info['flag'] . '</span>';
        $html  .= '<span>' . htmlspecialchars($info['label'], ENT_QUOTES, 'UTF-8') . '</span>';
        $html  .= '</a>';
    }
    $html .= '</div></div>';

    return $html;
}

$lang      = crm_admin_detect_lang();
$lang_meta = $CRM_ADMIN_LANGS[$lang] ?? $CRM_ADMIN_LANGS['ua'];

$lang_root = dirname(__DIR__, 2) . '/lang';
$en_t      = is_file($lang_root . '/en.php') ? require $lang_root . '/en.php' : [];
$en_admin  = $en_t['admin'] ?? [];

$lang_file = $lang_root . '/' . $lang . '.php';
if (!is_file($lang_file)) {
    $lang_file = $lang_root . '/ua.php';
}

$t  = require $lang_file;
$ta = array_replace_recursive($en_admin, $t['admin'] ?? []);