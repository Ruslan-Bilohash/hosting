<?php

function ai_platform_defs(): array
{
    static $defs = null;
    if ($defs === null) {
        $defs = require __DIR__ . '/../data/platform-defs.php';
    }
    return $defs;
}

function ai_platform_slugs(): array
{
    return array_keys(ai_platform_defs());
}

function ai_platform_hub_label(string $lang): string
{
    $labels = [
        'ua' => 'Платформи AI',
        'ru' => 'Платформы AI',
        'en' => 'AI platforms',
        'no' => 'AI-plattformer',
        'lt' => 'AI platformos',
        'sv' => 'AI-plattformar',
    ];
    return $labels[$lang] ?? $labels['en'];
}

function ai_platforms_build(): array
{
    $defs = ai_platform_defs();
    $tpl = [
        'ua' => [
            'title'       => 'AI чат Grok xAI для %s — віджет з інструкцією | bilohash.com',
            'description'   => 'AI-консультант Grok xAI на %s: плаваючий чат, збір лідів 24/7, Telegram-сповіщення. Встановлюєте самі, через програміста або домовляєтесь з нами.',
            'keywords'      => 'AI чат %s, Grok xAI %s, чат-віджет %s, встановлення AI чату, Telegram ліди, штучний інтелект для сайту',
            'h1'          => 'Grok xAI для %s',
            'subtitle'    => 'Розумний чат-консультант для вашого %s-сайту — з гнучким встановленням',
            'intro'       => 'Плаваючий AI-віджет Grok xAI для %s: код, інструкція, налаштування промпту під бізнес, Telegram-сповіщення та адаптивний дизайн чату.',
            'card_desc'   => 'AI-консультант Grok xAI для %s — код + інструкція.',
            'cta'         => 'Залишити заявку для %s',
        ],
        'ru' => [
            'title'       => 'AI чат Grok xAI для %s — виджет с инструкцией | bilohash.com',
            'description'   => 'AI-консультант Grok xAI на %s: плавающий чат, сбор лидов 24/7, уведомления Telegram. Устанавливаете сами, через программиста или договариваетесь с нами.',
            'keywords'      => 'AI чат %s, Grok xAI %s, чат-виджет %s, установка AI чата, Telegram лиды, искусственный интеллект для сайта',
            'h1'          => 'Grok xAI для %s',
            'subtitle'    => 'Умный чат-консультант для вашего %s-сайта — с гибкой установкой',
            'intro'       => 'Плавающий AI-виджет Grok xAI для %s: код, инструкция, настройка промпта, Telegram-уведомления и адаптивный дизайн чата.',
            'card_desc'   => 'AI-консультант Grok xAI для %s — код + инструкция.',
            'cta'         => 'Оставить заявку для %s',
        ],
        'en' => [
            'title'       => 'Grok xAI Chat for %s — Widget with Setup Guide | bilohash.com',
            'description'   => 'Grok xAI AI consultant for %s: floating chat, 24/7 lead capture, Telegram alerts. Install yourself, use your developer, or arrange setup with us.',
            'keywords'      => 'AI chat %s, Grok xAI %s, chat widget %s, AI chat installation, Telegram leads, smart chatbot',
            'h1'          => 'Grok xAI for %s',
            'subtitle'    => 'Smart AI consultant for your %s website — flexible installation',
            'intro'       => 'Floating Grok xAI widget for %s: code, setup guide, business prompt tuning, Telegram alerts and responsive chat design.',
            'card_desc'   => 'Grok xAI consultant for %s — code + guide.',
            'cta'         => 'Submit request for %s',
        ],
        'no' => [
            'title'       => 'Grok xAI chat for %s — widget med installasjonsguide | bilohash.com',
            'description'   => 'Grok xAI AI-konsulent for %s: flytende chat, lead-innsamling 24/7, Telegram-varsler. Installer selv, bruk utvikler, eller avtal med oss.',
            'keywords'      => 'AI chat %s, Grok xAI %s, chat widget %s, AI chat installasjon, Telegram leads, smart chatbot Norge',
            'h1'          => 'Grok xAI for %s',
            'subtitle'    => 'Smart AI-konsulent for ditt %s-nettsted — fleksibel installasjon',
            'intro'       => 'Flytende Grok xAI-widget for %s: kode, guide, prompt-tilpasning, Telegram-varsler og responsiv chatdesign.',
            'card_desc'   => 'Grok xAI-konsulent for %s — kode + guide.',
            'cta'         => 'Send forespørsel for %s',
        ],
        'lt' => [
            'title'       => 'Grok xAI pokalbis %s — valdiklis su instrukcija | bilohash.com',
            'description'   => 'Grok xAI AI konsultantas %s: plaukiojantis pokalbis, leadų surinkimas 24/7, Telegram pranešimai. Įdiekite patys, per programuotoją arba susitarkite su mumis.',
            'keywords'      => 'AI pokalbis %s, Grok xAI %s, pokalbių valdiklis %s, AI diegimas, Telegram leadai',
            'h1'          => 'Grok xAI %s',
            'subtitle'    => 'Išmanus AI konsultantas jūsų %s svetainei — lankstus diegimas',
            'intro'       => 'Plaukiojantis Grok xAI valdiklis %s: kodas, instrukcija, prompt pritaikymas, Telegram pranešimai ir adaptyvus dizainas.',
            'card_desc'   => 'Grok xAI konsultantas %s — kodas + instrukcija.',
            'cta'         => 'Palikti užklausą %s',
        ],
        'sv' => [
            'title'       => 'Grok xAI-chatt för %s — widget med installationsguide | bilohash.com',
            'description'   => 'Grok xAI AI-konsult för %s: flytande chatt, lead-insamling 24/7, Telegram-aviseringar. Installera själv, använd utvecklare, eller avtal med oss.',
            'keywords'      => 'AI chatt %s, Grok xAI %s, chattwidget %s, AI chatt installation, Telegram leads',
            'h1'          => 'Grok xAI för %s',
            'subtitle'    => 'Smart AI-konsult för din %s-webbplats — flexibel installation',
            'intro'       => 'Flytande Grok xAI-widget för %s: kod, guide, prompt-anpassning, Telegram-aviseringar och responsiv chattdesign.',
            'card_desc'   => 'Grok xAI-konsult för %s — kod + guide.',
            'cta'         => 'Skicka förfrågan för %s',
        ],
    ];

    $benefits = [
        'ua' => [
            ['title' => 'Швидкий запуск', 'text' => 'Встановлення на %s за 1–2 дні — самі за інструкцією, через програміста або з нами.'],
            ['title' => 'Збір лідів 24/7', 'text' => 'Grok xAI відповідає відвідувачам і збирає контакти навіть уночі та на вихідних.'],
            ['title' => 'Telegram-сповіщення', 'text' => 'Кожен важливий діалог — миттєво на ваш телефон з деталями розмови.'],
            ['title' => 'SEO та багатомовність', 'text' => 'Чат підтримує UA, RU, EN, NO та інші мови — ідеально для європейського бізнесу.'],
        ],
        'ru' => [
            ['title' => 'Быстрый запуск', 'text' => 'Установка на %s за 1–2 дня — сами по инструкции, через программиста или с нами.'],
            ['title' => 'Сбор лидов 24/7', 'text' => 'Grok xAI отвечает посетителям и собирает контакты даже ночью и в выходные.'],
            ['title' => 'Telegram-уведомления', 'text' => 'Каждый важный диалог — мгновенно на телефон с деталями разговора.'],
            ['title' => 'SEO и многоязычность', 'text' => 'Чат поддерживает UA, RU, EN, NO и другие языки — идеально для европейского бизнеса.'],
        ],
        'en' => [
            ['title' => 'Fast launch', 'text' => 'Install on %s within 1–2 days — DIY with our guide, your developer, or with us.'],
            ['title' => '24/7 lead capture', 'text' => 'Grok xAI answers visitors and collects contacts even at night and on weekends.'],
            ['title' => 'Telegram alerts', 'text' => 'Every important conversation — instantly on your phone with full details.'],
            ['title' => 'SEO & multilingual', 'text' => 'Chat supports UA, RU, EN, NO and more — perfect for European businesses.'],
        ],
        'no' => [
            ['title' => 'Rask oppstart', 'text' => 'Installasjon på %s innen 1–2 dager — selv med guiden, via utvikler eller med oss.'],
            ['title' => 'Lead-innsamling 24/7', 'text' => 'Grok xAI svarer besøkende og samler kontakter også om natten og i helger.'],
            ['title' => 'Telegram-varsler', 'text' => 'Hver viktig samtale — umiddelbart på telefonen med alle detaljer.'],
            ['title' => 'SEO og flerspråklig', 'text' => 'Chatten støtter UA, RU, EN, NO og mer — perfekt for europeiske bedrifter.'],
        ],
        'lt' => [
            ['title' => 'Greitas paleidimas', 'text' => 'Diegimas %s per 1–2 dienas — patys pagal instrukciją, per programuotoją arba su mumis.'],
            ['title' => 'Leadų surinkimas 24/7', 'text' => 'Grok xAI atsako lankytojams ir renka kontaktus net naktį ir savaitgaliais.'],
            ['title' => 'Telegram pranešimai', 'text' => 'Kiekvienas svarbus pokalbis — akimirksniu telefone su visais detalėmis.'],
            ['title' => 'SEO ir daugiakalbystė', 'text' => 'Pokalbis palaiko UA, RU, EN, NO ir daugiau — puiku Europos verslui.'],
        ],
        'sv' => [
            ['title' => 'Snabb start', 'text' => 'Installation på %s inom 1–2 dagar — själv med guiden, via utvecklare eller med oss.'],
            ['title' => 'Lead-insamling 24/7', 'text' => 'Grok xAI svarar besökare och samlar kontakter även på natten och helger.'],
            ['title' => 'Telegram-aviseringar', 'text' => 'Varje viktigt samtal — direkt på telefonen med alla detaljer.'],
            ['title' => 'SEO och flerspråkigt', 'text' => 'Chatten stöder UA, RU, EN, NO och mer — perfekt för europeiska företag.'],
        ],
    ];

    $features = [
        'ua' => ['Плаваючий чат-віджет Grok xAI', 'Налаштування промпту під ваш бізнес', 'Збір email та телефону в діалозі', 'Миттєві сповіщення в Telegram', 'Адаптивний дизайн для мобільних', 'Підтримка та оновлення 30 днів'],
        'ru' => ['Плавающий чат-виджет Grok xAI', 'Настройка промпта под ваш бизнес', 'Сбор email и телефона в диалоге', 'Мгновенные уведомления в Telegram', 'Адаптивный дизайн для мобильных', 'Поддержка и обновления 30 дней'],
        'en' => ['Floating Grok xAI chat widget', 'Business prompt tuning', 'Email and phone capture in dialogue', 'Instant Telegram notifications', 'Responsive mobile design', '30-day support and updates'],
        'no' => ['Flytende Grok xAI chatwidget', 'Tilpasning av prompt til din bedrift', 'E-post og telefon i dialogen', 'Umiddelbare Telegram-varsler', 'Responsivt mobil design', '30 dagers support og oppdateringer'],
        'lt' => ['Plaukiojantis Grok xAI pokalbių valdiklis', 'Verslo prompt pritaikymas', 'El. pašto ir telefono surinkimas', 'Momentiniai Telegram pranešimai', 'Adaptyvus mobilus dizainas', '30 dienų palaikymas ir atnaujinimai'],
        'sv' => ['Flytande Grok xAI chattwidget', 'Anpassning av prompt till ditt företag', 'E-post och telefon i dialogen', 'Omedelbara Telegram-aviseringar', 'Responsiv mobil design', '30 dagars support och uppdateringar'],
    ];

    $faq_q = [
        'ua' => ['Як встановлюється AI на %s?', 'Хто може встановити чат?', 'Чи потрібен доступ до коду %s?', 'Які мови підтримує чат?'],
        'ru' => ['Как устанавливается AI на %s?', 'Кто может установить чат?', 'Нужен ли доступ к коду %s?', 'Какие языки поддерживает чат?'],
        'en' => ['How is AI installed on %s?', 'Who can install the chat?', 'Do I need access to %s code?', 'Which languages does the chat support?'],
        'no' => ['Hvordan installeres AI på %s?', 'Hvem kan installere chatten?', 'Trenger jeg tilgang til %s-kode?', 'Hvilke språk støtter chatten?'],
        'lt' => ['Kaip diegiamas AI %s?', 'Kas gali įdiegti pokalbį?', 'Ar reikia prieigos prie %s kodo?', 'Kokias kalbas palaiko pokalbis?'],
        'sv' => ['Hur installeras AI på %s?', 'Vem kan installera chatten?', 'Behöver jag tillgång till %s-kod?', 'Vilka språk stöder chatten?'],
    ];
    $faq_a = [
        'ua' => ['Скрипт віджета вставляється в %s (HTML-блок, тема або кастомний код) за інструкцією — зазвичай за 1–2 дні.', 'Ви самі за інструкцією, ваш програміст, або ми за окремою домовленістю — залиште заявку.', 'Для самостійного встановлення потрібен доступ до редагування сайту або адмін-панелі %s.', 'UA, RU, EN, NO, SV, LT та інші — чат автоматично відповідає мовою відвідувача.'],
        'ru' => ['Скрипт виджета вставляется в %s (HTML-блок, тема или кастомный код) по инструкции — обычно за 1–2 дня.', 'Вы сами по инструкции, ваш программист, или мы по отдельной договорённости — оставьте заявку.', 'Для самостоятельной установки нужен доступ к редактированию сайта или админ-панели %s.', 'UA, RU, EN, NO, SV, LT и другие — чат автоматически отвечает языком посетителя.'],
        'en' => ['The widget script is embedded in %s (HTML block, theme or custom code) using our guide — usually within 1–2 days.', 'You with our guide, your developer, or us by separate arrangement — submit a request.', 'For DIY setup you need access to edit the site or %s admin panel.', 'UA, RU, EN, NO, SV, LT and more — the chat replies in the visitor\'s language.'],
        'no' => ['Widget-skriptet legges inn i %s (HTML-blokk, tema eller tilpasset kode) med guiden — vanligvis på 1–2 dager.', 'Du selv med guiden, din utvikler, eller oss etter separat avtale — send forespørsel.', 'For selv-installasjon trenger du tilgang til å redigere nettstedet eller %s adminpanel.', 'UA, RU, EN, NO, SV, LT og mer — chatten svarer på besøkendes språk.'],
        'lt' => ['Valdiklio skriptas įterpiamas į %s (HTML bloką, temą arba pasirinktinį kodą) pagal instrukciją — paprastai per 1–2 dienas.', 'Jūs patys pagal instrukciją, jūsų programuotojas arba mes atskiru susitarimu — palikite užklausą.', 'Savarankiškam diegimui reikia prieigos redaguoti svetainę arba %s administravimo panelę.', 'UA, RU, EN, NO, SV, LT ir daugiau — pokalbis atsako lankytojo kalba.'],
        'sv' => ['Widget-skriptet bäddas in i %s (HTML-block, tema eller anpassad kod) med guiden — vanligtvis på 1–2 dagar.', 'Du själv med guiden, din utvecklare, eller vi efter separat avtal — skicka förfrågan.', 'För själv-installation behöver du tillgång att redigera webbplatsen eller %s adminpanel.', 'UA, RU, EN, NO, SV, LT och mer — chatten svarar på besökarens språk.'],
    ];

    $platform_notes = [
        'wordpress' => [
            'ua' => 'Окремий плагін WordPress 2.8+ з адмін-панеллю, історією чатів і кастомізацією кольорів.',
            'ru' => 'Отдельный плагин WordPress 2.8+ с админ-панелью, историей чатов и настройкой цветов.',
            'en' => 'Dedicated WordPress plugin 2.8+ with admin panel, chat history and color customization.',
            'no' => 'Egen WordPress-plugin 2.8+ med adminpanel, chathistorikk og fargetilpasning.',
            'lt' => 'Atskiras WordPress įskiepis 2.8+ su administravimo skydeliu ir pokalbių istorija.',
            'sv' => 'Dedikerat WordPress-plugin 2.8+ med adminpanel, chatthistorik och färganpassning.',
        ],
        'tilda' => [
            'ua' => 'Вставка через блок T123 (HTML) або Zero Block — без зміни дизайну сайту.',
            'ru' => 'Вставка через блок T123 (HTML) или Zero Block — без изменения дизайна сайта.',
            'en' => 'Embed via T123 (HTML) block or Zero Block — no design changes needed.',
            'no' => 'Innbygging via T123 (HTML)-blokk eller Zero Block — ingen designendringer.',
            'lt' => 'Įterpimas per T123 (HTML) bloką arba Zero Block — be dizaino pakeitimų.',
            'sv' => 'Inbäddning via T123 (HTML)-block eller Zero Block — inga designändringar.',
        ],
        'shopify' => [
            'ua' => 'Додавання скрипта в theme.liquid або через додаток Custom Liquid — сумісно з усіма темами.',
            'ru' => 'Добавление скрипта в theme.liquid или через приложение Custom Liquid — совместимо со всеми темами.',
            'en' => 'Add script to theme.liquid or via Custom Liquid app — compatible with all themes.',
            'no' => 'Legg til skript i theme.liquid eller via Custom Liquid-app — kompatibelt med alle temaer.',
            'lt' => 'Skripto pridėjimas į theme.liquid arba per Custom Liquid programėlę.',
            'sv' => 'Lägg till skript i theme.liquid eller via Custom Liquid-app — kompatibelt med alla teman.',
        ],
        'wix' => [
            'ua' => 'Інтеграція через Velo (Dev Mode) або вбудований HTML iframe — швидкий запуск.',
            'ru' => 'Интеграция через Velo (Dev Mode) или встроенный HTML iframe — быстрый запуск.',
            'en' => 'Integration via Velo (Dev Mode) or embedded HTML iframe — fast launch.',
            'no' => 'Integrasjon via Velo (Dev Mode) eller innebygd HTML iframe — rask oppstart.',
            'lt' => 'Integracija per Velo (Dev Mode) arba įterptą HTML iframe.',
            'sv' => 'Integration via Velo (Dev Mode) eller inbäddad HTML iframe — snabb start.',
        ],
        'html-php' => [
            'ua' => 'Пряме вставлення в header.php, footer або шаблон — PHP, Laravel, чистий HTML.',
            'ru' => 'Прямая вставка в header.php, footer или шаблон — PHP, Laravel, чистый HTML.',
            'en' => 'Direct embed in header.php, footer or template — PHP, Laravel, plain HTML.',
            'no' => 'Direkte innbygging i header.php, footer eller mal — PHP, Laravel, ren HTML.',
            'lt' => 'Tiesioginis įterpimas į header.php, footer arba šabloną — PHP, Laravel, HTML.',
            'sv' => 'Direkt inbäddning i header.php, footer eller mall — PHP, Laravel, ren HTML.',
        ],
        'telegram' => [
            'ua' => 'AI-бот у Telegram + сповіщення про ліди з сайту — мультиканальна підтримка клієнтів.',
            'ru' => 'AI-бот в Telegram + уведомления о лидах с сайта — мультиканальная поддержка клиентов.',
            'en' => 'AI bot in Telegram + website lead alerts — multichannel customer support.',
            'no' => 'AI-bot i Telegram + varsler om leads fra nettstedet — flerkanals kundestøtte.',
            'lt' => 'AI botas Telegram + pranešimai apie leadus iš svetainės — daugiakanalė pagalba.',
            'sv' => 'AI-bot i Telegram + aviseringar om leads från webbplatsen — flerkanals kundsupport.',
        ],
    ];

    $out = [];
    foreach ($defs as $slug => $def) {
        if (!empty($def['external'])) {
            continue;
        }
        $entry = ['icon' => $def['icon'], 'color' => $def['color'] ?? '#00e5ff'];
        foreach (['ua', 'ru', 'en', 'no', 'lt', 'sv'] as $lng) {
            $name = $def[$lng];
            $t = $tpl[$lng];
            $faqs = [];
            foreach ($faq_q[$lng] as $i => $q) {
                $faqs[] = ['q' => sprintf($q, $name), 'a' => sprintf($faq_a[$lng][$i], $name)];
            }
            $benefit_items = array_map(static function ($b) use ($name) {
                return ['title' => $b['title'], 'text' => sprintf($b['text'], $name)];
            }, $benefits[$lng]);

            $entry[$lng] = [
                'title'       => sprintf($t['title'], $name),
                'description' => sprintf($t['description'], $name),
                'keywords'    => sprintf($t['keywords'], $name, $name, $name),
                'h1'          => sprintf($t['h1'], $name),
                'subtitle'    => sprintf($t['subtitle'], $name),
                'intro'       => sprintf($t['intro'], $name) . ' ' . ($platform_notes[$slug][$lng] ?? ''),
                'card_desc'   => sprintf($t['card_desc'], $name),
                'benefits'    => $benefit_items,
                'features'    => $features[$lng],
                'faq'         => $faqs,
                'cta'         => sprintf($t['cta'], $name),
                'name'        => $name,
            ];
        }
        $out[$slug] = $entry;
    }
    return $out;
}

function ai_platforms_all(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = ai_platforms_build();
    }
    return $cache;
}

function ai_platform_by_slug(string $slug): ?array
{
    if ($slug === 'wordpress') {
        return null;
    }
    return ai_platforms_all()[$slug] ?? null;
}

function ai_platform_lang(array $platform, string $lang): array
{
    $lang = in_array($lang, ['ua', 'ru', 'en', 'no', 'lt', 'sv'], true) ? $lang : 'ua';
    return $platform[$lang] ?? $platform['ua'] ?? [];
}

function ai_platform_url(string $slug, ?string $lang = null): string
{
    if ($slug === 'wordpress') {
        $path = '/ai/wordpress/';
        return $lang && $lang !== 'ua' ? $path . '?lang=' . urlencode($lang) : $path;
    }
    $path = ai_url($slug . '/');
    if ($lang && $lang !== 'ua') {
        return $path . '?lang=' . urlencode($lang);
    }
    return $path;
}

function ai_platform_canonical(string $slug): string
{
    global $lang;
    $base = ai_url($slug . '/');
    return $lang !== 'ua' ? $base . '?lang=' . $lang : $base;
}

function ai_platform_lang_url_for(string $slug, string $code): string
{
    return ai_platform_url($slug, $code === 'ua' ? null : $code);
}

function ai_integration_cards(string $lang): array
{
    $defs = ai_platform_defs();
    $platforms = ai_platforms_all();
    $cards = [];
    foreach ($defs as $slug => $def) {
        $name = $def[$lang] ?? $def['ua'];
        if (!empty($def['external'])) {
            $wp_desc = [
                'ua' => 'Плагін WordPress 2.8+ з адмін-панеллю та історією чатів.',
                'ru' => 'Плагин WordPress 2.8+ с админ-панелью и историей чатов.',
                'en' => 'WordPress plugin 2.8+ with admin panel and chat history.',
                'no' => 'WordPress-plugin 2.8+ med adminpanel og chathistorikk.',
                'lt' => 'WordPress įskiepis 2.8+ su administravimo skydeliu.',
                'sv' => 'WordPress-plugin 2.8+ med adminpanel och chatthistorik.',
            ];
            $cards[] = [
                'slug'  => $slug,
                'name'  => $name,
                'url'   => $def['external'],
                'icon'  => $def['icon'],
                'color' => $def['color'] ?? '#00e5ff',
                'desc'  => $wp_desc[$lang] ?? $wp_desc['en'],
            ];
            continue;
        }
        $p = $platforms[$slug][$lang] ?? $platforms[$slug]['ua'] ?? [];
        $cards[] = [
            'slug'  => $slug,
            'name'  => $name,
            'url'   => ai_platform_url($slug),
            'icon'  => $def['icon'],
            'color' => $def['color'] ?? '#00e5ff',
            'desc'  => $p['card_desc'] ?? $name,
        ];
    }
    return $cards;
}