<?php
/**
 * CRM AI Consultant — Налаштування OpenAI (ChatGPT)
 * Version: 4.2 — Розширений реєстр моделей
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die($ta['access_denied'] ?? 'Access denied');
}

$openai_model = crm_ai_resolve_channel_model('openai', $edit_site ?? []);
?>

<div id="settings_openai" class="channel-settings <?= ($edit_site['default_channel'] ?? '') === 'openai' ? '' : 'hidden' ?>">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fas fa-brain text-purple-400 text-2xl"></i>
        <?= htmlspecialchars($ta['settings_openai']['title']) ?>
    </h3>

    <div class="space-y-10">

        <div>
            <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_openai']['api_key']) ?></label>
            <input type="text" name="openai_api_key"
                   value="<?= htmlspecialchars($edit_site['openai_api_key'] ?? '') ?>"
                   class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono text-sm"
                   placeholder="sk-proj-................................">
            <p class="text-xs text-zinc-500 mt-2">
                <?= htmlspecialchars($ta['settings_openai']['api_key_hint']) ?> <a href="https://platform.openai.com/api-keys" target="_blank" class="text-sky-400 hover:underline">platform.openai.com/api-keys</a>
            </p>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-3">
                <?= htmlspecialchars($ta['settings_openai']['system_prompt']) ?>
            </label>
            <textarea name="openai_system_prompt" rows="10" 
                      class="w-full bg-zinc-900 border border-zinc-700 rounded-3xl px-7 py-6 font-mono text-sm leading-relaxed"
                      placeholder="<?= htmlspecialchars($ta['defaults']['openai_system_placeholder']) ?>"><?= htmlspecialchars($edit_site['openai_system_prompt'] ?? '') ?></textarea>
            <p class="text-xs text-amber-400 mt-3">
                <?= htmlspecialchars($ta['settings_openai']['system_prompt_hint']) ?>
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-zinc-700">
            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_openai']['model']) ?></label>
                <?php crm_ai_render_model_select('openai', 'openai_ai_model', $openai_model, $ta); ?>
            </div>

            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['settings_openai']['temperature']) ?></label>
                <select name="openai_temperature" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="0.7" <?= ($edit_site['openai_temperature'] ?? '0.7') === '0.7' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_openai']['temp_balanced']) ?></option>
                    <option value="0.3" <?= ($edit_site['openai_temperature'] ?? '0.7') === '0.3' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_openai']['temp_precise']) ?></option>
                    <option value="1.0" <?= ($edit_site['openai_temperature'] ?? '0.7') === '1.0' ? 'selected' : '' ?>><?= htmlspecialchars($ta['settings_openai']['temp_creative']) ?></option>
                </select>
                <p class="text-xs text-zinc-500 mt-2"><?= htmlspecialchars($ta['settings_openai']['temperature_hint'] ?? '') ?></p>
            </div>
        </div>

    </div>
</div>