<?php
/**
 * CRM AI Consultant — Сторінка входу адміністратора
 * Version: 5.0
 */

require_once __DIR__ . '/includes/bootstrap.php';

crm_ai_ensure_demo_user($pdo);

if (!empty($_SESSION['crm_ai_admin_logged_in'])) {
    header('Location: index.php');
    exit;
}

$login_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    if (!crm_ai_verify_csrf($_POST['csrf_token'] ?? '')) {
        $login_error = $ta['login']['csrf_error'];
    } elseif (crm_ai_login_rate_limited()) {
        $login_error = $ta['login']['rate_limit'];
    } else {
        $username = trim($_POST['username']);
        $password = $_POST['password'] ?? '';

        $cols = 'id, username, password_hash, full_name';
        try {
            $pdo->query('SELECT role FROM admins LIMIT 1');
            $cols .= ', role';
        } catch (PDOException $e) {
            // role column optional
        }

        $stmt = $pdo->prepare("SELECT {$cols} FROM admins WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password_hash'])) {
            crm_ai_set_admin_session($admin);
            crm_ai_clear_login_attempts();

            $update = $pdo->prepare('UPDATE admins SET last_login = NOW() WHERE id = ?');
            $update->execute([$admin['id']]);

            header('Location: index.php');
            exit;
        }

        crm_ai_register_failed_login();
        $login_error = $ta['login']['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= htmlspecialchars($ta['login']['title']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <?php require_once __DIR__ . '/includes/theme.php'; crm_admin_theme_head(); ?>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen flex items-center justify-center px-4">

<div class="max-w-md w-full mx-auto p-4 sm:p-8">
    <div class="fixed top-4 right-4 sm:top-6 sm:right-6 z-50 flex items-center gap-2">
        <?php crm_admin_theme_button(); ?>
        <?= crm_admin_lang_switcher() ?>
    </div>

    <div class="text-center mb-8 sm:mb-10">
        <div class="w-16 h-16 sm:w-20 sm:h-20 mx-auto bg-gradient-to-br from-sky-500 to-blue-600 rounded-3xl flex items-center justify-center text-4xl sm:text-5xl shadow-2xl">
            🤖
        </div>
        <h1 class="text-3xl sm:text-4xl font-bold mt-6"><?= htmlspecialchars($ta['app_name']) ?></h1>
        <p class="text-zinc-400 mt-2"><?= htmlspecialchars($ta['login']['admin_panel']) ?> · v<?= CRM_AI_VERSION ?></p>
    </div>

    <div class="bg-zinc-900 rounded-3xl p-6 sm:p-10 shadow-xl">
        <h2 class="text-xl sm:text-2xl font-semibold text-center mb-6 sm:mb-8"><?= htmlspecialchars($ta['login']['heading']) ?></h2>

        <?php if ($login_error): ?>
            <div class="bg-red-900/50 border border-red-700 text-red-200 p-4 rounded-2xl mb-6 text-center text-sm">
                <?= htmlspecialchars($login_error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-5 sm:space-y-6">
            <?= crm_ai_csrf_field() ?>
            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['login']['username']) ?></label>
                <input type="text" name="username" required autocomplete="username"
                       class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-5 sm:px-6 py-3.5 sm:py-4 focus:outline-none focus:border-sky-500">
            </div>

            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['login']['password']) ?></label>
                <input type="password" name="password" required autocomplete="current-password"
                       class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-5 sm:px-6 py-3.5 sm:py-4 focus:outline-none focus:border-sky-500">
            </div>

            <button type="submit"
                    class="w-full py-4 sm:py-5 bg-sky-600 hover:bg-sky-500 rounded-3xl font-bold text-base sm:text-lg transition">
                <?= htmlspecialchars($ta['login']['submit']) ?>
            </button>
        </form>

        <div class="text-center mt-6 sm:mt-8 text-xs text-zinc-500 space-y-2">
            <p><?= htmlspecialchars($ta['login']['demo_hint'] ?? 'Demo (read-only):') ?> <strong>demo</strong> / <strong>demo</strong></p>
            <p class="text-amber-400"><?= htmlspecialchars($ta['login']['change_password_hint']) ?></p>
        </div>
    </div>
</div>

<script>
function crmToggleLangMenu() {
    const menu = document.getElementById('crmLangMenu');
    if (menu) menu.classList.toggle('hidden');
}
document.addEventListener('click', function(e) {
    const wrap = document.getElementById('crmLangSwitcher');
    if (wrap && !wrap.contains(e.target)) {
        const menu = document.getElementById('crmLangMenu');
        if (menu) menu.classList.add('hidden');
    }
});
</script>
<?php crm_admin_theme_script(); ?>
</body>
</html>