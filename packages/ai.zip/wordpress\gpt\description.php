<?php
/**
 * Detailed Product Description - Адаптивна версія
 */
?>

<div class="container px-3 px-md-4">
    <div class="text-center mb-5">
        <h2 class="display-6 fw-bold text-white">Чому Bilohash GPT Chat Assistant Pro — найкращий вибір?</h2>
        <p class="lead text-light opacity-90 mt-3">Розумний, швидкий та професійний чатбот, який працює для вас 24/7</p>
    </div>

    <div class="row g-4 g-lg-5">

        <!-- Блок 1 -->
        <div class="col-lg-6">
            <div class="d-flex gap-3 gap-md-4">
                <div class="flex-shrink-0">
                    <i class="bi bi-cpu fs-1 text-info"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-white">Найсучасніший штучний інтелект</h5>
                    <p class="text-light opacity-75">
                        Працює на базі GPT-4o та GPT-4o-mini — найновіших моделей від OpenAI. 
                        Чатбот розуміє контекст, складні запитання та відповідає природною мовою.
                    </p>
                </div>
            </div>
        </div>

        <!-- Блок 2 -->
        <div class="col-lg-6">
            <div class="d-flex gap-3 gap-md-4">
                <div class="flex-shrink-0">
                    <i class="bi bi-translate fs-1 text-warning"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-white">Підтримка української та англійської</h5>
                    <p class="text-light opacity-75">
                        Автоматично визначає мову клієнта і відповідає на ній. 
                        Ідеально для українського бізнесу та міжнародних клієнтів.
                    </p>
                </div>
            </div>
        </div>

        <!-- Блок 3 -->
        <div class="col-lg-6">
            <div class="d-flex gap-3 gap-md-4">
                <div class="flex-shrink-0">
                    <i class="bi bi-bell fs-1 text-danger"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-white">Миттєві сповіщення в Telegram</h5>
                    <p class="text-light opacity-75">
                        Кожне повідомлення від клієнта приходить вам у Telegram у реальному часі. 
                        Ви ніколи не пропустите потенційного клієнта.
                    </p>
                </div>
            </div>
        </div>

        <!-- Блок 4 -->
        <div class="col-lg-6">
            <div class="d-flex gap-3 gap-md-4">
                <div class="flex-shrink-0">
                    <i class="bi bi-palette fs-1 text-success"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-white">Повна кастомізація під ваш бренд</h5>
                    <p class="text-light opacity-75">
                        Змінюйте кольори, градієнти, іконки, текст, позицію кнопки та стиль чату. 
                        Чат виглядає як частина вашого сайту.
                    </p>
                </div>
            </div>
        </div>

        <!-- Блок 5 -->
        <div class="col-lg-6">
            <div class="d-flex gap-3 gap-md-4">
                <div class="flex-shrink-0">
                    <i class="bi bi-shield-lock fs-1 text-primary"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-white">Безпечне зберігання даних</h5>
                    <p class="text-light opacity-75">
                        Вся історія розмов зберігається у захищеній папці на вашому сервері. 
                        Повна відповідність стандартам безпеки.
                    </p>
                </div>
            </div>
        </div>

        <!-- Блок 6 -->
        <div class="col-lg-6">
            <div class="d-flex gap-3 gap-md-4">
                <div class="flex-shrink-0">
                    <i class="bi bi-phone fs-1 text-info"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-white">Ідеально працює на всіх пристроях</h5>
                    <p class="text-light opacity-75">
                        Повністю адаптивний дизайн: чудово виглядає на смартфонах, планшетах та комп’ютерах.
                    </p>
                </div>
            </div>
        </div>

    </div>

    <!-- Додатковий блок переваг -->
    <div class="bg-white bg-opacity-10 rounded-4 p-4 p-md-5 mt-5">
        <div class="row text-center g-4">
            <div class="col-md-4">
                <h2 class="fw-bold text-info mb-1">24/7</h2>
                <p class="text-light">Працює цілодобово без вашої участі</p>
            </div>
            <div class="col-md-4">
                <h2 class="fw-bold text-info mb-1">∞</h2>
                <p class="text-light">Необмежена кількість діалогів</p>
            </div>
            <div class="col-md-4">
                <h2 class="fw-bold text-info mb-1">0₴</h2>
                <p class="text-light">Без абонентської плати за хостинг</p>
            </div>
        </div>
    </div>
</div>