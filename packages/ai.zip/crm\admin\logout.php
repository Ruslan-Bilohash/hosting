<?php
/**
 * CRM AI Consultant — Secure logout → public site
 */
require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_logout_redirect();