(function () {
    var burger = document.getElementById('wpBurger');
    var nav = document.getElementById('wpNav');
    var overlay = document.getElementById('wpOverlay');
    var langBtn = document.getElementById('wpLangBtn');
    var langMenu = document.getElementById('wpLangMenu');
    var langWrap = document.getElementById('wpLang');
    var modal = document.getElementById('wpModal');
    var modalImg = document.getElementById('wpModalImg');

    function setNav(open) {
        if (!nav || !burger || !overlay) return;
        nav.classList.toggle('is-open', open);
        overlay.hidden = !open;
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    if (burger) {
        burger.addEventListener('click', function () {
            setNav(!nav.classList.contains('is-open'));
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function () { setNav(false); });
    }
    if (nav) {
        nav.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', function () { setNav(false); });
        });
    }

    function closeLang() {
        if (!langWrap || !langBtn || !langMenu) return;
        langMenu.hidden = true;
        langBtn.setAttribute('aria-expanded', 'false');
    }

    if (langBtn && langMenu) {
        langBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = langMenu.hidden;
            langMenu.hidden = !open;
            langBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        langMenu.addEventListener('click', function (e) { e.stopPropagation(); });
        document.addEventListener('click', closeLang);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closeLang();
                setNav(false);
                if (modal) modal.classList.remove('is-open');
            }
        });
    }

    document.querySelectorAll('.wp-screenshot').forEach(function (img) {
        img.addEventListener('click', function () {
            if (!modal || !modalImg) return;
            modalImg.src = img.src;
            modalImg.alt = img.alt || '';
            modal.classList.add('is-open');
        });
    });
    if (modal) {
        modal.addEventListener('click', function () {
            modal.classList.remove('is-open');
        });
    }
})();