<?php
/**
 * Bilohash GPT Chat Assistant Pro - WordPress Plugin Description (SEO)
 */
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-8">

            <div class="text-center mb-5">
                <h1 class="display-6 fw-bold text-white">Bilohash GPT Chat Assistant Pro для WordPress</h1>
                <p class="lead text-light opacity-90">Сучасний інтелектуальний чатбот на базі GPT-4o, розроблений спеціально для сайтів на WordPress</p>
            </div>

            <!-- Вступний текст -->
            <div class="bg-white bg-opacity-10 rounded-4 p-5 mb-5">
                <p class="lead text-light">
                    <strong>Bilohash GPT Chat Assistant Pro</strong> — це потужний плагін для WordPress, який дозволяє додати на ваш сайт розумного чат-бота з підтримкою штучного інтелекту. 
                    Плагін працює на базі найновіших моделей OpenAI (GPT-4o та GPT-4o-mini), підтримує українську, англійську та норвезьку мови та ідеально підходить для бізнес-сайтів.
                </p>
            </div>

            <!-- Для кого підходить -->
            <h4 class="text-white mb-4 text-center">Для кого підходить цей плагін?</h4>
            <div class="row g-4 mb-5">
                <div class="col-md-6 col-lg-4">
                    <div class="d-flex align-items-start gap-3 bg-white bg-opacity-10 p-4 rounded-3 h-100">
                        <i class="bi bi-cart-check fs-3 text-success"></i>
                        <div>
                            <strong class="text-white">Власникам інтернет-магазинів</strong><br>
                            <small class="text-light">Консультації клієнтів, допомога з вибором товару, обробка замовлень</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="d-flex align-items-start gap-3 bg-white bg-opacity-10 p-4 rounded-3 h-100">
                        <i class="bi bi-briefcase fs-3 text-info"></i>
                        <div>
                            <strong class="text-white">Консалтинговим компаніям</strong><br>
                            <small class="text-light">Надання консультацій, запис на зустрічі, FAQ</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="d-flex align-items-start gap-3 bg-white bg-opacity-10 p-4 rounded-3 h-100">
                        <i class="bi bi-building fs-3 text-warning"></i>
                        <div>
                            <strong class="text-white">Сайтам послуг</strong><br>
                            <small class="text-light">(юридичні, медичні, будівельні, IT, маркетинг тощо)</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="d-flex align-items-start gap-3 bg-white bg-opacity-10 p-4 rounded-3 h-100">
                        <i class="bi bi-journal-text fs-3 text-primary"></i>
                        <div>
                            <strong class="text-white">Блогерам та інформаційним сайтам</strong><br>
                            <small class="text-light">Відповіді на коментарі та питання читачів</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="d-flex align-items-start gap-3 bg-white bg-opacity-10 p-4 rounded-3 h-100">
                        <i class="bi bi-people fs-3 text-success"></i>
                        <div>
                            <strong class="text-white">Агентствам та фрілансерам</strong><br>
                            <small class="text-light">Автоматизація комунікації з клієнтами</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Основні можливості -->
            <h4 class="text-white mb-4 text-center">Основні можливості плагіну</h4>
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="d-flex gap-3 bg-white bg-opacity-10 p-4 rounded-3">
                        <i class="bi bi-cpu fs-3 text-info"></i>
                        <div>
                            <strong>GPT-4o та GPT-4o-mini</strong><br>
                            <small class="text-light">Найсучасніші моделі штучного інтелекту від OpenAI</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-3 bg-white bg-opacity-10 p-4 rounded-3">
                        <i class="bi bi-telegram fs-3 text-primary"></i>
                        <div>
                            <strong>Миттєві сповіщення в Telegram</strong><br>
                            <small class="text-light">Всі повідомлення клієнтів приходять вам у реальному часі</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-3 bg-white bg-opacity-10 p-4 rounded-3">
                        <i class="bi bi-palette fs-3 text-success"></i>
                        <div>
                            <strong>Повна кастомізація дизайну</strong><br>
                            <small class="text-light">Змінюйте кольори, шрифти, іконки та стиль під ваш бренд</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-3 bg-white bg-opacity-10 p-4 rounded-3">
                        <i class="bi bi-clock-history fs-3 text-warning"></i>
                        <div>
                            <strong>Збереження історії розмов</strong><br>
                            <small class="text-light">Вся переписка зберігається у безпечній папці</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-3 bg-white bg-opacity-10 p-4 rounded-3">
                        <i class="bi bi-globe fs-3 text-info"></i>
                        <div>
                            <strong>Підтримка української, англійської та норвезької мов</strong>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-3 bg-white bg-opacity-10 p-4 rounded-3">
                        <i class="bi bi-shield-lock fs-3 text-success"></i>
                        <div>
                            <strong>Високий рівень безпеки</strong><br>
                            <small class="text-light">Захист від XSS, безпечне зберігання даних</small>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>