<?php
/**
 * Bilohash GPT Chat Assistant Pro - Screenshots Gallery with Lightbox
 */
include 'header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-9">

            <div class="text-center mb-5">
                <h1 class="display-6 fw-bold text-white">Скріншоти плагіну</h1>
                <p class="lead text-light">Як виглядає Bilohash GPT Chat Assistant Pro</p>
            </div>

            <div class="row g-4" id="screenshot-gallery">
                <!-- Скріншоти додаються автоматично -->
            </div>

        </div>
    </div>
</div>

<!-- Lightbox Modal -->
<div class="modal fade" id="lightboxModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content bg-dark border-0">
            <div class="modal-header border-0">
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-0">
                <img id="lightboxImage" src="" class="img-fluid" alt="Скріншот" style="max-height: 85vh; width: auto;">
            </div>
            <div class="modal-footer border-0 justify-content-center gap-4">
                <button onclick="prevImage()" class="btn btn-outline-light"><i class="bi bi-chevron-left"></i> Назад</button>
                <span id="imageCounter" class="text-light mx-3"></span>
                <button onclick="nextImage()" class="btn btn-outline-light">Вперед <i class="bi bi-chevron-right"></i></button>
            </div>
        </div>
    </div>
</div>

<script>
// Масив скріншотів (додавайте нові файли сюди)
const screenshots = [
    "1.jpg",
    "screenshot-2.jpg",
    "screenshot-3.jpg",
    "screenshot-4.jpg",
    "screenshot-5.jpg",
    "screenshot-6.jpg",
    "screenshot-7.jpg",
    "screenshot-8.jpg"
];

let currentIndex = 0;

// Генерація галереї
const gallery = document.getElementById('screenshot-gallery');

screenshots.forEach((filename, index) => {
    const col = document.createElement('div');
    col.className = 'col-md-6 col-lg-4';
    col.innerHTML = `
        <div class="card h-100 shadow-sm overflow-hidden cursor-pointer" onclick="openLightbox(${index})">
            <img src="screenshots/${filename}" 
                 class="card-img-top" 
                 alt="Скріншот ${index + 1}"
                 style="height: 280px; object-fit: cover;">
        </div>
    `;
    gallery.appendChild(col);
});

// Lightbox functions
function openLightbox(index) {
    currentIndex = index;
    updateLightbox();
    const modal = new bootstrap.Modal(document.getElementById('lightboxModal'));
    modal.show();
}

function updateLightbox() {
    document.getElementById('lightboxImage').src = `screenshots/${screenshots[currentIndex]}`;
    document.getElementById('imageCounter').textContent = `${currentIndex + 1} / ${screenshots.length}`;
}

function nextImage() {
    currentIndex = (currentIndex + 1) % screenshots.length;
    updateLightbox();
}

function prevImage() {
    currentIndex = (currentIndex - 1 + screenshots.length) % screenshots.length;
    updateLightbox();
}

// Закриття по клавіші Escape
document.addEventListener('keydown', function(e) {
    if (e.key === "Escape") {
        const modal = bootstrap.Modal.getInstance(document.getElementById('lightboxModal'));
        if (modal) modal.hide();
    }
    if (e.key === "ArrowRight") nextImage();
    if (e.key === "ArrowLeft") prevImage();
});
</script>

<?php include 'footer.php'; ?>