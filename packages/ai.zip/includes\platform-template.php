<?php
/** @var string $slug @var array $platform @var array $p @var string $canonical @var string $canon_abs */
require_once __DIR__ . '/platform-lib.php';

$hub_label = ai_platform_hub_label($lang);
$all_platforms = ai_integration_cards($lang);
$benefits_title = ['ua' => 'Переваги', 'ru' => 'Преимущества', 'en' => 'Benefits', 'no' => 'Fordeler', 'lt' => 'Privalumai', 'sv' => 'Fördelar'][$lang] ?? 'Benefits';
$features_title = ['ua' => 'Що входить у пакет', 'ru' => 'Что входит в пакет', 'en' => 'What\'s included', 'no' => 'Hva er inkludert', 'lt' => 'Kas įeina', 'sv' => 'Vad ingår'][$lang] ?? 'What\'s included';
$faq_title = ['ua' => 'Часті питання', 'ru' => 'Частые вопросы', 'en' => 'FAQ', 'no' => 'Ofte stilte spørsmål', 'lt' => 'DUK', 'sv' => 'Vanliga frågor'][$lang] ?? 'FAQ';
$related_title = ['ua' => 'Інші платформи', 'ru' => 'Другие платформы', 'en' => 'Other platforms', 'no' => 'Andre plattformer', 'lt' => 'Kitos platformos', 'sv' => 'Andra plattformar'][$lang] ?? 'Other platforms';
$breadcrumb_home = ['ua' => 'Головна', 'ru' => 'Главная', 'en' => 'Home', 'no' => 'Hjem', 'lt' => 'Pradžia', 'sv' => 'Hem'][$lang] ?? 'Home';
$region_note = ['ua' => 'Норвегія · Європа · Україна', 'ru' => 'Норвегия · Европа · Украина', 'en' => 'Norway · Europe · Ukraine', 'no' => 'Norge · Europa · Ukraina', 'lt' => 'Norvegija · Europa · Ukraina', 'sv' => 'Norge · Europa · Ukraina'][$lang] ?? 'Norway · Europe · Ukraine';
$icon = $platform['icon'] ?? 'fa-plug';
$color = $platform['color'] ?? '#00e5ff';

$seo_schemas = [
    [
        '@context' => 'https://schema.org',
        '@type' => 'WebPage',
        '@id' => $canon_abs . '#webpage',
        'name' => $page_title,
        'description' => $page_desc,
        'url' => $canon_abs,
        'inLanguage' => $lang_meta['html'],
        'isPartOf' => ['@type' => 'WebSite', 'name' => 'bilohash.com AI', 'url' => ai_absolute_url(ai_url('index.php'))],
    ],
    [
        '@context' => 'https://schema.org',
        '@type' => 'Service',
        '@id' => $canon_abs . '#service',
        'name' => $p['h1'] ?? $page_title,
        'description' => $page_desc,
        'url' => $canon_abs,
        'provider' => ['@type' => 'Organization', 'name' => 'bilohash.com', 'url' => 'https://bilohash.com/'],
        'areaServed' => ['NO', 'UA', 'EU'],
        'offers' => [
            '@type' => 'Offer',
            'url' => ai_absolute_url(ai_url('index.php') . '#contact'),
            'availability' => 'https://schema.org/InStock',
        ],
    ],
    [
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'bilohash.com', 'item' => 'https://bilohash.com/'],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'AI Platform', 'item' => ai_absolute_url(ai_url('index.php'))],
            ['@type' => 'ListItem', 'position' => 3, 'name' => $p['h1'] ?? $slug, 'item' => $canon_abs],
        ],
    ],
];
if (!empty($p['faq'])) {
    $entities = [];
    foreach ($p['faq'] as $item) {
        $entities[] = [
            '@type' => 'Question',
            'name' => $item['q'],
            'acceptedAnswer' => ['@type' => 'Answer', 'text' => $item['a']],
        ];
    }
    $seo_schemas[] = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $entities];
}

require __DIR__ . '/header.php';
?>

<section class="ai-platform-hero">
    <div class="ai-container">
        <nav class="ai-platform-crumb" aria-label="Breadcrumb">
            <a href="<?= ai_url('index.php') ?>"><?= htmlspecialchars($breadcrumb_home) ?></a>
            <span aria-hidden="true">→</span>
            <a href="<?= ai_url('index.php') ?>#integrations"><?= htmlspecialchars($hub_label) ?></a>
            <span aria-hidden="true">→</span>
            <span><?= htmlspecialchars($p['h1'] ?? $slug) ?></span>
        </nav>
        <div class="ai-platform-hero-inner">
            <div class="ai-platform-hero-icon" style="--platform-color: <?= htmlspecialchars($color) ?>">
                <i class="<?= htmlspecialchars(ai_fa_icon($icon)) ?>" aria-hidden="true"></i>
            </div>
            <div>
                <h1><?= htmlspecialchars($p['h1'] ?? $slug) ?></h1>
                <p class="ai-platform-subtitle"><?= htmlspecialchars($p['subtitle'] ?? '') ?></p>
                <p class="ai-platform-intro"><?= htmlspecialchars($p['intro'] ?? '') ?></p>
                <p class="ai-platform-region"><i class="fas fa-globe-europe" aria-hidden="true"></i> <?= htmlspecialchars($region_note) ?></p>
                <div class="ai-platform-cta-row">
                    <a href="<?= ai_url('index.php') ?>#contact" class="ai-btn-primary"><?= htmlspecialchars($t['hero']['cta_contact']) ?></a>
                    <a href="<?= ai_url('index.php') ?>#install" class="ai-btn-secondary"><?= htmlspecialchars($t['install']['title'] ?? $t['nav']['contact']) ?></a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($benefits_title) ?></h2>
        <div class="ai-platform-benefits">
            <?php foreach ($p['benefits'] ?? [] as $b): ?>
            <article class="ai-platform-benefit">
                <h3><?= htmlspecialchars($b['title']) ?></h3>
                <p><?= htmlspecialchars($b['text']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="ai-section ai-section--tight" style="background: rgba(255,255,255,.02);">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($features_title) ?></h2>
        <ul class="ai-platform-features">
            <?php foreach ($p['features'] ?? [] as $f): ?>
            <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($f) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<?php if (!empty($p['faq'])): ?>
<section class="ai-section ai-section--tight" id="faq">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($faq_title) ?></h2>
        <div class="ai-faq">
            <?php foreach ($p['faq'] as $item): ?>
            <div class="ai-faq-item">
                <button type="button" class="ai-faq-q">
                    <?= htmlspecialchars($item['q']) ?>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <div class="ai-faq-a"><?= htmlspecialchars($item['a']) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="ai-section ai-section--tight" id="integrations">
    <div class="ai-container">
        <h2 class="ai-section-title"><?= htmlspecialchars($related_title) ?></h2>
        <div class="ai-integrations-grid">
            <?php foreach ($all_platforms as $card):
                if ($card['slug'] === $slug) continue;
            ?>
            <a href="<?= htmlspecialchars($card['url']) ?>" class="ai-integration-card">
                <span class="ai-integration-card-icon" style="--platform-color: <?= htmlspecialchars($card['color']) ?>">
                    <i class="<?= htmlspecialchars(ai_fa_icon($card['icon'])) ?>" aria-hidden="true"></i>
                </span>
                <span class="ai-integration-card-name"><?= htmlspecialchars($card['name']) ?></span>
                <span class="ai-integration-card-desc"><?= htmlspecialchars($card['desc']) ?></span>
                <span class="ai-integration-card-arrow"><i class="fas fa-arrow-right"></i></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require __DIR__ . '/footer.php'; ?>