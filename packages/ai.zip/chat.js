/** @deprecated Use /assets/js/bh-chat-widget.js */
(function () {
    'use strict';
    if (window.__bhChatWidgetInit) return;
    if (!document.querySelector('link[href*="bh-chat-widget.css"]')) {
        var l = document.createElement('link');
        l.rel = 'stylesheet';
        l.href = '/assets/css/bh-chat-widget.css?v=1';
        document.head.appendChild(l);
    }
    window.BH_CHAT_CONFIG = Object.assign({
        apiUrl: '/ai/bot.php',
        historyUrl: '/ai/get-messages.php',
        sessionKey: 'grok_ai_consultant_session',
        requireConsent: false
    }, window.BH_CHAT_CONFIG || {});
    var s = document.createElement('script');
    s.src = '/assets/js/bh-chat-widget.js?v=1';
    s.defer = true;
    document.body.appendChild(s);
})();