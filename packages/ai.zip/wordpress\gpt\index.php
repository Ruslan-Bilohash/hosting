<?php
/**
 * Bilohash GPT Chat Assistant Pro - Головна сторінка оплати
 */

include 'header.php';
include 'description.php';
include 'download.php';
include 'wp.php';
include 'footer.php';
?>