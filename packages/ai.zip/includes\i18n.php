<?php
require_once __DIR__ . '/landing-config.php';

define('AI_LANG_COOKIE', 'ai_lang');

$AI_LANGS = [
    'ua' => ['label' => 'UA', 'name' => 'Українська', 'flag' => '🇺🇦', 'locale' => 'uk_UA', 'html' => 'uk', 'hreflang' => 'uk'],
    'ru' => ['label' => 'RU', 'name' => 'Русский', 'flag' => '🇷🇺', 'locale' => 'ru_RU', 'html' => 'ru', 'hreflang' => 'ru'],
    'en' => ['label' => 'EN', 'name' => 'English', 'flag' => '🇬🇧', 'locale' => 'en_GB', 'html' => 'en', 'hreflang' => 'en'],
    'lt' => ['label' => 'LT', 'name' => 'Lietuvių', 'flag' => '🇱🇹', 'locale' => 'lt_LT', 'html' => 'lt', 'hreflang' => 'lt'],
    'no' => ['label' => 'NO', 'name' => 'Norsk', 'flag' => '🇳🇴', 'locale' => 'nb_NO', 'html' => 'no', 'hreflang' => 'no'],
    'sv' => ['label' => 'SV', 'name' => 'Svenska', 'flag' => '🇸🇪', 'locale' => 'sv_SE', 'html' => 'sv', 'hreflang' => 'sv'],
];

function ai_langs(): array { global $AI_LANGS; return $AI_LANGS; }

function ai_detect_lang(): string
{
    global $ai_base_path, $AI_LANGS;
    $codes = array_keys($AI_LANGS);

    if (!empty($_GET['lang']) && in_array($_GET['lang'], $codes, true)) {
        $chosen = $_GET['lang'];
        setcookie(AI_LANG_COOKIE, $chosen, [
            'expires' => time() + 365 * 86400,
            'path'    => rtrim($ai_base_path, '/') . '/' ?: '/',
            'secure'  => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'samesite'=> 'Lax',
        ]);
        if ($chosen === 'ua') {
            $uri = $_SERVER['REQUEST_URI'] ?? '/';
            $parts = parse_url($uri);
            parse_str($parts['query'] ?? '', $q);
            unset($q['lang']);
            $clean = ($parts['path'] ?? '/') . ($q ? '?' . http_build_query($q) : '');
            if ($clean !== $uri) { header('Location: ' . $clean, true, 302); exit; }
        }
        return $chosen;
    }
    if (!empty($_COOKIE[AI_LANG_COOKIE]) && in_array($_COOKIE[AI_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[AI_LANG_COOKIE];
    }
    return 'ua';
}

$lang      = ai_detect_lang();
$lang_meta = $AI_LANGS[$lang] ?? $AI_LANGS['ua'];
$lang_file = __DIR__ . '/../lang/' . $lang . '.php';
if (!is_file($lang_file)) {
    $lang_file = __DIR__ . '/../lang/ua.php';
}
$t = require $lang_file;

require_once dirname(__DIR__, 2) . '/includes/ecosystem-i18n.php';
require_once __DIR__ . '/subscription.php';
$t = bh_apply_ecosystem_translations($t, $lang, 'ai');
$t = ai_apply_subscription_translations($t, $lang);