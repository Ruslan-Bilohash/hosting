<?php
/**
 * CRM AI Consultant — Performance profiler / debugger (v5.1)
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

class CrmPerf
{
    private static ?float $start = null;
    private static array $marks = [];
    private static bool $enabled = false;

    public static function enable(): void
    {
        self::$enabled = true;
        self::$start = microtime(true);
        self::$marks = [];
    }

    public static function mark(string $label): void
    {
        if (!self::$enabled) {
            return;
        }
        self::$marks[] = [
            'label' => $label,
            'time'  => microtime(true),
            'mem'   => memory_get_usage(true),
        ];
    }

    public static function report(): array
    {
        if (!self::$enabled || self::$start === null) {
            return [];
        }
        $end = microtime(true);
        $rows = [];
        $prev = self::$start;
        foreach (self::$marks as $m) {
            $rows[] = [
                'label'  => $m['label'],
                'ms'     => round(($m['time'] - $prev) * 1000, 2),
                'mem_kb' => round($m['mem'] / 1024, 1),
            ];
            $prev = $m['time'];
        }
        $rows[] = [
            'label'  => 'TOTAL',
            'ms'     => round(($end - self::$start) * 1000, 2),
            'mem_kb' => round(memory_get_peak_usage(true) / 1024, 1),
        ];
        return $rows;
    }

    public static function reset(): void
    {
        self::$enabled = false;
        self::$start = null;
        self::$marks = [];
    }
}

function crm_perf_benchmark(string $site_id, string $session = 'bench_test'): array
{
    require_once __DIR__ . '/storage.php';
    $tests = [];

    $run = function (string $name, callable $fn) use (&$tests) {
        $t0 = microtime(true);
        $fn();
        $tests[] = [
            'name' => $name,
            'ms'   => round((microtime(true) - $t0) * 1000, 2),
        ];
    };

    $run('Load site settings (JSON)', fn() => crm_storage_get_site($site_id));
    $run('Load secrets (JSON)', fn() => crm_storage_get_secrets($site_id));
    $run('Load full site + secrets', fn() => crm_storage_get_site($site_id, true));
    $run('Load prompt file', fn() => crm_storage_get_prompt($site_id));
    $run('Save test message', fn() => crm_storage_save_message($site_id, $session, 'benchmark ping', 'client'));
    $run('Read conversation', fn() => crm_storage_get_conversation($site_id, $session));
    $run('List all conversations', fn() => crm_storage_list_conversations());
    $run('List sites index', fn() => crm_storage_list_sites());

    $settings = crm_storage_get_site($site_id, true);
    if (!empty($settings['grok_api_key'])) {
        $run('Grok API ping (minimal)', function () use ($settings) {
            $ch = curl_init('https://api.x.ai/v1/chat/completions');
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $settings['grok_api_key'],
                ],
                CURLOPT_POSTFIELDS => json_encode([
                    'model' => crm_ai_resolve_channel_model('grok', $settings),
                    'messages' => [['role' => 'user', 'content' => 'ping']],
                    'max_tokens' => 5,
                ]),
            ]);
            curl_exec($ch);
            curl_close($ch);
        });
    }

    if (!empty($settings['openai_api_key'])) {
        $run('OpenAI API ping (minimal)', function () use ($settings) {
            $ch = curl_init('https://api.openai.com/v1/chat/completions');
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $settings['openai_api_key'],
                ],
                CURLOPT_POSTFIELDS => json_encode([
                    'model' => crm_ai_resolve_channel_model('openai', $settings),
                    'messages' => [['role' => 'user', 'content' => 'ping']],
                    'max_tokens' => 5,
                ]),
            ]);
            curl_exec($ch);
            curl_close($ch);
        });
    }

    return $tests;
}

function crm_perf_save_log(array $entry): void
{
    $path = CRM_DATA_DIR . '/debug-log.json';
    $log = crm_perf_read_log();
    array_unshift($log, $entry);
    $log = array_slice($log, 0, 50);
    crm_storage_write_json($path, $log);
}

function crm_perf_read_log(): array
{
    $path = CRM_DATA_DIR . '/debug-log.json';
    $log = crm_storage_read_json($path, []);
    return is_array($log) ? $log : [];
}

function crm_perf_speed_class(float $ms): string
{
    if ($ms < 5) {
        return 'text-emerald-400';
    }
    if ($ms < 50) {
        return 'text-sky-400';
    }
    if ($ms < 500) {
        return 'text-amber-400';
    }
    return 'text-red-400';
}