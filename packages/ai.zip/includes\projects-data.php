<?php
/** bilohash.com ecosystem — multilingual project cards for /ai/ */
function ai_ecosystem_projects(string $lang): array
{
    $pick = static function (array $row) use ($lang): array {
        return [
            'title' => $row[$lang] ?? $row['en'] ?? reset($row),
            'desc'  => ($row['desc'][$lang] ?? $row['desc']['en'] ?? ''),
        ];
    };

    $items = [
        [
            'icon' => 'house',
            'url'  => 'https://bilohash.com/contact.php',
            'badge'=> 'Hub',
            'title'=> ['ua'=>'bilohash.com — головний портал','en'=>'bilohash.com — main hub','ru'=>'bilohash.com — главный портал','no'=>'bilohash.com — hovedportal','sv'=>'bilohash.com — huvudportal','lt'=>'bilohash.com — pagrindinis portalas'],
            'desc' => ['ua'=>'Портфоліо, CMS-рішення, новини та контакти з Норвегії.','en'=>'Portfolio, CMS solutions, news and contacts from Norway.','ru'=>'Портфолио, CMS-решения, новости и контакты из Норвегии.','no'=>'Portefølje, CMS-løsninger, nyheter og kontakt fra Norge.','sv'=>'Portfolio, CMS-lösningar, nyheter och kontakt från Norge.','lt'=>'Portfolio, CMS sprendimai, naujienos ir kontaktai iš Norvegijos.'],
        ],
        [
            'icon' => 'gamepad',
            'url'  => 'https://bilohash.com/gamehub/',
            'badge'=> 'CMS',
            'title'=> ['ua'=>'GameHub CMS','en'=>'GameHub CMS','ru'=>'GameHub CMS','no'=>'GameHub CMS','sv'=>'GameHub CMS','lt'=>'GameHub CMS'],
            'desc' => ['ua'=>'PHP монітор ігрових серверів: CS2, превʼю карт, live-статистика, адмін, 4 мови.','en'=>'PHP game server monitor — CS2, map previews, live stats, admin, 4 languages.','ru'=>'PHP монитор игровых серверов: CS2, превью карт, live-статистика, админ, 4 языка.','no'=>'PHP spillserver-monitor — CS2, kart, live statistikk, admin, 4 språk.','sv'=>'PHP spelservermonitor — CS2, kartor, live statistik, admin, 4 språk.','lt'=>'PHP žaidimų serverių monitorius — CS2, žemėlapiai, live statistika, admin, 4 kalbos.'],
        ],
        [
            'icon' => 'gavel',
            'url'  => 'https://bilohash.com/auction/',
            'badge'=> 'CMS',
            'title'=> ['ua'=>'Auction CMS','en'=>'Auction CMS','ru'=>'Auction CMS','no'=>'Auction CMS','sv'=>'Auction CMS','lt'=>'Auction CMS'],
            'desc' => ['ua'=>'PHP онлайн-аукціон: лоти, ставки, адмін-панель, SEO.','en'=>'PHP online auction: lots, bids, admin panel, SEO.','ru'=>'PHP онлайн-аукцион: лоты, ставки, админ-панель, SEO.','no'=>'PHP nettauksjon: objekter, bud, adminpanel, SEO.','sv'=>'PHP onlineauktion: objekt, bud, adminpanel, SEO.','lt'=>'PHP internetinis aukcionas: lotai, statymai, admin, SEO.'],
        ],
        [
            'icon' => 'calendar-check',
            'url'  => 'https://bilohash.com/booking/',
            'badge'=> 'CMS',
            'title'=> ['ua'=>'Booking CMS','en'=>'Booking CMS','ru'=>'Booking CMS','no'=>'Booking CMS','sv'=>'Booking CMS','lt'=>'Booking CMS'],
            'desc' => ['ua'=>'Скрипт бронювання готелів/квартир з demo та адмінкою.','en'=>'Hotel/apartment booking script with demo and admin.','ru'=>'Скрипт бронирования с demo и админкой.','no'=>'Booking-skript for hotell/leilighet med demo og admin.','sv'=>'Bokningsskript för hotell/lägenhet med demo och admin.','lt'=>'Viešbučių/apartamentų booking skriptas su demo.'],
        ],
        [
            'icon' => 'briefcase',
            'url'  => 'https://bilohash.com/freelance/',
            'badge'=> 'CMS',
            'title'=> ['ua'=>'Freelance CMS','en'=>'Freelance CMS','ru'=>'Freelance CMS','no'=>'Freelance CMS','sv'=>'Freelance CMS','lt'=>'Freelance CMS'],
            'desc' => ['ua'=>'PHP фріланс-маркетплейс: проєкти, пропозиції, адмін, 4 мови.','en'=>'PHP freelance marketplace: projects, proposals, admin, 4 languages.','ru'=>'PHP фриланс-маркетплейс: проекты, предложения, админ, 4 языка.','no'=>'PHP frilans-markedsplass: prosjekter, tilbud, admin, 4 språk.','sv'=>'PHP frilansmarknadsplats: projekt, förslag, admin, 4 språk.','lt'=>'PHP freelance rinka: projektai, pasiūlymai, admin, 4 kalbos.'],
        ],
        [
            'icon' => 'shopping-bag',
            'url'  => 'https://bilohash.com/shop/',
            'badge'=> 'CMS',
            'title'=> ['ua'=>'Shop CMS','en'=>'Shop CMS','ru'=>'Shop CMS','no'=>'Shop CMS','sv'=>'Shop CMS','lt'=>'Shop CMS'],
            'desc' => ['ua'=>'PHP e-commerce: каталог, кошик, категорії, Product SEO, адмін, 4 мови.','en'=>'PHP e-commerce: catalog, cart, categories, Product SEO, admin, 4 languages.','ru'=>'PHP e-commerce: каталог, корзина, категории, Product SEO, админ, 4 языка.','no'=>'PHP e-handel: katalog, handlekurv, kategorier, Product SEO, admin, 4 språk.','sv'=>'PHP e-handel: katalog, varukorg, kategorier, Product SEO, admin, 4 språk.','lt'=>'PHP e-commerce: katalogas, krepšelis, kategorijos, Product SEO, admin, 4 kalbos.'],
        ],
        [
            'icon' => 'pizza-slice',
            'url'  => 'https://bilohash.com/pizza/',
            'badge'=> 'CMS',
            'title'=> ['ua'=>'Pizza CMS','en'=>'Pizza CMS','ru'=>'Pizza CMS','no'=>'Pizza CMS','sv'=>'Pizza CMS','lt'=>'Pizza CMS'],
            'desc' => ['ua'=>'PHP ресторан/піцерія: меню, бронювання столиків, тераса #solaskinner, адмін, 4 мови.','en'=>'PHP restaurant/pizzeria: menu, table reservations, #solaskinner terrace, admin, 4 languages.','ru'=>'PHP ресторан/пиццерия: меню, бронирование столиков, терраса #solaskinner, админ, 4 языка.','no'=>'PHP restaurant/pizzeria: meny, bordreservasjon, #solaskinner terrasse, admin, 4 språk.','sv'=>'PHP restaurang/pizzeria: meny, bordsbokning, #solaskinner terrass, admin, 4 språk.','lt'=>'PHP restoranas/picerija: meniu, staliukų rezervacija, #solaskinner terasa, admin, 4 kalbos.'],
        ],
        [
            'icon' => 'cube',
            'url'  => 'https://bilohash.com/3d/',
            'badge'=> '3D',
            'title'=> ['ua'=>'3D Maps & Tours','en'=>'3D Maps & Tours','ru'=>'3D Maps & Tours','no'=>'3D Maps & Tours','sv'=>'3D Maps & Tours','lt'=>'3D Maps & Tours'],
            'desc' => ['ua'=>'3D карти, віртуальні тури, інтерактивні рішення.','en'=>'3D maps, virtual tours, interactive solutions.','ru'=>'3D карты, виртуальные туры, интерактив.','no'=>'3D-kart, virtuelle turer, interaktive løsninger.','sv'=>'3D-kartor, virtuella turer, interaktiva lösningar.','lt'=>'3D žemėlapiai, virtualūs turai, interaktyvūs sprendimai.'],
        ],
        [
            'icon' => 'wordpress',
            'url'  => 'https://bilohash.com/ai/wordpress/',
            'badge'=> 'WP',
            'title'=> ['ua'=>'AI Consultant GROK — WordPress','en'=>'AI Consultant GROK — WordPress','ru'=>'AI Consultant GROK — WordPress','no'=>'AI Consultant GROK — WordPress','sv'=>'AI Consultant GROK — WordPress','lt'=>'AI Consultant GROK — WordPress'],
            'desc' => ['ua'=>'Плагін WordPress 2.8+ з Grok xAI та Telegram.','en'=>'WordPress plugin 2.8+ with Grok xAI and Telegram.','ru'=>'Плагин WordPress 2.8+ с Grok xAI и Telegram.','no'=>'WordPress-plugin 2.8+ med Grok xAI og Telegram.','sv'=>'WordPress-plugin 2.8+ med Grok xAI och Telegram.','lt'=>'WordPress papildinys 2.8+ su Grok xAI ir Telegram.'],
        ],
        [
            'icon' => 'database',
            'url'  => 'https://bilohash.com/ai/crm/',
            'badge'=> 'CRM',
            'title'=> ['ua'=>'CRM AI Consultant 4.0','en'=>'CRM AI Consultant 4.0','ru'=>'CRM AI Consultant 4.0','no'=>'CRM AI Consultant 4.0','sv'=>'CRM AI Consultant 4.0','lt'=>'CRM AI Consultant 4.0'],
            'desc' => ['ua'=>'PHP+MySQL: Grok, OpenAI, Telegram, WhatsApp, Viber.','en'=>'PHP+MySQL: Grok, OpenAI, Telegram, WhatsApp, Viber.','ru'=>'PHP+MySQL: Grok, OpenAI, Telegram, WhatsApp, Viber.','no'=>'PHP+MySQL: Grok, OpenAI, Telegram, WhatsApp, Viber.','sv'=>'PHP+MySQL: Grok, OpenAI, Telegram, WhatsApp, Viber.','lt'=>'PHP+MySQL: Grok, OpenAI, Telegram, WhatsApp, Viber.'],
        ],
        [
            'icon' => 'robot',
            'url'  => 'https://bilohash.com/bot/',
            'badge'=> 'Bot',
            'title'=> ['ua'=>'AI Bot Demo','en'=>'AI Bot Demo','ru'=>'AI Bot Demo','no'=>'AI Bot Demo','sv'=>'AI Bot Demo','lt'=>'AI Bot Demo'],
            'desc' => ['ua'=>'Легкий AI-бот для сайту та тестування сценаріїв.','en'=>'Lightweight AI bot for website and scenario testing.','ru'=>'Лёгкий AI-бот для сайта и тестирования.','no'=>'Lett AI-bot for nettsted og testing.','sv'=>'Lätt AI-bot för webbplats och testning.','lt'=>'Lengvas AI botas svetainei ir testavimui.'],
        ],
        [
            'icon' => 'newspaper',
            'url'  => 'https://bilohash.com/today/',
            'badge'=> 'NEW',
            'title'=> ['ua'=>'Today CMS','en'=>'Today CMS','ru'=>'Today CMS','no'=>'Today CMS','sv'=>'Today CMS','lt'=>'Today CMS'],
            'desc' => ['ua'=>'PHP новинний сайт: журналісти, редактори, 4 мови, газетний дизайн.','en'=>'PHP news site: journalists, editors, 4 languages, newspaper design.','ru'=>'PHP новостной сайт: журналисты, редакторы, 4 языка, газетный дизайн.','no'=>'PHP-nyhetsside: journalister, redaktører, 4 språk, avisdesign.','sv'=>'PHP-nyhetssida: journalister, redaktörer, 4 språk, tidningsdesign.','lt'=>'PHP naujienų svetainė: žurnalistai, redaktoriai, 4 kalbos, laikraščio dizainas.'],
        ],
        [
            'icon' => 'newspaper',
            'url'  => 'https://bilohash.com/news/',
            'badge'=> 'News',
            'title'=> ['ua'=>'Новини & кейси','en'=>'News & case studies','ru'=>'Новости и кейсы','no'=>'Nyheter og caser','sv'=>'Nyheter och case','lt'=>'Naujienos ir atvejai'],
            'desc' => ['ua'=>'Оновлення продуктів, SEO-статті, релізи CMS та AI.','en'=>'Product updates, SEO articles, CMS and AI releases.','ru'=>'Обновления продуктов, SEO-статьи, релизы CMS и AI.','no'=>'Produktoppdateringer, SEO-artikler, CMS- og AI-lanseringer.','sv'=>'Produktuppdateringar, SEO-artiklar, CMS- och AI-lanseringar.','lt'=>'Produktų naujienos, SEO straipsniai, CMS ir AI.'],
        ],
    ];

    return array_map(static function ($item) use ($pick, $lang) {
        $t = $pick($item);
        return [
            'icon'  => $item['icon'],
            'url'   => $item['url'],
            'badge' => $item['badge'],
            'title' => $t['title'],
            'desc'  => $t['desc'],
        ];
    }, $items);
}