<?php
/**
 * CRM AI Consultant — Configuration (MySQL: admins only; sites/data → JSON)
 * Version: 5.1
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

if (file_exists(__DIR__ . '/config.local.php')) {
    require_once __DIR__ . '/config.local.php';
}

define('CRM_AI_DEBUG', defined('CRM_AI_DEBUG') ? CRM_AI_DEBUG : false);
define('CRM_AI_VERSION', '5.1');
define('BASE_URL', 'https://bilohash.com/ai/crm/');

if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'u762384583_bilohash_aicrm');
if (!defined('DB_PASS')) define('DB_PASS', 'Odifar78@');
if (!defined('DB_NAME')) define('DB_NAME', 'u762384583_bilohash_aicrm');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4',
        ]
    );
} catch (PDOException $e) {
    error_log('CRM AI DB error: ' . $e->getMessage());
    die('Database connection error. Please contact the administrator.');
}

if (!CRM_AI_DEBUG) {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
}
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/crm-ai-error.log');