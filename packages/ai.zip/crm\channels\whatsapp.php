<?php
/**
 * CRM AI Consultant — Канал WhatsApp
 * Version: 4.0 — Повністю адаптовано під MySQL
 * 
 * Бот пропонує користувачу писати безпосередньо в WhatsApp через пряме посилання
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

/**
 * Обробка повідомлення через WhatsApp
 * 
 * @param string $site_id       ID сайту
 * @param string $session       ID сесії користувача
 * @param string $user_message  Повідомлення від користувача
 * @return array                ['success' => bool, 'message' => string]
 */
function crm_ai_send_to_whatsapp($site_id, $session, $user_message) {
    
    // 1. Отримуємо налаштування сайту з бази даних MySQL
    $settings = crm_ai_get_site_settings($site_id);

    if (!$settings) {
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    // 2. Витягуємо номер WhatsApp
    $secrets = crm_ai_get_secrets($site_id);
    $whatsapp_number = trim($secrets['whatsapp_number'] ?? '');
    $welcome_text    = trim($settings['whatsapp_welcome_text'] ?? '');

    // 3. Зберігаємо повідомлення користувача в базу
    crm_ai_save_message($site_id, $session, $user_message, 'client');

    if (!empty($whatsapp_number)) {
        // Очищаємо номер від зайвих символів
        $clean_number = preg_replace('/[^0-9]/', '', $whatsapp_number);
        
        // Створюємо пряме посилання на чат у WhatsApp
        $whatsapp_link = "https://wa.me/" . $clean_number;

        $reply = ($welcome_text ?: "Я отримав ваше повідомлення!") . "\n\n"
               . "Найшвидше я відповідаю в **WhatsApp**.\n\n"
               . "👉 [Написати мені в WhatsApp](" . $whatsapp_link . ")";

        // Зберігаємо відповідь бота
        crm_ai_save_message($site_id, $session, $reply, 'bot');

        return [
            'success' => true,
            'message' => $reply
        ];
    } 
    else {
        // Якщо номер WhatsApp не налаштований
        $reply = "WhatsApp канал ще налаштовується.\n\n"
               . "Напишіть мені в **Telegram** — я відповім швидко.";

        crm_ai_save_message($site_id, $session, $reply, 'bot');

        return [
            'success' => true,
            'message' => $reply
        ];
    }
}
?>