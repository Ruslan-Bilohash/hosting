/**
 * CRM AI Consultant Chat Widget
 * Version: 5.0 — Responsive mobile/tablet + XSS-safe messages
 */

(function () {
    'use strict';

    const s = window.crmAI;
    if (!s || !s.site_id) {
        console.error('CRM AI: crmAI not initialized');
        return;
    }

    const SESSION_KEY = 'crm_ai_session_' + s.site_id;
    let session = localStorage.getItem(SESSION_KEY) || ('s_' + Date.now() + '_' + Math.random().toString(36).substr(2, 12));
    localStorage.setItem(SESSION_KEY, session);

    function isMobileView() {
        return window.innerWidth < 640;
    }
    function isTabletView() {
        return window.innerWidth >= 640 && window.innerWidth < 1024;
    }
    function chatDimensions() {
        if (isMobileView()) return { width: '100vw', height: '100vh', bottom: '0', side: '0', radius: '0', btnBottom: '20px' };
        if (isTabletView()) return { width: '380px', height: '560px', bottom: '20px', side: '20px', radius: '24px', btnBottom: '25px' };
        return { width: '420px', height: '620px', bottom: '20px', side: '20px', radius: '24px', btnBottom: '25px' };
    }
    let dims = chatDimensions();

    // Кнопка відкриття
    const openBtn = document.createElement('button');
    openBtn.id = 'crm-ai-widget-open';
    openBtn.setAttribute('aria-label', 'Open AI chat');
    openBtn.style.cssText = `
        position: fixed; 
        bottom: ${dims.btnBottom}; 
        ${s.position === 'left' ? 'left: 20px' : 'right: 20px'};
        width: 68px; height: 68px; 
        background: ${s.widget_color}; 
        color: #fff; 
        border: none; 
        border-radius: 50%; 
        font-size: 34px; 
        cursor: pointer; 
        z-index: 99999; 
        box-shadow: 0 10px 40px rgba(0,0,0,0.5);
        transition: all 0.3s ease;
    `;
    openBtn.innerHTML = s.bot_icon || '🤖';
    document.body.appendChild(openBtn);

    // Вікно чату
    const chat = document.createElement('div');
    chat.style.cssText = `
        position: fixed; 
        bottom: ${dims.bottom}; 
        ${s.position === 'left' ? 'left: ' + dims.side : 'right: ' + dims.side};
        width: ${dims.width}; 
        height: ${dims.height}; 
        max-height: ${isMobileView() ? '100vh' : '85vh'};
        background: ${s.chat_bg_color || '#0f172a'}; 
        border-radius: ${dims.radius};
        box-shadow: 0 25px 70px rgba(0,0,0,0.65);
        display: none; 
        flex-direction: column; 
        z-index: 99999; 
        overflow: hidden;
        border: 1px solid rgba(148,163,184,0.3);
    `;

    chat.innerHTML = `
        <!-- Header -->
        <div style="background:${s.header_bg_color || '#1e2937'}; padding:18px 20px; color:#fff; display:flex; align-items:center; justify-content:space-between;">
            <div style="display:flex; align-items:center; gap:12px;">
                <div style="font-size:32px;">${s.bot_icon || '🤖'}</div>
                <div>
                    <div style="font-weight:700; font-size:18px;">${s.chat_title || 'AI Consultant'}</div>
                    <div style="font-size:13px; opacity:0.9;">${s.chat_subtitle || 'Швидка допомога'}</div>
                </div>
            </div>
            <button id="closeBtn" style="background:none; border:none; color:#fff; font-size:28px; cursor:pointer; opacity:0.8;">×</button>
        </div>
        
        <!-- Повідомлення -->
        <div id="messages" style="flex:1; padding:20px; overflow-y:auto; background:${s.chat_bg_color || '#0f172a'};"></div>
        
        <!-- Поле вводу -->
        <div style="padding:15px 20px; background:rgba(15,23,42,0.98); display:flex; gap:10px;">
            <input id="inputField" type="text" placeholder="Напишіть повідомлення..." 
                   style="flex:1; padding:14px 18px; background:rgba(255,255,255,0.1); border:1px solid rgba(148,163,184,0.4); border-radius:9999px; color:#fff; outline:none;">
            <button id="sendBtn" style="width:56px; height:56px; background:${s.widget_color}; border:none; border-radius:9999px; color:#000; font-size:24px;">→</button>
        </div>

        <!-- Футер з гарним посиланням -->
<div style="padding:10px 20px; text-align:center; font-size:11px; color:#64748b; background:rgba(0,0,0,0.45); border-top:1px solid rgba(148,163,184,0.2);">
    Powered by 
    <a href="https://bilohash.com/" 
       target="_blank" 
       rel="noopener"
       style="color:#67e8f9; font-weight:600; text-decoration:none; transition:all 0.25s ease;">
        CRM AI Consultant
    </a>
</div>
    `;

    document.body.appendChild(chat);

    const messagesDiv = document.getElementById('messages');
    const inputField = document.getElementById('inputField');

    function addMessage(text, isUser) {
        const div = document.createElement('div');
        div.style.cssText = isUser 
            ? `margin-left:auto; background:${s.user_bubble_color || '#22d3ee'}; color:#000; padding:13px 19px; border-radius:20px 20px 4px 20px; max-width:82%; margin-bottom:12px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);`
            : `margin-right:auto; background:${s.bot_bubble_color || '#334155'}; color:#fff; padding:13px 19px; border-radius:20px 20px 20px 4px; max-width:82%; margin-bottom:12px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);`;
        const safe = document.createElement('span');
        safe.textContent = text;
        div.appendChild(safe);
        div.style.whiteSpace = 'pre-wrap';
        messagesDiv.appendChild(div);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    let firstOpen = true;

    function openChat() {
        chat.style.display = 'flex';
        openBtn.style.display = 'none';
        if (firstOpen && s.welcome_text) {
            setTimeout(() => addMessage(s.welcome_text, false), 500);
            firstOpen = false;
        }
    }

    // Авто-відкриття
    if (s.auto_open) {
        setTimeout(openChat, s.auto_open_delay || 7000);
    }

    // Події
    openBtn.onclick = openChat;
    document.getElementById('closeBtn').onclick = () => {
        chat.style.display = 'none';
        openBtn.style.display = 'block';
    };

    document.getElementById('sendBtn').onclick = sendMessage;
    inputField.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });

    async function sendMessage() {
        const text = inputField.value.trim();
        if (!text) return;

        addMessage(text, true);
        inputField.value = '';

        const fd = new FormData();
        fd.append('action', 'crm_ai_send');
        fd.append('session', session);
        fd.append('message', text);
        fd.append('site_id', s.site_id);

        try {
            const res = await fetch(s.ajax_url, { method: 'POST', body: fd });
            const result = await res.json();
            if (result.success) {
                addMessage(result.message || 'Повідомлення надіслано', false);
            } else {
                addMessage('❌ ' + (result.message || 'Помилка'), false);
            }
        } catch (e) {
            addMessage('❌ Помилка зв’язку', false);
        }
    }

    window.addEventListener('resize', () => {
        dims = chatDimensions();
        chat.style.width = dims.width;
        chat.style.height = dims.height;
        chat.style.maxHeight = isMobileView() ? '100vh' : '85vh';
        chat.style.borderRadius = dims.radius;
        chat.style.bottom = dims.bottom;
        if (s.position === 'left') {
            chat.style.left = dims.side;
            chat.style.right = 'auto';
        } else {
            chat.style.right = dims.side;
            chat.style.left = 'auto';
        }
    });

})();