<?php
/**
 * Grok (xAI) — Version 4.1
 * Промпт з файлу + швидкий cURL
 */

if (!defined('CRM_AI_CONSULTANT')) die('Access denied');

function crm_ai_send_to_grok($site_id, $session, $user_message) {
    
    $settings = crm_ai_get_site_settings($site_id);
    $secrets  = crm_ai_get_secrets($site_id);
    $api_key  = trim($secrets['grok_api_key'] ?? '');

    if (empty($api_key)) {
        crm_ai_save_message($site_id, $session, $user_message, 'client');
        $error_msg = "❌ Grok API ключ не налаштовано.";
        crm_ai_save_message($site_id, $session, $error_msg, 'bot');
        return ['success' => false, 'message' => $error_msg];
    }

    $system_prompt = crm_ai_get_prompt($site_id);
    if (empty($system_prompt)) {
        $system_prompt = "Ти — дружній та професійний AI-консультант.";
    }

    $model = crm_ai_resolve_channel_model('grok', $settings);

    $payload = [
        "model" => $model,
        "messages" => [
            ["role" => "system", "content" => $system_prompt],
            ["role" => "user",   "content" => $user_message]
        ],
        "max_tokens"  => 1800
    ];

    if (crm_ai_model_supports_temperature('grok', $model)) {
        $payload["temperature"] = (float)($settings['grok_temperature'] ?? 0.7);
    }

    $ch = curl_init("https://api.x.ai/v1/chat/completions");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer " . $api_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

    $response_body = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code === 200) {
        $data = json_decode($response_body, true);
        $reply = $data['choices'][0]['message']['content'] ?? "Вибач, я не зміг сформувати відповідь.";
    } else {
        $reply = "❌ Помилка Grok API (код $http_code)";
    }

    crm_ai_save_message($site_id, $session, $user_message, 'client');
    crm_ai_save_message($site_id, $session, $reply, 'bot');

    return [
        'success' => ($http_code === 200),
        'message' => $reply
    ];
}
?>