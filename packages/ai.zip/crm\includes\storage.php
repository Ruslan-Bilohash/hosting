<?php
/**
 * CRM AI Consultant — JSON file storage (v5.1)
 * MySQL: admins only. Sites, secrets, conversations → JSON files.
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

define('CRM_DATA_DIR', dirname(__DIR__) . '/data');
define('CRM_SITES_DIR', CRM_DATA_DIR . '/sites');
define('CRM_SECRETS_DIR', CRM_DATA_DIR . '/secrets');
define('CRM_CONV_DIR', CRM_DATA_DIR . '/conversations');
define('CRM_PROMPTS_DIR', CRM_DATA_DIR . '/prompts');
define('CRM_SITES_INDEX', CRM_DATA_DIR . '/sites-index.json');

function crm_storage_init(): void
{
    foreach ([CRM_DATA_DIR, CRM_SITES_DIR, CRM_SECRETS_DIR, CRM_CONV_DIR, CRM_PROMPTS_DIR] as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
        }
    }
    if (!file_exists(CRM_SITES_INDEX)) {
        crm_storage_write_json(CRM_SITES_INDEX, []);
    }
}

function crm_storage_safe_id(string $site_id): string
{
    return preg_replace('/[^a-zA-Z0-9_-]/', '', $site_id);
}

function crm_storage_write_json(string $path, $data): bool
{
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        return false;
    }
    $tmp = $path . '.tmp.' . getmypid();
    if (file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    @chmod($tmp, 0600);
    return rename($tmp, $path);
}

function crm_storage_read_json(string $path, $default = null)
{
    if (!is_file($path)) {
        return $default;
    }
    $raw = file_get_contents($path);
    if ($raw === false || $raw === '') {
        return $default;
    }
    $data = json_decode($raw, true);
    return is_array($data) || is_null($data) ? $data : $default;
}

function crm_storage_site_path(string $site_id): string
{
    return CRM_SITES_DIR . '/' . crm_storage_safe_id($site_id) . '.json';
}

function crm_storage_secrets_path(string $site_id): string
{
    return CRM_SECRETS_DIR . '/' . crm_storage_safe_id($site_id) . '.json';
}

function crm_storage_conv_dir(string $site_id): string
{
    return CRM_CONV_DIR . '/' . crm_storage_safe_id($site_id);
}

function crm_storage_conv_path(string $site_id, string $session): string
{
    $safe = preg_replace('/[^a-zA-Z0-9_-]/', '', $session);
    return crm_storage_conv_dir($site_id) . '/' . $safe . '.json';
}

function crm_storage_conv_index_path(string $site_id): string
{
    return crm_storage_conv_dir($site_id) . '/_index.json';
}

function crm_storage_prompt_path(string $site_id): string
{
    return CRM_PROMPTS_DIR . '/' . crm_storage_safe_id($site_id) . '.txt';
}

function crm_storage_list_site_ids(): array
{
    crm_storage_init();
    $ids = crm_storage_read_json(CRM_SITES_INDEX, []);
    return is_array($ids) ? $ids : [];
}

function crm_storage_register_site(string $site_id): void
{
    $ids = crm_storage_list_site_ids();
    if (!in_array($site_id, $ids, true)) {
        $ids[] = $site_id;
        crm_storage_write_json(CRM_SITES_INDEX, array_values($ids));
    }
}

function crm_storage_get_site(string $site_id, bool $with_secrets = false): ?array
{
    crm_storage_init();
    $site_id = crm_storage_safe_id($site_id);
    if ($site_id === '') {
        return null;
    }

    static $mem = [];
    $key = $site_id . ($with_secrets ? ':full' : ':pub');
    if (isset($mem[$key])) {
        return $mem[$key];
    }

    $settings = crm_storage_read_json(crm_storage_site_path($site_id));
    if (!$settings) {
        return null;
    }

    if ($with_secrets) {
        $secrets = crm_storage_read_json(crm_storage_secrets_path($site_id), []);
        if (is_array($secrets)) {
            $settings = array_merge($settings, $secrets);
        }
    }

    $mem[$key] = $settings;
    return $settings;
}

function crm_storage_get_secrets(string $site_id): array
{
    crm_storage_init();
    $site_id = crm_storage_safe_id($site_id);
    static $cache = [];
    if (isset($cache[$site_id])) {
        return $cache[$site_id];
    }
    $secrets = crm_storage_read_json(crm_storage_secrets_path($site_id), []);
    $cache[$site_id] = is_array($secrets) ? $secrets : [];
    return $cache[$site_id];
}

function crm_storage_save_site(string $site_id, array $data): bool
{
    crm_storage_init();
    $site_id = crm_storage_safe_id($site_id);
    if ($site_id === '') {
        return false;
    }

    $secret_keys = [
        'telegram_token', 'telegram_chat_id', 'grok_api_key', 'openai_api_key',
        'whatsapp_number', 'viber_number',
    ];
    $secrets = [];
    $public = $data;
    $public['id'] = $site_id;
    $public['updated_at'] = date('Y-m-d H:i:s');

    foreach ($secret_keys as $k) {
        if (array_key_exists($k, $public)) {
            $secrets[$k] = $public[$k];
            unset($public[$k]);
        }
    }

    $prompt = $public['system_prompt'] ?? $public['bot_system_prompt'] ?? '';
    file_put_contents(crm_storage_prompt_path($site_id), $prompt, LOCK_EX);

    crm_storage_register_site($site_id);
    crm_storage_write_json(crm_storage_secrets_path($site_id), $secrets);
    return crm_storage_write_json(crm_storage_site_path($site_id), $public);
}

function crm_storage_delete_site(string $site_id): void
{
    crm_storage_init();
    $site_id = crm_storage_safe_id($site_id);

    @unlink(crm_storage_site_path($site_id));
    @unlink(crm_storage_secrets_path($site_id));
    @unlink(crm_storage_prompt_path($site_id));

    $conv_dir = crm_storage_conv_dir($site_id);
    if (is_dir($conv_dir)) {
        foreach (glob($conv_dir . '/*') ?: [] as $f) {
            @unlink($f);
        }
        @rmdir($conv_dir);
    }

    $ids = array_values(array_filter(crm_storage_list_site_ids(), fn($id) => $id !== $site_id));
    crm_storage_write_json(CRM_SITES_INDEX, $ids);

    @unlink(__DIR__ . "/../sites/cache/{$site_id}_cache.json");
    @unlink(__DIR__ . "/../sites/{$site_id}_prompt.txt");
}

function crm_storage_update_site(string $site_id, array $patch): bool
{
    $site = crm_storage_get_site($site_id, true);
    if (!$site) {
        return false;
    }
    return crm_storage_save_site($site_id, array_merge($site, $patch));
}

function crm_storage_list_sites(): array
{
    $sites = [];
    foreach (crm_storage_list_site_ids() as $id) {
        $s = crm_storage_get_site($id);
        if ($s) {
            $sites[] = $s;
        }
    }
    usort($sites, fn($a, $b) => strcmp($a['name'] ?? '', $b['name'] ?? ''));
    return $sites;
}

function crm_storage_save_message(string $site_id, string $session, string $content, string $sender = 'bot'): bool
{
    crm_storage_init();
    $site_id = crm_storage_safe_id($site_id);
    $session = preg_replace('/[^a-zA-Z0-9_-]/', '', $session);
    if ($site_id === '' || $session === '') {
        return false;
    }

    $dir = crm_storage_conv_dir($site_id);
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }

    $entry = [
        'message'    => $content,
        'sender'     => $sender,
        'created_at' => date('Y-m-d H:i:s'),
    ];

    $path = crm_storage_conv_path($site_id, $session);
    $messages = crm_storage_read_json($path, []);
    if (!is_array($messages)) {
        $messages = [];
    }
    $messages[] = $entry;
    crm_storage_write_json($path, $messages);

    $index_path = crm_storage_conv_index_path($site_id);
    $index = crm_storage_read_json($index_path, ['sessions' => []]);
    if (!isset($index['sessions']) || !is_array($index['sessions'])) {
        $index['sessions'] = [];
    }
    $index['sessions'][$session] = [
        'message_count' => count($messages),
        'last_time'     => $entry['created_at'],
        'last_message'  => mb_substr($content, 0, 200),
    ];
    crm_storage_write_json($index_path, $index);

    return true;
}

function crm_storage_get_conversation(string $site_id, string $session, int $limit = 0): array
{
    crm_storage_init();
    $path = crm_storage_conv_path($site_id, $session);
    $messages = crm_storage_read_json($path, []);
    if (!is_array($messages)) {
        return [];
    }
    if ($limit > 0 && count($messages) > $limit) {
        return array_slice($messages, -$limit);
    }
    return $messages;
}

function crm_storage_list_conversations(?string $filter_site = null): array
{
    crm_storage_init();
    $result = [];
    $site_ids = $filter_site
        ? [crm_storage_safe_id($filter_site)]
        : crm_storage_list_site_ids();

    foreach ($site_ids as $site_id) {
        if ($site_id === '') {
            continue;
        }
        $site = crm_storage_get_site($site_id);
        $index = crm_storage_read_json(crm_storage_conv_index_path($site_id), ['sessions' => []]);
        $sessions = $index['sessions'] ?? [];
        if (!is_array($sessions)) {
            continue;
        }
        foreach ($sessions as $session_id => $meta) {
            $result[] = [
                'site_id'       => $site_id,
                'site_name'     => $site['name'] ?? $site_id,
                'session_id'    => $session_id,
                'message_count' => (int)($meta['message_count'] ?? 0),
                'last_time'     => $meta['last_time'] ?? '',
                'last_message'  => $meta['last_message'] ?? '',
            ];
        }
    }

    usort($result, fn($a, $b) => strcmp($b['last_time'], $a['last_time']));
    return $result;
}

function crm_storage_get_prompt(string $site_id): string
{
    crm_storage_init();
    $path = crm_storage_prompt_path($site_id);
    if (is_file($path)) {
        return trim((string)file_get_contents($path));
    }
    $legacy = __DIR__ . "/../sites/{$site_id}_prompt.txt";
    return is_file($legacy) ? trim((string)file_get_contents($legacy)) : '';
}

function crm_storage_stats(): array
{
    crm_storage_init();
    $sites = count(crm_storage_list_site_ids());
    $conv_files = 0;
    $total_bytes = 0;
    foreach (glob(CRM_CONV_DIR . '/*/*.json') ?: [] as $f) {
        if (basename($f) === '_index.json') {
            continue;
        }
        $conv_files++;
        $total_bytes += (int)filesize($f);
    }
    return [
        'sites'            => $sites,
        'conversation_files' => $conv_files,
        'data_size_kb'     => round($total_bytes / 1024, 1),
    ];
}