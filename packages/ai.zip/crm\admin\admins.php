<?php
/**
 * CRM AI Consultant — Управління адміністратором (простий варіант)
 * Version: 4.5 — Показ імені + зміна пароля
 */

require_once __DIR__ . '/includes/bootstrap.php';
crm_ai_require_login();

if (crm_ai_is_demo()) {
    header('Location: index.php?demo_readonly=1');
    exit;
}

$message = '';
$error = '';

// ====================== ЗМІНА ПАРОЛЯ ======================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    crm_ai_require_write_access();
    if (!crm_ai_verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = $ta['common']['csrf_error'];
    } else {
    $current_password = $_POST['current_password'] ?? '';
    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($new_password) || $new_password !== $confirm_password) {
        $error = $ta['admins']['password_mismatch'];
    } elseif (strlen($new_password) < 6) {
        $error = $ta['admins']['password_min_length'];
    } else {
        $stmt = $pdo->prepare("SELECT password_hash FROM admins WHERE id = ? LIMIT 1");
        $stmt->execute([$_SESSION['crm_ai_admin_id']]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($current_password, $admin['password_hash'])) {
            
            $new_hash = password_hash($new_password, PASSWORD_ARGON2ID);

            $update = $pdo->prepare("UPDATE admins SET password_hash = ? WHERE id = ?");
            $update->execute([$new_hash, $_SESSION['crm_ai_admin_id']]);

            $message = $ta['admins']['password_changed'];
        } else {
            $error = $ta['admins']['current_password_wrong'];
        }
    }
    }
}
?>

<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ta['admins']['title']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <?php require_once __DIR__ . '/includes/theme.php'; crm_admin_theme_head(); ?>
</head>
<body class="bg-zinc-950 text-zinc-100">

<?php include 'navigation.php'; ?>

<div class="max-w-3xl mx-auto px-6 py-12">

    <h1 class="text-4xl font-bold mb-2"><?= htmlspecialchars($ta['admins']['heading']) ?></h1>
    
    <div class="bg-zinc-900 rounded-3xl p-10 mt-8">
        
        <div class="flex items-center gap-4 mb-10">
            <div class="w-16 h-16 bg-gradient-to-br from-sky-500 to-blue-600 rounded-2xl flex items-center justify-center text-5xl">
                👤
            </div>
            <div>
                <p class="text-zinc-400 text-sm"><?= htmlspecialchars($ta['admins']['logged_in_as']) ?></p>
                <p class="text-3xl font-semibold text-white">
                    <?= htmlspecialchars($_SESSION['crm_ai_admin_username'] ?? 'admin') ?>
                </p>
                <p class="text-emerald-400 text-lg">
                    <?= htmlspecialchars($_SESSION['crm_ai_admin_full_name'] ?? 'Ruslan Bilohash') ?>
                </p>
            </div>
        </div>

        <h2 class="text-2xl font-semibold mb-6 flex items-center gap-3">
            <i class="fas fa-key text-amber-400"></i>
            <?= htmlspecialchars($ta['admins']['change_password']) ?>
        </h2>

        <?php if ($message): ?>
            <div class="bg-emerald-900 border border-emerald-700 p-5 rounded-2xl mb-8">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="bg-red-900 border border-red-700 p-5 rounded-2xl mb-8">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <?= crm_ai_csrf_field() ?>
            <input type="hidden" name="change_password" value="1">

            <div>
                <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['admins']['current_password']) ?></label>
                <input type="password" name="current_password" required 
                       class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-5">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['admins']['new_password']) ?></label>
                    <input type="password" name="new_password" required 
                           class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-5">
                </div>
                <div>
                    <label class="block text-sm text-zinc-400 mb-2"><?= htmlspecialchars($ta['admins']['confirm_password']) ?></label>
                    <input type="password" name="confirm_password" required 
                           class="w-full bg-zinc-800 border border-zinc-700 rounded-3xl px-6 py-5">
                </div>
            </div>

            <button type="submit" 
                    class="w-full py-6 bg-amber-600 hover:bg-amber-500 rounded-3xl font-bold text-lg">
                <?= htmlspecialchars($ta['admins']['change_password_btn']) ?>
            </button>
        </form>
    </div>

</div>

<?php include 'footer.php'; ?>

</body>
</html>