<?php
/**
 * CRM AI Consultant — Admin bootstrap
 * Version: 5.1
 */

if (!defined('CRM_AI_CONSULTANT')) {
    define('CRM_AI_CONSULTANT', true);
}

require_once dirname(__DIR__, 2) . '/config.php';
require_once dirname(__DIR__, 2) . '/includes/functions.php';
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_once dirname(__DIR__, 2) . '/includes/security.php';

crm_ai_send_security_headers();

if (!CRM_AI_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
}
ini_set('log_errors', '1');
ini_set('error_log', dirname(__DIR__, 2) . '/crm-ai-error.log');

crm_ai_session_start();

if (isset($_GET['logout'])) {
    crm_ai_logout_redirect();
}

require_once __DIR__ . '/i18n.php';