<?php
$langCode = $CRM_LANDING_LANG ?? 'uk';
$all = require __DIR__ . '/landing-i18n.php';
$L = $all[$langCode] ?? $all['uk'];
if (!empty($CRM_LANDING_FILE)) {
    $L['file'] = $CRM_LANDING_FILE;
    $L['canonical'] = 'https://bilohash.com/ai/crm/' . $CRM_LANDING_FILE;
}
function crm_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function crm_allow_br($s) {
    $s = str_replace(['<br>', '<br/>', '<br />'], '[[BR]]', (string)$s);
    $s = htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    return str_replace('[[BR]]', '<br>', $s);
}
function crm_allow_strong($s) {
    return strip_tags((string)$s, '<strong>');
}
$screenImgs = ['screen/admin_password.jpg','screen/site_wigets_color.jpg','screen/model_settings.jpg','screen/history.jpg','screen/wigets.jpg','screen/admin_site.jpg'];
$channelIcons = ['fab fa-telegram text-blue-400','fas fa-robot text-orange-400','fas fa-brain text-purple-400','fab fa-whatsapp text-green-400','fab fa-viber text-purple-500'];
$techIcons = ['fab fa-php','fas fa-database','fas fa-lock','fas fa-server','fas fa-plug','fas fa-code'];
$techColorClasses = [
    'bg-blue-100 text-blue-600',
    'bg-orange-100 text-orange-600',
    'bg-emerald-100 text-emerald-600',
    'bg-purple-100 text-purple-600',
    'bg-pink-100 text-pink-600',
    'bg-amber-100 text-amber-600',
];
$featureEmojis = ['⚙️', null, null, null, null, null];
$featureIcons = [null, 'fa-plug', 'fa-shield-alt', 'fa-bolt', 'fa-palette', 'fa-history'];
$featureIconClasses = [
    'bg-sky-100 text-sky-600',
    'bg-emerald-100 text-emerald-600',
    'bg-amber-100 text-amber-600',
    'bg-purple-100 text-purple-600',
    'bg-pink-100 text-pink-600',
    'bg-orange-100 text-orange-600',
];
$version = '5.0';
$paypal = 'https://www.paypal.com/ncp/payment/4AGSKV8V2N2K2';
$hreflangs = [
    ['uk', 'index.html'],
    ['ru', 'ru.html'],
    ['en', 'en.html'],
    ['no', 'no.html'],
    ['lt', 'lt.html'],
    ['sv', 'sv.html'],
    ['pl', 'pl.html'],
    ['de', 'de.html'],
];
$langSwitcherMap = ['uk' => 0, 'en' => 1, 'no' => 2, 'ru' => 3, 'lt' => 4, 'sv' => 5, 'pl' => 6, 'de' => 7];
$currentLangIndex = $langSwitcherMap[$langCode] ?? 0;
$counterLocale = $L['html_lang'] === 'uk' ? 'uk-UA' : ($L['html_lang'] . '-' . strtoupper($L['html_lang']));
if ($L['html_lang'] === 'en') $counterLocale = 'en-US';
if ($L['html_lang'] === 'no') $counterLocale = 'nb-NO';
if ($L['html_lang'] === 'sv') $counterLocale = 'sv-SE';
?>
<!DOCTYPE html>
<html lang="<?= crm_h($L['html_lang']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="<?= crm_h($L['meta_description']) ?>">
    <meta name="keywords" content="<?= crm_h($L['meta_keywords']) ?>">
    <meta name="author" content="Ruslan Bilohash">
    <meta name="robots" content="index, follow, max-image-preview:large">
    <meta name="language" content="<?= crm_h($L['html_lang']) ?>">
    <meta name="geo.region" content="UA">

    <link rel="canonical" href="<?= crm_h($L['canonical']) ?>">

    <title><?= crm_h($L['title']) ?></title>

    <meta property="og:title" content="<?= crm_h($L['og_title']) ?>">
    <meta property="og:description" content="<?= crm_h($L['og_description']) ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="CRM AI Consultant 5.0 — AI chat widget">
    <meta property="og:image" content="https://bilohash.com/ai/crm/assets/og-image.jpg">
    <meta property="og:url" content="<?= crm_h($L['canonical']) ?>">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="<?= crm_h($L['og_locale']) ?>">
    <meta property="og:site_name" content="CRM AI Consultant">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= crm_h($L['og_title']) ?>">
    <meta name="twitter:site" content="@bilohash">
    <meta name="twitter:creator" content="@bilohash">
    <meta name="twitter:description" content="<?= crm_h($L['og_description']) ?>">
    <meta name="twitter:image" content="https://bilohash.com/ai/crm/assets/og-image.jpg">

    <meta name="theme-color" content="#0ea5e9">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

<?php foreach ($hreflangs as [$hl, $file]): ?>
    <link rel="alternate" hreflang="<?= crm_h($hl) ?>" href="https://bilohash.com/ai/crm/<?= crm_h($file) ?>">
<?php endforeach; ?>
    <link rel="alternate" hreflang="x-default" href="https://bilohash.com/ai/crm/index.html">
    <link rel="sitemap" type="application/xml" title="Sitemap" href="https://bilohash.com/ai/crm/sitemap.xml">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": "CRM AI Consultant 5.0",
      "description": <?= json_encode($L['software_desc'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
      "applicationCategory": "BusinessApplication",
      "operatingSystem": "Web",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "UAH",
        "description": <?= json_encode($L['offer_desc'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>
      },
      "author": {
        "@type": "Person",
        "name": "Ruslan Bilohash"
      },
      "url": <?= json_encode($L['canonical'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
      "softwareVersion": "5.0",
      "datePublished": "2026-07-14",
      "inLanguage": <?= json_encode($L['html_lang'], JSON_UNESCAPED_UNICODE) ?>,
      "programmingLanguage": "PHP",
      "database": "MySQL",
      "featureList": "Grok, OpenAI, Telegram, WhatsApp, Viber, custom design, personal prompt, chat history"
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
<?php
$faqSchemaItems = [];
foreach ($L['faq_schema'] as $item) {
    $faqSchemaItems[] = '        {
          "@type": "Question",
          "name": ' . json_encode($item['q'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ',
          "acceptedAnswer": {
            "@type": "Answer",
            "text": ' . json_encode($item['a'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '
          }
        }';
}
echo implode(",\n", $faqSchemaItems);
?>

      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Bilohash",
      "url": "https://bilohash.com/",
      "logo": "https://bilohash.com/ai/crm/assets/og-image.jpg",
      "sameAs": ["https://github.com/Ruslan-Bilohash/crm-ai-consultant"]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "CRM AI Consultant",
      "url": "https://bilohash.com/ai/crm/",
      "inLanguage": <?= json_encode($L['html_lang'], JSON_UNESCAPED_UNICODE) ?>,
      "publisher": { "@type": "Organization", "name": "Bilohash" }
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Bilohash", "item": "https://bilohash.com/" },
        { "@type": "ListItem", "position": 2, "name": "AI", "item": "https://bilohash.com/ai/" },
        { "@type": "ListItem", "position": 3, "name": "CRM AI Consultant 5.0", "item": <?= json_encode($L['canonical'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?> }
      ]
    }
    </script>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Space+Grotesk:wght@500;600;700&display=swap');

        :root {
            --primary: 14 165 233;
        }
        .hero-bg {
            background: linear-gradient(135deg, #0ea5e9 0%, #1e40af 50%, #312e81 100%);
        }
        .feature-card {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .feature-card:hover {
            transform: translateY(-12px) scale(1.03);
            box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.4);
        }
        .channel-card {
            transition: all 0.3s ease;
        }
        .channel-card:hover {
            transform: scale(1.08) rotate(2deg);
        }
        .stat-number {
            font-variant-numeric: tabular-nums;
        }
        .faq-item {
            transition: all 0.3s ease;
        }
        .payment-btn {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body class="bg-zinc-950 text-zinc-100 font-sans" style="font-family: 'Inter', system-ui, sans-serif;">

<nav class="bg-zinc-900/80 backdrop-blur-lg border-b border-zinc-800 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 md:px-6 py-4 md:py-5 flex justify-between items-center">

        <div class="flex items-center gap-2 md:gap-3">
            <i class="fas fa-robot text-3xl text-sky-400"></i>
            <div class="flex items-center gap-2">
                <a href="./<?= crm_h($L['file']) ?>"><span class="text-2xl md:text-3xl font-bold tracking-tighter">CRM AI Consultant</span></a>
                <span class="text-xs md:text-sm bg-emerald-400 text-emerald-950 px-3 py-1 rounded-3xl font-medium"><?= crm_h($version) ?></span>
            </div>
        </div>

        <div class="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium">
            <a href="#features" class="hover:text-sky-400 transition"><?= crm_h($L['nav_features']) ?></a>
            <a href="#tech" class="hover:text-sky-400 transition"><?= crm_h($L['nav_tech']) ?></a>
            <a href="#how" class="hover:text-sky-400 transition"><?= crm_h($L['nav_how']) ?></a>
            <a href="#channels" class="hover:text-sky-400 transition"><?= crm_h($L['nav_channels']) ?></a>
            <a href="#demo" class="hover:text-sky-400 transition"><?= crm_h($L['nav_demo']) ?></a>
            <a href="#faq" class="hover:text-sky-400 transition"><?= crm_h($L['nav_faq']) ?></a>
        </div>

        <div class="flex items-center gap-3">
            <a href="admin/login.php" class="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-3xl border border-sky-400/50 text-sky-300 hover:bg-sky-500/10 text-sm font-medium transition">
                <i class="fas fa-user-lock"></i> <?= crm_h($L['nav_demo_admin']) ?>
            </a>
            <button onclick="toggleMobileMenu()" class="md:hidden text-3xl text-white p-2">
                <i id="hamburgerIcon" class="fas fa-bars"></i>
            </button>
        </div>
    </div>

    <div id="mobileMenu" class="hidden md:hidden bg-zinc-900 border-t border-zinc-800 px-6 py-6">
        <div class="flex flex-col gap-5 text-lg font-medium">
            <a href="#features" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_features']) ?></a>
            <a href="#tech" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_tech']) ?></a>
            <a href="#how" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_how']) ?></a>
            <a href="#channels" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_channels']) ?></a>
            <a href="#demo" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_demo']) ?></a>
            <a href="#faq" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_faq']) ?></a>
            <a href="admin/login.php" onclick="toggleMobileMenu()" class="hover:text-sky-400 transition"><?= crm_h($L['nav_demo_admin']) ?></a>
        </div>
    </div>
</nav>

<script>
    function toggleMobileMenu() {
        const menu = document.getElementById('mobileMenu');
        const icon = document.getElementById('hamburgerIcon');
        menu.classList.toggle('hidden');
        if (menu.classList.contains('hidden')) {
            icon.classList.replace('fa-xmark', 'fa-bars');
        } else {
            icon.classList.replace('fa-bars', 'fa-xmark');
        }
    }
</script>

    <section class="hero-bg py-24 lg:py-40 relative overflow-hidden">
        <div class="max-w-7xl mx-auto px-6 text-center relative z-10">
            <div class="inline-flex items-center gap-3 bg-white/10 backdrop-blur-md text-white text-sm px-8 py-3 rounded-3xl mb-10 border border-white/20">
                <i class="fas fa-sparkles"></i>
                <?= crm_h($L['hero_badge']) ?>
            </div>

            <h1 class="text-5xl lg:text-7xl font-bold leading-none tracking-tighter mb-8">
                CRM AI Consultant <?= crm_h($version) ?>
            </h1>
            <h2 class="text-3xl lg:text-5xl font-semibold text-white/90 mb-8">
                <?= crm_allow_br($L['hero_h2']) ?>
            </h2>

            <p class="text-xl lg:text-2xl text-white/90 max-w-4xl mx-auto mb-12">
                <?= crm_h($L['hero_p']) ?>
            </p>

            <div class="flex flex-col sm:flex-row gap-5 justify-center mb-12">
                <a href="<?= crm_h($paypal) ?>" target="_blank" class="payment-btn bg-white hover:bg-sky-100 text-zinc-900 font-semibold px-14 py-8 rounded-3xl text-2xl flex items-center justify-center gap-4 transition-all hover:scale-105 shadow-2xl">
                    <i class="fas fa-credit-card text-4xl"></i> <?= crm_h($L['hero_buy']) ?>
                </a>
                <a href="#demo" class="border-2 border-white/70 hover:border-white font-semibold px-14 py-8 rounded-3xl text-2xl flex items-center justify-center gap-4 transition-all">
                    <i class="fas fa-play-circle text-4xl"></i> <?= crm_h($L['hero_demo']) ?>
                </a>
            </div>

            <div class="flex flex-wrap justify-center gap-x-10 gap-y-4 text-white/70 text-sm font-medium">
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> PHP 8.1+</div>
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> MySQL 5.7+</div>
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> WordPress</div>
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> Tilda</div>
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> Shopify</div>
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> Laravel</div>
                <div class="flex items-center gap-2"><i class="fas fa-check"></i> <?= crm_h($L['hero_plain_html']) ?></div>
            </div>
        </div>
        <div class="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-zinc-950 to-transparent"></div>
    </section>

<section class="py-16 bg-zinc-900">
    <div class="max-w-7xl mx-auto px-6">
        <div class="text-center mb-12">
            <h2 class="text-3xl md:text-4xl font-bold text-white"><?= crm_h($L['stats_title']) ?></h2>
            <p class="text-zinc-400 mt-4 text-lg max-w-2xl mx-auto">
                <?= crm_h($L['stats_subtitle']) ?>
            </p>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
                <div class="text-5xl md:text-6xl font-bold text-sky-400 stat-number" x-data="{ count: 0 }" x-init="setTimeout(() => { count = 14200 }, 300)">+127</div>
                <p class="text-zinc-400 mt-3"><?= crm_h($L['stat1_label']) ?></p>
                <p class="text-emerald-400 text-sm mt-1"><?= crm_h($L['stat1_sub']) ?></p>
            </div>
            <div>
                <div class="text-5xl md:text-6xl font-bold text-emerald-400 stat-number" x-data="{ count: 0 }" x-init="setTimeout(() => { count = 3470000 }, 600)">115 000</div>
                <p class="text-zinc-400 mt-3"><?= crm_h($L['stat2_label']) ?></p>
                <p class="text-emerald-400 text-sm mt-1"><?= crm_h($L['stat2_sub']) ?></p>
            </div>
            <div>
                <div class="text-5xl md:text-6xl font-bold text-purple-400 stat-number" x-data="{ count: 0 }" x-init="setTimeout(() => { count = 41 }, 900)">7</div>
                <p class="text-zinc-400 mt-3"><?= crm_h($L['stat3_label']) ?></p>
            </div>
            <div>
                <div class="text-5xl md:text-6xl font-bold text-amber-400 stat-number" x-data="{ count: 0 }" x-init="setTimeout(() => { count = 99.97 }, 1200)">99%</div>
                <p class="text-zinc-400 mt-3"><?= crm_h($L['stat4_label']) ?></p>
                <p class="text-emerald-400 text-sm mt-1"><?= crm_h($L['stat4_sub']) ?></p>
            </div>
        </div>
    </div>
</section>

    <section id="tech" class="py-24 bg-white text-zinc-900">
        <div class="max-w-7xl mx-auto px-6">
            <h2 class="text-4xl lg:text-5xl font-bold text-center mb-6"><?= crm_h($L['tech_title']) ?></h2>
            <p class="text-center text-zinc-600 max-w-3xl mx-auto mb-16">
                <?= crm_h($L['tech_subtitle']) ?>
            </p>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
<?php foreach ($L['tech_cards'] as $i => $card):
    $tc = $techColorClasses[$i] ?? 'bg-blue-100 text-blue-600';
    $icon = $techIcons[$i] ?? 'fas fa-code';
?>
                <div class="feature-card bg-zinc-100 p-10 rounded-3xl group">
                    <div class="w-16 h-16 <?= crm_h($tc) ?> rounded-2xl flex items-center justify-center text-4xl mb-8 group-hover:rotate-12 transition"><i class="<?= crm_h($icon) ?>"></i></div>
                    <h3 class="text-2xl font-semibold mb-4"><?= crm_h($card['title']) ?></h3>
                    <p class="text-zinc-600 leading-relaxed"><?= crm_h($card['text']) ?></p>
                </div>
<?php endforeach; ?>
            </div>

            <div class="flex justify-center mt-16">
                <a href="<?= crm_h($L['doc_file']) ?>"
                   class="group inline-flex items-center gap-4 bg-zinc-900 hover:bg-black text-white font-semibold text-xl px-12 py-6 rounded-3xl transition-all duration-300 hover:scale-105 shadow-xl">
                    <span>📖 <?= crm_h($L['doc_btn']) ?></span>
                    <i class="fas fa-arrow-right group-hover:translate-x-2 transition-transform"></i>
                </a>
            </div>
        </div>
    </section>

    <section id="features" class="py-24 bg-zinc-900 text-white">
        <div class="max-w-7xl mx-auto px-6">
            <h2 class="text-4xl lg:text-5xl font-bold text-center mb-6"><?= crm_h($L['features_title']) ?></h2>
            <p class="text-center text-zinc-400 max-w-3xl mx-auto mb-16">
                <?= crm_h($L['features_subtitle']) ?>
            </p>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
<?php foreach ($L['feature_cards'] as $i => $card):
    $fc = $featureIconClasses[$i] ?? 'bg-sky-100 text-sky-600';
    $emoji = $featureEmojis[$i] ?? null;
    $fIcon = $featureIcons[$i] ?? null;
?>
                <div class="feature-card bg-zinc-800 p-10 rounded-3xl group">
                    <div class="w-16 h-16 <?= crm_h($fc) ?> rounded-2xl flex items-center justify-center text-4xl mb-8 group-hover:rotate-12 transition"><?php if ($emoji): ?><?= $emoji ?><?php else: ?><i class="fas <?= crm_h($fIcon) ?>"></i><?php endif; ?></div>
                    <h3 class="text-2xl font-semibold mb-4"><?= crm_h($card['title']) ?></h3>
                    <p class="text-zinc-400 leading-relaxed"><?= crm_h($card['text']) ?></p>
                </div>
<?php endforeach; ?>
            </div>
        </div>
    </section>

    <section id="how" class="py-24 bg-white text-zinc-900">
        <div class="max-w-7xl mx-auto px-6">
            <h2 class="text-4xl lg:text-5xl font-bold text-center mb-16"><?= crm_h($L['how_title']) ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-10">
<?php foreach ($L['how_steps'] as $i => $step): ?>
                <div class="text-center group">
                    <div class="w-20 h-20 mx-auto bg-sky-500 text-white rounded-3xl flex items-center justify-center text-5xl font-bold mb-6 group-hover:scale-110 transition"><?= (int)$i + 1 ?></div>
                    <h4 class="text-2xl font-semibold mb-3"><?= crm_h($step['title']) ?></h4>
                    <p class="text-zinc-600"><?= crm_h($step['text']) ?></p>
                </div>
<?php endforeach; ?>
            </div>
        </div>
    </section>

<section id="channels" class="py-20 md:py-24 bg-zinc-900">
    <div class="max-w-7xl mx-auto px-6">
        <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-10 md:mb-12 text-white">
            <?= crm_h($L['channels_title']) ?>
        </h2>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6 md:gap-8">
<?php foreach ($L['channel_cards'] as $i => $ch):
    $chIcon = $channelIcons[$i] ?? 'fas fa-comments';
?>
            <div class="channel-card bg-white/10 p-6 md:p-10 rounded-3xl text-center text-white hover:scale-105 transition-all duration-300">
                <i class="<?= crm_h($chIcon) ?> text-6xl md:text-8xl mb-4 md:mb-6"></i>
                <p class="text-2xl md:text-3xl font-semibold"><?= crm_h($ch['title']) ?></p>
                <p class="text-zinc-400 text-sm md:text-base mt-3"><?= crm_h($ch['text']) ?></p>
            </div>
<?php endforeach; ?>
        </div>
    </div>
</section>

<section id="screenshots" class="py-24 bg-white text-zinc-900">
    <div class="max-w-7xl mx-auto px-6">
        <div class="text-center mb-16">
            <div class="inline-flex items-center gap-3 bg-emerald-100 text-emerald-700 text-sm px-6 py-2 rounded-3xl mb-6">
                <i class="fas fa-camera"></i>
                <?= crm_h($L['screens_badge']) ?>
            </div>
            <h2 class="text-4xl lg:text-5xl font-bold tracking-tight mb-4"><?= crm_h($L['screens_title']) ?></h2>
            <p class="text-xl text-zinc-600 max-w-2xl mx-auto">
                <?= crm_h($L['screens_subtitle']) ?>
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
<?php foreach ($L['screen_cards'] as $i => $scr):
    $img = $screenImgs[$i] ?? '';
?>
            <div onclick="openLightbox('<?= crm_h($img) ?>')"
                 class="group bg-white border border-zinc-100 rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer">
                <div class="aspect-video bg-zinc-100 flex items-center justify-center overflow-hidden">
                    <img src="<?= crm_h($img) ?>" alt="<?= crm_h($scr['alt']) ?>" loading="lazy"
                         class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110">
                </div>
                <div class="p-6">
                    <h4 class="font-semibold text-xl mb-1"><?= crm_h($scr['title']) ?></h4>
                    <p class="text-zinc-600"><?= crm_h($scr['text']) ?></p>
                </div>
            </div>
<?php endforeach; ?>
        </div>
    </div>
</section>

<div id="lightbox" onclick="if(event.target.id === 'lightbox') closeLightbox()"
     style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.95); z-index:99999; align-items:center; justify-content:center;">
    <div style="position:relative; max-width:95%; max-height:95%;">
        <button onclick="closeLightbox()"
                style="position:absolute; top:-50px; right:0; color:white; font-size:40px; background:none; border:none; cursor:pointer;">
            ✕
        </button>
        <img id="lightboxImage" src="" style="max-width:100%; max-height:90vh; border-radius:16px; box-shadow:0 25px 50px -12px rgb(0 0 0 / 0.5);">
    </div>
</div>

<script>
function openLightbox(src) {
    const lightbox = document.getElementById('lightbox');
    const image = document.getElementById('lightboxImage');
    image.src = src;
    lightbox.style.display = 'flex';
}
function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
}
</script>

    <section id="demo" class="py-24 bg-white text-zinc-900">
        <div class="max-w-7xl mx-auto px-6 text-center">
            <h2 class="text-4xl lg:text-5xl font-bold mb-6"><?= crm_h($L['demo_title']) ?></h2>
            <p class="text-xl text-zinc-600 max-w-3xl mx-auto mb-12">
                <?= crm_h($L['demo_p']) ?>
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="admin/login.php" class="inline-flex items-center gap-4 bg-gradient-to-r from-sky-400 to-blue-600 text-white font-semibold text-xl sm:text-2xl px-10 sm:px-16 py-6 sm:py-7 rounded-3xl hover:scale-105 transition shadow-2xl">
                    <i class="fas fa-user-lock text-3xl sm:text-4xl"></i>
                    <?= crm_h($L['demo_admin_btn']) ?>
                </a>
                <button type="button" onclick="document.getElementById('crm-ai-widget-open')?.click()" class="inline-flex items-center gap-4 border-2 border-sky-500 text-sky-700 font-semibold text-xl sm:text-2xl px-10 sm:px-16 py-6 sm:py-7 rounded-3xl hover:bg-sky-50 transition">
                    <i class="fas fa-comments text-3xl sm:text-4xl"></i>
                    <?= crm_h($L['demo_chat_btn']) ?>
                </button>
            </div>
            <p class="text-sm text-zinc-500 mt-8"><?= crm_allow_strong($L['demo_hint']) ?></p>
        </div>
    </section>

    <section id="faq" class="py-24 bg-zinc-900">
        <div class="max-w-7xl mx-auto px-6">
            <h2 class="text-4xl lg:text-5xl font-bold text-center mb-16 text-white"><?= crm_h($L['faq_title']) ?></h2>
            <div class="max-w-3xl mx-auto space-y-4" x-data="{ open: null }">
<?php foreach ($L['faq_items'] as $i => $faq): $n = $i + 1; ?>
                <div class="faq-item bg-zinc-800 rounded-3xl p-6 cursor-pointer" @click="open = open === <?= $n ?> ? null : <?= $n ?>">
                    <div class="flex justify-between items-center text-white">
                        <h4 class="text-xl font-semibold"><?= crm_h($faq['q']) ?></h4>
                        <i class="fas fa-chevron-down transition" :class="{ 'rotate-180': open === <?= $n ?> }"></i>
                    </div>
                    <p x-show="open === <?= $n ?>" class="text-zinc-400 mt-4 leading-relaxed"><?= crm_h($faq['a']) ?></p>
                </div>
<?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="py-24 bg-gradient-to-r from-emerald-500 via-sky-500 to-blue-600 text-white">
        <div class="max-w-4xl mx-auto px-6 text-center">
            <h2 class="text-4xl sm:text-5xl font-bold mb-6"><?= crm_h($L['cta_title']) ?></h2>
            <p class="text-2xl mb-10"><?= crm_h($L['cta_p']) ?></p>
            <a href="<?= crm_h($paypal) ?>" target="_blank" class="payment-btn inline-block bg-white text-zinc-900 font-semibold text-3xl px-20 py-8 rounded-3xl hover:scale-110 transition shadow-2xl flex items-center justify-center gap-4 mx-auto">
                <i class="fas fa-credit-card text-4xl"></i>
                <?= crm_h($L['cta_buy']) ?>
            </a>
            <p class="text-sm mt-8 opacity-75"><?= crm_h($L['cta_note']) ?></p>
        </div>
    </section>

  <footer class="bg-zinc-950 py-20 border-t border-zinc-800">
    <div class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">

            <div>
                <div class="flex items-center gap-3 mb-6">
                    <i class="fas fa-robot text-4xl text-sky-400"></i>
                    <span class="text-3xl font-bold tracking-tighter">CRM AI Consultant</span>
                </div>
                <p class="text-zinc-400 leading-relaxed mb-8">
                    <?= crm_h($L['footer_desc']) ?>
                </p>
                <a href="admin/login.php"
                   class="inline-flex items-center gap-3 border border-sky-400 text-sky-300 px-8 py-4 rounded-3xl font-semibold hover:bg-sky-500/10 transition">
                    <i class="fas fa-user-lock"></i> <?= crm_h($L['footer_demo_btn']) ?>
                </a>
            </div>

            <div>
                <h4 class="font-semibold mb-6 text-lg text-white"><?= crm_h($L['footer_product']) ?></h4>
                <ul class="space-y-4 text-zinc-400">
                    <li><a href="<?= crm_h($L['doc_file']) ?>" class="hover:text-white transition"><?= crm_h($L['footer_doc']) ?></a></li>
                    <li><a href="#tech" class="hover:text-white transition"><?= crm_h($L['nav_tech']) ?></a></li>
                    <li><a href="#features" class="hover:text-white transition"><?= crm_h($L['nav_features']) ?></a></li>
                    <li><a href="#channels" class="hover:text-white transition"><?= crm_h($L['nav_channels']) ?></a></li>
                    <li><a href="#demo" class="hover:text-white transition"><?= crm_h($L['nav_demo']) ?></a></li>
                </ul>
            </div>

            <div>
                <h4 class="font-semibold mb-6 text-lg text-white"><?= crm_h($L['footer_links']) ?></h4>
                <ul class="space-y-4 text-zinc-400">
                    <li><a href="https://github.com/Ruslan-Bilohash/crm-ai-consultant/tree/main/5.0" target="_blank" class="hover:text-white transition">GitHub 5.0</a></li>
                    <li><a href="<?= crm_h($paypal) ?>" target="_blank" class="hover:text-white transition">PayPal</a></li>
                </ul>
            </div>

            <div>
                <h4 class="font-semibold mb-6 text-lg text-white"><?= crm_h($L['footer_contacts']) ?></h4>
                <p class="text-zinc-400">Автор: Ruslan Bilohash</p>
                <p class="text-xs text-zinc-500 mt-8"><?= crm_h($L['footer_copyright']) ?></p>
            </div>

        </div>

        <div class="border-t border-zinc-800 mt-16 pt-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div class="flex items-center gap-8 text-sm text-zinc-400">
                <div class="flex items-center gap-2">
                    <i class="fas fa-eye text-sky-400"></i>
                    <span class="font-medium"><?= crm_h($L['counter_total']) ?></span>
                    <span id="totalVisits" class="font-semibold text-white text-lg">0</span>
                </div>
                <div class="flex items-center gap-2">
                    <i class="fas fa-user text-emerald-400"></i>
                    <span class="font-medium"><?= crm_h($L['counter_unique']) ?></span>
                    <span id="uniqueVisits" class="font-semibold text-white text-lg">0</span>
                </div>
            </div>
        </div>

    </div>
</footer>

<div id="langSwitcher"
     onclick="toggleLangMenu()"
     class="fixed bottom-6 left-6 z-[9999] w-16 h-16 bg-white shadow-2xl border border-zinc-200 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 active:scale-95 transition-all duration-300">
    <div class="flex flex-col items-center">
        <span id="currentFlag" class="text-4xl leading-none"></span>
        <span id="currentLangCode" class="text-[10px] font-bold text-zinc-700 tracking-widest -mt-1"></span>
    </div>
</div>

<div id="langMenu" class="hidden fixed bottom-24 left-6 bg-white shadow-2xl border border-zinc-200 rounded-3xl p-3 z-[10000]">
    <div class="flex flex-col gap-3">
        <span onclick="changeLanguage('UA')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇺🇦</span>
        <span onclick="changeLanguage('EN')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇬🇧</span>
        <span onclick="changeLanguage('NO')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇳🇴</span>
        <span onclick="changeLanguage('RU')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇷🇺</span>
        <span onclick="changeLanguage('LT')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇱🇹</span>
        <span onclick="changeLanguage('SV')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇸🇪</span>
        <span onclick="changeLanguage('PL')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇵🇱</span>
        <span onclick="changeLanguage('DE')" class="text-4xl cursor-pointer hover:scale-125 transition flex justify-center">🇩🇪</span>
    </div>
</div>
<?php include dirname(__DIR__) . '/gdpr.php'; ?>
<script>
    const languages = [
        { code: "UA", flag: "🇺🇦", file: "index.html" },
        { code: "EN", flag: "🇬🇧", file: "en.html" },
        { code: "NO", flag: "🇳🇴", file: "no.html" },
        { code: "RU", flag: "🇷🇺", file: "ru.html" },
        { code: "LT", flag: "🇱🇹", file: "lt.html" },
        { code: "SV", flag: "🇸🇪", file: "sv.html" },
        { code: "PL", flag: "🇵🇱", file: "pl.html" },
        { code: "DE", flag: "🇩🇪", file: "de.html" }
    ];

    let currentIndex = <?= (int)$currentLangIndex ?>;

    function updateSwitcher() {
        document.getElementById("currentFlag").textContent = languages[currentIndex].flag;
        document.getElementById("currentLangCode").textContent = languages[currentIndex].code;
    }

    function nextLanguage() {
        currentIndex = (currentIndex + 1) % languages.length;
        updateSwitcher();
    }

    function startAutoSwitch() {
        setInterval(nextLanguage, 2500);
    }

    function toggleLangMenu() {
        document.getElementById("langMenu").classList.toggle("hidden");
    }

    function changeLanguage(code) {
        const lang = languages.find(item => item.code === code);
        if (lang) {
            window.location.href = lang.file;
        }
    }

    window.onload = function() {
        updateSwitcher();
        startAutoSwitch();
    };
</script>
<script>
async function loadCounter() {
    try {
        const response = await fetch('counter.php');
        const data = await response.json();
        document.getElementById('totalVisits').textContent = data.total.toLocaleString(<?= json_encode($counterLocale) ?>);
        document.getElementById('uniqueVisits').textContent = data.unique.toLocaleString(<?= json_encode($counterLocale) ?>);
    } catch (e) {
        console.log('Counter failed to load');
    }
}
window.addEventListener('load', loadCounter);
</script>

    <script src="https://bilohash.com/ai/crm/index.php?site=bilohash_com_ai_crm_index_html"></script>
</body>
</html>