<?php
/**
 * CRM AI Consultant — Головний файл віджету (MySQL)
 * Version: 5.1
 */

define('CRM_AI_CONSULTANT', true);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/security.php';

crm_ai_send_security_headers();

if (isset($_GET['action']) || isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');

    $action  = $_GET['action'] ?? $_POST['action'] ?? '';
    $site_id = crm_ai_sanitize_id($_GET['site_id'] ?? $_POST['site_id'] ?? '');
    $session = trim($_GET['session'] ?? $_POST['session'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($site_id === '' || $session === '' || strlen($session) > 128) {
        echo json_encode(['success' => false, 'message' => 'Invalid request'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!crm_ai_validate_origin($site_id)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Origin not allowed'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }

    if ($action === 'crm_ai_send') {
        if ($message === '' || strlen($message) > 8000) {
            echo json_encode(['success' => false, 'message' => 'Invalid message'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $result = crm_ai_process_message($site_id, $session, $message);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'crm_ai_get_messages') {
        $messages = crm_ai_get_conversation($site_id, $session);
        echo json_encode($messages, JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
    exit;
}

$site_id = crm_ai_sanitize_id(trim($_GET['site'] ?? ''));

if ($site_id === '') {
    header('Content-Type: text/plain; charset=utf-8');
    http_response_code(400);
    die('Use ?site=YOUR_SITE_ID');
}

$settings = crm_ai_get_site_settings($site_id);

if (!$settings || empty($settings['enable_chat'])) {
    header('Content-Type: text/plain; charset=utf-8');
    http_response_code(403);
    die('Chat disabled for this site');
}

$config = [
    'ajax_url'          => BASE_URL . 'index.php',
    'site_id'           => $site_id,
    'chat_title'        => $settings['chat_title']        ?? 'AI Consultant',
    'chat_subtitle'     => $settings['chat_subtitle']     ?? 'Quick help',
    'bot_icon'          => $settings['bot_icon']          ?? '🤖',
    'position'          => $settings['position']          ?? 'right',
    'widget_color'      => $settings['widget_color']      ?? '#22d3ee',
    'chat_bg_color'     => $settings['chat_bg_color']     ?? '#0f172a',
    'header_bg_color'   => $settings['header_bg_color']   ?? '#1e2937',
    'user_bubble_color' => $settings['user_bubble_color'] ?? '#22d3ee',
    'bot_bubble_color'  => $settings['bot_bubble_color']  ?? '#334155',
    'welcome_text'      => $settings['welcome_text']      ?? 'Hello! How can I help you today?',
    'auto_open'         => !empty($settings['auto_open']),
    'auto_open_delay'   => (int)($settings['auto_open_delay'] ?? 7000),
];

header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: public, max-age=300');

if (ob_get_level()) {
    ob_clean();
}

$v = CRM_AI_VERSION;
echo 'window.crmAI = ' . json_encode($config, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT) . ";\n\n";
echo "var script = document.createElement('script');\n";
echo "script.src = '" . BASE_URL . "assets/chat.js?v={$v}';\n";
echo "document.head.appendChild(script);\n";

exit;