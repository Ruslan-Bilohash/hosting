<?php
require_once __DIR__ . '/init.php';
fl_admin_require();
require_once dirname(__DIR__) . '/includes/storage.php';
require_once dirname(__DIR__) . '/includes/theme.php';
require_once __DIR__ . '/includes/settings-lib.php';

$admin_page = 'settings';
$settings_tab = 'appearance';
$page_title = $ta['settings_tab_appearance'] ?? ($ta['settings_appearance'] ?? 'Appearance');
$settings = fl_load_settings();
$palettes = fl_color_palettes();
$activePalette = trim((string) ($settings['color_palette'] ?? 'nordic_light'));
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = fl_settings_apply_post('appearance', $_POST, $settings);
    $flash = fl_save_settings($settings) ? 'success' : 'error';
    $settings = fl_load_settings();
    $activePalette = trim((string) ($settings['color_palette'] ?? 'nordic_light'));
}

require __DIR__ . '/includes/layout.php';
require __DIR__ . '/includes/settings-tabs.php';
?>

<?php if ($flash === 'success'): ?>
<div class="adm-alert adm-alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($ta['settings_saved'] ?? 'Saved') ?></div>
<?php elseif ($flash === 'error'): ?>
<div class="adm-alert adm-alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($ta['error']) ?></div>
<?php endif; ?>

<form method="post" class="adm-settings-form">
    <div class="adm-card">
        <div class="adm-card-head"><h2><?= htmlspecialchars($ta['palette_section'] ?? 'Colour palettes') ?></h2></div>
        <div class="adm-card-body padded">
            <p class="adm-help"><?= htmlspecialchars($ta['palette_help'] ?? '') ?></p>
            <div class="adm-palette-grid">
                <?php foreach ($palettes as $id => $p): ?>
                <?php
                $label = $ta['palette_' . $id] ?? ($p['label'] ?? $id);
                $isActive = $activePalette === $id && empty($settings['color_random_auto']);
                ?>
                <label class="adm-palette-card<?= $isActive ? ' is-active' : '' ?>">
                    <input type="radio" name="color_palette" value="<?= htmlspecialchars($id) ?>"<?= $isActive ? ' checked' : '' ?>>
                    <span class="adm-palette-swatches">
                        <span style="background:<?= htmlspecialchars($p['bg']) ?>"></span>
                        <span style="background:<?= htmlspecialchars($p['primary']) ?>"></span>
                        <span style="background:<?= htmlspecialchars($p['card']) ?>;border:1px solid <?= htmlspecialchars($p['border']) ?>"></span>
                    </span>
                    <strong><?= htmlspecialchars($label) ?></strong>
                    <small><?= htmlspecialchars(($p['mode'] ?? 'light') === 'light' ? ($ta['palette_mode_light'] ?? 'Light') : ($ta['palette_mode_dark'] ?? 'Dark')) ?></small>
                </label>
                <?php endforeach; ?>
                <label class="adm-palette-card<?= $activePalette === 'custom' && empty($settings['color_random_auto']) ? ' is-active' : '' ?>">
                    <input type="radio" name="color_palette" value="custom"<?= $activePalette === 'custom' && empty($settings['color_random_auto']) ? ' checked' : '' ?>>
                    <span class="adm-palette-swatches adm-palette-swatches--custom">
                        <span style="background:<?= htmlspecialchars($settings['bg_color'] ?? '#0c1222') ?>"></span>
                        <span style="background:<?= htmlspecialchars($settings['color_primary'] ?? '#10b981') ?>"></span>
                        <span style="background:<?= htmlspecialchars($settings['color_button'] ?? '#10b981') ?>"></span>
                    </span>
                    <strong><?= htmlspecialchars($ta['palette_custom'] ?? 'Custom colours') ?></strong>
                    <small><?= htmlspecialchars($ta['palette_custom_hint'] ?? 'Manual pickers below') ?></small>
                </label>
            </div>
            <div class="adm-field adm-field-check" style="margin-top:18px">
                <label class="adm-check">
                    <input type="checkbox" name="color_random_auto" value="1"<?= !empty($settings['color_random_auto']) ? ' checked' : '' ?>>
                    <?= htmlspecialchars($ta['color_random_auto'] ?? 'Auto-random palette on each visit') ?>
                </label>
                <p class="adm-hint"><?= htmlspecialchars($ta['color_random_auto_hint'] ?? '') ?></p>
            </div>
            <div class="adm-field">
                <label for="color_random_interval_sec"><?= htmlspecialchars($ta['color_random_interval'] ?? 'Rotate while browsing (seconds)') ?></label>
                <input type="number" id="color_random_interval_sec" name="color_random_interval_sec" min="15" max="300" step="5"
                       value="<?= (int) ($settings['color_random_interval_sec'] ?? 45) ?>">
                <p class="adm-hint"><?= htmlspecialchars($ta['color_random_interval_hint'] ?? '') ?></p>
            </div>
        </div>
    </div>

    <div class="adm-card">
        <div class="adm-card-head"><h2><?= htmlspecialchars($ta['settings_appearance'] ?? 'Custom colours') ?></h2></div>
        <div class="adm-card-body padded">
            <p class="adm-help"><?= htmlspecialchars($ta['appearance_help'] ?? '') ?></p>
            <div class="adm-form-grid adm-color-grid">
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['color_primary'] ?? 'Site accent colour') ?></label>
                    <input type="color" name="color_primary" value="<?= htmlspecialchars($settings['color_primary'] ?? '#10b981') ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['color_button'] ?? 'Button colour') ?></label>
                    <input type="color" name="color_button" value="<?= htmlspecialchars($settings['color_button'] ?? '#10b981') ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['color_button_hover'] ?? 'Button hover') ?></label>
                    <input type="color" name="color_button_hover" value="<?= htmlspecialchars($settings['color_button_hover'] ?? '#059669') ?>">
                </div>
                <div class="adm-field">
                    <label><?= htmlspecialchars($ta['bg_color'] ?? 'Background colour') ?></label>
                    <input type="color" name="bg_color" value="<?= htmlspecialchars($settings['bg_color'] ?? '#f4f7fb') ?>">
                </div>
                <div class="adm-field adm-field-full">
                    <label><?= htmlspecialchars($ta['bg_image'] ?? 'Background image URL') ?></label>
                    <input type="url" name="bg_image" value="<?= htmlspecialchars($settings['bg_image'] ?? '') ?>" placeholder="https://...">
                </div>
            </div>
        </div>
    </div>
    <div class="adm-form-actions adm-form-actions-sticky">
        <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save']) ?></button>
    </div>
</form>

<?php require __DIR__ . '/includes/layout-end.php'; ?>