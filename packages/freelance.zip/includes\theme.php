<?php

function fl_hex_color(string $hex, string $fallback = '#10b981'): string
{
    $hex = trim($hex);
    if (preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $hex)) {
        return $hex;
    }
    return $fallback;
}

/** @return array<string, array<string, string>> */
function fl_color_palettes(): array
{
    return [
        'nordic_light' => [
            'label' => 'Nordic Light',
            'mode' => 'light',
            'primary' => '#3b82f6',
            'button' => '#2563eb',
            'button_hover' => '#1d4ed8',
            'bg' => '#f4f7fb',
            'surface' => '#ffffff',
            'surface_alt' => '#e8eef6',
            'card' => '#ffffff',
            'text' => '#1e293b',
            'text_muted' => '#64748b',
            'border' => 'rgba(100, 116, 139, .22)',
            'accent_light' => '#60a5fa',
            'glow' => 'rgba(59, 130, 246, .18)',
        ],
        'sage_calm' => [
            'label' => 'Sage Calm',
            'mode' => 'light',
            'primary' => '#6b9e78',
            'button' => '#5a8f68',
            'button_hover' => '#4a7d58',
            'bg' => '#f6f8f5',
            'surface' => '#ffffff',
            'surface_alt' => '#e9efe8',
            'card' => '#ffffff',
            'text' => '#2d3a32',
            'text_muted' => '#6b7c72',
            'border' => 'rgba(90, 120, 100, .2)',
            'accent_light' => '#8bb896',
            'glow' => 'rgba(107, 158, 120, .2)',
        ],
        'lavender_soft' => [
            'label' => 'Lavender Soft',
            'mode' => 'light',
            'primary' => '#8b7fd4',
            'button' => '#7569c4',
            'button_hover' => '#6358b0',
            'bg' => '#f8f6fc',
            'surface' => '#ffffff',
            'surface_alt' => '#ece8f8',
            'card' => '#ffffff',
            'text' => '#3d365c',
            'text_muted' => '#7a7199',
            'border' => 'rgba(120, 110, 160, .2)',
            'accent_light' => '#a89ee0',
            'glow' => 'rgba(139, 127, 212, .2)',
        ],
        'warm_sand' => [
            'label' => 'Warm Sand',
            'mode' => 'light',
            'primary' => '#c17f59',
            'button' => '#a86b48',
            'button_hover' => '#8f5738',
            'bg' => '#faf8f4',
            'surface' => '#ffffff',
            'surface_alt' => '#f0ebe3',
            'card' => '#ffffff',
            'text' => '#3d342c',
            'text_muted' => '#8a7d72',
            'border' => 'rgba(140, 120, 100, .22)',
            'accent_light' => '#d49a78',
            'glow' => 'rgba(193, 127, 89, .2)',
        ],
        'ocean_mist' => [
            'label' => 'Ocean Mist',
            'mode' => 'light',
            'primary' => '#4a9eae',
            'button' => '#3d8796',
            'button_hover' => '#2f6f7c',
            'bg' => '#f3f8fa',
            'surface' => '#ffffff',
            'surface_alt' => '#e3f0f3',
            'card' => '#ffffff',
            'text' => '#1e3a42',
            'text_muted' => '#5f7d86',
            'border' => 'rgba(74, 130, 145, .2)',
            'accent_light' => '#6eb8c6',
            'glow' => 'rgba(74, 158, 174, .2)',
        ],
        'rose_clay' => [
            'label' => 'Rose Clay',
            'mode' => 'light',
            'primary' => '#c4788a',
            'button' => '#a86072',
            'button_hover' => '#8f4f60',
            'bg' => '#faf6f6',
            'surface' => '#ffffff',
            'surface_alt' => '#f3e8ea',
            'card' => '#ffffff',
            'text' => '#3d2c32',
            'text_muted' => '#8a6d75',
            'border' => 'rgba(160, 110, 125, .2)',
            'accent_light' => '#d99aaa',
            'glow' => 'rgba(196, 120, 138, .2)',
        ],
        'slate_pro' => [
            'label' => 'Slate Pro',
            'mode' => 'dark',
            'primary' => '#38bdf8',
            'button' => '#0ea5e9',
            'button_hover' => '#0284c7',
            'bg' => '#1e293b',
            'surface' => '#334155',
            'surface_alt' => '#475569',
            'card' => '#334155',
            'text' => '#f1f5f9',
            'text_muted' => '#94a3b8',
            'border' => 'rgba(148, 163, 184, .25)',
            'accent_light' => '#7dd3fc',
            'glow' => 'rgba(56, 189, 248, .25)',
        ],
        'midnight' => [
            'label' => 'Midnight (classic)',
            'mode' => 'dark',
            'primary' => '#10b981',
            'button' => '#10b981',
            'button_hover' => '#059669',
            'bg' => '#0f172a',
            'surface' => '#1e293b',
            'surface_alt' => '#334155',
            'card' => '#1e1b4b',
            'text' => '#e8edf5',
            'text_muted' => '#94a3b8',
            'border' => 'rgba(148, 163, 184, .2)',
            'accent_light' => '#34d399',
            'glow' => 'rgba(16, 185, 129, .25)',
        ],
    ];
}

function fl_palette_id_valid(string $id): string
{
    $palettes = fl_color_palettes();
    return isset($palettes[$id]) ? $id : 'nordic_light';
}

/** @return array<string, string> */
function fl_palette_custom_from_settings(array $s): array
{
    return [
        'label' => 'Custom',
        'mode' => 'dark',
        'primary' => fl_hex_color($s['color_primary'] ?? '#10b981'),
        'button' => fl_hex_color($s['color_button'] ?? ($s['color_primary'] ?? '#10b981')),
        'button_hover' => fl_hex_color($s['color_button_hover'] ?? '#059669'),
        'bg' => fl_hex_color($s['bg_color'] ?? '#0c1222', '#0c1222'),
        'surface' => fl_hex_color($s['bg_color'] ?? '#0c1222', '#0c1222'),
        'surface_alt' => fl_hex_color($s['bg_color'] ?? '#0c1222', '#0c1222'),
        'card' => fl_hex_color($s['bg_color'] ?? '#1e1b4b', '#1e1b4b'),
        'text' => '#e8edf5',
        'text_muted' => '#94a3b8',
        'border' => 'rgba(148, 163, 184, .2)',
        'accent_light' => fl_hex_color($s['color_primary'] ?? '#34d399'),
        'glow' => 'rgba(16, 185, 129, .2)',
    ];
}

/** @return array{id:string, colors:array<string,string>} */
function fl_resolve_active_palette(?array $settings = null): array
{
    $settings = $settings ?? fl_load_settings();
    $palettes = fl_color_palettes();
    $paletteId = trim((string) ($settings['color_palette'] ?? 'nordic_light'));
    $randomAuto = !empty($settings['color_random_auto']);

    if ($randomAuto) {
        $ids = array_keys($palettes);
        $paletteId = $ids[array_rand($ids)];
    } elseif ($paletteId === 'custom') {
        return ['id' => 'custom', 'colors' => fl_palette_custom_from_settings($settings)];
    } else {
        $paletteId = fl_palette_id_valid($paletteId);
    }

    return ['id' => $paletteId, 'colors' => $palettes[$paletteId]];
}

function fl_theme_vars(): array
{
    static $vars = null;
    if ($vars !== null) {
        return $vars;
    }
    $s = fl_load_settings();
    $resolved = fl_resolve_active_palette($s);
    $c = $resolved['colors'];
    $vars = [
        'palette_id' => $resolved['id'],
        'primary' => $c['primary'],
        'button' => $c['button'],
        'button_hover' => $c['button_hover'],
        'bg' => $c['bg'],
        'bg_image' => trim($s['bg_image'] ?? ''),
        'surface' => $c['surface'],
        'surface_alt' => $c['surface_alt'],
        'card' => $c['card'],
        'text' => $c['text'],
        'text_muted' => $c['text_muted'],
        'border' => $c['border'],
        'accent_light' => $c['accent_light'],
        'glow' => $c['glow'],
        'mode' => $c['mode'] ?? 'light',
    ];
    return $vars;
}

/** @return list<array<string, mixed>> */
function fl_palettes_for_js(): array
{
    $out = [];
    foreach (fl_color_palettes() as $id => $colors) {
        $out[] = array_merge(['id' => $id], $colors);
    }
    return $out;
}

function fl_render_theme_styles(): void
{
    $s = fl_load_settings();
    $v = fl_theme_vars();
    $randomAuto = !empty($s['color_random_auto']);
    $interval = max(0, (int) ($s['color_random_interval_sec'] ?? 45));
    $bgRule = $v['bg_image'] !== ''
        ? "background-color:{$v['bg']};background-image:url('" . htmlspecialchars($v['bg_image'], ENT_QUOTES) . "');background-size:cover;background-attachment:fixed;background-position:center;"
        : "background-color:{$v['bg']};";
    ?>
<style id="fl-theme-vars">
:root {
    --fl-indigo: <?= $v['primary'] ?>;
    --fl-indigo-hover: <?= $v['button_hover'] ?>;
    --fl-indigo-light: <?= $v['accent_light'] ?>;
    --fl-indigo-glow: <?= $v['glow'] ?>;
    --fl-emerald: <?= $v['primary'] ?>;
    --fl-emerald-light: <?= $v['accent_light'] ?>;
    --fl-emerald-glow: <?= $v['glow'] ?>;
    --fl-navy: <?= $v['bg'] ?>;
    --fl-navy-mid: <?= $v['surface'] ?>;
    --fl-navy-light: <?= $v['surface_alt'] ?>;
    --fl-green: <?= $v['primary'] ?>;
    --fl-green-hover: <?= $v['button_hover'] ?>;
    --fl-green-light: <?= $v['accent_light'] ?>;
    --fl-green-glow: <?= $v['glow'] ?>;
    --fl-gold: var(--fl-indigo);
    --fl-gold-hover: var(--fl-indigo-hover);
    --fl-gold-light: var(--fl-indigo-light);
    --fl-amber-glow: var(--fl-indigo-glow);
    --fl-text: <?= $v['text'] ?>;
    --fl-text-muted: <?= $v['text_muted'] ?>;
    --fl-border: <?= $v['border'] ?>;
    --fl-card: <?= $v['card'] ?>;
    --fl-btn: <?= $v['button'] ?>;
    --fl-btn-hover: <?= $v['button_hover'] ?>;
}
body.fl-theme-animate, body.fl-theme-animate .fl-header, body.fl-theme-animate .fl-card,
body.fl-theme-animate .fl-project-card, body.fl-theme-animate .fl-freelancer-card,
body.fl-theme-animate .fl-search-box, body.fl-theme-animate .fl-footer {
    transition: background-color .55s ease, color .35s ease, border-color .35s ease, box-shadow .35s ease;
}
body { <?= $bgRule ?> }
body.fl-theme-light .fl-demo-strip { background: #fef9c3; color: #713f12; border-color: #fde047; }
body.fl-theme-light .fl-demo-strip a { color: #854d0e; }
.fl-btn-primary, .fl-btn-gold { background: linear-gradient(135deg, var(--fl-btn), var(--fl-btn-hover)) !important; color: <?= ($v['mode'] === 'light') ? '#fff' : 'var(--fl-navy)' ?> !important; }
.fl-btn-primary:hover, .fl-btn-gold:hover { box-shadow: 0 4px 16px color-mix(in srgb, var(--fl-btn) 35%, transparent); }
</style>
<script>
window.FL_THEME=<?= json_encode([
    'paletteId' => $v['palette_id'],
    'randomAuto' => $randomAuto,
    'intervalSec' => $interval,
    'palettes' => fl_palettes_for_js(),
    'mode' => $v['mode'],
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;
</script>
    <?php
}