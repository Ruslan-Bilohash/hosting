<?php
require_once __DIR__ . '/_bootstrap.php';
require_once dirname(__DIR__, 2) . '/includes/ecosystem-load.php';
sh_require_ecosystem('bh-cms-domain-hostinger.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sh_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$domain = bh_cms_domain_normalize((string) ($payload['domain'] ?? ''));
$product = bh_cms_domain_normalize_product((string) ($payload['product'] ?? 'shop'));

if ($domain === '') {
    $domain = function_exists('sh_license_host') ? bh_cms_domain_normalize(sh_license_host()) : '';
}

$result = bh_cms_domain_check($domain, $product);
if (!$result['ok']) {
    sh_json_response(['ok' => false, 'error' => $result['error'] ?: 'invalid_domain'], 400);
}

$lang = trim((string) ($payload['lang'] ?? $_GET['lang'] ?? 'en'));
$result['links'] = bh_cms_domain_hostinger_links($lang, $product);
sh_json_response(['ok' => true] + $result);