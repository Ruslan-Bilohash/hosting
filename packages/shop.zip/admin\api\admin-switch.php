<?php
require_once dirname(__DIR__, 2) . '/init.php';
sh_admin_require();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . sh_admin_url('index.php'), true, 302);
    exit;
}

if (!sh_admin_can_switch_users()) {
    header('Location: ' . sh_admin_url('index.php'), true, 302);
    exit;
}

$username = trim((string) ($_POST['username'] ?? ''));
$back = trim((string) ($_POST['back'] ?? '')) === '1';

if ($back) {
    if (sh_admin_switch_back()) {
        $_SESSION['sh_admin_flash'] = ['type' => 'success', 'msg' => ($t['admin']['admin_users_page']['switched_back'] ?? 'Back to owner account.')];
    }
    header('Location: ' . sh_admin_url('index.php'));
    exit;
}

if ($username !== '' && sh_admin_switch_to($username)) {
    $ta = $t['admin'] ?? [];
    $up = $ta['admin_users_page'] ?? [];
    $_SESSION['sh_admin_flash'] = ['type' => 'info', 'msg' => strtr(
        $up['switched'] ?? 'Switched to {user}.',
        ['{user}' => $username]
    )];
    header('Location: ' . sh_admin_url('index.php'));
    exit;
}

header('Location: ' . sh_admin_url('admin-users.php'), true, 302);
exit;