<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/i18n.php';
require_once __DIR__ . '/includes/seo.php';
require_once dirname(__DIR__) . '/includes/version.php';
$shsDemoTracker = dirname(__DIR__) . '/includes/demo-page-tracker.php';
if (is_file($shsDemoTracker)) {
    require_once $shsDemoTracker;
    sh_demo_tracker_product_site($lang ?? 'no');
}