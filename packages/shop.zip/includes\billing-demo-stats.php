<?php
/**
 * Demo activity monitor — storefront/product-site page views, logins, billing.
 */
declare(strict_types=1);

define('SH_DEMO_STATS_MAX', 500);
define('SH_DEMO_STATS_PAGE_DEDUP_SEC', 300);

function sh_demo_stats_path(): string
{
    return dirname(__DIR__) . '/data/billing-demo-stats.json';
}

/** @return array{events:list<array<string,mixed>>,summary:array<string,int>} */
function sh_demo_stats_defaults(): array
{
    return ['events' => [], 'summary' => []];
}

/** @return array{events:list<array<string,mixed>>,summary:array<string,int>} */
function sh_demo_stats_load(): array
{
    $path = sh_demo_stats_path();
    if (!is_file($path)) {
        return sh_demo_stats_defaults();
    }
    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        return sh_demo_stats_defaults();
    }
    $data['events'] = is_array($data['events'] ?? null) ? $data['events'] : [];
    $data['summary'] = is_array($data['summary'] ?? null) ? $data['summary'] : [];
    return array_merge(sh_demo_stats_defaults(), $data);
}

/** @param array{events:list<array<string,mixed>>,summary:array<string,int>} $data */
function sh_demo_stats_save(array $data): bool
{
    $dir = dirname(sh_demo_stats_path());
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        return false;
    }
    return file_put_contents(sh_demo_stats_path(), $json . "\n", LOCK_EX) !== false;
}

function sh_demo_stats_client_ip(): string
{
    $keys = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_REAL_IP',
        'REMOTE_ADDR',
    ];
    foreach ($keys as $key) {
        $raw = trim((string) ($_SERVER[$key] ?? ''));
        if ($raw === '') {
            continue;
        }
        if ($key === 'HTTP_X_FORWARDED_FOR') {
            $parts = array_map('trim', explode(',', $raw));
            $raw = $parts[0] ?? $raw;
        }
        if (filter_var($raw, FILTER_VALIDATE_IP)) {
            return $raw;
        }
    }
    return '0.0.0.0';
}

/** @return array<string, string> */
function sh_demo_stats_lang_countries(): array
{
    return [
        'no' => 'NO',
        'uk' => 'UA',
        'en' => 'US',
        'ru' => 'RU',
        'sv' => 'SE',
        'lt' => 'LT',
    ];
}

function sh_demo_stats_client_country(string $lang = 'en'): string
{
    $hdr = strtoupper(trim((string) ($_SERVER['HTTP_CF_IPCOUNTRY'] ?? $_SERVER['HTTP_X_COUNTRY_CODE'] ?? '')));
    if ($hdr !== '' && $hdr !== 'XX' && preg_match('/^[A-Z]{2}$/', $hdr)) {
        return $hdr;
    }
    $map = sh_demo_stats_lang_countries();
    return $map[$lang] ?? '—';
}

/**
 * @param array<string, mixed> $extra
 */
function sh_demo_stats_recent_duplicate(string $action, string $ip, string $page = ''): bool
{
    if ($ip === '' || $ip === '0.0.0.0') {
        return false;
    }
    $cutoff = time() - SH_DEMO_STATS_PAGE_DEDUP_SEC;
    foreach (sh_demo_stats_load()['events'] as $ev) {
        if ((string) ($ev['action'] ?? '') !== $action) {
            continue;
        }
        if ((string) ($ev['ip'] ?? '') !== $ip) {
            continue;
        }
        if ($page !== '' && (string) ($ev['page'] ?? '') !== $page) {
            continue;
        }
        $ts = strtotime((string) ($ev['ts'] ?? ''));
        if ($ts !== false && $ts >= $cutoff) {
            return true;
        }
    }
    return false;
}

function sh_demo_stats_record(string $action, array $extra = []): void
{
    $action = trim($action);
    if ($action === '') {
        return;
    }

    $lang = trim((string) ($extra['lang'] ?? ($_GET['lang'] ?? 'en'))) ?: 'en';
    $ip = sh_demo_stats_client_ip();
    $country = sh_demo_stats_client_country($lang);
    $page = trim((string) ($extra['page'] ?? ''));
    $zone = trim((string) ($extra['zone'] ?? ''));

    if ($action === 'page_view' && sh_demo_stats_recent_duplicate($action, $ip, $page)) {
        return;
    }

    $event = [
        'ts'      => gmdate('c'),
        'action'  => $action,
        'ip'      => $ip,
        'country' => $country,
        'lang'    => $lang,
        'user'    => trim((string) ($extra['user'] ?? '')),
        'role'    => trim((string) ($extra['role'] ?? '')),
        'plan'    => trim((string) ($extra['plan'] ?? '')),
        'page'    => $page,
        'zone'    => $zone,
        'ua'      => substr(trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 180),
    ];

    $data = sh_demo_stats_load();
    array_unshift($data['events'], $event);
    if (count($data['events']) > SH_DEMO_STATS_MAX) {
        $data['events'] = array_slice($data['events'], 0, SH_DEMO_STATS_MAX);
    }

    $data['summary']['total'] = (int) ($data['summary']['total'] ?? 0) + 1;
    $data['summary']['action:' . $action] = (int) ($data['summary']['action:' . $action] ?? 0) + 1;
    $data['summary']['country:' . $country] = (int) ($data['summary']['country:' . $country] ?? 0) + 1;

    sh_demo_stats_save($data);
}

/** @return array{total:int,unique_ips:int,page_views:int,today_views:int,top_countries:list<array{code:string,count:int}>,top_pages:list<array{page:string,count:int}>,zones:array<string,int>,actions:array<string,int>,recent:list<array<string,mixed>>} */
function sh_demo_stats_summary(): array
{
    $data = sh_demo_stats_load();
    $events = $data['events'];
    $ips = [];
    $pageIps = [];
    $countries = [];
    $pages = [];
    $zones = [];
    $actions = [];
    $pageViews = 0;
    $todayViews = 0;
    $today = gmdate('Y-m-d');

    foreach ($events as $ev) {
        $action = (string) ($ev['action'] ?? '');
        if ($action !== '') {
            $actions[$action] = ($actions[$action] ?? 0) + 1;
        }

        $ip = (string) ($ev['ip'] ?? '');
        if ($ip !== '' && $ip !== '0.0.0.0') {
            $ips[$ip] = true;
        }

        if ($action === 'page_view') {
            $pageViews++;
            $tsDay = substr((string) ($ev['ts'] ?? ''), 0, 10);
            if ($tsDay === $today) {
                $todayViews++;
            }
            if ($ip !== '' && $ip !== '0.0.0.0') {
                $pageIps[$ip] = true;
            }
            $pg = (string) ($ev['page'] ?? '');
            if ($pg !== '') {
                $pages[$pg] = ($pages[$pg] ?? 0) + 1;
            }
            $zone = (string) ($ev['zone'] ?? 'storefront');
            $zones[$zone] = ($zones[$zone] ?? 0) + 1;
        }

        $cc = (string) ($ev['country'] ?? '');
        if ($cc !== '' && $cc !== '—') {
            $countries[$cc] = ($countries[$cc] ?? 0) + 1;
        }
    }

    arsort($countries);
    $top = [];
    foreach (array_slice($countries, 0, 8, true) as $code => $count) {
        $top[] = ['code' => (string) $code, 'count' => (int) $count];
    }

    arsort($pages);
    $topPages = [];
    foreach (array_slice($pages, 0, 10, true) as $page => $count) {
        $topPages[] = ['page' => (string) $page, 'count' => (int) $count];
    }

    arsort($actions);

    return [
        'total'         => count($events),
        'unique_ips'    => count($ips),
        'page_views'    => $pageViews,
        'today_views'   => $todayViews,
        'unique_visitors' => count($pageIps),
        'top_countries' => $top,
        'top_pages'     => $topPages,
        'zones'         => $zones,
        'actions'       => $actions,
        'recent'        => array_slice($events, 0, 60),
    ];
}

define('SH_DEMO_STATS_PER_PAGE', 20);

/** @return list<array{id:string,action:string,zone:string}> */
function sh_demo_stats_section_keys(): array
{
    return [
        ['id' => 'storefront', 'action' => 'page_view', 'zone' => 'storefront'],
        ['id' => 'product_site', 'action' => 'page_view', 'zone' => 'product_site'],
        ['id' => 'admin_login', 'action' => 'admin_login', 'zone' => ''],
        ['id' => 'customer_demo_login', 'action' => 'customer_demo_login', 'zone' => ''],
        ['id' => 'billing_page', 'action' => 'billing_page', 'zone' => ''],
        ['id' => 'billing_subscribe', 'action' => 'billing_subscribe', 'zone' => ''],
        ['id' => 'billing_cancel', 'action' => 'billing_cancel', 'zone' => ''],
        ['id' => 'billing_api', 'action' => 'billing_api', 'zone' => ''],
    ];
}

/** @return list<array<string,mixed>> */
function sh_demo_stats_filter_section_events(string $sectionId): array
{
    $def = null;
    foreach (sh_demo_stats_section_keys() as $row) {
        if (($row['id'] ?? '') === $sectionId) {
            $def = $row;
            break;
        }
    }
    if ($def === null) {
        return [];
    }

    $action = (string) ($def['action'] ?? '');
    $zone = (string) ($def['zone'] ?? '');
    $out = [];
    foreach (sh_demo_stats_load()['events'] as $ev) {
        if (!is_array($ev) || (string) ($ev['action'] ?? '') !== $action) {
            continue;
        }
        if ($action === 'page_view') {
            $evZone = (string) ($ev['zone'] ?? 'storefront');
            if ($evZone !== $zone) {
                continue;
            }
        }
        $out[] = $ev;
    }

    return $out;
}

/**
 * @return array{
 *   sections:list<array{id:string,total:int,page:int,pages:int,per_page:int,events:list<array<string,mixed>>}>,
 *   active:string
 * }
 */
function sh_demo_stats_paginated_sections(string $activeTab = '', int $page = 1, int $perPage = SH_DEMO_STATS_PER_PAGE): array
{
    $perPage = max(1, min(100, $perPage));
    $page = max(1, $page);
    $sections = [];

    foreach (sh_demo_stats_section_keys() as $def) {
        $id = (string) ($def['id'] ?? '');
        if ($id === '') {
            continue;
        }
        $all = sh_demo_stats_filter_section_events($id);
        $total = count($all);
        $pages = max(1, (int) ceil($total / $perPage));
        $usePage = ($activeTab === $id) ? min($page, $pages) : 1;
        $offset = ($usePage - 1) * $perPage;
        $sections[] = [
            'id'       => $id,
            'total'    => $total,
            'page'     => $usePage,
            'pages'    => $pages,
            'per_page' => $perPage,
            'events'   => array_slice($all, $offset, $perPage),
        ];
    }

    $validIds = array_column(sh_demo_stats_section_keys(), 'id');
    if ($activeTab === '' || !in_array($activeTab, $validIds, true)) {
        $activeTab = 'storefront';
    }

    return ['sections' => $sections, 'active' => $activeTab];
}