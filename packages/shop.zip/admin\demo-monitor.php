<?php
require_once __DIR__ . '/init.php';
sh_admin_require();

if (!sh_admin_is_owner()) {
    header('Location: ' . sh_admin_url('index.php'), true, 302);
    exit;
}

require_once dirname(__DIR__) . '/includes/billing-demo-stats.php';

$admin_page = 'demo-monitor';
$mp = $ta['demo_monitor_page'] ?? [];
$st = $mp['stats'] ?? [];
$page_title = $mp['title'] ?? 'Demo monitor';

$stats = sh_demo_stats_summary();
$actionLabels = is_array($mp['actions'] ?? null) ? $mp['actions'] : [];
$zoneLabels = is_array($mp['zones'] ?? null) ? $mp['zones'] : [];

$activeTab = trim((string) ($_GET['tab'] ?? 'storefront'));
$pageNum = max(1, (int) ($_GET['p'] ?? 1));
$paged = sh_demo_stats_paginated_sections($activeTab, $pageNum);
$activeTab = $paged['active'];
$sections = $paged['sections'];
$activeSection = null;
foreach ($sections as $sec) {
    if (($sec['id'] ?? '') === $activeTab) {
        $activeSection = $sec;
        break;
    }
}
if ($activeSection === null) {
    $activeSection = $sections[0] ?? ['id' => 'storefront', 'total' => 0, 'page' => 1, 'pages' => 1, 'per_page' => SH_DEMO_STATS_PER_PAGE, 'events' => []];
}

function sh_demo_monitor_section_label(string $id, array $actionLabels, array $zoneLabels): string
{
    if (isset($zoneLabels[$id])) {
        return (string) $zoneLabels[$id];
    }
    return (string) ($actionLabels[$id] ?? $id);
}

function sh_demo_monitor_tab_url(string $tab, int $page = 1): string
{
    $q = ['tab' => $tab];
    if ($page > 1) {
        $q['p'] = $page;
    }
    return sh_admin_url('demo-monitor.php?' . http_build_query($q));
}

$admin_extra_js = [sh_asset('js/admin-demo-monitor.js') . '?v=2'];

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-dm-page" id="shDemoMonitor"
     data-api="<?= htmlspecialchars(sh_admin_url('api/demo-monitor.php')) ?>"
     data-lang="<?= htmlspecialchars($lang) ?>">

    <div class="adm-dm-head">
        <p class="adm-dm-intro"><?= htmlspecialchars($mp['intro'] ?? 'Live stats for demo storefront, product site and admin demo activity.') ?></p>
        <button type="button" class="adm-btn adm-btn-outline adm-btn-xs" id="shDemoMonitorRefresh">
            <i class="fas fa-rotate"></i> <?= htmlspecialchars($st['refresh'] ?? 'Refresh') ?>
        </button>
    </div>

    <div class="adm-dm-kpis" id="shDemoMonitorKpis">
        <span class="adm-dm-kpi"><strong data-kpi="page_views"><?= (int) $stats['page_views'] ?></strong> <?= htmlspecialchars($st['page_views'] ?? 'Page views') ?></span>
        <span class="adm-dm-kpi"><strong data-kpi="today_views"><?= (int) $stats['today_views'] ?></strong> <?= htmlspecialchars($st['today_views'] ?? 'Today') ?></span>
        <span class="adm-dm-kpi"><strong data-kpi="unique_visitors"><?= (int) ($stats['unique_visitors'] ?? 0) ?></strong> <?= htmlspecialchars($st['unique_visitors'] ?? 'Unique visitors') ?></span>
        <span class="adm-dm-kpi"><strong data-kpi="total"><?= (int) $stats['total'] ?></strong> <?= htmlspecialchars($st['total_events'] ?? 'All events') ?></span>
    </div>

    <nav class="adm-dm-tabs" aria-label="<?= htmlspecialchars($mp['sections_aria'] ?? 'Event sections') ?>">
        <?php foreach ($sections as $sec):
            $sid = (string) ($sec['id'] ?? '');
            $isActive = $sid === $activeTab;
            $label = sh_demo_monitor_section_label($sid, $actionLabels, $zoneLabels);
            ?>
        <a href="<?= htmlspecialchars(sh_demo_monitor_tab_url($sid)) ?>"
           class="adm-dm-tab<?= $isActive ? ' is-active' : '' ?>">
            <?= htmlspecialchars($label) ?>
            <span class="adm-dm-tab-count"><?= (int) ($sec['total'] ?? 0) ?></span>
        </a>
        <?php endforeach; ?>
    </nav>

    <div class="adm-card adm-dm-card">
        <div class="adm-card-head adm-dm-card-head">
            <h2><?= htmlspecialchars(sh_demo_monitor_section_label($activeTab, $actionLabels, $zoneLabels)) ?></h2>
            <span class="adm-muted adm-text-sm">
                <?= htmlspecialchars(str_replace(
                    ['{shown}', '{total}', '{page}', '{pages}'],
                    [
                        (string) count($activeSection['events'] ?? []),
                        (string) (int) ($activeSection['total'] ?? 0),
                        (string) (int) ($activeSection['page'] ?? 1),
                        (string) (int) ($activeSection['pages'] ?? 1),
                    ],
                    $st['list_meta'] ?? '{shown} of {total} · page {page}/{pages}'
                )) ?>
            </span>
        </div>
        <div class="adm-card-body padded adm-dm-card-body">
            <div class="adm-table-wrap adm-dm-table-wrap">
                <table class="adm-table adm-dm-table">
                    <thead>
                        <tr>
                            <th><?= htmlspecialchars($st['col_time'] ?? 'Time') ?></th>
                            <?php if (str_starts_with($activeTab, 'billing') || in_array($activeTab, ['admin_login', 'customer_demo_login'], true)): ?>
                            <th><?= htmlspecialchars($st['col_user'] ?? 'User') ?></th>
                            <?php else: ?>
                            <th><?= htmlspecialchars($st['col_page'] ?? 'Page') ?></th>
                            <?php endif; ?>
                            <th><?= htmlspecialchars($st['col_country'] ?? 'Country') ?></th>
                            <th><?= htmlspecialchars($st['col_ip'] ?? 'IP') ?></th>
                            <th><?= htmlspecialchars($st['col_lang'] ?? 'Lang') ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($activeSection['events'])): ?>
                        <tr><td colspan="5" class="adm-muted"><?= htmlspecialchars($st['no_data'] ?? 'No data yet') ?></td></tr>
                        <?php else: foreach ($activeSection['events'] as $ev): ?>
                        <tr>
                            <td><?= htmlspecialchars(date('m-d H:i', strtotime((string) ($ev['ts'] ?? 'now')))) ?></td>
                            <?php if (str_starts_with($activeTab, 'billing') || in_array($activeTab, ['admin_login', 'customer_demo_login'], true)): ?>
                            <td><?= htmlspecialchars((string) ($ev['user'] ?? '—')) ?></td>
                            <?php else: ?>
                            <td><?= ($ev['page'] ?? '') !== '' ? '<code>' . htmlspecialchars((string) $ev['page']) . '</code>' : '—' ?></td>
                            <?php endif; ?>
                            <td><?= htmlspecialchars((string) ($ev['country'] ?? '—')) ?></td>
                            <td><code><?= htmlspecialchars((string) ($ev['ip'] ?? '')) ?></code></td>
                            <td><?= htmlspecialchars(strtoupper((string) ($ev['lang'] ?? ''))) ?></td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <?php
            $curPage = (int) ($activeSection['page'] ?? 1);
            $totalPages = (int) ($activeSection['pages'] ?? 1);
            if ($totalPages > 1):
            ?>
            <nav class="adm-dm-pager" aria-label="<?= htmlspecialchars($st['pager_aria'] ?? 'Pagination') ?>">
                <?php if ($curPage > 1): ?>
                <a class="adm-btn adm-btn-outline adm-btn-xs" href="<?= htmlspecialchars(sh_demo_monitor_tab_url($activeTab, $curPage - 1)) ?>">
                    <i class="fas fa-chevron-left"></i> <?= htmlspecialchars($st['prev'] ?? 'Prev') ?>
                </a>
                <?php endif; ?>
                <span class="adm-dm-pager-info">
                    <?= htmlspecialchars(str_replace(
                        ['{page}', '{pages}'],
                        [(string) $curPage, (string) $totalPages],
                        $st['page_of'] ?? 'Page {page} of {pages}'
                    )) ?>
                </span>
                <?php if ($curPage < $totalPages): ?>
                <a class="adm-btn adm-btn-outline adm-btn-xs" href="<?= htmlspecialchars(sh_demo_monitor_tab_url($activeTab, $curPage + 1)) ?>">
                    <?= htmlspecialchars($st['next'] ?? 'Next') ?> <i class="fas fa-chevron-right"></i>
                </a>
                <?php endif; ?>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>