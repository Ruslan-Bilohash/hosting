<?php
require_once __DIR__ . '/init.php';
sh_admin_require();

$admin_page = 'support';
$ta = $t['admin'] ?? [];
$sp = $ta['support_page'] ?? [];
$page_title = $sp['title'] ?? 'Support & mail';

$apiOwner = sh_admin_url('api/owner-message.php');
$apiAi = sh_admin_url('api/ai-compose-message.php');
$aiThinking = (string) (($ta['ai_agent_page'] ?? [])['thinking'] ?? 'Thinking…');

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-support-page">
    <div class="adm-leads-hero">
        <div class="adm-leads-hero-text">
            <h2 class="adm-leads-title"><i class="fas fa-headset"></i> <?= htmlspecialchars($page_title) ?></h2>
            <p><?= htmlspecialchars($sp['help'] ?? '') ?></p>
        </div>
        <?php if (function_exists('sh_admin_is_owner') && sh_admin_is_owner()): ?>
        <a href="https://bilohash.com/ecosystem/admin.php<?= $lang !== 'en' ? '?lang=' . urlencode($lang === 'uk' ? 'ua' : $lang) : '' ?>#admin-messages" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank" rel="noopener">
            <i class="fas fa-inbox"></i> <?= htmlspecialchars($sp['inbox_link'] ?? 'Support inbox') ?>
        </a>
        <?php endif; ?>
    </div>

    <div class="adm-support-tabs" role="tablist">
        <button type="button" class="adm-support-tab is-active" data-tab="owner" role="tab" aria-selected="true">
            <i class="fas fa-comments"></i> <?= htmlspecialchars($sp['tab_owner'] ?? 'General ecosystem chat') ?>
        </button>
        <button type="button" class="adm-support-tab" data-tab="client" role="tab" aria-selected="false">
            <i class="fas fa-user"></i> <?= htmlspecialchars($sp['tab_client'] ?? 'Email to customer') ?>
        </button>
    </div>

    <div class="adm-card adm-support-panel" id="admSupportOwner" data-panel="owner">
        <div class="adm-card-body padded">
            <p class="adm-muted adm-support-hint"><?= htmlspecialchars($sp['owner_hint'] ?? '') ?></p>
            <div class="adm-form-grid adm-form-grid--2">
                <div>
                    <label class="adm-label" for="owner_category"><?= htmlspecialchars($sp['category'] ?? 'Category') ?></label>
                    <select id="owner_category" class="adm-input">
                        <option value="support"><?= htmlspecialchars($sp['cat_support'] ?? 'Support') ?></option>
                        <option value="bug"><?= htmlspecialchars($sp['cat_bug'] ?? 'Bug') ?></option>
                        <option value="billing"><?= htmlspecialchars($sp['cat_billing'] ?? 'Billing') ?></option>
                        <option value="feature"><?= htmlspecialchars($sp['cat_feature'] ?? 'Feature') ?></option>
                        <option value="other"><?= htmlspecialchars($sp['cat_other'] ?? 'Other') ?></option>
                    </select>
                </div>
                <div>
                    <label class="adm-label" for="owner_email"><?= htmlspecialchars($sp['your_email'] ?? 'Your email') ?></label>
                    <input type="email" id="owner_email" class="adm-input" placeholder="you@example.com">
                    <p class="adm-hint"><?= htmlspecialchars($sp['your_email_hint'] ?? '') ?></p>
                </div>
            </div>
            <div class="adm-form-group">
                <label class="adm-label" for="owner_draft"><?= htmlspecialchars($sp['draft_notes'] ?? 'Draft') ?></label>
                <textarea id="owner_draft" class="adm-input" rows="3" placeholder="<?= htmlspecialchars($sp['draft_notes'] ?? '') ?>"></textarea>
            </div>
            <div class="adm-support-ai-panel" id="owner_ai_panel">
                <div class="adm-support-ai-actions">
                    <button type="button" class="adm-btn adm-btn-primary adm-btn-ai-generate" id="owner_ai_btn"
                            data-thinking="<?= htmlspecialchars($aiThinking) ?>"
                            data-label-default="<?= htmlspecialchars($sp['ai_compose'] ?? 'Improve with AI') ?>">
                        <i class="fas fa-wand-magic-sparkles adm-ai-btn-icon" aria-hidden="true"></i>
                        <span class="adm-ai-btn-label"><?= htmlspecialchars($sp['ai_compose'] ?? 'Improve with AI') ?></span>
                    </button>
                    <p class="adm-ai-status adm-ai-status--block" id="owner_ai_status" hidden role="status"></p>
                </div>
            </div>
            <div class="adm-form-group">
                <label class="adm-label" for="owner_subject"><?= htmlspecialchars($sp['subject'] ?? 'Subject') ?></label>
                <input type="text" id="owner_subject" class="adm-input" required>
            </div>
            <div class="adm-form-group">
                <label class="adm-label" for="owner_body"><?= htmlspecialchars($sp['message'] ?? 'Message') ?></label>
                <textarea id="owner_body" class="adm-input" rows="8" required></textarea>
            </div>
            <div class="adm-form-actions adm-support-send-row">
                <button type="button" class="adm-btn adm-btn-primary adm-btn-support-send" id="owner_send_btn">
                    <i class="fas fa-paper-plane"></i> <?= htmlspecialchars($sp['send_owner'] ?? 'Send') ?>
                </button>
            </div>
            <p class="adm-support-status" id="owner_status" hidden></p>
        </div>
    </div>

    <div class="adm-card adm-support-panel" id="admSupportClient" data-panel="client" hidden>
        <div class="adm-card-body padded">
            <p class="adm-muted adm-support-hint"><?= htmlspecialchars($sp['client_hint'] ?? '') ?></p>
            <div class="adm-form-grid adm-form-grid--2">
                <div>
                    <label class="adm-label" for="client_name"><?= htmlspecialchars($sp['client_name'] ?? 'Customer') ?></label>
                    <input type="text" id="client_name" class="adm-input" placeholder="Anna K.">
                </div>
                <div>
                    <label class="adm-label" for="client_topic"><?= htmlspecialchars($sp['client_topic'] ?? 'Topic') ?></label>
                    <input type="text" id="client_topic" class="adm-input" placeholder="Order #1042">
                </div>
            </div>
            <div class="adm-form-group">
                <label class="adm-label" for="client_draft"><?= htmlspecialchars($sp['draft_notes'] ?? 'Notes') ?></label>
                <textarea id="client_draft" class="adm-input" rows="4"></textarea>
            </div>
            <div class="adm-support-ai-panel" id="client_ai_panel">
                <div class="adm-support-ai-actions">
                    <button type="button" class="adm-btn adm-btn-primary adm-btn-ai-generate" id="client_ai_btn"
                            data-thinking="<?= htmlspecialchars($aiThinking) ?>"
                            data-label-default="<?= htmlspecialchars($sp['ai_compose_client'] ?? 'Draft with AI') ?>">
                        <i class="fas fa-wand-magic-sparkles adm-ai-btn-icon" aria-hidden="true"></i>
                        <span class="adm-ai-btn-label"><?= htmlspecialchars($sp['ai_compose_client'] ?? 'Draft with AI') ?></span>
                    </button>
                    <p class="adm-ai-status adm-ai-status--block" id="client_ai_status" hidden role="status"></p>
                </div>
            </div>
            <div class="adm-form-group">
                <label class="adm-label" for="client_subject"><?= htmlspecialchars($sp['subject'] ?? 'Subject') ?></label>
                <input type="text" id="client_subject" class="adm-input">
            </div>
            <div class="adm-form-group">
                <label class="adm-label" for="client_body"><?= htmlspecialchars($sp['message'] ?? 'Message') ?></label>
                <textarea id="client_body" class="adm-input" rows="8"></textarea>
            </div>
            <div class="adm-form-actions adm-support-client-actions">
                <button type="button" class="adm-btn adm-btn-outline adm-btn-support-secondary" id="client_copy_btn">
                    <i class="fas fa-copy"></i> <?= htmlspecialchars($sp['copy_draft'] ?? 'Copy') ?>
                </button>
                <button type="button" class="adm-btn adm-btn-primary adm-btn-support-send" id="client_mailto_btn">
                    <i class="fas fa-envelope"></i> <?= htmlspecialchars($sp['mailto_client'] ?? 'Mail app') ?>
                </button>
            </div>
            <p class="adm-support-status" id="client_status" hidden></p>
        </div>
    </div>
</div>

<script>
(function () {
    const LANG = <?= json_encode($lang, JSON_UNESCAPED_UNICODE) ?>;
    const API_OWNER = <?= json_encode($apiOwner) ?>;
    const API_AI = <?= json_encode($apiAi) ?>;
    const MSG = {
        sent_ok: <?= json_encode($sp['sent_ok'] ?? 'Sent.') ?>,
        sent_error: <?= json_encode($sp['sent_error'] ?? 'Error.') ?>,
        ai_error: <?= json_encode($sp['ai_error'] ?? 'AI error.') ?>,
        copied: <?= json_encode($sp['copied'] ?? 'Copied.') ?>,
    };

    document.querySelectorAll('.adm-support-tab').forEach(function (tab) {
        tab.addEventListener('click', function () {
            const id = tab.getAttribute('data-tab');
            document.querySelectorAll('.adm-support-tab').forEach(function (t) {
                t.classList.toggle('is-active', t === tab);
                t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
            });
            document.querySelectorAll('.adm-support-panel').forEach(function (p) {
                p.hidden = p.getAttribute('data-panel') !== id;
            });
        });
    });

    async function aiCompose(mode, draft, extra) {
        const res = await fetch(API_AI, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify(Object.assign({ mode: mode, draft: draft, lang: LANG }, extra || {})),
        });
        return res.json();
    }

    function setAiLoading(btn, panel, statusEl, loading) {
        if (!btn) return;
        btn.classList.toggle('is-loading', loading);
        btn.disabled = loading;
        if (panel) panel.classList.toggle('is-ai-thinking', loading);
        var icon = btn.querySelector('.adm-ai-btn-icon');
        var label = btn.querySelector('.adm-ai-btn-label');
        if (icon) {
            icon.className = loading ? 'fas fa-brain adm-ai-btn-icon' : 'fas fa-wand-magic-sparkles adm-ai-btn-icon';
        }
        if (label) {
            label.textContent = loading
                ? (btn.getAttribute('data-thinking') || 'Thinking…')
                : (btn.getAttribute('data-label-default') || label.textContent);
        }
        if (statusEl) {
            if (loading) {
                statusEl.hidden = false;
                statusEl.className = 'adm-ai-status adm-ai-status--block adm-ai-status--loading';
                statusEl.innerHTML = (btn.getAttribute('data-thinking') || 'Thinking…')
                    + ' <span class="adm-ai-thinking-dots" aria-hidden="true"><span></span><span></span><span></span></span>';
            } else {
                statusEl.hidden = true;
                statusEl.textContent = '';
            }
        }
    }

    document.getElementById('owner_ai_btn').addEventListener('click', async function () {
        const btn = this;
        const panel = document.getElementById('owner_ai_panel');
        const statusEl = document.getElementById('owner_ai_status');
        setAiLoading(btn, panel, statusEl, true);
        try {
            const data = await aiCompose('owner_support', document.getElementById('owner_draft').value, {});
            if (!data.ok) throw new Error(data.error || MSG.ai_error);
            if (data.subject) document.getElementById('owner_subject').value = data.subject;
            if (data.body) document.getElementById('owner_body').value = data.body;
        } catch (e) {
            alert(e.message || MSG.ai_error);
        } finally {
            setAiLoading(btn, panel, statusEl, false);
        }
    });

    document.getElementById('owner_send_btn').addEventListener('click', async function () {
        const status = document.getElementById('owner_status');
        const subject = document.getElementById('owner_subject').value.trim();
        const body = document.getElementById('owner_body').value.trim();
        if (!subject || !body) return;
        const btn = this;
        btn.disabled = true;
        status.hidden = true;
        try {
            const res = await fetch(API_OWNER, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({
                    subject: subject,
                    body: body,
                    category: document.getElementById('owner_category').value,
                    from_email: document.getElementById('owner_email').value.trim(),
                    lang: LANG,
                }),
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.error || MSG.sent_error);
            status.textContent = MSG.sent_ok;
            status.className = 'adm-support-status is-ok';
            status.hidden = false;
            document.getElementById('owner_draft').value = '';
        } catch (e) {
            status.textContent = e.message || MSG.sent_error;
            status.className = 'adm-support-status is-err';
            status.hidden = false;
        } finally {
            btn.disabled = false;
        }
    });

    document.getElementById('client_ai_btn').addEventListener('click', async function () {
        const btn = this;
        const panel = document.getElementById('client_ai_panel');
        const statusEl = document.getElementById('client_ai_status');
        setAiLoading(btn, panel, statusEl, true);
        try {
            const data = await aiCompose('client_email', document.getElementById('client_draft').value, {
                client_name: document.getElementById('client_name').value.trim(),
                topic: document.getElementById('client_topic').value.trim(),
            });
            if (!data.ok) throw new Error(data.error || MSG.ai_error);
            if (data.subject) document.getElementById('client_subject').value = data.subject;
            if (data.body) document.getElementById('client_body').value = data.body;
        } catch (e) {
            alert(e.message || MSG.ai_error);
        } finally {
            setAiLoading(btn, panel, statusEl, false);
        }
    });

    document.getElementById('client_copy_btn').addEventListener('click', function () {
        const text = (document.getElementById('client_subject').value ? 'Subject: ' + document.getElementById('client_subject').value + '\n\n' : '')
            + document.getElementById('client_body').value;
        navigator.clipboard.writeText(text).then(function () {
            const st = document.getElementById('client_status');
            st.textContent = MSG.copied;
            st.className = 'adm-support-status is-ok';
            st.hidden = false;
        });
    });

    document.getElementById('client_mailto_btn').addEventListener('click', function () {
        const sub = encodeURIComponent(document.getElementById('client_subject').value || '');
        const body = encodeURIComponent(document.getElementById('client_body').value || '');
        window.location.href = 'mailto:?subject=' + sub + '&body=' + body;
    });
})();
</script>

<?php require __DIR__ . '/includes/layout-end.php'; ?>