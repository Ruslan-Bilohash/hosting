<?php
require_once __DIR__ . '/_bootstrap.php';
require_once dirname(__DIR__, 2) . '/includes/license-runtime.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sh_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$action = trim((string) ($payload['action'] ?? 'sync'));
$status = sh_license_status();

if ($status['status'] !== 'licensed') {
    sh_json_response([
        'ok'    => false,
        'error' => 'license_required',
        'message' => 'Activate a BHSHOP license key to manage connected domains',
    ], 403);
}

if ($action === 'detach') {
    if (!sh_admin_is_owner()) {
        sh_json_response(['ok' => false, 'error' => 'forbidden'], 403);
    }
    $domain = strtolower(trim((string) ($payload['domain'] ?? '')));
    if ($domain === '') {
        sh_json_response(['ok' => false, 'error' => 'invalid_domain'], 400);
    }
    $host = sh_license_host();
    if ($domain === $host) {
        sh_json_response(['ok' => false, 'error' => 'cannot_detach_current'], 400);
    }
    $result = sh_license_unregister_site($domain);
    if (!$result['ok']) {
        sh_json_response(['ok' => false, 'error' => $result['error'] ?: 'detach_failed'], 400);
    }
    sh_json_response([
        'ok'          => true,
        'action'      => 'detach',
        'sites_count' => $result['sites_count'],
        'sites'       => $result['sites'],
        'removed'     => $domain,
    ]);
}

$reg = sh_license_register_site();
$info = sh_license_verify_current(false);
sh_json_response([
    'ok'           => $reg['ok'],
    'action'       => 'sync',
    'sites_count'  => $info['sites_count'],
    'sites'        => $info['sites'],
    'days_left'    => $info['days_left'],
    'exp_label'    => $info['exp_label'],
    'license_status' => $status['status'],
    'error'        => $reg['error'],
    'synced_at'    => gmdate('c'),
], $reg['ok'] ? 200 : 400);