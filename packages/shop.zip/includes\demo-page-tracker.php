<?php
/**
 * Record public demo storefront / product-site page views for owner monitor.
 */
declare(strict_types=1);

function sh_demo_tracker_skip_request(): bool
{
    if (PHP_SAPI === 'cli') {
        return true;
    }
    if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
        return true;
    }
    $uri = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?? '/');
    if ($uri === '') {
        return true;
    }
    if (preg_match('#/(admin|api|assets|cron|install)(/|$)#i', $uri)) {
        return true;
    }
    if (preg_match('#\.(css|js|json|xml|txt|map|woff2?|png|jpe?g|gif|svg|ico|webp|zip)$#i', $uri)) {
        return true;
    }
    return false;
}

function sh_demo_tracker_normalize_page(string $uri, string $basePath): string
{
    $base = rtrim($basePath, '/');
    $path = $uri;
    if ($base !== '' && str_starts_with($path, $base)) {
        $path = substr($path, strlen($base)) ?: '/';
    }
    $path = '/' . ltrim($path, '/');
    if ($path === '/') {
        return '/index.php';
    }
    return $path;
}

function sh_demo_tracker_record(string $zone, string $basePath, string $lang = 'en'): void
{
    if (sh_demo_tracker_skip_request()) {
        return;
    }
    $statsFile = __DIR__ . '/billing-demo-stats.php';
    if (!is_file($statsFile)) {
        return;
    }
    require_once $statsFile;

    $uri = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?? '/');
    $page = sh_demo_tracker_normalize_page($uri, $basePath);

    sh_demo_stats_record('page_view', [
        'lang' => $lang,
        'page' => $page,
        'zone' => $zone,
    ]);
}

function sh_demo_tracker_storefront(string $lang = 'en'): void
{
    $base = defined('SH_BASE_PATH') ? (string) SH_BASE_PATH : '/shop';
    sh_demo_tracker_record('storefront', $base, $lang);
}

function sh_demo_tracker_product_site(string $lang = 'no'): void
{
    $base = defined('SHS_BASE_PATH') ? (string) SHS_BASE_PATH : '/shop/site';
    sh_demo_tracker_record('product_site', $base, $lang);
}