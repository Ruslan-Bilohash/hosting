<?php
/**
 * Hostinger MySQL — bilohash.com/shop/install/
 * Do not commit (gitignored).
 */
return [
    'host'     => 'localhost',
    'database' => 'u762384583_shop',
    'user'     => 'u762384583_shop',
    'pass'     => 'Odifarka78@',
    'prefix'   => 'sh_',
];