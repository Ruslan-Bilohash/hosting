<?php
/**
 * Admin panel users — JSON storage in data/admin-users.json.
 * Owner manages accounts; demo accounts stay in sh_admin_demo_accounts().
 */

function sh_admin_users_data_dir(): string
{
    return dirname(__DIR__) . '/data';
}

function sh_admin_users_file(): string
{
    return sh_admin_users_data_dir() . '/admin-users.json';
}

function sh_admin_login_meta_file(): string
{
    return sh_admin_users_data_dir() . '/admin-login-meta.json';
}

function sh_admin_client_ip(): string
{
    if (function_exists('sh_demo_stats_client_ip')) {
        return sh_demo_stats_client_ip();
    }
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($keys as $key) {
        $raw = trim((string) ($_SERVER[$key] ?? ''));
        if ($raw === '') {
            continue;
        }
        if ($key === 'HTTP_X_FORWARDED_FOR') {
            $parts = array_map('trim', explode(',', $raw));
            $raw = $parts[0] ?? $raw;
        }
        if (filter_var($raw, FILTER_VALIDATE_IP)) {
            return $raw;
        }
    }
    return '0.0.0.0';
}

/** @return array{logins:array<string,array<string,mixed>>,overrides:array<string,array<string,mixed>>} */
function sh_admin_login_meta_load(): array
{
    static $cache = null;
    if (is_array($cache)) {
        return $cache;
    }
    $defaults = ['logins' => [], 'overrides' => []];
    $file = sh_admin_login_meta_file();
    if (!is_readable($file)) {
        $cache = $defaults;
        return $cache;
    }
    $data = json_decode((string) file_get_contents($file), true);
    if (!is_array($data)) {
        $cache = $defaults;
        return $cache;
    }
    $cache = [
        'logins' => is_array($data['logins'] ?? null) ? $data['logins'] : [],
        'overrides' => is_array($data['overrides'] ?? null) ? $data['overrides'] : [],
    ];
    return $cache;
}

/** @param array{logins:array<string,array<string,mixed>>,overrides:array<string,array<string,mixed>>} $data */
function sh_admin_login_meta_save(array $data): bool
{
    $dir = sh_admin_users_data_dir();
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    $payload = json_encode(
        [
            'logins' => $data['logins'] ?? [],
            'overrides' => $data['overrides'] ?? [],
        ],
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );
    if ($payload === false) {
        return false;
    }
    $ok = file_put_contents(sh_admin_login_meta_file(), $payload . "\n", LOCK_EX) !== false;
    if ($ok) {
        $GLOBALS['sh_admin_login_meta_cache_reset'] = true;
    }
    return $ok;
}

function sh_admin_record_login(string $username): void
{
    $username = trim($username);
    if ($username === '') {
        return;
    }
    $data = sh_admin_login_meta_load();
    $prev = is_array($data['logins'][$username] ?? null) ? $data['logins'][$username] : [];
    $data['logins'][$username] = [
        'last_ip' => sh_admin_client_ip(),
        'last_login_at' => gmdate('c'),
        'login_count' => (int) ($prev['login_count'] ?? 0) + 1,
    ];
    sh_admin_login_meta_save($data);
}

/** @return array{last_ip:string,last_login_at:string,login_count:int} */
function sh_admin_login_meta_for(string $username): array
{
    $username = trim($username);
    $empty = ['last_ip' => '', 'last_login_at' => '', 'login_count' => 0];
    if ($username === '') {
        return $empty;
    }

    $row = sh_admin_login_meta_load()['logins'][$username] ?? null;
    if (is_array($row) && (!empty($row['last_ip']) || !empty($row['last_login_at']))) {
        return [
            'last_ip' => (string) ($row['last_ip'] ?? ''),
            'last_login_at' => (string) ($row['last_login_at'] ?? ''),
            'login_count' => (int) ($row['login_count'] ?? 0),
        ];
    }

    if (is_readable(__DIR__ . '/billing-demo-stats.php')) {
        require_once __DIR__ . '/billing-demo-stats.php';
        foreach (sh_demo_stats_load()['events'] as $ev) {
            if ((string) ($ev['action'] ?? '') !== 'admin_login' || (string) ($ev['user'] ?? '') !== $username) {
                continue;
            }
            return [
                'last_ip' => (string) ($ev['ip'] ?? ''),
                'last_login_at' => (string) ($ev['ts'] ?? ''),
                'login_count' => 0,
            ];
        }
    }

    return $empty;
}

function sh_admin_user_name_override(string $username): string
{
    $username = trim($username);
    if ($username === '') {
        return '';
    }
    $override = sh_admin_login_meta_load()['overrides'][$username]['name'] ?? '';
    return trim((string) $override);
}

function sh_admin_format_last_login(string $iso): string
{
    $iso = trim($iso);
    if ($iso === '') {
        return '';
    }
    if (function_exists('sh_license_format_last_seen')) {
        return sh_license_format_last_seen($iso);
    }
    $ts = strtotime($iso);
    return $ts !== false ? gmdate('Y-m-d H:i', $ts) . ' UTC' : $iso;
}

/** @return array{users:list<array<string,mixed>>} */
function sh_admin_users_load(): array
{
    static $cache = null;
    if (is_array($cache)) {
        return $cache;
    }
    $file = sh_admin_users_file();
    if (!is_readable($file)) {
        $cache = ['users' => []];
        return $cache;
    }
    $raw = file_get_contents($file);
    $data = json_decode((string) $raw, true);
    if (!is_array($data) || !isset($data['users']) || !is_array($data['users'])) {
        $cache = ['users' => []];
        return $cache;
    }
    $cache = ['users' => array_values($data['users'])];
    return $cache;
}

/** @param array{users:list<array<string,mixed>>} $data */
function sh_admin_users_save(array $data): bool
{
    $dir = sh_admin_users_data_dir();
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    $payload = json_encode(
        ['users' => array_values($data['users'] ?? [])],
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );
    if ($payload === false) {
        return false;
    }
    $ok = file_put_contents(sh_admin_users_file(), $payload . "\n", LOCK_EX) !== false;
    if ($ok) {
        $GLOBALS['sh_admin_users_cache_reset'] = true;
    }
    return $ok;
}

function sh_admin_username_valid(string $username): bool
{
    return (bool) preg_match('/^[a-zA-Z0-9_.-]{3,32}$/', $username);
}

/** @param array<string,mixed> $base */
function sh_admin_users_apply_meta(array $base): array
{
    $username = (string) ($base['username'] ?? '');
    $nameOverride = sh_admin_user_name_override($username);
    if ($nameOverride !== '') {
        $base['name'] = $nameOverride;
    }
    $login = sh_admin_login_meta_for($username);
    $base['last_ip'] = (string) ($login['last_ip'] ?? '');
    $base['last_login_at'] = (string) ($login['last_login_at'] ?? '');
    $base['login_count'] = (int) ($login['login_count'] ?? 0);
    return $base;
}

/** @return list<array{id:string,username:string,role:string,name:string,source:string,protected:bool,last_ip:string,last_login_at:string,login_count:int}> */
function sh_admin_users_list_accounts(): array
{
    require_once __DIR__ . '/admin-auth.php';

    $out = [];
    $seen = [];

    $creds = sh_admin_credentials();
    if (!empty($creds['user']) && ($creds['pass_hash'] !== null || $creds['pass_plain'] !== null)) {
        $u = (string) $creds['user'];
        $seen[$u] = true;
        $out[] = sh_admin_users_apply_meta([
            'id'        => 'config:' . $u,
            'username'  => $u,
            'role'      => 'owner',
            'name'      => $u,
            'source'    => 'config',
            'protected' => true,
            'editable'  => true,
        ]);
    }

    foreach (sh_admin_demo_accounts() as $acc) {
        $u = (string) ($acc['user'] ?? '');
        if ($u === '' || isset($seen[$u])) {
            continue;
        }
        $seen[$u] = true;
        $out[] = sh_admin_users_apply_meta([
            'id'        => 'demo:' . $u,
            'username'  => $u,
            'role'      => (string) ($acc['role'] ?? 'demo'),
            'name'      => (string) ($acc['name'] ?? $u),
            'source'    => 'demo',
            'protected' => true,
            'editable'  => true,
        ]);
    }

    foreach (sh_admin_users_load()['users'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $u = trim((string) ($row['username'] ?? ''));
        if ($u === '' || isset($seen[$u])) {
            continue;
        }
        $seen[$u] = true;
        $out[] = sh_admin_users_apply_meta([
            'id'        => (string) ($row['id'] ?? $u),
            'username'  => $u,
            'role'      => (string) ($row['role'] ?? 'admin'),
            'name'      => (string) ($row['name'] ?? $u),
            'source'    => 'custom',
            'protected' => !empty($row['protected']),
            'editable'  => empty($row['protected']),
        ]);
    }

    return $out;
}

/** @return ?array<string,mixed> */
function sh_admin_user_record_by_username(string $username): ?array
{
    $username = trim($username);
    if ($username === '') {
        return null;
    }

    require_once __DIR__ . '/admin-auth.php';

    $creds = sh_admin_credentials();
    if ($username === (string) ($creds['user'] ?? '')) {
        $name = $username;
        $override = sh_admin_user_name_override($username);
        if ($override !== '') {
            $name = $override;
        }
        return [
            'id'       => 'config:' . $username,
            'username' => $username,
            'role'     => 'owner',
            'name'     => $name,
            'source'   => 'config',
        ];
    }

    foreach (sh_admin_demo_accounts() as $acc) {
        if ($username === (string) ($acc['user'] ?? '')) {
            $name = (string) ($acc['name'] ?? $username);
            $override = sh_admin_user_name_override($username);
            if ($override !== '') {
                $name = $override;
            }
            return [
                'id'       => 'demo:' . $username,
                'username' => $username,
                'role'     => (string) ($acc['role'] ?? 'demo'),
                'name'     => $name,
                'source'   => 'demo',
                'pass'     => (string) ($acc['pass'] ?? ''),
            ];
        }
    }

    foreach (sh_admin_users_load()['users'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        if ($username === (string) ($row['username'] ?? '')) {
            return $row + ['source' => 'custom'];
        }
    }

    return null;
}

function sh_admin_user_verify_password(string $username, string $pass): bool
{
    require_once __DIR__ . '/admin-auth.php';

    $creds = sh_admin_credentials();
    if ($username === (string) ($creds['user'] ?? '')) {
        if ($creds['pass_hash'] !== null) {
            return password_verify($pass, (string) $creds['pass_hash']);
        }
        return $pass === (string) ($creds['pass_plain'] ?? '');
    }

    foreach (sh_admin_demo_accounts() as $acc) {
        if ($username === (string) ($acc['user'] ?? '') && $pass === (string) ($acc['pass'] ?? '')) {
            return true;
        }
    }

    foreach (sh_admin_users_load()['users'] as $row) {
        if (!is_array($row) || $username !== (string) ($row['username'] ?? '')) {
            continue;
        }
        $hash = (string) ($row['pass_hash'] ?? '');
        return $hash !== '' && password_verify($pass, $hash);
    }

    return false;
}

function sh_admin_user_create(string $username, string $pass, string $role, string $name): array
{
    $username = trim($username);
    $name = trim($name) ?: $username;
    $role = in_array($role, ['admin', 'demo'], true) ? $role : 'admin';

    if (!sh_admin_username_valid($username)) {
        return ['ok' => false, 'error' => 'invalid_username'];
    }
    if (strlen($pass) < 4) {
        return ['ok' => false, 'error' => 'weak_password'];
    }
    if (sh_admin_user_record_by_username($username) !== null) {
        return ['ok' => false, 'error' => 'exists'];
    }

    $data = sh_admin_users_load();
    $data['users'][] = [
        'id'         => bin2hex(random_bytes(8)),
        'username'   => $username,
        'pass_hash'  => password_hash($pass, PASSWORD_DEFAULT),
        'role'       => $role,
        'name'       => $name,
        'created_at' => gmdate('Y-m-d H:i:s'),
        'protected'  => false,
    ];

    if (!sh_admin_users_save($data)) {
        return ['ok' => false, 'error' => 'save_failed'];
    }

    return ['ok' => true, 'error' => ''];
}

function sh_admin_user_update(string $id, array $patch): array
{
    $data = sh_admin_users_load();
    $found = false;

    foreach ($data['users'] as $i => $row) {
        if (!is_array($row) || (string) ($row['id'] ?? '') !== $id) {
            continue;
        }
        $found = true;
        if (!empty($row['protected'])) {
            return ['ok' => false, 'error' => 'protected'];
        }
        if (isset($patch['name'])) {
            $row['name'] = trim((string) $patch['name']) ?: (string) $row['username'];
        }
        if (isset($patch['role']) && in_array($patch['role'], ['admin', 'demo'], true)) {
            $row['role'] = $patch['role'];
        }
        if (!empty($patch['password'])) {
            $pass = (string) $patch['password'];
            if (strlen($pass) < 4) {
                return ['ok' => false, 'error' => 'weak_password'];
            }
            $row['pass_hash'] = password_hash($pass, PASSWORD_DEFAULT);
        }
        $data['users'][$i] = $row;
        break;
    }

    if (!$found) {
        return ['ok' => false, 'error' => 'not_found'];
    }
    if (!sh_admin_users_save($data)) {
        return ['ok' => false, 'error' => 'save_failed'];
    }

    return ['ok' => true, 'error' => ''];
}

function sh_admin_user_update_builtin(string $username, array $patch): array
{
    $username = trim($username);
    if ($username === '' || sh_admin_user_record_by_username($username) === null) {
        return ['ok' => false, 'error' => 'not_found'];
    }

    $source = (string) (sh_admin_user_record_by_username($username)['source'] ?? '');
    if (!in_array($source, ['config', 'demo'], true)) {
        return ['ok' => false, 'error' => 'protected'];
    }

    $data = sh_admin_login_meta_load();
    $row = is_array($data['overrides'][$username] ?? null) ? $data['overrides'][$username] : [];

    if (isset($patch['name'])) {
        $row['name'] = trim((string) $patch['name']) ?: $username;
    }

    $data['overrides'][$username] = $row;
    if (!sh_admin_login_meta_save($data)) {
        return ['ok' => false, 'error' => 'save_failed'];
    }

    return ['ok' => true, 'error' => ''];
}

function sh_admin_user_delete(string $id): array
{
    $data = sh_admin_users_load();
    $before = count($data['users']);
    $data['users'] = array_values(array_filter($data['users'], static function ($row) use ($id) {
        if (!is_array($row) || (string) ($row['id'] ?? '') !== $id) {
            return true;
        }
        return empty($row['protected']);
    }));

    if (count($data['users']) === $before) {
        return ['ok' => false, 'error' => 'not_found'];
    }
    if (!sh_admin_users_save($data)) {
        return ['ok' => false, 'error' => 'save_failed'];
    }

    return ['ok' => true, 'error' => ''];
}