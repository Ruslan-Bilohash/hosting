<?php
require_once __DIR__ . '/init.php';
sh_admin_require();

if (!sh_admin_can_manage_users()) {
    header('Location: ' . sh_admin_url('index.php'), true, 302);
    exit;
}

require_once dirname(__DIR__) . '/includes/admin-users.php';

$admin_page = 'admin-users';
$up = $ta['admin_users_page'] ?? [];
$page_title = $up['title'] ?? 'Admin users';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string) ($_POST['action'] ?? ''));

    if ($action === 'create') {
        $result = sh_admin_user_create(
            trim((string) ($_POST['username'] ?? '')),
            (string) ($_POST['password'] ?? ''),
            trim((string) ($_POST['role'] ?? 'admin')),
            trim((string) ($_POST['name'] ?? ''))
        );
        if ($result['ok']) {
            $_SESSION['sh_admin_flash'] = ['type' => 'success', 'msg' => $up['created'] ?? 'User created.'];
        } else {
            $errKey = (string) ($result['error'] ?? 'save_failed');
            $msg = $up['error_' . $errKey] ?? ($up['create_error'] ?? 'Could not create user.');
            $_SESSION['sh_admin_flash'] = ['type' => 'error', 'msg' => $msg];
        }
        header('Location: ' . sh_admin_url('admin-users.php'));
        exit;
    }

    if ($action === 'update') {
        $id = trim((string) ($_POST['user_id'] ?? ''));
        $name = trim((string) ($_POST['name'] ?? ''));
        if (str_contains($id, ':')) {
            $username = substr($id, strpos($id, ':') + 1);
            $result = sh_admin_user_update_builtin($username, ['name' => $name]);
        } else {
            $patch = [
                'name' => $name,
                'role' => trim((string) ($_POST['role'] ?? 'admin')),
            ];
            if (trim((string) ($_POST['password'] ?? '')) !== '') {
                $patch['password'] = (string) $_POST['password'];
            }
            $result = sh_admin_user_update($id, $patch);
        }
        if ($result['ok']) {
            $_SESSION['sh_admin_flash'] = ['type' => 'success', 'msg' => $up['updated'] ?? 'User updated.'];
        } else {
            $errKey = (string) ($result['error'] ?? 'save_failed');
            $msg = $up['error_' . $errKey] ?? ($up['update_error'] ?? 'Could not update user.');
            $_SESSION['sh_admin_flash'] = ['type' => 'error', 'msg' => $msg];
        }
        header('Location: ' . sh_admin_url('admin-users.php'));
        exit;
    }

    if ($action === 'delete') {
        $result = sh_admin_user_delete(trim((string) ($_POST['user_id'] ?? '')));
        if ($result['ok']) {
            $_SESSION['sh_admin_flash'] = ['type' => 'success', 'msg' => $up['deleted'] ?? 'User removed.'];
        } else {
            $errKey = (string) ($result['error'] ?? 'save_failed');
            $msg = $up['error_' . $errKey] ?? ($up['delete_error'] ?? 'Could not remove user.');
            $_SESSION['sh_admin_flash'] = ['type' => 'error', 'msg' => $msg];
        }
        header('Location: ' . sh_admin_url('admin-users.php'));
        exit;
    }
}

$accounts = sh_admin_users_list_accounts();

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><i class="fas fa-users-cog"></i> <?= htmlspecialchars($page_title) ?></h2>
    </div>
    <div class="adm-card-body padded">
        <p class="adm-help"><?= htmlspecialchars($up['help'] ?? 'Add staff or demo accounts. Only the owner can manage users and switch sessions from the top bar.') ?></p>

        <div class="adm-table-wrap" style="margin-bottom:24px">
            <table class="adm-table adm-table--cards">
                <thead>
                    <tr>
                        <th><?= htmlspecialchars($up['col_username'] ?? 'Username') ?></th>
                        <th><?= htmlspecialchars($up['col_name'] ?? 'Display name') ?></th>
                        <th><?= htmlspecialchars($up['col_role'] ?? 'Role') ?></th>
                        <th><?= htmlspecialchars($up['col_ip'] ?? 'Last IP') ?></th>
                        <th><?= htmlspecialchars($up['col_last_login'] ?? 'Last login') ?></th>
                        <th><?= htmlspecialchars($up['col_source'] ?? 'Source') ?></th>
                        <th><?= htmlspecialchars($up['col_actions'] ?? 'Actions') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($accounts as $acc):
                        $role = (string) ($acc['role'] ?? '');
                        $roleLabel = $up['role_' . $role] ?? $role;
                        $source = (string) ($acc['source'] ?? '');
                        $sourceLabel = $up['source_' . $source] ?? $source;
                        $isCurrent = ((string) ($_SESSION['sh_admin_user'] ?? '')) === (string) ($acc['username'] ?? '');
                        $isCustom = $source === 'custom';
                        $isEditable = !empty($acc['editable']);
                        $lastIp = trim((string) ($acc['last_ip'] ?? ''));
                        $lastLogin = sh_admin_format_last_login((string) ($acc['last_login_at'] ?? ''));
                        ?>
                    <tr class="<?= $isCurrent ? 'adm-row-current' : '' ?>">
                        <td data-label="<?= htmlspecialchars($up['col_username'] ?? 'Username') ?>">
                            <code><?= htmlspecialchars((string) ($acc['username'] ?? '')) ?></code>
                            <?php if ($isCurrent): ?>
                            <span class="adm-badge adm-badge-info adm-badge-sm"><?= htmlspecialchars($up['current_badge'] ?? 'Active') ?></span>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?= htmlspecialchars($up['col_name'] ?? 'Display name') ?>"><?= htmlspecialchars((string) ($acc['name'] ?? '')) ?></td>
                        <td data-label="<?= htmlspecialchars($up['col_role'] ?? 'Role') ?>">
                            <span class="adm-role-badge adm-role-badge--<?= htmlspecialchars($role) ?>"><?= htmlspecialchars($roleLabel) ?></span>
                        </td>
                        <td data-label="<?= htmlspecialchars($up['col_ip'] ?? 'Last IP') ?>">
                            <?php if ($lastIp !== ''): ?>
                            <code><?= htmlspecialchars($lastIp) ?></code>
                            <?php else: ?>
                            <span class="adm-muted"><?= htmlspecialchars($up['no_login_yet'] ?? '—') ?></span>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?= htmlspecialchars($up['col_last_login'] ?? 'Last login') ?>">
                            <?php if ($lastLogin !== ''): ?>
                            <?= htmlspecialchars($lastLogin) ?>
                            <?php else: ?>
                            <span class="adm-muted"><?= htmlspecialchars($up['no_login_yet'] ?? '—') ?></span>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?= htmlspecialchars($up['col_source'] ?? 'Source') ?>"><?= htmlspecialchars($sourceLabel) ?></td>
                        <td data-label="<?= htmlspecialchars($up['col_actions'] ?? 'Actions') ?>">
                            <div class="adm-actions-row">
                                <?php if (sh_admin_can_switch_users() && !$isCurrent): ?>
                                <form method="post" action="<?= htmlspecialchars(sh_admin_url('api/admin-switch.php')) ?>" class="adm-inline-form">
                                    <input type="hidden" name="username" value="<?= htmlspecialchars((string) ($acc['username'] ?? '')) ?>">
                                    <button type="submit" class="adm-btn adm-btn-outline adm-btn-sm" title="<?= htmlspecialchars($up['switch_btn'] ?? 'Switch to this user') ?>">
                                        <i class="fas fa-right-left"></i> <?= htmlspecialchars($up['switch_btn'] ?? 'Switch') ?>
                                    </button>
                                </form>
                                <?php endif; ?>
                                <?php if ($isEditable): ?>
                                <button type="button" class="adm-btn adm-btn-outline adm-btn-sm"
                                        data-admin-user-edit
                                        data-id="<?= htmlspecialchars((string) ($acc['id'] ?? '')) ?>"
                                        data-username="<?= htmlspecialchars((string) ($acc['username'] ?? '')) ?>"
                                        data-name="<?= htmlspecialchars((string) ($acc['name'] ?? '')) ?>"
                                        data-role="<?= htmlspecialchars($role) ?>"
                                        data-builtin="<?= $isCustom ? '0' : '1' ?>"
                                        title="<?= htmlspecialchars($up['edit_btn'] ?? 'Edit') ?>">
                                    <i class="fas fa-pen"></i>
                                </button>
                                <?php endif; ?>
                                <?php if ($isCustom): ?>
                                <form method="post" class="adm-inline-form" onsubmit="return confirm('<?= htmlspecialchars($up['confirm_delete'] ?? 'Remove this user?') ?>');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="user_id" value="<?= htmlspecialchars((string) ($acc['id'] ?? '')) ?>">
                                    <button type="submit" class="adm-btn adm-btn-danger adm-btn-sm"><i class="fas fa-trash"></i></button>
                                </form>
                                <?php elseif (!empty($acc['protected']) && !$isEditable): ?>
                                <span class="adm-muted adm-text-sm"><?= htmlspecialchars($up['protected_hint'] ?? 'Built-in') ?></span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="adm-card adm-card--nested">
            <div class="adm-card-head">
                <h3><i class="fas fa-user-plus"></i> <?= htmlspecialchars($up['add_title'] ?? 'Add user') ?></h3>
            </div>
            <div class="adm-card-body padded">
                <form method="post" class="adm-form-grid adm-form-grid--2">
                    <input type="hidden" name="action" value="create">
                    <div class="adm-field">
                        <label for="new_username"><?= htmlspecialchars($up['field_username'] ?? 'Username') ?></label>
                        <input type="text" id="new_username" name="username" required pattern="[A-Za-z0-9_.-]{3,32}" autocomplete="off">
                    </div>
                    <div class="adm-field">
                        <label for="new_name"><?= htmlspecialchars($up['field_name'] ?? 'Display name') ?></label>
                        <input type="text" id="new_name" name="name" autocomplete="off">
                    </div>
                    <div class="adm-field">
                        <label for="new_password"><?= htmlspecialchars($up['field_password'] ?? 'Password') ?></label>
                        <input type="password" id="new_password" name="password" required minlength="4" autocomplete="new-password">
                    </div>
                    <div class="adm-field">
                        <label for="new_role"><?= htmlspecialchars($up['field_role'] ?? 'Role') ?></label>
                        <select id="new_role" name="role">
                            <option value="admin"><?= htmlspecialchars($up['role_admin'] ?? 'Administrator') ?></option>
                            <option value="demo"><?= htmlspecialchars($up['role_demo'] ?? 'Demo user') ?></option>
                        </select>
                    </div>
                    <div class="adm-field adm-field--full">
                        <button type="submit" class="adm-btn adm-btn-primary">
                            <i class="fas fa-plus"></i> <?= htmlspecialchars($up['add_btn'] ?? 'Add user') ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<dialog id="admUserEditDialog" class="adm-dialog">
    <form method="post" class="adm-dialog-form">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="user_id" id="edit_user_id" value="">
        <h3><i class="fas fa-pen"></i> <?= htmlspecialchars($up['edit_title'] ?? 'Edit user') ?></h3>
        <p class="adm-muted"><code id="edit_username_label"></code></p>
        <div class="adm-field">
            <label for="edit_name"><?= htmlspecialchars($up['field_name'] ?? 'Display name') ?></label>
            <input type="text" id="edit_name" name="name" required>
        </div>
        <div class="adm-field" data-edit-role-wrap>
            <label for="edit_role"><?= htmlspecialchars($up['field_role'] ?? 'Role') ?></label>
            <select id="edit_role" name="role">
                <option value="admin"><?= htmlspecialchars($up['role_admin'] ?? 'Administrator') ?></option>
                <option value="demo"><?= htmlspecialchars($up['role_demo'] ?? 'Demo user') ?></option>
            </select>
        </div>
        <p class="adm-help adm-help--compact" data-edit-builtin-note hidden><?= htmlspecialchars($up['edit_builtin_note'] ?? 'Built-in account — only display name can be changed.') ?></p>
        <div class="adm-field" data-edit-password-wrap>
            <label for="edit_password"><?= htmlspecialchars($up['field_password_new'] ?? 'New password (optional)') ?></label>
            <input type="password" id="edit_password" name="password" minlength="4" autocomplete="new-password">
        </div>
        <div class="adm-dialog-actions">
            <button type="button" class="adm-btn adm-btn-outline" data-dialog-close><?= htmlspecialchars($up['cancel_btn'] ?? 'Cancel') ?></button>
            <button type="submit" class="adm-btn adm-btn-primary"><?= htmlspecialchars($up['save_btn'] ?? 'Save') ?></button>
        </div>
    </form>
</dialog>

<script>
(function () {
    var dlg = document.getElementById('admUserEditDialog');
    if (!dlg) return;
    var roleWrap = dlg.querySelector('[data-edit-role-wrap]');
    var passWrap = dlg.querySelector('[data-edit-password-wrap]');
    var builtinNote = dlg.querySelector('[data-edit-builtin-note]');
    document.querySelectorAll('[data-admin-user-edit]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var isBuiltin = btn.dataset.builtin === '1';
            document.getElementById('edit_user_id').value = btn.dataset.id || '';
            document.getElementById('edit_username_label').textContent = btn.dataset.username || '';
            document.getElementById('edit_name').value = btn.dataset.name || '';
            document.getElementById('edit_role').value = btn.dataset.role || 'admin';
            document.getElementById('edit_password').value = '';
            if (roleWrap) roleWrap.hidden = isBuiltin;
            if (passWrap) passWrap.hidden = isBuiltin;
            if (builtinNote) builtinNote.hidden = !isBuiltin;
            if (typeof dlg.showModal === 'function') dlg.showModal();
        });
    });
    dlg.querySelectorAll('[data-dialog-close]').forEach(function (btn) {
        btn.addEventListener('click', function () { dlg.close(); });
    });
})();
</script>

<?php require __DIR__ . '/includes/layout-end.php'; ?>