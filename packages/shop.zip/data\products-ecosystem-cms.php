<?php
/**
 * Ecosystem CMS products for catalog seed / merge.
 */
require_once dirname(__DIR__) . '/includes/products-ecosystem-seed.php';

return sh_ecosystem_cms_products_seed();