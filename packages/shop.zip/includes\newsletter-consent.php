<?php
declare(strict_types=1);

function sh_newsletter_privacy_url(): string
{
    if (function_exists('sh_url')) {
        $local = sh_url('page.php?slug=privacy');
        if ($local !== '') {
            return $local;
        }
    }
    return 'https://bilohash.com/website/privacy-policy.php';
}

function sh_newsletter_consent_accepted(mixed $value): bool
{
    if (is_bool($value)) {
        return $value;
    }
    $v = strtolower(trim((string) $value));
    return in_array($v, ['1', 'true', 'yes', 'on'], true);
}

/**
 * @param array<string, string> $sub Translations from $t['subscribe']
 */
function sh_newsletter_consent_field(array $sub, string $inputId = 'shNlConsent'): void
{
    $privacyLabel = (string) ($sub['privacy_link'] ?? 'Privacy policy');
    $privacyUrl = sh_newsletter_privacy_url();
    $before = (string) ($sub['consent_before'] ?? 'I agree to receive newsletter emails and accept the ');
    $after = (string) ($sub['consent_after'] ?? '.');
    ?>
    <label class="sh-newsletter-consent" for="<?= htmlspecialchars($inputId) ?>">
        <input type="checkbox" class="sh-newsletter-consent-input" id="<?= htmlspecialchars($inputId) ?>"
               name="newsletter_consent" value="1" required>
        <span class="sh-newsletter-consent-text">
            <?= htmlspecialchars($before) ?><a href="<?= htmlspecialchars($privacyUrl) ?>" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($privacyLabel) ?></a><?= htmlspecialchars($after) ?>
        </span>
    </label>
    <?php
}