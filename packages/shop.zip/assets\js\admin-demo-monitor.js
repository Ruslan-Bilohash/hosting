(function () {
    'use strict';
    var root = document.getElementById('shDemoMonitor');
    if (!root) return;

    var api = root.dataset.api || '';
    var refreshBtn = document.getElementById('shDemoMonitorRefresh');

    function setKpi(name, val) {
        var el = document.querySelector('[data-kpi="' + name + '"]');
        if (el) el.textContent = String(val);
    }

    function refresh() {
        if (!api) return;
        fetch(api, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ action: 'stats' })
        }).then(function (r) { return r.json(); }).then(function (res) {
            if (!res.ok || !res.stats) return;
            var s = res.stats;
            setKpi('page_views', s.page_views || 0);
            setKpi('today_views', s.today_views || 0);
            setKpi('unique_visitors', s.unique_visitors || 0);
            setKpi('total', s.total || 0);

        }).catch(function () {});
    }

    if (refreshBtn) {
        refreshBtn.addEventListener('click', refresh);
    }
    setInterval(refresh, 60000);
})();