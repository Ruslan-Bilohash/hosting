<?php
require_once dirname(__DIR__, 2) . '/init.php';
sh_admin_require();

header('Content-Type: application/json; charset=utf-8');

if (!sh_admin_is_owner()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Forbidden']);
    exit;
}

require_once dirname(__DIR__, 2) . '/includes/billing-demo-stats.php';

$raw = file_get_contents('php://input');
$payload = is_string($raw) && $raw !== '' ? json_decode($raw, true) : [];
if (!is_array($payload)) {
    $payload = [];
}

$action = (string) ($payload['action'] ?? $_GET['action'] ?? 'stats');

if ($action === 'stats') {
    echo json_encode([
        'ok'    => true,
        'stats' => sh_demo_stats_summary(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action']);