<?php
/**
 * Mobile burger menu — quick demo sign-in (Google, Apple, admin, phone/customer).
 * Shown on storefront when SH_DEMO_MODE is on.
 */
if (empty($sh_show_admin_demo_nav)) {
    return;
}

require_once __DIR__ . '/customer-auth.php';
$sh_demo_auth = sh_customer_auth_settings();
$sh_demo_login_url = sh_url('login.php');
$sh_demo_has_oauth = sh_customer_google_login_available($sh_demo_auth) || sh_customer_apple_login_available($sh_demo_auth);
$sh_demo_has_phone = sh_customer_phone_login_enabled($sh_demo_auth) && sh_customer_auth_enabled($sh_demo_auth);
?>
<div class="sh-mobile-demo-auth">
    <p class="sh-mobile-demo-auth-title"><?= htmlspecialchars($t['nav']['mobile_demo_title'] ?? 'Demo sign-in') ?></p>

    <a href="<?= htmlspecialchars(sh_admin_demo_autologin_url()) ?>" class="sh-mobile-demo-auth-btn sh-mobile-demo-auth-btn--admin">
        <i class="fas fa-user-shield" aria-hidden="true"></i>
        <span><?= htmlspecialchars($t['nav']['admin_demo_signin'] ?? 'Admin demo') ?></span>
    </a>

    <?php if (sh_customer_google_login_available($sh_demo_auth)): ?>
    <form method="post" action="<?= htmlspecialchars($sh_demo_login_url) ?>">
        <input type="hidden" name="action" value="google_demo">
        <button type="submit" class="sh-mobile-demo-auth-btn sh-mobile-demo-auth-btn--google">
            <i class="fab fa-google" aria-hidden="true"></i>
            <span><?= htmlspecialchars(
                sh_customer_google_demo_only($sh_demo_auth)
                    ? ($t['customer_auth']['google_demo'] ?? $t['customer_auth']['google'] ?? 'Google')
                    : ($t['customer_auth']['google'] ?? 'Google')
            ) ?></span>
        </button>
    </form>
    <?php endif; ?>

    <?php if (sh_customer_apple_login_available($sh_demo_auth)): ?>
    <form method="post" action="<?= htmlspecialchars($sh_demo_login_url) ?>">
        <input type="hidden" name="action" value="apple_demo">
        <button type="submit" class="sh-mobile-demo-auth-btn sh-mobile-demo-auth-btn--apple">
            <i class="fab fa-apple" aria-hidden="true"></i>
            <span><?= htmlspecialchars(
                sh_customer_apple_demo_only($sh_demo_auth)
                    ? ($t['customer_auth']['apple_demo'] ?? $t['customer_auth']['apple'] ?? 'Apple')
                    : ($t['customer_auth']['apple'] ?? 'Apple')
            ) ?></span>
        </button>
    </form>
    <?php endif; ?>

    <?php if ($sh_demo_has_phone): ?>
    <a href="<?= htmlspecialchars($sh_demo_login_url) ?>" class="sh-mobile-demo-auth-btn sh-mobile-demo-auth-btn--phone">
        <i class="fas fa-phone" aria-hidden="true"></i>
        <span><?= htmlspecialchars($t['nav']['mobile_demo_phone'] ?? $t['customer_auth']['phone_submit'] ?? 'Phone sign-in') ?></span>
    </a>
    <?php endif; ?>

    <?php if (sh_customer_auth_enabled($sh_demo_auth)): ?>
    <form method="post" action="<?= htmlspecialchars($sh_demo_login_url) ?>">
        <input type="hidden" name="action" value="demo_customer">
        <button type="submit" class="sh-mobile-demo-auth-btn sh-mobile-demo-auth-btn--customer">
            <i class="fas fa-user-tag" aria-hidden="true"></i>
            <span><?= htmlspecialchars($t['customer_auth']['demo_customer_btn'] ?? 'Demo customer') ?></span>
        </button>
    </form>
    <?php endif; ?>
</div>