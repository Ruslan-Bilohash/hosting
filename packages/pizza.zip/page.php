<?php
declare(strict_types=1);
require __DIR__ . '/init.php';

$slug = trim((string) ($_GET['slug'] ?? ''));
$registry = pz_seo_pages();
if ($slug === '' || !isset($registry[$slug])) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$config = $registry[$slug];
$v = pz_page_lang($slug);
if ($v === []) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$menu = pz_menu_items();
$current_page = $slug;
$page_title = $v['meta_title'] ?? $t['meta_title'];
$page_desc  = $v['meta_desc'] ?? $t['meta_desc'];
$canonical  = pz_page_url($slug);
$canon_abs  = pz_absolute_url($canonical);
$og_image   = $config['og_image'] ?? null;
$page_keywords = $v['meta_keywords'] ?? null;

$seo_schemas = [
    pz_seo_organization(),
    pz_seo_website(pz_absolute_url($site_url . '/')),
    pz_seo_webpage($canon_abs, $page_title, $page_desc),
    pz_seo_restaurant(),
    pz_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => pz_absolute_url(pz_url('index.php'))],
        ['name' => $v['h1'] ?? $slug, 'url' => $canon_abs],
    ]),
];

if ($slug === 'menu') {
    $seo_schemas[] = pz_seo_menu_schema($menu, $canon_abs);
    $seo_schemas[] = pz_seo_menu_list($menu, $canon_abs);
}

if (!empty($v['faq']) && ($faq = pz_seo_faq_page($v['faq'])) !== null) {
    $seo_schemas[] = $faq;
}

$seo_og_type = 'website';
$body_class = 'pz-page-seo pz-page-' . $slug;
$seo_keywords_override = $page_keywords;
$seo_og_image_rel = $og_image;

require __DIR__ . '/includes/seo-page-template.php';