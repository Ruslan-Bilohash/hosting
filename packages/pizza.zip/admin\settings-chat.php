<?php
require_once __DIR__ . '/init.php';
pz_admin_require();
require_once dirname(__DIR__) . '/includes/storage.php';
$settings_tab = 'chat';
$bh_cms_load_settings = 'pz_load_settings';
$bh_cms_save_settings = 'pz_save_settings';
$bh_cms_admin_url = 'pz_admin_url';
$bh_cms_layout = __DIR__ . '/includes/layout.php';
$bh_cms_layout_end = __DIR__ . '/includes/layout-foot.php';
require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
require dirname(__DIR__, 2) . '/includes/bh-cms-admin/complete-settings-page.php';