<?php
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/admin-auth.php';
pz_admin_logout();
header('Location: ' . pz_admin_url('login.php'), true, 302);
exit;