<?php
require_once __DIR__ . '/../config.php';

define('PZS_LANG_COOKIE', 'pzs_lang');

$PZS_LANGS = [
    'en' => ['label' => 'EN', 'name' => 'English', 'flag' => '🇬🇧', 'locale' => 'en-GB', 'html' => 'en'],
    'no' => ['label' => 'NO', 'name' => 'Norsk', 'flag' => '🇳🇴', 'locale' => 'nb-NO', 'html' => 'no'],
    'uk' => ['label' => 'UA', 'name' => 'Українська', 'flag' => '🇺🇦', 'locale' => 'uk-UA', 'html' => 'uk'],
    'ru' => ['label' => 'RU', 'name' => 'Русский', 'flag' => '🇷🇺', 'locale' => 'ru-RU', 'html' => 'ru'],
];

function pzs_langs(): array { global $PZS_LANGS; return $PZS_LANGS; }

function pzs_detect_lang(): string
{
    global $base_path, $PZS_LANGS;
    $codes = array_keys($PZS_LANGS);
    if (!empty($_GET['lang']) && in_array($_GET['lang'], $codes, true)) {
        $chosen = $_GET['lang'];
        setcookie(PZS_LANG_COOKIE, $chosen, [
            'expires' => time() + 365 * 86400,
            'path'    => rtrim($base_path, '/') . '/' ?: '/',
            'secure'  => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'samesite'=> 'Lax',
        ]);
        if ($chosen === 'en') {
            $uri = $_SERVER['REQUEST_URI'] ?? '/';
            $parts = parse_url($uri);
            parse_str($parts['query'] ?? '', $q);
            unset($q['lang']);
            $clean = ($parts['path'] ?? '/') . ($q ? '?' . http_build_query($q) : '');
            if ($clean !== $uri) { header('Location: ' . $clean, true, 302); exit; }
        }
        return $chosen;
    }
    if (!empty($_COOKIE[PZS_LANG_COOKIE]) && in_array($_COOKIE[PZS_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[PZS_LANG_COOKIE];
    }
    if (!empty($_COOKIE['pz_lang']) && in_array($_COOKIE['pz_lang'], $codes, true)) {
        return $_COOKIE['pz_lang'];
    }
    return 'en';
}

$lang      = pzs_detect_lang();
$lang_meta = $PZS_LANGS[$lang] ?? $PZS_LANGS['en'];
$lang_file = __DIR__ . '/../lang/' . $lang . '.php';
if (!is_file($lang_file)) $lang_file = __DIR__ . '/../lang/en.php';
$t = require $lang_file;

require_once dirname(__DIR__, 3) . '/includes/ecosystem-i18n.php';
$t = bh_apply_ecosystem_translations($t, $lang, 'pizza');

require_once __DIR__ . '/helpers.php';