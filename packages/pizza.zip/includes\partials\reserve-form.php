<?php
$pz_qr_url = $pz_qr_url ?? pz_page_menu_url($lang);
$pz_qr_img = $pz_qr_img ?? pz_qr_code_url($pz_qr_url, 200);
?>
<section class="pz-section" id="reserve">
    <div class="pz-container">
        <div class="pz-split">
            <form class="pz-form" id="pzReserveForm" action="<?= htmlspecialchars(pz_url('reserve.php')) ?>" method="post" data-error="<?= htmlspecialchars($t['form_error']) ?>" data-success="<?= htmlspecialchars($t['form_success']) ?>">
                <div class="pz-form-grid">
                    <div class="pz-field">
                        <label for="pz-name"><?= htmlspecialchars($t['form_name']) ?></label>
                        <input type="text" id="pz-name" name="name" required maxlength="120" autocomplete="name">
                    </div>
                    <div class="pz-field">
                        <label for="pz-phone"><?= htmlspecialchars($t['form_phone']) ?></label>
                        <input type="tel" id="pz-phone" name="phone" required maxlength="40" autocomplete="tel">
                    </div>
                    <div class="pz-field pz-field--full">
                        <label for="pz-email"><?= htmlspecialchars($t['form_email']) ?></label>
                        <input type="email" id="pz-email" name="email" maxlength="160" autocomplete="email">
                    </div>
                    <div class="pz-field">
                        <label for="pz-date"><?= htmlspecialchars($t['form_date']) ?></label>
                        <input type="date" id="pz-date" name="date" required>
                    </div>
                    <div class="pz-field">
                        <label for="pz-time"><?= htmlspecialchars($t['form_time']) ?></label>
                        <input type="time" id="pz-time" name="time" value="19:00">
                    </div>
                    <div class="pz-field">
                        <label for="pz-guests"><?= htmlspecialchars($t['form_guests']) ?></label>
                        <select id="pz-guests" name="guests" required>
                            <?php for ($g = 1; $g <= 12; $g++): ?>
                            <option value="<?= $g ?>"<?= $g === 2 ? ' selected' : '' ?>><?= $g ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="pz-field pz-field--full">
                        <label for="pz-note"><?= htmlspecialchars($t['form_note']) ?></label>
                        <textarea id="pz-note" name="note" rows="3" maxlength="500" placeholder="<?= htmlspecialchars($t['form_note_placeholder'] ?? '') ?>"></textarea>
                    </div>
                </div>
                <?php require __DIR__ . '/recaptcha-widget.php'; ?>
                <button type="submit" class="pz-btn pz-btn-primary" style="margin-top:1.25rem;width:100%">
                    <i class="fas fa-paper-plane" aria-hidden="true"></i>
                    <?= htmlspecialchars($t['form_submit']) ?>
                </button>
                <div class="pz-form-msg" id="pzFormMsg" role="status"></div>
            </form>
            <div class="pz-info-card" id="contact">
                <div class="pz-qr-block" id="qr">
                    <div class="pz-qr-copy">
                        <h4 class="pz-qr-title">
                            <i class="fas fa-qrcode" aria-hidden="true"></i>
                            <?= htmlspecialchars($t['qr_title']) ?>
                        </h4>
                        <p class="pz-qr-sub"><?= htmlspecialchars($t['qr_sub']) ?></p>
                    </div>
                    <a href="<?= htmlspecialchars($pz_qr_url) ?>" class="pz-qr-frame" aria-label="<?= htmlspecialchars($t['qr_alt']) ?>">
                        <img
                            src="<?= htmlspecialchars($pz_qr_img) ?>"
                            alt="<?= htmlspecialchars($t['qr_alt']) ?>"
                            width="200"
                            height="200"
                            loading="lazy"
                            decoding="async"
                        >
                    </a>
                </div>
                <h3><?= htmlspecialchars($t['contact_title']) ?></h3>
                <p class="pz-contact-sub"><?= htmlspecialchars($t['contact_sub']) ?></p>
                <h3 style="font-size:1.1rem;margin-top:1.5rem"><?= htmlspecialchars($t['hours_title']) ?></h3>
                <div class="pz-hours-row"><span><?= htmlspecialchars($t['hours_week']) ?></span><span><?= htmlspecialchars($t['hours_week_val']) ?></span></div>
                <div class="pz-hours-row"><span><?= htmlspecialchars($t['hours_fri']) ?></span><span><?= htmlspecialchars($t['hours_fri_val']) ?></span></div>
                <div class="pz-hours-row"><span><?= htmlspecialchars($t['hours_sun']) ?></span><span><?= htmlspecialchars($t['hours_sun_val']) ?></span></div>
                <div class="pz-contact-lines">
                    <div class="pz-contact-line">
                        <i class="fas fa-location-dot" aria-hidden="true"></i>
                        <span><?= htmlspecialchars($brand['address']) ?></span>
                    </div>
                    <div class="pz-contact-line">
                        <i class="fas fa-phone" aria-hidden="true"></i>
                        <a href="tel:<?= htmlspecialchars($brand['phone']) ?>"><?= htmlspecialchars($brand['phone']) ?></a>
                    </div>
                    <div class="pz-contact-line">
                        <i class="fas fa-envelope" aria-hidden="true"></i>
                        <a href="mailto:<?= htmlspecialchars($brand['email']) ?>"><?= htmlspecialchars($brand['email']) ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>