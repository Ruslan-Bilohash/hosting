<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/landing-lib.php';

$current_page = 'markets';
$page_title = $t['markets']['meta_title'] ?? 'Pizza CMS countries';
$page_desc  = $t['markets']['meta_desc'] ?? '';
$canonical  = pzs_url('markets.php');
$canon_abs  = pzs_absolute_url($canonical);
$all = pzs_markets_all();

$seo_schemas = pzs_landing_seo_schemas($canon_abs, $page_title, $page_desc, [
    'h1' => $t['markets']['hub_title'] ?? 'Countries',
    'intro' => $t['markets']['hub_desc'] ?? '',
    'faq' => [],
], [
    ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => pzs_absolute_url(pzs_url('index.php'))],
    ['name' => $t['markets']['hub_title'] ?? 'Countries', 'url' => $canon_abs],
]);

require __DIR__ . '/includes/header.php';
?>

<main class="shs-container shs-hub-main">
    <nav class="shs-breadcrumb" aria-label="Breadcrumb">
        <a href="<?= pzs_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a>
        <span>/</span>
        <span><?= htmlspecialchars($t['markets']['hub_title'] ?? 'Countries') ?></span>
    </nav>
    <h1><?= htmlspecialchars($t['markets']['hub_title'] ?? 'Countries') ?></h1>
    <p class="shs-hub-lead"><?= htmlspecialchars($t['markets']['hub_desc'] ?? '') ?></p>

    <div class="shs-hub-grid shs-hub-grid--markets">
        <?php foreach ($all as $slug => $item):
            $lv = pzs_landing_lang($item, $lang);
        ?>
        <a href="<?= htmlspecialchars(pzs_landing_url($slug)) ?>" class="shs-hub-card shs-hub-card--market">
            <span class="shs-hub-flag" aria-hidden="true"><?= $item['flag'] ?? '' ?></span>
            <strong><?= htmlspecialchars($lv['h1']) ?></strong>
            <span><?= htmlspecialchars(implode(' · ', array_slice($item['cities'] ?? [], 0, 3))) ?></span>
        </a>
        <?php endforeach; ?>
    </div>

    <section class="shs-hub-cross">
        <h2><?= htmlspecialchars($t['solutions']['hub_title'] ?? 'Solutions') ?></h2>
        <div class="shs-hub-tags">
            <?php foreach (pzs_usecases_all() as $uslug => $uitem):
                $uv = pzs_landing_lang($uitem, $lang);
            ?>
            <a href="<?= htmlspecialchars(pzs_landing_url($uslug)) ?>"><?= htmlspecialchars($uv['h1']) ?></a>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>