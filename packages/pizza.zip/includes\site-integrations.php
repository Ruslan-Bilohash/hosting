<?php

require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
require_once __DIR__ . '/storage.php';

function pz_site_settings(): array
{
    static $s = null;
    if ($s === null) {
        $s = pz_load_settings();
        $GLOBALS['bh_cms_site_settings'] = $s;
        bh_cms_bind_recaptcha_settings($s);
    }
    return $s;
}

function pz_boot_public_integrations(): void
{
    pz_site_settings();
}