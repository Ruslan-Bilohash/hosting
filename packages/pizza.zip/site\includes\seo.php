<?php

function pzs_seo_organization(): array
{
    return [
        '@type' => 'Organization',
        '@id' => 'https://bilohash.com/pizza/site/#organization',
        'name' => 'Pizza CMS · Bilohash',
        'url' => 'https://bilohash.com/pizza/site/',
        'logo' => 'https://bilohash.com/favicon.ico',
        'areaServed' => ['NO', 'UA', 'SE', 'DE', 'LT', 'EU', 'US'],
        'knowsAbout' => [
            'Restaurant website development',
            'Pizzeria CMS',
            'PHP menu and reservation systems',
            'Schema.org Restaurant SEO',
        ],
    ];
}

function pzs_seo_breadcrumbs(array $items): array
{
    $list = [];
    $pos = 1;
    foreach ($items as $item) {
        $entry = [
            '@type' => 'ListItem',
            'position' => $pos++,
            'name' => $item['name'],
        ];
        if (!empty($item['url'])) {
            $entry['item'] = $item['url'];
        }
        $list[] = $entry;
    }
    return [
        '@type' => 'BreadcrumbList',
        'itemListElement' => $list,
    ];
}

function pzs_seo_faq_page(array $faq): ?array
{
    $entities = [];
    foreach ($faq as $item) {
        $q = trim((string) ($item['q'] ?? ''));
        $a = trim((string) ($item['a'] ?? ''));
        if ($q === '' || $a === '') {
            continue;
        }
        $entities[] = [
            '@type' => 'Question',
            'name' => $q,
            'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a],
        ];
    }
    if ($entities === []) {
        return null;
    }
    return ['@type' => 'FAQPage', 'mainEntity' => $entities];
}

function pzs_seo_schemas(string $canonical, string $title, string $desc): array
{
    return [
        pzs_seo_organization(),
        [
            '@type' => 'SoftwareApplication',
            '@id' => $canonical . '#software',
            'name' => PZS_PRODUCT_NAME,
            'applicationCategory' => 'BusinessApplication',
            'applicationSubCategory' => 'Restaurant and pizzeria website software',
            'description' => $desc,
            'url' => $canonical,
            'operatingSystem' => 'Web',
            'inLanguage' => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
            'offers' => [
                '@type' => 'Offer',
                'price' => '0',
                'priceCurrency' => 'NOK',
                'url' => $canonical,
            ],
            'author' => ['@id' => 'https://bilohash.com/pizza/site/#organization'],
        ],
        [
            '@type' => 'WebPage',
            '@id' => $canonical . '#webpage',
            'url' => $canonical,
            'name' => $title,
            'description' => $desc,
        ],
    ];
}

function pzs_landing_seo_schemas(string $canonical, string $title, string $desc, array $v, array $breadcrumbs): array
{
    $graphs = pzs_seo_schemas($canonical, $title, $desc);
    $graphs[] = pzs_seo_breadcrumbs($breadcrumbs);
    if (!empty($v['faq']) && ($faq = pzs_seo_faq_page($v['faq'])) !== null) {
        $graphs[] = $faq;
    }
    return $graphs;
}

function pzs_render_seo_head(
    string $page_title,
    string $page_desc,
    string $canonical,
    array $schemas = [],
    ?string $keywords_override = null
): void {
    global $lang_meta, $lang;
    $canonical_abs = pzs_absolute_url($canonical);
    $keywords = $keywords_override ?? ($GLOBALS['t']['meta']['keywords'] ?? '');
    $og_image = pzs_absolute_url(pzs_demo_url('assets/images/hero-pizza.jpg'));
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
    <meta name="author" content="Pizza CMS · Bilohash">
    <meta name="theme-color" content="#fff7ed">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(pzs_full_lang_url('en')) ?>">
    <?php foreach (pzs_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= $code === 'uk' ? 'uk' : $code ?>" href="<?= htmlspecialchars(pzs_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars(PZS_PRODUCT_NAME) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <?php foreach (pzs_langs() as $code => $info):
        if ($code === $lang) continue; ?>
    <meta property="og:locale:alternate" content="<?= htmlspecialchars(str_replace('-', '_', $info['locale'])) ?>">
    <?php endforeach; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">
    <?php if (!empty($schemas)): ?>
    <script type="application/ld+json"><?= json_encode(['@context' => 'https://schema.org', '@graph' => array_values(array_filter($schemas))], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
    <?php endif;
}