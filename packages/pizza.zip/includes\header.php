<?php
require_once __DIR__ . '/site-integrations.php';
pz_boot_public_integrations();
$page_title = $page_title ?? ($t['meta_title'] ?? $t['meta']['title'] ?? PZ_SITE_NAME);
$page_desc  = $page_desc ?? ($t['meta_desc'] ?? $t['meta']['description'] ?? '');
$canonical  = $canonical ?? ($site_url . ($lang !== 'en' ? '?lang=' . urlencode($lang) : ''));
$menu       = $menu ?? pz_menu_items();
$seo_schemas = $seo_schemas ?? [
    pz_seo_organization(),
    pz_seo_software_app(pz_absolute_url($canonical), $page_desc),
    pz_seo_website(pz_absolute_url($site_url . '/')),
    pz_seo_webpage(pz_absolute_url($canonical), $page_title, $page_desc),
    pz_seo_restaurant(),
    pz_seo_menu_schema($menu, pz_absolute_url($canonical)),
    pz_seo_menu_list($menu, pz_absolute_url($canonical)),
];
$seo_keywords_override = $seo_keywords_override ?? null;
$seo_og_image_rel = $seo_og_image_rel ?? null;
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($html_lang) ?>" prefix="og: https://ogp.me/ns#">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pz_render_seo_head($page_title, $page_desc, $canonical, $seo_schemas, $seo_og_type ?? 'website', $seo_noindex ?? false, $seo_keywords_override, $seo_og_image_rel); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700;1,9..40,400&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(pz_asset('css/site.css')) ?>?v=20">
    <?php bh_cms_render_theme_styles('pizza', pz_site_settings()); ?>
    <?php if ((!empty($cms_prefix) && $cms_prefix !== 'fl') || ($current_page ?? '') === 'contact'): ?>
    <link rel="stylesheet" href="<?= htmlspecialchars(cms_contact_stylesheet_href()) ?>">
    <?php endif; ?>
    <?php
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    ecosystem_subscription_strip_head_link();
    ?>
</head>
<body<?= !empty($body_class) ? ' class="' . htmlspecialchars($body_class) . '"' : '' ?>>
<header class="pz-header">
    <?php ecosystem_subscription_strip_render($lang); ?>
    <div class="pz-container pz-header-inner">
        <?php
        $pz_on_home = ($current_page ?? 'home') === 'home';
        $pz_home = pz_url('index.php');
        ?>
        <a href="<?= $pz_on_home ? '#top' : htmlspecialchars($pz_home) ?>" class="pz-logo">
            <?php if ($pz_logo_img = pz_brand_image('logo_image') ?: pz_brand_image('hero_image')): ?>
            <img
                class="pz-logo-photo"
                src="<?= htmlspecialchars($pz_logo_img) ?>"
                alt="<?= htmlspecialchars($brand['name'] . ', ' . $brand['city'] . ', ' . $brand['country']) ?>"
                width="40"
                height="40"
                decoding="async"
            >
            <?php else: ?>
            <span class="pz-logo-mark" aria-hidden="true">🍕</span>
            <?php endif; ?>
            <span class="pz-logo-text">
                <strong><?= htmlspecialchars($brand['name']) ?></strong>
                <span><?= htmlspecialchars($brand['city']) ?>, <?= htmlspecialchars($brand['country']) ?></span>
            </span>
        </a>
        <?php
        $pz_desktop_nav = [
            ['href' => $pz_on_home ? '#menu' : pz_page_url('menu'), 'label' => $t['nav_menu'] ?? 'Menu'],
            ['href' => $pz_on_home ? '#about' : pz_page_url('about'), 'label' => $t['nav_about'] ?? 'About'],
            ['href' => $pz_on_home ? '#solaskinner' : pz_page_url('terrace'), 'label' => $t['nav_sol'] ?? 'Terrace'],
            ['href' => $pz_on_home ? '#reserve' : pz_page_url('reservations'), 'label' => $t['nav_reserve'] ?? 'Reserve'],
            ['href' => $pz_on_home ? '#contact' : pz_url('contact.php'), 'label' => $t['nav_contact'] ?? 'Contact'],
        ];
        ?>
        <nav class="pz-nav pz-nav--desktop" aria-label="<?= htmlspecialchars($t['nav_main'] ?? 'Main') ?>">
            <?php foreach ($pz_desktop_nav as $navItem): ?>
            <a href="<?= htmlspecialchars($navItem['href']) ?>"><?= htmlspecialchars($navItem['label']) ?></a>
            <?php endforeach; ?>
        </nav>
        <div class="pz-header-actions">
            <?php require __DIR__ . '/lang-dropdown.php'; ?>
            <a href="tel:<?= htmlspecialchars($brand['phone']) ?>" class="pz-btn pz-btn-ghost pz-btn-order">
                <i class="fas fa-phone" aria-hidden="true"></i>
                <span class="pz-btn-label"><?= htmlspecialchars($t['nav_order']) ?></span>
            </a>
            <a href="<?= $pz_on_home ? '#reserve' : htmlspecialchars($pz_home . '#reserve') ?>" class="pz-btn pz-btn-primary pz-btn-reserve">
                <i class="fas fa-calendar-check" aria-hidden="true"></i>
                <span class="pz-btn-label"><?= htmlspecialchars($t['nav_reserve']) ?></span>
            </a>
            <button type="button" class="pz-burger" id="pzBurger" aria-controls="pzMobilePanel" aria-expanded="false" aria-label="<?= htmlspecialchars($t['nav_menu']) ?>">
                <i class="fas fa-bars pz-burger-open" aria-hidden="true"></i>
                <i class="fas fa-times pz-burger-close" aria-hidden="true"></i>
            </button>
        </div>
    </div>
    <div class="pz-nav-overlay" id="pzNavOverlay" hidden></div>
    <div class="pz-mobile-panel" id="pzMobilePanel" hidden>
        <nav class="pz-nav-mobile" aria-label="<?= htmlspecialchars($t['nav_main'] ?? 'Main') ?>">
            <a href="<?= $pz_on_home ? '#menu' : htmlspecialchars($pz_home . '#menu') ?>" class="pz-nav-mobile-link pz-nav-mobile-link--primary">
                <i class="fas fa-utensils" aria-hidden="true"></i>
                <?= htmlspecialchars($t['nav_menu']) ?>
            </a>
            <div class="pz-nav-mobile-sub" role="group" aria-label="<?= htmlspecialchars($t['menu_categories'] ?? 'Menu categories') ?>">
                <a href="<?= $pz_on_home ? '#menu-pizza' : htmlspecialchars($pz_home . '#menu-pizza') ?>" class="pz-nav-mobile-chip" data-menu-filter="pizza"><?= htmlspecialchars($t['filter_pizza']) ?></a>
                <a href="<?= $pz_on_home ? '#menu-pasta' : htmlspecialchars($pz_home . '#menu-pasta') ?>" class="pz-nav-mobile-chip" data-menu-filter="pasta"><?= htmlspecialchars($t['filter_pasta']) ?></a>
                <a href="<?= $pz_on_home ? '#menu-starters' : htmlspecialchars($pz_home . '#menu-starters') ?>" class="pz-nav-mobile-chip" data-menu-filter="starters"><?= htmlspecialchars($t['filter_starters']) ?></a>
                <a href="<?= $pz_on_home ? '#menu-dessert' : htmlspecialchars($pz_home . '#menu-dessert') ?>" class="pz-nav-mobile-chip" data-menu-filter="dessert"><?= htmlspecialchars($t['filter_dessert']) ?></a>
                <a href="<?= $pz_on_home ? '#menu-drinks' : htmlspecialchars($pz_home . '#menu-drinks') ?>" class="pz-nav-mobile-chip" data-menu-filter="drinks"><?= htmlspecialchars($t['filter_drinks']) ?></a>
            </div>
            <a href="<?= $pz_on_home ? '#about' : htmlspecialchars($pz_home . '#about') ?>" class="pz-nav-mobile-link"><?= htmlspecialchars($t['nav_about']) ?></a>
            <a href="<?= $pz_on_home ? '#gallery' : htmlspecialchars($pz_home . '#gallery') ?>" class="pz-nav-mobile-link"><?= htmlspecialchars($t['nav_gallery']) ?></a>
            <a href="<?= $pz_on_home ? '#solaskinner' : htmlspecialchars($pz_home . '#solaskinner') ?>" class="pz-nav-mobile-link"><?= htmlspecialchars($t['nav_sol']) ?></a>
            <a href="<?= $pz_on_home ? '#reserve' : htmlspecialchars($pz_home . '#reserve') ?>" class="pz-nav-mobile-link"><?= htmlspecialchars($t['nav_reserve']) ?></a>
            <a href="<?= $pz_on_home ? '#contact' : htmlspecialchars(pz_url('contact.php')) ?>" class="pz-nav-mobile-link"><?= htmlspecialchars($t['nav_contact']) ?></a>
            <a href="<?= $pz_on_home ? '#maps' : htmlspecialchars($pz_home . '#maps') ?>" class="pz-nav-mobile-link">
                <i class="fab fa-google" aria-hidden="true"></i>
                <?= htmlspecialchars($t['nav_maps'] ?? 'Maps') ?>
            </a>
            <a href="<?= htmlspecialchars($brand['google_review_url']) ?>" class="pz-nav-mobile-link pz-nav-mobile-link--google" target="_blank" rel="noopener noreferrer">
                <i class="fas fa-star" aria-hidden="true"></i>
                <?= htmlspecialchars($t['review_btn']) ?>
            </a>
            <a href="tel:<?= htmlspecialchars($brand['phone']) ?>" class="pz-nav-mobile-link pz-nav-mobile-link--phone">
                <i class="fas fa-phone" aria-hidden="true"></i>
                <?= htmlspecialchars($t['nav_order']) ?>
            </a>
            <div class="pz-nav-mobile-lang">
                <?php
                $dropdown_id = 'pzLangDropdownMobile';
                $btn_id = 'pzLangBtnMobile';
                $menu_id = 'pzLangMenuMobile';
                require __DIR__ . '/lang-dropdown.php';
                ?>
            </div>
            <div class="pz-nav-mobile-legal">
                <a href="https://bilohash.com/website/privacy-policy.php"><?= htmlspecialchars($t['footer']['privacy'] ?? 'Privacy') ?></a>
                <a href="https://bilohash.com/website/cookies.php"><?= htmlspecialchars($t['footer']['cookies'] ?? 'Cookies') ?></a>
            </div>
        </nav>
    </div>
</header>
<main id="top">