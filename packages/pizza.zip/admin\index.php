<?php
require_once __DIR__ . '/init.php';
pz_admin_require();

$admin_page = 'dashboard';
$page_title = $ta['dashboard'] ?? 'Dashboard';
$items = pz_menu_items(true);
$stats   = pz_platform_stats();
$chart   = pz_admin_category_chart();
$featured = array_values(array_filter($items, fn($i) => !empty($i['featured'])));
$reservations = array_map('pz_normalize_reservation', pz_load_reservations());
usort($reservations, static function (array $a, array $b): int {
    $da = ($a['date'] ?? '') . ' ' . ($a['time'] ?? '');
    $db = ($b['date'] ?? '') . ' ' . ($b['time'] ?? '');
    return strcmp($da, $db);
});
$pending_count = count(array_filter($reservations, static fn(array $r): bool => ($r['status'] ?? '') !== 'paid'));
$status_labels = [
    'pending'   => $ta['status_pending'] ?? 'Pending',
    'confirmed' => $ta['status_confirmed'] ?? 'Confirmed',
    'paid'      => $ta['status_paid'] ?? 'Paid',
];

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-alert adm-alert-info">
    <i class="fas fa-flask"></i> <?= htmlspecialchars($ta['add_note'] ?? 'Demo data — menu loaded from JSON seed.') ?>
</div>

<div class="adm-stats">
    <div class="adm-stat">
        <div class="adm-stat-icon blue"><i class="fas fa-utensils"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($items) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_items'] ?? 'Menu items') ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon green"><i class="fas fa-star"></i></div>
        <div>
            <div class="adm-stat-val"><?= (int) $stats['featured'] ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_featured'] ?? 'Featured') ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon orange"><i class="fas fa-layer-group"></i></div>
        <div>
            <div class="adm-stat-val"><?= (int) $stats['categories'] ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_cats'] ?? 'Categories') ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon gold"><i class="fas fa-coins"></i></div>
        <div>
            <div class="adm-stat-val"><?= pz_price((int) $stats['volume']) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_vol'] ?? 'Menu value') ?></div>
        </div>
    </div>
    <div class="adm-stat">
        <div class="adm-stat-icon purple"><i class="fas fa-calendar-check"></i></div>
        <div>
            <div class="adm-stat-val"><?= count($reservations) ?></div>
            <div class="adm-stat-label"><?= htmlspecialchars($ta['stats_reservations'] ?? 'Reservations') ?></div>
        </div>
    </div>
</div>

<div class="adm-dash-grid">
    <div class="adm-card">
        <div class="adm-card-head"><h2><?= htmlspecialchars($ta['by_category'] ?? 'By category') ?></h2></div>
        <div class="adm-card-body padded">
            <div class="adm-bar-chart">
                <?php foreach ($chart as $row): ?>
                <div class="adm-bar-row">
                    <span class="adm-bar-label"><?= htmlspecialchars($t['categories'][$row['cat']] ?? $row['cat']) ?></span>
                    <div class="adm-bar-track"><div class="adm-bar-fill" style="width:<?= (int) $row['pct'] ?>%"></div></div>
                    <span class="adm-bar-val"><?= (int) $row['count'] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="adm-card">
        <div class="adm-card-head">
            <h2><?= htmlspecialchars($ta['featured_count'] ?? 'Featured dishes') ?></h2>
            <a href="<?= pz_url('index.php#menu') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank"><?= htmlspecialchars($ta['view_site'] ?? 'View site') ?></a>
        </div>
        <div class="adm-card-body padded adm-product-list">
            <?php foreach (array_slice($featured, 0, 6) as $fp): ?>
            <div class="adm-product-item">
                <?php if ($thumb = pz_menu_image($fp)): ?>
                <img src="<?= htmlspecialchars($thumb) ?>" alt="" width="48" height="48" loading="lazy" decoding="async">
                <?php endif; ?>
                <div>
                    <strong><?= htmlspecialchars(pz_localized($fp, 'name')) ?></strong>
                    <span><?= pz_price((int) $fp['price']) ?> · <?= htmlspecialchars($t['categories'][$fp['cat'] ?? ''] ?? '') ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="adm-card adm-res-card">
    <div class="adm-card-head">
        <h2><i class="fas fa-chair"></i> <?= htmlspecialchars($ta['reservations'] ?? 'Reservations') ?></h2>
        <div class="adm-card-head-actions">
            <span class="adm-res-pill"><?= (int) $pending_count ?> <?= htmlspecialchars($ta['awaiting_payment'] ?? 'awaiting payment') ?></span>
            <a href="<?= pz_url('index.php#reserve') ?>" class="adm-btn adm-btn-outline adm-btn-sm" target="_blank"><?= htmlspecialchars($ta['view_reserve_form'] ?? 'Reserve form') ?></a>
        </div>
    </div>
    <div class="adm-card-body padded">
        <?php if ($reservations === []): ?>
        <p class="adm-muted-text"><?= htmlspecialchars($ta['no_reservations'] ?? 'No reservations yet.') ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
            <table class="adm-res-table">
                <thead>
                    <tr>
                        <th><?= htmlspecialchars($ta['col_date'] ?? 'Date') ?></th>
                        <th><?= htmlspecialchars($ta['col_guests'] ?? 'Guests') ?></th>
                        <th><?= htmlspecialchars($ta['col_guest'] ?? 'Guest') ?></th>
                        <th><?= htmlspecialchars($ta['col_note'] ?? 'Note') ?></th>
                        <th><?= htmlspecialchars($ta['col_deposit'] ?? 'Deposit') ?></th>
                        <th><?= htmlspecialchars($ta['col_status'] ?? 'Status') ?></th>
                        <th><?= htmlspecialchars($ta['col_payment'] ?? 'Payment') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservations as $res): ?>
                    <?php
                        $status = $res['status'] ?? 'pending';
                        $isPaid = $status === 'paid' || ($res['payment'] ?? '') === 'vipps_demo';
                        $amount = (int) ($res['amount_nok'] ?? 200);
                    ?>
                    <tr data-res-id="<?= htmlspecialchars($res['id'] ?? '') ?>">
                        <td>
                            <strong><?= htmlspecialchars($res['date'] ?? '') ?></strong>
                            <?php if (!empty($res['time'])): ?>
                            <span class="adm-res-time"><?= htmlspecialchars($res['time']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?= (int) ($res['guests'] ?? 0) ?></td>
                        <td>
                            <strong><?= htmlspecialchars($res['name'] ?? '') ?></strong>
                            <span class="adm-res-meta"><?= htmlspecialchars($res['phone'] ?? '') ?></span>
                            <?php if (!empty($res['email'])): ?>
                            <span class="adm-res-meta"><?= htmlspecialchars($res['email']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="adm-res-note"><?= htmlspecialchars($res['note'] ?? '—') ?></td>
                        <td><?= pz_price($amount) ?></td>
                        <td>
                            <span class="adm-status adm-status-<?= htmlspecialchars($status) ?>">
                                <?= htmlspecialchars($status_labels[$status] ?? $status) ?>
                            </span>
                        </td>
                        <td class="adm-res-pay">
                            <?php if ($isPaid): ?>
                            <span class="adm-vipps-paid"><i class="fas fa-check-circle"></i> Vipps</span>
                            <?php else: ?>
                            <button type="button"
                                class="adm-vipps-btn"
                                data-id="<?= htmlspecialchars($res['id'] ?? '') ?>"
                                data-amount="<?= $amount ?>"
                                aria-label="<?= htmlspecialchars(($ta['vipps_pay'] ?? 'Pay with Vipps') . ' — ' . ($res['name'] ?? '')) ?>">
                                <svg class="adm-vipps-icon" viewBox="0 0 48 16" aria-hidden="true"><text x="0" y="13" fill="currentColor" font-family="Segoe UI,sans-serif" font-size="14" font-weight="800">Vipps</text></svg>
                                <?= htmlspecialchars($ta['vipps_pay'] ?? 'Pay with Vipps') ?>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="adm-vipps-note"><i class="fas fa-info-circle"></i> <?= htmlspecialchars($ta['vipps_demo_note'] ?? 'Demo only — no real Vipps payment is processed.') ?></p>
        <?php endif; ?>
    </div>
</div>

<div class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($ta['quick_actions'] ?? 'Quick actions') ?></h2></div>
    <div class="adm-card-body padded adm-quick-actions">
        <a href="<?= pz_admin_url('menu.php') ?>" class="adm-btn adm-btn-primary"><i class="fas fa-utensils"></i> <?= htmlspecialchars($ta['menu_manage'] ?? 'Manage menu') ?></a>
        <a href="<?= pz_url('index.php') ?>" class="adm-btn adm-btn-outline" target="_blank"><i class="fas fa-store"></i> <?= htmlspecialchars($ta['view_site'] ?? 'View site') ?></a>
        <a href="<?= pz_url('contact.php') ?>" class="adm-btn adm-btn-outline" target="_blank"><i class="fas fa-comments"></i> <?= htmlspecialchars($ta['contact'] ?? 'Contact') ?></a>
        <a href="https://bilohash.com/pizza/site/" class="adm-btn adm-btn-outline" target="_blank"><i class="fas fa-book"></i> <?= htmlspecialchars($ta['product_page'] ?? 'Product page') ?></a>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-foot.php'; ?>