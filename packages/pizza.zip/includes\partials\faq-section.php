<?php
/** @var array $faq_items @var string $faq_title */
if (empty($faq_items)) {
    return;
}
?>
<section class="pz-section pz-faq-section" id="faq">
    <div class="pz-container">
        <div class="pz-section-head">
            <h2><?= htmlspecialchars($faq_title) ?></h2>
        </div>
        <div class="pz-faq-list">
            <?php foreach ($faq_items as $item): ?>
            <details class="pz-faq-item">
                <summary><?= htmlspecialchars($item['q'] ?? $item['question'] ?? '') ?></summary>
                <p><?= htmlspecialchars($item['a'] ?? $item['answer'] ?? '') ?></p>
            </details>
            <?php endforeach; ?>
        </div>
    </div>
</section>