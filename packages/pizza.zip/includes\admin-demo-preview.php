<?php
$adm = $t['admin_demo'] ?? [];
$ta  = $t['admin'] ?? [];
$adm_stats = pz_platform_stats();
$adm_featured = array_values(array_filter(pz_menu_items(), fn($i) => !empty($i['featured']) && ($i['active'] ?? true)));
$adm_featured = array_slice($adm_featured, 0, 3);
$adm_chart = array_slice(pz_admin_category_chart(), 0, 4);
?>
<div class="pz-admin-demo" aria-label="<?= htmlspecialchars($adm['preview_label'] ?? 'Admin preview') ?>">
    <div class="pz-adm-window">
        <div class="pz-adm-chrome">
            <span></span><span></span><span></span>
            <em><?= htmlspecialchars($adm['preview_label'] ?? 'Dashboard preview') ?></em>
        </div>
        <div class="pz-adm-layout">
            <aside class="pz-adm-side" aria-hidden="true">
                <div class="pz-adm-brand">
                    <span class="pz-adm-logo">P</span>
                    <span>Pizza CMS</span>
                </div>
                <nav class="pz-adm-nav">
                    <span class="is-active"><i class="fas fa-chart-pie"></i> <?= htmlspecialchars($ta['dashboard'] ?? 'Dashboard') ?></span>
                    <span><i class="fas fa-utensils"></i> <?= htmlspecialchars($ta['menu_manage'] ?? 'Menu') ?></span>
                    <span><i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['view_site'] ?? 'View site') ?></span>
                </nav>
            </aside>
            <div class="pz-adm-main">
                <div class="pz-adm-top">
                    <strong><?= htmlspecialchars($ta['dashboard'] ?? 'Dashboard') ?></strong>
                    <span><i class="fas fa-user-circle"></i> demo</span>
                </div>
                <div class="pz-adm-body">
                    <div class="pz-adm-stats">
                        <div class="pz-adm-stat pz-adm-stat--blue">
                            <i class="fas fa-utensils"></i>
                            <div><strong><?= (int) $adm_stats['items'] ?></strong><span><?= htmlspecialchars($adm['stats_items'] ?? 'Menu items') ?></span></div>
                        </div>
                        <div class="pz-adm-stat pz-adm-stat--green">
                            <i class="fas fa-star"></i>
                            <div><strong><?= (int) $adm_stats['featured'] ?></strong><span><?= htmlspecialchars($adm['stats_featured'] ?? 'Featured') ?></span></div>
                        </div>
                        <div class="pz-adm-stat pz-adm-stat--gold">
                            <i class="fas fa-layer-group"></i>
                            <div><strong><?= (int) $adm_stats['categories'] ?></strong><span><?= htmlspecialchars($adm['stats_cats'] ?? 'Categories') ?></span></div>
                        </div>
                    </div>
                    <div class="pz-adm-panel">
                        <div class="pz-adm-panel-head"><?= htmlspecialchars($ta['featured_count'] ?? 'Featured dishes') ?></div>
                        <ul class="pz-adm-menu-list">
                            <?php foreach ($adm_featured as $fp): ?>
                            <li>
                                <?php if ($thumb = pz_menu_image($fp)): ?>
                                <img src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars(pz_localized($fp, 'name')) ?>" width="40" height="40" loading="lazy" decoding="async">
                                <?php else: ?>
                                <span class="pz-adm-thumb-fallback"><i class="fas fa-pizza-slice"></i></span>
                                <?php endif; ?>
                                <div>
                                    <strong><?= htmlspecialchars(pz_localized($fp, 'name')) ?></strong>
                                    <span><?= pz_price((int) $fp['price']) ?></span>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php if ($adm_chart): ?>
                    <div class="pz-adm-bars" aria-hidden="true">
                        <?php foreach ($adm_chart as $row): ?>
                        <div class="pz-adm-bar-row">
                            <span><?= htmlspecialchars($t['categories'][$row['cat']] ?? $row['cat']) ?></span>
                            <div class="pz-adm-bar"><i style="width:<?= (int) $row['pct'] ?>%"></i></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <p class="pz-admin-creds">
        <i class="fas fa-key" aria-hidden="true"></i>
        <?= htmlspecialchars($ta['demo_creds'] ?? 'Demo login: demo / pizza2026') ?>
    </p>
    <a href="<?= htmlspecialchars(pz_admin_url('login.php')) ?>" class="pz-btn pz-btn-primary pz-admin-cta" target="_blank" rel="noopener noreferrer">
        <i class="fas fa-user-shield" aria-hidden="true"></i>
        <?= htmlspecialchars($adm['cta'] ?? 'Open admin demo') ?>
    </a>
</div>