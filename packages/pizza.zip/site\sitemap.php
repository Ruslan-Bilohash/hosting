<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/landing-lib.php';
header('Content-Type: application/xml; charset=UTF-8');

$base = 'https://bilohash.com/pizza/site';
$langs = ['no', 'uk', 'ru'];
$lastmod = date('Y-m-d', max(
    filemtime(__DIR__ . '/index.php'),
    filemtime(__DIR__ . '/usecase.php'),
    filemtime(__DIR__ . '/market.php')
));

$urls = [
    ['loc' => $base . '/', 'priority' => '1.0', 'hreflang' => true, 'path' => '/pizza/site/'],
    ['loc' => $base . '/solutions', 'priority' => '0.95', 'hreflang' => true, 'path' => '/pizza/site/solutions'],
    ['loc' => $base . '/markets', 'priority' => '0.95', 'hreflang' => true, 'path' => '/pizza/site/markets'],
];

foreach (pzs_usecase_slugs() as $slug) {
    $urls[] = ['loc' => $base . '/' . $slug, 'priority' => '0.9', 'hreflang' => true, 'path' => '/pizza/site/' . $slug];
}
foreach (pzs_market_slugs() as $slug) {
    $urls[] = ['loc' => $base . '/' . $slug, 'priority' => '0.88', 'hreflang' => true, 'path' => '/pizza/site/' . $slug];
}

foreach ($langs as $lng) {
    $urls[] = ['loc' => $base . '/?lang=' . $lng, 'priority' => '0.85'];
    $urls[] = ['loc' => $base . '/solutions?lang=' . $lng, 'priority' => '0.84'];
    $urls[] = ['loc' => $base . '/markets?lang=' . $lng, 'priority' => '0.84'];
    foreach (pzs_usecase_slugs() as $slug) {
        $urls[] = ['loc' => $base . '/' . $slug . '?lang=' . $lng, 'priority' => '0.82'];
    }
    foreach (pzs_market_slugs() as $slug) {
        $urls[] = ['loc' => $base . '/' . $slug . '?lang=' . $lng, 'priority' => '0.8'];
    }
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
<?php foreach ($urls as $u): ?>
    <url>
        <loc><?= htmlspecialchars($u['loc']) ?></loc>
        <lastmod><?= htmlspecialchars($lastmod) ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority><?= $u['priority'] ?? '0.5' ?></priority>
        <?php if (!empty($u['hreflang']) && !empty($u['path'])): ?>
        <xhtml:link rel="alternate" hreflang="x-default" href="https://bilohash.com<?= htmlspecialchars($u['path']) ?>"/>
        <xhtml:link rel="alternate" hreflang="en" href="https://bilohash.com<?= htmlspecialchars($u['path']) ?>"/>
        <xhtml:link rel="alternate" hreflang="no" href="https://bilohash.com<?= htmlspecialchars($u['path']) ?>?lang=no"/>
        <xhtml:link rel="alternate" hreflang="uk" href="https://bilohash.com<?= htmlspecialchars($u['path']) ?>?lang=uk"/>
        <xhtml:link rel="alternate" hreflang="ru" href="https://bilohash.com<?= htmlspecialchars($u['path']) ?>?lang=ru"/>
        <?php endif; ?>
    </url>
<?php endforeach; ?>
</urlset>