<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/init.php';
pz_admin_require();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed']);
    exit;
}

$id = trim($_POST['id'] ?? '');
$action = trim($_POST['action'] ?? '');

if ($id === '' || $action !== 'vipps_demo') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => $ta['error'] ?? 'Invalid request']);
    exit;
}

$reservations = pz_load_reservations();
$target = null;
foreach ($reservations as $row) {
    if (($row['id'] ?? '') === $id) {
        $target = $row;
        break;
    }
}

if ($target === null) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => $ta['error'] ?? 'Not found']);
    exit;
}

if (($target['status'] ?? '') === 'paid') {
    echo json_encode([
        'ok' => true,
        'already' => true,
        'message' => $ta['vipps_already_paid'] ?? 'Already paid',
    ]);
    exit;
}

if (!pz_update_reservation_status($id, 'paid', 'vipps_demo')) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => $ta['error'] ?? 'Could not save']);
    exit;
}

echo json_encode([
    'ok' => true,
    'message' => $ta['vipps_demo_success'] ?? 'Demo payment recorded',
]);