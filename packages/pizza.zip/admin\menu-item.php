<?php
require_once __DIR__ . '/init.php';
pz_admin_require();

$admin_page = 'menu';
$id = trim($_GET['id'] ?? '');
$editing = $id !== '';
$page_title = $editing ? ($ta['edit_item'] ?? 'Edit item') : ($ta['add_item'] ?? 'Add item');
$item = $editing ? pz_menu_by_id($id, true) : null;

if ($editing && !$item) {
    header('Location: ' . pz_admin_url('menu.php'), true, 302);
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nameEn = trim($_POST['name_en'] ?? '');
    if ($nameEn === '') {
        $error = $ta['error_name'] ?? 'Name (EN) is required.';
    } else {
        $newId = trim($_POST['id'] ?? '');
        if ($newId === '') {
            $newId = pz_next_menu_id(pz_slugify($nameEn));
        }
        $list = pz_menu_items(true);
        if (!$editing && pz_menu_by_id($newId, true)) {
            $error = $ta['error_id'] ?? 'ID already exists.';
        } else {
            $tags = array_values(array_filter(array_map('trim', explode(',', $_POST['tags'] ?? ''))));
            $image = trim($_POST['image'] ?? '');
            if ($image === '' && !empty($v['image'])) {
                $image = trim((string) $v['image']);
            }
            $record = [
                'id' => $newId,
                'cat' => $_POST['cat'] ?? 'pizza',
                'price' => max(0, (int) ($_POST['price'] ?? 0)),
                'active' => !empty($_POST['active']),
                'featured' => !empty($_POST['featured']),
                'tags' => $tags,
                'name' => [
                    'en' => $nameEn,
                    'no' => trim($_POST['name_no'] ?? '') ?: $nameEn,
                    'uk' => trim($_POST['name_uk'] ?? '') ?: $nameEn,
                    'ru' => trim($_POST['name_ru'] ?? '') ?: $nameEn,
                ],
                'desc' => [
                    'en' => trim($_POST['desc_en'] ?? ''),
                    'no' => trim($_POST['desc_no'] ?? ''),
                    'uk' => trim($_POST['desc_uk'] ?? ''),
                    'ru' => trim($_POST['desc_ru'] ?? ''),
                ],
            ];
            if ($image !== '') {
                $record['image'] = $image;
            }
            $found = false;
            foreach ($list as $i => $row) {
                if (($row['id'] ?? '') === ($editing ? $id : $newId)) {
                    $list[$i] = $record;
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $list[] = $record;
            }
            pz_save_menu($list);
            header('Location: ' . pz_admin_url('menu.php'), true, 302);
            exit;
        }
    }
}

$v = $item ?? [];
require __DIR__ . '/includes/layout.php';
?>

<?php if ($error): ?><div class="adm-alert adm-alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="post" class="adm-card">
    <div class="adm-card-head"><h2><?= htmlspecialchars($page_title) ?></h2></div>
    <div class="adm-card-body padded adm-form-grid">
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['id'] ?? 'ID') ?></label>
            <input type="text" name="id" value="<?= htmlspecialchars($v['id'] ?? '') ?>" <?= $editing ? 'readonly' : '' ?> placeholder="auto">
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['category'] ?? 'Category') ?></label>
            <select name="cat">
                <?php foreach (pz_categories() as $cat): ?>
                <option value="<?= htmlspecialchars($cat) ?>"<?= ($v['cat'] ?? 'pizza') === $cat ? ' selected' : '' ?>><?= htmlspecialchars($t['categories'][$cat] ?? $cat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['price'] ?? 'Price (NOK)') ?></label>
            <input type="number" name="price" min="0" value="<?= (int) ($v['price'] ?? 0) ?>">
        </div>
        <div class="adm-field">
            <label><?= htmlspecialchars($ta['tags'] ?? 'Tags') ?></label>
            <input type="text" name="tags" value="<?= htmlspecialchars(implode(', ', $v['tags'] ?? [])) ?>" placeholder="veg, spicy, chef">
        </div>
        <div class="adm-field adm-field--full">
            <label><?= htmlspecialchars($ta['image'] ?? 'Image path') ?></label>
            <input type="text" name="image" value="<?= htmlspecialchars($v['image'] ?? '') ?>" placeholder="images/menu/margherita-dop.jpg">
            <?php if (!empty($v['image']) && ($imgUrl = pz_menu_image($v))): ?>
            <img src="<?= htmlspecialchars($imgUrl) ?>" alt="" class="adm-menu-preview" width="120" height="90" loading="lazy">
            <?php endif; ?>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="active" value="1"<?= ($v['active'] ?? true) ? ' checked' : '' ?>> <?= htmlspecialchars($ta['active'] ?? 'Active') ?></label>
        </div>
        <div class="adm-field adm-field-check">
            <label><input type="checkbox" name="featured" value="1"<?= !empty($v['featured']) ? ' checked' : '' ?>> <?= htmlspecialchars($ta['featured'] ?? 'Featured') ?></label>
        </div>
        <?php foreach (['en','no','uk','ru'] as $lc): ?>
        <div class="adm-field adm-field--full">
            <label><?= htmlspecialchars($ta['name_' . $lc] ?? 'Name ' . strtoupper($lc)) ?></label>
            <input type="text" name="name_<?= $lc ?>" value="<?= htmlspecialchars($v['name'][$lc] ?? '') ?>" <?= $lc === 'en' ? 'required' : '' ?>>
        </div>
        <div class="adm-field adm-field--full">
            <label><?= htmlspecialchars($ta['desc_' . $lc] ?? 'Description ' . strtoupper($lc)) ?></label>
            <textarea name="desc_<?= $lc ?>" rows="2"><?= htmlspecialchars($v['desc'][$lc] ?? '') ?></textarea>
        </div>
        <?php endforeach; ?>
        <div class="adm-form-actions">
            <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= htmlspecialchars($ta['save'] ?? 'Save') ?></button>
            <a href="<?= pz_admin_url('menu.php') ?>" class="adm-btn adm-btn-outline"><?= htmlspecialchars($ta['cancel'] ?? 'Cancel') ?></a>
        </div>
    </div>
</form>

<?php require __DIR__ . '/includes/layout-foot.php'; ?>