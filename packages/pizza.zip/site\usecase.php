<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/landing-lib.php';

$slug = trim((string) ($_GET['slug'] ?? ''));
$item = pzs_usecase_by_slug($slug);
if (!$item) {
    header('Location: ' . pzs_url('solutions.php'), true, 302);
    exit;
}

$GLOBALS['landing_slug'] = $slug;
$GLOBALS['landing_type'] = 'usecase';
$v = pzs_landing_lang($item, $lang);
$page_title = $v['title'];
$page_desc  = $v['description'];
$canonical  = pzs_landing_canonical($slug);
$canon_abs  = pzs_absolute_url($canonical);
$page_keywords = $v['keywords'] ?? null;

$seo_schemas = pzs_landing_seo_schemas($canon_abs, $page_title, $page_desc, $v, [
    ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => pzs_absolute_url(pzs_url('index.php'))],
    ['name' => $t['solutions']['hub_title'] ?? 'Solutions', 'url' => pzs_absolute_url(pzs_url('solutions.php'))],
    ['name' => $v['h1'], 'url' => $canon_abs],
]);

require __DIR__ . '/includes/landing-template.php';