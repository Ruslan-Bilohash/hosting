<?php
if (empty($pz_skip_ecosystem) && is_file(__DIR__ . '/ecosystem-strip.php')) {
    require __DIR__ . '/ecosystem-strip.php';
}
$ft = $t['footer'] ?? [];
$pz_copyright = sprintf($ft['copyright'] ?? '© %s Forno Romano Demo.', date('Y'));
?>
</main>

<footer class="pz-footer">
    <div class="pz-container pz-footer-grid">
        <div class="pz-footer-col">
            <h4><?= htmlspecialchars($brand['name']) ?></h4>
            <p class="pz-footer-text"><?= htmlspecialchars($t['footer_tag'] ?? '') ?></p>
            <p class="pz-footer-dev">
                <i class="fas fa-code" aria-hidden="true"></i>
                <?= htmlspecialchars($ft['dev_notice'] ?? '') ?>
            </p>
            <a href="https://bilohash.com/pizza/site/" class="pz-footer-product"><?= htmlspecialchars($t['footer_demo'] ?? 'Pizza CMS') ?></a>
        </div>
        <div class="pz-footer-col">
            <h4><?= htmlspecialchars($ft['links'] ?? 'Links') ?></h4>
            <ul class="pz-footer-list">
                <li><a href="<?= htmlspecialchars(pz_page_url('menu')) ?>"><?= htmlspecialchars($t['nav_menu'] ?? 'Menu') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_page_url('about')) ?>"><?= htmlspecialchars($t['nav_about'] ?? 'About') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_page_url('terrace')) ?>"><?= htmlspecialchars($t['nav_sol'] ?? 'Terrace') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_page_url('reservations')) ?>"><?= htmlspecialchars($t['nav_reserve'] ?? 'Reserve') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_page_url('gallery')) ?>"><?= htmlspecialchars($t['nav_gallery'] ?? 'Gallery') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_url('index.php#maps')) ?>"><?= htmlspecialchars($t['nav_maps'] ?? 'Maps') ?></a></li>
                <li><a href="<?= htmlspecialchars($brand['google_review_url']) ?>" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($t['review_btn'] ?? 'Google review') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_url('contact.php')) ?>"><?= htmlspecialchars($t['nav_contact'] ?? 'Contact') ?></a></li>
                <li><a href="<?= htmlspecialchars(pz_url('admin/login.php')) ?>"><?= htmlspecialchars($t['admin']['title'] ?? 'Admin') ?></a></li>
            </ul>
        </div>
        <div class="pz-footer-col">
            <h4><?= htmlspecialchars($ft['legal'] ?? 'Legal') ?></h4>
            <ul class="pz-footer-list">
                <li><a href="https://bilohash.com/website/privacy-policy.php"><?= htmlspecialchars($ft['privacy'] ?? 'Privacy policy') ?></a></li>
                <li><a href="https://bilohash.com/website/cookies.php"><?= htmlspecialchars($ft['cookies'] ?? 'Cookies') ?></a></li>
                <li><a href="https://bilohash.com/"><?= htmlspecialchars($ft['portfolio'] ?? 'Bilohash.com') ?></a></li>
            </ul>
        </div>
        <div class="pz-footer-col pz-footer-col--social">
            <h4><?= htmlspecialchars($ft['follow'] ?? 'Follow') ?></h4>
            <div class="pz-social">
                <a href="<?= htmlspecialchars($brand['instagram']) ?>" target="_blank" rel="noopener" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="<?= htmlspecialchars($brand['facebook']) ?>" target="_blank" rel="noopener" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://wa.me/<?= htmlspecialchars($brand['phone_raw']) ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
    <?php if (!empty($t['ecosystem']['items'])): ?>
    <div class="pz-container pz-footer-eco">
        <?php require dirname(__DIR__, 2) . '/includes/ecosystem-footer-pills.php'; ?>
    </div>
    <?php endif; ?>
    <?php require __DIR__ . '/footer-eco-cloud.php'; ?>
    <div class="pz-container pz-footer-bottom">
        <p><?= htmlspecialchars($pz_copyright) ?></p>
    </div>
</footer>

<script src="<?= htmlspecialchars(pz_asset('js/site.js')) ?>?v=4" defer></script>
<?php
$gdpr_lang = match ($lang) {
    'uk' => 'uk', 'ru' => 'ru', 'en' => 'en', 'no' => 'no', default => 'en',
};
$gdpr_privacy_url = '/website/privacy-policy.php';
$gdpr_cookies_url = '/website/cookies.php';
$gdpr_storage_key = 'pz_gdpr_consent';
$gdpr_include = dirname(__DIR__, 2) . '/includes/gdpr-consent.php';
if (is_file($gdpr_include)) {
    include $gdpr_include;
}
bh_cms_render_chat_widget('Pizza CMS', pz_site_settings(), $lang ?? 'en');
?>
</body>
</html>