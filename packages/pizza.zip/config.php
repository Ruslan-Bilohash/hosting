<?php
/**
 * Bilohash Pizza CMS — restaurant & pizzeria demo
 * /pizza
 */
define('PZ_BASE_PATH', '/pizza');
define('PZ_DOMAIN', 'bilohash.com');
define('PZ_SITE_NAME', 'Pizza CMS');
define('PZ_CURRENCY', 'NOK');
define('PZ_DEMO_MODE', true);
define('PZ_BRAND_NAME', 'Forno Romano');

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, PZ_DOMAIN) !== false) ? PZ_BASE_PATH : ($detected ?: PZ_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function pz_url(string $path = '', ?string $langCode = null): string
{
    global $base_path, $lang;
    $langCode = $langCode ?? $lang;
    $path = ltrim($path, '/');
    $url = rtrim($base_path, '/') . ($path !== '' ? '/' . $path : '/');
    if ($langCode !== 'en') {
        $url .= (str_contains($url, '?') ? '&' : '?') . 'lang=' . urlencode($langCode);
    }
    return $url;
}

function pz_page_url(string $slug, ?string $langCode = null): string
{
    global $base_path, $lang;
    $langCode = $langCode ?? $lang;
    $url = rtrim($base_path, '/') . '/' . rawurlencode($slug);
    if ($langCode !== 'en') {
        $url .= '?lang=' . urlencode($langCode);
    }
    return $url;
}

function pz_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function pz_price(int $amount): string
{
    return number_format($amount, 0, ',', ' ') . ' kr';
}

if (!function_exists('bh_str_lower')) {
    function bh_str_lower(string $str): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($str) : strtolower($str);
    }
}