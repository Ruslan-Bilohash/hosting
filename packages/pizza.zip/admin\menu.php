<?php
require_once __DIR__ . '/init.php';
pz_admin_require();

$admin_page = 'menu';
$page_title = $ta['menu_manage'] ?? 'Menu';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $id = trim($_POST['id'] ?? '');
    $list = pz_menu_items(true);
    $list = array_values(array_filter($list, fn($item) => ($item['id'] ?? '') !== $id));
    pz_save_menu($list);
    header('Location: ' . pz_admin_url('menu.php'), true, 302);
    exit;
}

$items = pz_menu_items(true);

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card">
    <div class="adm-card-head">
        <h2><?= htmlspecialchars($page_title) ?></h2>
        <a href="<?= pz_admin_url('menu-item.php') ?>" class="adm-btn adm-btn-primary adm-btn-sm"><i class="fas fa-plus"></i> <?= htmlspecialchars($ta['add_item'] ?? 'Add item') ?></a>
    </div>
    <div class="adm-card-body padded">
        <table class="adm-table">
            <thead>
                <tr>
                    <th><?= htmlspecialchars($ta['id'] ?? 'ID') ?></th>
                    <th><?= htmlspecialchars($ta['name_en'] ?? 'Name') ?></th>
                    <th><?= htmlspecialchars($ta['category'] ?? 'Category') ?></th>
                    <th><?= htmlspecialchars($ta['price'] ?? 'Price') ?></th>
                    <th><?= htmlspecialchars($ta['active'] ?? 'Active') ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><code><?= htmlspecialchars($item['id'] ?? '') ?></code></td>
                    <td><?= htmlspecialchars(pz_localized($item, 'name')) ?></td>
                    <td><?= htmlspecialchars($t['categories'][$item['cat'] ?? ''] ?? ($item['cat'] ?? '')) ?></td>
                    <td><?= pz_price((int) ($item['price'] ?? 0)) ?></td>
                    <td><?= ($item['active'] ?? true) ? '✓' : '—' ?></td>
                    <td class="adm-table-actions">
                        <a href="<?= pz_admin_url('menu-item.php?id=' . urlencode($item['id'] ?? '')) ?>" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['edit_item'] ?? 'Edit') ?></a>
                        <form method="post" style="display:inline" onsubmit="return confirm('Delete?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($item['id'] ?? '') ?>">
                            <button type="submit" class="adm-btn adm-btn-outline adm-btn-sm"><?= htmlspecialchars($ta['delete'] ?? 'Delete') ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-foot.php'; ?>