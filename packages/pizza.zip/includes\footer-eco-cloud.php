<?php
$fc = $t['footer_cloud'] ?? [];
$fc_tag = $fc['tag'] ?? 'BILOHASH';
$fc_label = $fc['label'] ?? 'Product ecosystem';
$fc_title = $fc['title'] ?? 'Bilohash ecosystem';
?>
<div class="pz-container pz-footer-cloud-wrap">
    <a href="https://bilohash.com/" class="pz-eco-cloud" target="_blank" rel="noopener noreferrer"
       title="<?= htmlspecialchars($fc_title) ?>">
        <div class="pz-planet-stage" aria-hidden="true">
            <div class="pz-planet-nebula"></div>
            <div class="pz-planet-ring"></div>
            <div class="pz-planet-body"></div>
            <div class="pz-planet-moon-orbit">
                <span class="pz-planet-moon"></span>
            </div>
        </div>
        <span class="pz-planet-tag"><?= htmlspecialchars($fc_tag) ?></span>
        <span class="pz-planet-label"><?= htmlspecialchars($fc_label) ?></span>
    </a>
</div>