<?php
/**
 * SEO landing pages — slug => config
 */
return [
    'menu' => [
        'section'  => 'menu',
        'og_image' => 'images/hero-pizza.jpg',
    ],
    'about' => [
        'section'  => 'about',
        'og_image' => 'images/gallery-forno.jpg',
    ],
    'terrace' => [
        'section'  => 'terrace',
        'og_image' => 'images/gallery-terrace.jpg',
    ],
    'reservations' => [
        'section'  => 'reservations',
        'og_image' => 'images/gallery-terrace.jpg',
    ],
    'gallery' => [
        'section'  => 'gallery',
        'og_image' => 'images/gallery-pizza.jpg',
    ],
];