<?php

function pzs_landing_sprintf(string $fmt, string ...$args): string
{
    if (!str_contains($fmt, '%')) {
        return $fmt;
    }
    $needed = substr_count($fmt, '%s') + substr_count($fmt, '%d');
    if ($needed === 0) {
        return $fmt;
    }
    while (count($args) < $needed) {
        $args[] = $args[0] ?? '';
    }
    return sprintf($fmt, ...array_slice($args, 0, $needed));
}

function pzs_usecase_defs(): array
{
    static $defs = null;
    if ($defs === null) {
        $path = __DIR__ . '/../data/usecase-defs.php';
        $defs = is_file($path) ? (require $path) : [];
    }
    return is_array($defs) ? $defs : [];
}

function pzs_market_defs(): array
{
    static $defs = null;
    if ($defs === null) {
        $path = __DIR__ . '/../data/market-defs.php';
        $defs = is_file($path) ? (require $path) : [];
    }
    return is_array($defs) ? $defs : [];
}

function pzs_usecase_slugs(): array
{
    return array_keys(pzs_usecase_defs());
}

function pzs_market_slugs(): array
{
    return array_keys(pzs_market_defs());
}

function pzs_landing_url(string $slug): string
{
    return pzs_url($slug . '/');
}

function pzs_landing_canonical(string $slug): string
{
    global $site_url;
    return rtrim($site_url, '/') . '/' . $slug . '/';
}

function pzs_usecase_by_slug(string $slug): ?array
{
    return pzs_usecases_all()[$slug] ?? null;
}

function pzs_market_by_slug(string $slug): ?array
{
    return pzs_markets_all()[$slug] ?? null;
}

function pzs_landing_name(array $meta, string $lang): string
{
    return $meta['names'][$lang] ?? $meta['names']['en'] ?? '';
}

function pzs_usecase_templates(): array
{
    return [
        'en' => [
            'title' => '%s — PHP script | Pizza CMS Norway & Europe',
            'description' => 'Order a custom %s for your restaurant. PHP pizzeria CMS with multilingual menu, reservations, admin panel, Schema.org SEO and live Forno Romano demo.',
            'keywords' => '%s, pizzeria script Norway, restaurant website PHP, order pizzeria CMS, Pizza CMS Europe, online pizza menu',
            'h1' => '%s',
            'subtitle' => 'PHP restaurant platform — menu, reservations, admin & SEO',
            'cta' => 'Order custom %s — contact Bilohash',
            'benefits' => [
                ['title' => 'Built for %s', 'text' => 'Demo UI, menu categories and reservation flow tuned for %s workflows — extend with delivery, POS and payments.'],
                ['title' => 'Multilingual SEO', 'text' => 'EN, NO, UK, RU with hreflang, Schema.org Restaurant, FAQPage and country landing pages.'],
                ['title' => 'JSON admin panel', 'text' => 'Edit dishes, prices, photos and categories without redeploying — ideal for %s launches.'],
                ['title' => 'Hostinger-ready PHP', 'text' => 'No framework — deploy on shared hosting in Norway, EU and Ukraine in minutes.'],
            ],
            'features' => [
                '14 demo menu items with NOK prices and category filters',
                'Table reservation form with JSON storage',
                'Wood-fired hero, terrace section and Google Maps block',
                'Admin demo: menu CRUD and dashboard stats',
                'reCAPTCHA contact form for lead capture',
                'Bilohash ecosystem — Shop, Booking, Freelance CMS',
            ],
            'faq_base' => [
                ['q' => 'Is Pizza CMS a ready-made %s?', 'a' => 'It is a universal PHP demo — Forno Romano sample data. Production adds your branding, payments, delivery and real bookings.'],
                ['q' => 'How fast can we launch %s?', 'a' => 'Demo deploys in minutes on PHP 8+. Custom design, menu import and integrations typically take 2–8 weeks.'],
            ],
        ],
        'no' => [
            'title' => '%s — PHP-skript | Pizza CMS Norge',
            'description' => 'Bestill skreddersydd %s for restauranten. PHP pizzeria-CMS med flerspråklig meny, reservasjoner, admin og Schema.org — live demo.',
            'keywords' => '%s, pizzeria skript Norge, restaurant nettside PHP, bestill Pizza CMS, online pizzameny',
            'h1' => '%s',
            'subtitle' => 'PHP restaurantplattform — meny, reservasjoner, admin og SEO',
            'cta' => 'Bestill tilpasset %s — kontakt Bilohash',
            'benefits' => [
                ['title' => 'Bygget for %s', 'text' => 'Demo-UI og reservasjonsflyt tilpasset %s — utvid med levering, POS og Vipps.'],
                ['title' => 'Flerspråklig SEO', 'text' => 'EN, NO, UK, RU med hreflang, Schema.org Restaurant og landssider.'],
                ['title' => 'JSON adminpanel', 'text' => 'Rediger retter, priser og bilder uten ny deploy — ideelt for %s.'],
                ['title' => 'PHP uten rammeverk', 'text' => 'Deploy på Hostinger eller VPS i Norge og EU på minutter.'],
            ],
            'features' => [
                '14 demoretter med NOK-priser og kategorifilter',
                'Bordreservasjon med JSON-lagring',
                'Vedfyrt hero, terrasse og Google Maps',
                'Admin-demo: meny-CRUD og dashboard',
                'reCAPTCHA kontaktskjema',
                'Bilohash-økosystem — Shop, Booking, Freelance',
            ],
            'faq_base' => [
                ['q' => 'Er Pizza CMS ferdig %s?', 'a' => 'Det er en universell PHP-demo. Produksjon legger til merkevare, betaling og ekte booking.'],
                ['q' => 'Hvor raskt kan vi lansere %s?', 'a' => 'Demo på minutter. Tilpasset design og integrasjoner tar vanligvis 2–8 uker.'],
            ],
        ],
        'uk' => [
            'title' => '%s — PHP-скрипт | Pizza CMS Норвегія',
            'description' => 'Замовте %s для ресторану. PHP CMS піцерії з багатомовним меню, бронюванням, адміном та Schema.org — live demo Forno Romano.',
            'keywords' => '%s, скрипт піцерії Норвегія, сайт ресторану PHP, замовити Pizza CMS, онлайн меню піцерії',
            'h1' => '%s',
            'subtitle' => 'PHP-платформа — меню, бронювання, адмін і SEO',
            'cta' => 'Замовити %s — зв\'яжіться з Bilohash',
            'benefits' => [
                ['title' => 'Для %s', 'text' => 'Демо-інтерфейс і бронювання під %s — додайте доставку, POS та оплату.'],
                ['title' => 'Багатомовне SEO', 'text' => 'EN, NO, UK, RU з hreflang, Schema.org Restaurant та сторінками країн.'],
                ['title' => 'JSON-адмін', 'text' => 'Редагуйте страви та ціни без redeploy — ідеально для %s.'],
                ['title' => 'PHP без фреймворку', 'text' => 'Деплой на Hostinger у Норвегії, ЄС та Україні за хвилини.'],
            ],
            'features' => [
                '14 демо-страв з цінами NOK і фільтрами',
                'Форма бронювання столика з JSON',
                'Hero на дровах, тераса та Google Maps',
                'Адмін-демо: CRUD меню та дашборд',
                'reCAPTCHA контактна форма',
                'Екосистема Bilohash',
            ],
            'faq_base' => [
                ['q' => 'Чи Pizza CMS — готовий %s?', 'a' => 'Це універсальне PHP-демо. Продакшен додає брендинг, оплату та реальне бронювання.'],
                ['q' => 'Як швидко запустити %s?', 'a' => 'Демо за хвилини. Кастомізація зазвичай 2–8 тижнів.'],
            ],
        ],
        'ru' => [
            'title' => '%s — PHP-скрипт | Pizza CMS Норвегия',
            'description' => 'Закажите %s для ресторана. PHP CMS пиццерии с мультиязычным меню, бронированием, админом и Schema.org — live demo Forno Romano.',
            'keywords' => '%s, скрипт пиццерии Норвегия, сайт ресторана PHP, заказать Pizza CMS, онлайн меню пиццерии',
            'h1' => '%s',
            'subtitle' => 'PHP-платформа — меню, бронирование, админ и SEO',
            'cta' => 'Заказать %s — связаться с Bilohash',
            'benefits' => [
                ['title' => 'Для %s', 'text' => 'Демо-интерфейс и бронирование под %s — добавьте доставку, POS и оплату.'],
                ['title' => 'Мультиязычное SEO', 'text' => 'EN, NO, UK, RU с hreflang, Schema.org Restaurant и страницами стран.'],
                ['title' => 'JSON-админ', 'text' => 'Редактируйте блюда и цены без redeploy — идеально для %s.'],
                ['title' => 'PHP без фреймворка', 'text' => 'Деплой на Hostinger в Норвегии, ЕС и Украине за минуты.'],
            ],
            'features' => [
                '14 демо-блюд с ценами NOK и фильтрами',
                'Форма бронирования столика с JSON',
                'Hero на дровах, терраса и Google Maps',
                'Админ-демо: CRUD меню и дашборд',
                'reCAPTCHA контактная форма',
                'Экосистема Bilohash',
            ],
            'faq_base' => [
                ['q' => 'Pizza CMS — готовый %s?', 'a' => 'Это универсальное PHP-демо. Продакшен добавляет брендинг, оплату и реальное бронирование.'],
                ['q' => 'Как быстро запустить %s?', 'a' => 'Демо за минуты. Кастомизация обычно 2–8 недель.'],
            ],
        ],
    ];
}

function pzs_market_templates(): array
{
    return [
        'en' => [
            'title' => 'Pizza CMS for %s — restaurant & pizzeria website script',
            'description' => 'Order restaurant and pizzeria website development in %s. PHP Pizza CMS — multilingual menu, table reservations, Vipps-ready admin, Schema.org SEO. Cities: %s.',
            'keywords' => 'pizzeria website %s, restaurant script %s, order pizzeria CMS %s, PHP restaurant %s, online pizza menu %s',
            'h1' => 'Pizza CMS for %s',
            'subtitle' => 'PHP pizzeria & restaurant platform — menu, bookings, admin',
            'cta' => 'Order Pizza CMS for %s — contact Bilohash',
            'benefits' => [
                ['title' => 'Local SEO for %s', 'text' => 'Hreflang, Schema.org Restaurant, Google Maps and city-focused landing pages for %s restaurants.'],
                ['title' => 'Payments & currency', 'text' => 'Demo uses %s — extend with %s and delivery zones for your market.'],
                ['title' => '4 languages', 'text' => 'Serve tourists and locals in EN, NO, UK, RU — switch via cookie and ?lang= URLs.'],
                ['title' => 'Fast PHP deploy', 'text' => 'Host on EU/Nordic hosting — GDPR-friendly contact forms and cookie consent included.'],
            ],
            'features' => [
                'Live Forno Romano demo — wood-fired pizzeria in Drammen',
                'Menu admin with photos, categories and multilingual fields',
                'Reservation JSON workflow — connect SMS/email in production',
                'Terrace storytelling (#solaskinner) for summer SEO',
                'Cross-links to Shop, Booking and Freelance CMS',
                'White-label branding for agencies in %s',
            ],
            'faq_base' => [
                ['q' => 'Does Pizza CMS work for restaurants in %s?', 'a' => 'Yes — the script is market-agnostic PHP. We adapt menu currency, payments, languages and local SEO for %s during custom development.'],
                ['q' => 'Which cities in %s do you target?', 'a' => 'Demo copy references %s. Production sites target your exact address, Google Business Profile and local keywords.'],
            ],
        ],
        'no' => [
            'title' => 'Pizza CMS for %s — restaurant- og pizzerianettsted',
            'description' => 'Bestill restaurant- og pizzerianettsted i %s. PHP Pizza CMS — flerspråklig meny, bordreservasjon, admin, Schema.org. Byer: %s.',
            'keywords' => 'pizzeria nettside %s, restaurant skript %s, bestill Pizza CMS %s, PHP restaurant %s',
            'h1' => 'Pizza CMS for %s',
            'subtitle' => 'PHP pizzeria- og restaurantplattform',
            'cta' => 'Bestill Pizza CMS for %s — kontakt Bilohash',
            'benefits' => [
                ['title' => 'Lokal SEO for %s', 'text' => 'Hreflang, Schema.org Restaurant og bysider for restauranter i %s.'],
                ['title' => 'Betaling og valuta', 'text' => 'Demo med %s — utvid med %s og leveringssoner.'],
                ['title' => '4 språk', 'text' => 'EN, NO, UK, RU for turister og lokale gjester.'],
                ['title' => 'Rask PHP-deploy', 'text' => 'GDPR-vennlig hosting i EU/Norden.'],
            ],
            'features' => [
                'Live demo Forno Romano — vedfyrt pizzeria',
                'Menyadmin med bilder og flerspråklige felt',
                'Reservasjons-JSON — koble SMS/e-post i produksjon',
                'Terrasse-SEO (#solaskinner)',
                'Kobling til Shop, Booking og Freelance CMS',
                'White-label for byrå i %s',
            ],
            'faq_base' => [
                ['q' => 'Fungerer Pizza CMS for restauranter i %s?', 'a' => 'Ja — vi tilpasser valuta, betaling og lokal SEO for %s.'],
                ['q' => 'Hvilke byer i %s?', 'a' => 'Demotekst nevner %s. Produksjon bruker din adresse og Google Business Profile.'],
            ],
        ],
        'uk' => [
            'title' => 'Pizza CMS для %s — сайт піцерії та ресторану',
            'description' => 'Замовте сайт піцерії та ресторану в %s. PHP Pizza CMS — меню, бронювання, адмін, Schema.org. Міста: %s.',
            'keywords' => 'сайт піцерії %s, скрипт ресторану %s, замовити Pizza CMS %s, PHP ресторан %s',
            'h1' => 'Pizza CMS для %s',
            'subtitle' => 'PHP-платформа для піцерій і ресторанів',
            'cta' => 'Замовити Pizza CMS для %s — Bilohash',
            'benefits' => [
                ['title' => 'Локальне SEO для %s', 'text' => 'Hreflang, Schema.org Restaurant та сторінки міст для %s.'],
                ['title' => 'Оплата та валюта', 'text' => 'Демо: %s — розширення з %s та зонами доставки.'],
                ['title' => '4 мови', 'text' => 'EN, NO, UK, RU для туристів і місцевих гостей.'],
                ['title' => 'Швидкий PHP-деплой', 'text' => 'GDPR-хостинг у ЄС та Норвегії.'],
            ],
            'features' => [
                'Live demo Forno Romano',
                'Адмін меню з фото та перекладами',
                'JSON-бронювання — SMS/email у продакшені',
                'Тераса #solaskinner для літнього SEO',
                'Зв\'язок з Shop, Booking, Freelance CMS',
                'White-label для агенцій у %s',
            ],
            'faq_base' => [
                ['q' => 'Чи підходить Pizza CMS для %s?', 'a' => 'Так — адаптуємо валюту, оплату та локальне SEO для %s.'],
                ['q' => 'Які міста в %s?', 'a' => 'Демо згадує %s. Продакшен — ваша адреса та Google Business Profile.'],
            ],
        ],
        'ru' => [
            'title' => 'Pizza CMS для %s — сайт пиццерии и ресторана',
            'description' => 'Закажите сайт пиццерии и ресторана в %s. PHP Pizza CMS — меню, бронирование, админ, Schema.org. Города: %s.',
            'keywords' => 'сайт пиццерии %s, скрипт ресторана %s, заказать Pizza CMS %s, PHP ресторан %s',
            'h1' => 'Pizza CMS для %s',
            'subtitle' => 'PHP-платформа для пиццерий и ресторанов',
            'cta' => 'Заказать Pizza CMS для %s — Bilohash',
            'benefits' => [
                ['title' => 'Локальное SEO для %s', 'text' => 'Hreflang, Schema.org Restaurant и страницы городов для %s.'],
                ['title' => 'Оплата и валюта', 'text' => 'Демо: %s — расширение с %s и зонами доставки.'],
                ['title' => '4 языка', 'text' => 'EN, NO, UK, RU для туристов и местных гостей.'],
                ['title' => 'Быстрый PHP-деплой', 'text' => 'GDPR-хостинг в ЕС и Норвегии.'],
            ],
            'features' => [
                'Live demo Forno Romano',
                'Админ меню с фото и переводами',
                'JSON-бронирование — SMS/email в продакшене',
                'Терраса #solaskinner для летнего SEO',
                'Связь с Shop, Booking, Freelance CMS',
                'White-label для агентств в %s',
            ],
            'faq_base' => [
                ['q' => 'Подходит ли Pizza CMS для %s?', 'a' => 'Да — адаптируем валюту, оплату и локальное SEO для %s.'],
                ['q' => 'Какие города в %s?', 'a' => 'Демо упоминает %s. Продакшен — ваш адрес и Google Business Profile.'],
            ],
        ],
    ];
}

function pzs_build_landing_i18n(array $meta, array $tpl, string $lng, string $type): array
{
    $name = $meta['names'][$lng] ?? $meta['names']['en'] ?? '';
    $cities_str = implode(', ', array_slice($meta['cities'] ?? [], 0, 4));
    $payments_str = implode(', ', array_slice($meta['payments'] ?? [], 0, 3));
    $currency = $meta['currency'] ?? 'NOK';

    $benefits = array_map(static function ($b) use ($name, $cities_str, $payments_str, $currency, $type) {
        if ($type === 'market') {
            return [
                'title' => pzs_landing_sprintf($b['title'], $name),
                'text'  => pzs_landing_sprintf($b['text'], $name, $currency, $payments_str),
            ];
        }
        return [
            'title' => pzs_landing_sprintf($b['title'], $name),
            'text'  => pzs_landing_sprintf($b['text'], $name, $name),
        ];
    }, $tpl['benefits']);

    $faq = array_map(static function ($f) use ($name, $cities_str, $type) {
        if ($type === 'market') {
            return [
                'q' => pzs_landing_sprintf($f['q'], $name),
                'a' => pzs_landing_sprintf($f['a'], $name, $cities_str),
            ];
        }
        return [
            'q' => pzs_landing_sprintf($f['q'], $name),
            'a' => pzs_landing_sprintf($f['a'], $name),
        ];
    }, $tpl['faq_base']);

    foreach ($meta['faq_extra'][$lng] ?? $meta['faq_extra']['en'] ?? [] as $extra) {
        $faq[] = $extra;
    }

    $row = [
        'title'       => $meta['seo_title'][$lng] ?? ($type === 'market'
            ? pzs_landing_sprintf($tpl['title'], $name)
            : pzs_landing_sprintf($tpl['title'], $name)),
        'description' => $meta['seo_description'][$lng] ?? ($type === 'market'
            ? pzs_landing_sprintf($tpl['description'], $name, $cities_str)
            : pzs_landing_sprintf($tpl['description'], $name)),
        'keywords'    => $meta['seo_keywords'][$lng] ?? ($type === 'market'
            ? pzs_landing_sprintf($tpl['keywords'], $name, $name, $name, $name, $name)
            : pzs_landing_sprintf($tpl['keywords'], $name, $name)),
        'h1'          => pzs_landing_sprintf($tpl['h1'], $name),
        'subtitle'    => $tpl['subtitle'],
        'intro'       => $meta['intro'][$lng] ?? $meta['intro']['en'] ?? '',
        'cta'         => pzs_landing_sprintf($tpl['cta'], $name),
        'benefits'    => $benefits,
        'features'    => array_merge(
            array_map(static fn($f) => $type === 'market' ? pzs_landing_sprintf($f, $name) : $f, $tpl['features']),
            $meta['features_extra'][$lng] ?? $meta['features_extra']['en'] ?? []
        ),
        'faq'         => $faq,
    ];

    if ($type === 'market') {
        $row['cities'] = $meta['cities'] ?? [];
        $row['payments'] = $meta['payments'] ?? [];
        $row['currency'] = $currency;
        $row['flag'] = $meta['flag'] ?? '';
    }

    return $row;
}

function pzs_usecases_all(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $tpls = pzs_usecase_templates();
    $out = [];
    foreach (pzs_usecase_defs() as $slug => $meta) {
        $row = array_merge($meta, ['slug' => $slug, 'type' => 'usecase', 'i18n' => []]);
        foreach (['en', 'no', 'uk', 'ru'] as $lng) {
            $row['i18n'][$lng] = pzs_build_landing_i18n($meta, $tpls[$lng] ?? $tpls['en'], $lng, 'usecase');
        }
        $out[$slug] = $row;
    }
    $cache = $out;
    return $out;
}

function pzs_markets_all(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $tpls = pzs_market_templates();
    $out = [];
    foreach (pzs_market_defs() as $slug => $meta) {
        $row = array_merge($meta, ['slug' => $slug, 'type' => 'market', 'i18n' => []]);
        foreach (['en', 'no', 'uk', 'ru'] as $lng) {
            $row['i18n'][$lng] = pzs_build_landing_i18n($meta, $tpls[$lng] ?? $tpls['en'], $lng, 'market');
        }
        $out[$slug] = $row;
    }
    $cache = $out;
    return $out;
}

function pzs_landing_lang(array $item, string $lang): array
{
    return $item['i18n'][$lang] ?? $item['i18n']['en'] ?? [];
}

function pzs_landing_related(array $item, string $lang, int $limit = 8): array
{
    $type = $item['type'] ?? 'usecase';
    $slugs = $item['related_' . ($type === 'market' ? 'markets' : 'usecases')] ?? [];
    $pool = $type === 'market' ? pzs_markets_all() : pzs_usecases_all();
    $out = [];
    foreach ($slugs as $slug) {
        if (!isset($pool[$slug])) {
            continue;
        }
        $out[] = ['slug' => $slug, 'v' => pzs_landing_lang($pool[$slug], $lang), 'meta' => $pool[$slug]];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function pzs_landing_cross_markets(int $limit = 6): array
{
    return array_slice(pzs_market_slugs(), 0, $limit);
}

function pzs_landing_cross_usecases(int $limit = 6): array
{
    return array_slice(pzs_usecase_slugs(), 0, $limit);
}