<footer class="shs-footer">
    <div class="shs-container shs-footer-inner">
        <div class="shs-footer-grid">
            <div>
                <strong>Pizza CMS</strong>
                <p>PHP restaurant script — Norway & Europe</p>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['product']) ?></h4>
                <ul>
                    <li><a href="<?= pzs_url('index.php') ?>">Pizza CMS</a></li>
                    <li><a href="<?= pzs_url('solutions.php') ?>"><?= htmlspecialchars($t['footer']['solutions'] ?? 'Solutions') ?></a></li>
                    <li><a href="<?= pzs_url('markets.php') ?>"><?= htmlspecialchars($t['footer']['markets'] ?? 'Countries') ?></a></li>
                    <li><a href="<?= pzs_demo_url() ?>"><?= htmlspecialchars($t['footer']['demo_link']) ?></a></li>
                    <li><a href="<?= pzs_demo_url('llms.txt') ?>"><?= htmlspecialchars($t['footer']['llms']) ?></a></li>
                </ul>
            </div>
            <div>
                <h4><?= htmlspecialchars($t['footer']['links']) ?></h4>
                <ul>
                    <li><a href="https://bilohash.com/" rel="author"><?= htmlspecialchars($t['footer']['order']) ?></a></li>
                    <li><a href="<?= pzs_demo_url('contact.php') ?>"><?= htmlspecialchars($t['nav']['contact']) ?></a></li>
                </ul>
            </div>
            <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-column.php'; ?>
        </div>
        <?php require dirname(__DIR__, 3) . '/includes/ecosystem-footer-pills.php'; ?>
        <div class="shs-footer-bottom">
            <?= sprintf(htmlspecialchars($t['footer']['copyright']), date('Y')) ?>
        </div>
    </div>
</footer>
<script src="<?= htmlspecialchars(pzs_asset('js/site.js')) ?>?v=1" defer></script>
</body>
</html>