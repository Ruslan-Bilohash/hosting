        </div>
    </main>
</div>
<script>
(function(){
    var btn=document.getElementById('admMenuBtn'),sb=document.getElementById('admSidebar'),ov=document.getElementById('admOverlay');
    if(!btn||!sb)return;
    btn.addEventListener('click',function(){sb.classList.toggle('open');ov.hidden=!ov.hidden;});
    ov&&ov.addEventListener('click',function(){sb.classList.remove('open');ov.hidden=true;});
})();
</script>
<script>
(function(){
    var toast=document.getElementById('admVippsToast');
    var msgDemo=<?= json_encode($ta['vipps_demo_alert'] ?? 'Demo — no real payment', JSON_UNESCAPED_UNICODE) ?>;
    var actionUrl=<?= json_encode(pz_admin_url('reservation-action.php'), JSON_UNESCAPED_UNICODE) ?>;
    function showToast(text){
        if(!toast){alert(text);return;}
        toast.textContent=text;
        toast.hidden=false;
        clearTimeout(showToast._t);
        showToast._t=setTimeout(function(){toast.hidden=true;},4200);
    }
    document.querySelectorAll('.adm-vipps-btn').forEach(function(btn){
        btn.addEventListener('click',function(){
            var id=btn.getAttribute('data-id');
            if(!id||btn.disabled)return;
            btn.disabled=true;
            var fd=new FormData();
            fd.append('id',id);
            fd.append('action','vipps_demo');
            fetch(actionUrl,{method:'POST',body:fd,credentials:'same-origin'})
                .then(function(r){return r.json();})
                .then(function(data){
                    showToast((data&&data.message)?data.message:msgDemo);
                    if(data&&data.ok){
                        var row=btn.closest('tr');
                        if(row){
                            var status=row.querySelector('.adm-status');
                            if(status){
                                status.className='adm-status adm-status-paid';
                                status.textContent=<?= json_encode($ta['status_paid'] ?? 'Paid', JSON_UNESCAPED_UNICODE) ?>;
                            }
                            var cell=row.querySelector('.adm-res-pay');
                            if(cell){cell.innerHTML='<span class="adm-vipps-paid"><i class="fas fa-check-circle"></i> Vipps</span>';}
                        }
                    }else{btn.disabled=false;}
                })
                .catch(function(){showToast(msgDemo);btn.disabled=false;});
        });
    });
})();
</script>
<div id="admVippsToast" class="adm-vipps-toast" hidden role="status" aria-live="polite"></div>
</body>
</html>