<?php

$brand = [
    'name' => 'Forno Romano',
    'city' => 'Drammen',
    'country' => 'Norway',
    'phone' => '+47 32 88 45 60',
    'phone_raw' => '4732884560',
    'email' => 'hello@fornoromano.no',
    'address' => 'Drammen, Norway',
    'maps' => 'https://www.google.com/maps/search/?api=1&query=Drammen,+Norway&hl=no',
    'maps_embed' => 'https://maps.google.com/maps?q=Drammen,Norway&hl=no&z=13&ie=UTF8&iwloc=&output=embed',
    // Replace with real place_id when a Google Business Profile exists
    'google_review_url' => 'https://www.google.com/maps/search/?api=1&query=Forno+Romano+Drammen+Norway&hl=no',
    'google_rating' => 4.8,
    'google_reviews_count' => 124,
    'instagram' => 'https://instagram.com/',
    'facebook' => 'https://facebook.com/',
    'logo_image' => 'images/gallery-forno.jpg',
    'hero_image' => 'images/hero-pizza.jpg',
    'gallery_images' => [
        ['file' => 'images/gallery-forno.jpg', 'label' => 'forno'],
        ['file' => 'images/gallery-pizza.jpg', 'label' => ''],
        ['file' => 'images/gallery-pasta.jpg', 'label' => ''],
        ['file' => 'images/gallery-terrace.jpg', 'label' => ''],
        ['file' => 'images/hero-pizza.jpg', 'label' => ''],
    ],
];

function pz_menu_items(bool $include_inactive = false): array
{
    require_once __DIR__ . '/storage.php';
    pz_bootstrap_data();
    $list = pz_load_menu_raw();
    if (!$include_inactive) {
        $list = array_values(array_filter($list, fn($item) => ($item['active'] ?? true) !== false));
    }
    return $list;
}

function pz_menu_by_id(string $id, bool $include_inactive = false): ?array
{
    foreach (pz_menu_items($include_inactive) as $item) {
        if (($item['id'] ?? '') === $id) {
            return $item;
        }
    }
    return null;
}

function pz_localized(array $item, string $field, ?string $lang = null): string
{
    global $lang;
    $lang = $lang ?? 'en';
    $val = $item[$field] ?? '';
    if (!is_array($val)) {
        return (string) $val;
    }
    return $val[$lang] ?? $val['uk'] ?? $val['ua'] ?? $val['en'] ?? $val['no'] ?? $val['ru'] ?? '';
}

function pz_categories(): array
{
    return ['pizza', 'pasta', 'starters', 'dessert', 'drinks'];
}

function pz_lang_url(string $code, bool $for_hreflang = false): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: pz_url('');
    parse_str(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY) ?? '', $q);
    if ($code === 'en' && $for_hreflang) {
        unset($q['lang']);
    } else {
        $q['lang'] = $code;
    }
    $qs = http_build_query($q);
    return $path . ($qs !== '' ? '?' . $qs : '');
}

function pz_platform_stats(): array
{
    $items = pz_menu_items(true);
    $cats = [];
    $featured = 0;
    $volume = 0;
    foreach ($items as $item) {
        $cat = $item['cat'] ?? 'other';
        $cats[$cat] = ($cats[$cat] ?? 0) + 1;
        if (!empty($item['featured'])) {
            $featured++;
        }
        if (($item['active'] ?? true) !== false) {
            $volume += (int) ($item['price'] ?? 0);
        }
    }
    return [
        'items'      => count($items),
        'active'     => count(pz_menu_items(false)),
        'categories' => count($cats),
        'featured'   => $featured,
        'volume'     => $volume,
        'cats'       => $cats,
    ];
}

function pz_admin_category_chart(): array
{
    $stats = pz_platform_stats();
    $max = max(1, max($stats['cats'] ?: [1]));
    $rows = [];
    foreach (pz_categories() as $cat) {
        $count = (int) ($stats['cats'][$cat] ?? 0);
        if ($count === 0) {
            continue;
        }
        $rows[] = [
            'cat' => $cat,
            'count' => $count,
            'pct' => (int) round(($count / $max) * 100),
        ];
    }
    return $rows;
}

function pz_slugify(string $text): string
{
    $text = bh_str_lower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text) ?? '';
    return trim($text, '-') ?: 'item';
}

function pz_next_menu_id(string $base): string
{
    $ids = array_column(pz_menu_items(true), 'id');
    $candidate = $base;
    $n = 2;
    while (in_array($candidate, $ids, true)) {
        $candidate = $base . '-' . $n++;
    }
    return $candidate;
}

function pz_admin_url(string $path = ''): string
{
    return pz_url('admin/' . ltrim($path, '/'));
}

function pz_brand_image(string $key = 'hero_image'): ?string
{
    global $brand;
    $rel = trim((string) ($brand[$key] ?? ''));
    if ($rel === '') {
        return null;
    }
    $path = __DIR__ . '/../assets/' . ltrim($rel, '/');
    if (!is_file($path)) {
        return null;
    }
    return pz_asset($rel);
}

function pz_menu_image(array $item): ?string
{
    $rel = trim((string) ($item['image'] ?? ''));
    if ($rel === '') {
        $id = trim((string) ($item['id'] ?? ''));
        if ($id === '') {
            return null;
        }
        $rel = 'images/menu/' . $id . '.jpg';
    }
    $path = __DIR__ . '/../assets/' . ltrim($rel, '/');
    if (!is_file($path)) {
        return null;
    }
    return pz_asset($rel);
}

function pz_page_menu_url(?string $langCode = null): string
{
    global $lang;
    require_once __DIR__ . '/seo.php';
    $langCode = $langCode ?? $lang;
    return pz_absolute_url(pz_url('', $langCode) . '#menu');
}

function pz_seo_pages(): array
{
    static $pages = null;
    if ($pages === null) {
        $file = __DIR__ . '/../data/seo-pages.php';
        $pages = is_file($file) ? require $file : [];
    }
    return $pages;
}

function pz_seo_page_valid(string $slug): bool
{
    return isset(pz_seo_pages()[$slug]);
}

function pz_page_lang(string $slug, ?array $translations = null): array
{
    $translations = $translations ?? ($GLOBALS['t'] ?? []);
    return $translations['pages'][$slug] ?? [];
}

function pz_qr_code_url(string $targetUrl, int $size = 180): string
{
    return 'https://api.qrserver.com/v1/create-qr-code/?' . http_build_query([
        'size'    => $size . 'x' . $size,
        'data'    => $targetUrl,
        'bgcolor' => '241c16',
        'color'   => 'f5efe6',
        'margin'  => 12,
        'format'  => 'png',
        'qzone'   => 1,
    ]);
}