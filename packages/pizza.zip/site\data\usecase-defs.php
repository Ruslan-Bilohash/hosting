<?php
/** Pizza CMS — SEO use-case landing pages (4 langs via landing-lib) */
return [
    'pizzeria-script' => [
        'icon' => 'pizza-slice',
        'names' => [
            'en' => 'Pizzeria website script',
            'no' => 'Pizzeria nettside-skript',
            'uk' => 'Скрипт сайту піцерії',
            'ru' => 'Скрипт сайта пиццерии',
        ],
        'intro' => [
            'en' => 'Launch a professional pizzeria website without WordPress bloat — PHP menu catalog, category filters, QR menu, table reservations and JSON admin. Ideal for independent pizzerias in Norway, Ukraine, Sweden, Germany and across Europe.',
            'no' => 'Lanser profesjonell pizzerianettsted uten WordPress — PHP-meny, kategorifilter, QR-meny, bordreservasjon og JSON-admin. Ideelt for uavhengige pizzeriaer i Norge, Ukraina, Sverige, Tyskland og Europa.',
            'uk' => 'Запустіть сайт піцерії без WordPress — PHP-меню, фільтри категорій, QR-меню, бронювання столиків і JSON-адмін. Для незалежних піцерій у Норвегії, Україні, Швеції, Німеччині та Європі.',
            'ru' => 'Запустите сайт пиццерии без WordPress — PHP-меню, фильтры категорий, QR-меню, бронирование столиков и JSON-админ. Для независимых пиццерий в Норвегии, Украине, Швеции, Германии и Европе.',
        ],
        'related_usecases' => ['online-pizzeria', 'wood-fired-pizza-website', 'table-reservation-system', 'pizza-franchise-website'],
        'related_markets' => ['norway', 'ukraine', 'germany', 'sweden', 'italy'],
    ],
    'restaurant-website' => [
        'icon' => 'utensils',
        'names' => [
            'en' => 'Restaurant website script',
            'no' => 'Restaurant nettside-skript',
            'uk' => 'Скрипт сайту ресторану',
            'ru' => 'Скрипт сайта ресторана',
        ],
        'intro' => [
            'en' => 'Universal PHP restaurant CMS — pasta, starters, desserts, drinks, opening hours, Google Maps and contact blocks. White-label for trattorias, bistros, hotel restaurants and catering brands.',
            'no' => 'Universell PHP restaurant-CMS — pasta, forretter, desserter, drikke, åpningstider, Google Maps og kontakt. White-label for trattoriaer, bistroer og hotellrestauranter.',
            'uk' => 'Універсальна PHP CMS ресторану — паста, закуски, десерти, напої, години роботи, Google Maps. White-label для тратторій, бістро та готельних ресторанів.',
            'ru' => 'Универсальная PHP CMS ресторана — паста, закуски, десерты, напитки, часы работы, Google Maps. White-label для тратторий, бистро и ресторанов отелей.',
        ],
        'related_usecases' => ['italian-restaurant-cms', 'hotel-restaurant-menu', 'table-reservation-system', 'pizzeria-script'],
        'related_markets' => ['norway', 'lithuania', 'netherlands', 'switzerland', 'united-kingdom'],
    ],
    'online-pizzeria' => [
        'icon' => 'laptop',
        'names' => [
            'en' => 'Online pizzeria website',
            'no' => 'Online pizzeria nettside',
            'uk' => 'Онлайн-сайт піцерії',
            'ru' => 'Онлайн-сайт пиццерии',
        ],
        'intro' => [
            'en' => 'Mobile-first online pizzeria storefront — fast menu browsing, lazy-loaded dish photos, QR code menu for dine-in and SEO pages for delivery keywords. Extend with cart, Vipps, Swish or Stripe in production.',
            'no' => 'Mobil-først online pizzeria — rask meny, lazy-load bilder, QR-meny for servering og SEO for levering. Utvid med handlekurv, Vipps, Swish eller Stripe.',
            'uk' => 'Мобільний онлайн-магазин піцерії — швидке меню, lazy-load фото, QR для залу та SEO під доставку. Розширення: кошик, Vipps, Stripe.',
            'ru' => 'Мобильный онлайн-магазин пиццерии — быстрое меню, lazy-load фото, QR для зала и SEO под доставку. Расширение: корзина, Vipps, Stripe.',
        ],
        'related_usecases' => ['pizzeria-script', 'dark-kitchen-menu', 'food-truck-website', 'wood-fired-pizza-website'],
        'related_markets' => ['ukraine', 'poland', 'germany', 'usa', 'spain'],
    ],
    'wood-fired-pizza-website' => [
        'icon' => 'fire',
        'names' => [
            'en' => 'Wood-fired pizza website',
            'no' => 'Vedfyrt pizza nettside',
            'uk' => 'Сайт піци на дровах',
            'ru' => 'Сайт пиццы на дровах',
        ],
        'intro' => [
            'en' => 'Story-driven landing for Neapolitan and Roman oven pizzerias — animated sun hero, oven stats (485°C, 48h dough), gallery and #solaskinner terrace section. Perfect for premium pizza brands in Oslo, Bergen, Kyiv and Berlin.',
            'no' => 'Historiedrevet landing for napolitanske og romerske steinovn-pizzeriaer — animert sol, ovntall, galleri og #solaskinner. Perfekt for premium pizza i Oslo, Bergen og Berlin.',
            'uk' => 'Landing для неаполітанських піцерій на дровах — анімоване сонце, статистика печі, галерея та #solaskinner. Для преміум-брендів у Києві, Осло та Берліні.',
            'ru' => 'Лендинг для неаполитанских пиццерий на дровах — анимированное солнце, статистика печи, галерея и #solaskinner. Для премиум-брендов в Киеве, Осло и Берлине.',
        ],
        'related_usecases' => ['pizzeria-script', 'italian-restaurant-cms', 'online-pizzeria', 'pizza-franchise-website'],
        'related_markets' => ['italy', 'norway', 'germany', 'ukraine', 'austria'],
    ],
    'table-reservation-system' => [
        'icon' => 'calendar-check',
        'names' => [
            'en' => 'Table reservation system',
            'no' => 'Bordreservasjonssystem',
            'uk' => 'Система бронювання столиків',
            'ru' => 'Система бронирования столиков',
        ],
        'intro' => [
            'en' => 'JSON-backed table booking for restaurants — date, time, guests, allergies and admin status workflow (pending, confirmed, Vipps demo). Connect email SMTP, SMS or OpenTable-style calendar in production.',
            'no' => 'JSON-bordreservasjon — dato, tid, gjester, allergier og admin-status. Koble SMTP, SMS eller kalender i produksjon.',
            'uk' => 'JSON-бронювання столиків — дата, час, гості, алергії та статуси в адміні. Підключення SMTP, SMS у продакшені.',
            'ru' => 'JSON-бронирование столиков — дата, время, гости, аллергии и статусы в админе. Подключение SMTP, SMS в продакшене.',
        ],
        'related_usecases' => ['restaurant-website', 'pizzeria-script', 'hotel-restaurant-menu', 'italian-restaurant-cms'],
        'related_markets' => ['norway', 'denmark', 'sweden', 'france', 'belgium'],
    ],
    'italian-restaurant-cms' => [
        'icon' => 'wine-glass',
        'names' => [
            'en' => 'Italian restaurant CMS',
            'no' => 'Italiensk restaurant CMS',
            'uk' => 'CMS італійського ресторану',
            'ru' => 'CMS итальянского ресторана',
        ],
        'intro' => [
            'en' => 'Trattoria and osteria website template — pasta, antipasti, wine list, Italian copy in 4 languages and Schema.org Restaurant markup. Sell to Italian dining concepts across Nordic and EU markets.',
            'no' => 'Trattoria/osteria-mal — pasta, antipasti, vinliste, italiensk copy på 4 språk og Schema.org Restaurant. For italienske konsepter i Norden og EU.',
            'uk' => 'Шаблон тратторії — паста, антипасті, винна карта, італійський контент 4 мовами та Schema.org Restaurant.',
            'ru' => 'Шаблон траттории — паста, антипасти, винная карта, итальянский контент 4 языками и Schema.org Restaurant.',
        ],
        'related_usecases' => ['restaurant-website', 'wood-fired-pizza-website', 'hotel-restaurant-menu', 'pizzeria-script'],
        'related_markets' => ['italy', 'switzerland', 'germany', 'austria', 'netherlands'],
    ],
    'pizza-franchise-website' => [
        'icon' => 'store',
        'names' => [
            'en' => 'Pizza franchise website',
            'no' => 'Pizza franchise nettside',
            'uk' => 'Сайт піцерійної франшизи',
            'ru' => 'Сайт пиццерийной франшизы',
        ],
        'intro' => [
            'en' => 'Multi-location pizza chain starter — shared menu JSON, brand hero, franchise admin demo and SEO hub pages per city. Agencies white-label Pizza CMS for 5–50 location rollouts in wealthy EU markets.',
            'no' => 'Multi-lokasjon pizza-kjede — delt meny-JSON, franchise-admin og SEO per by. White-label for 5–50 lokasjoner i EU.',
            'uk' => 'Стартер для мережі піцерій — спільне JSON-меню, адмін і SEO-сторінки по містах. White-label для 5–50 локацій у ЄС.',
            'ru' => 'Стартер для сети пиццерий — общее JSON-меню, админ и SEO-страницы по городам. White-label для 5–50 локаций в ЕС.',
        ],
        'related_usecases' => ['pizzeria-script', 'online-pizzeria', 'dark-kitchen-menu', 'restaurant-website'],
        'related_markets' => ['usa', 'united-kingdom', 'germany', 'poland', 'netherlands'],
    ],
    'dark-kitchen-menu' => [
        'icon' => 'box',
        'names' => [
            'en' => 'Dark kitchen menu website',
            'no' => 'Dark kitchen meny-nettside',
            'uk' => 'Сайт dark kitchen',
            'ru' => 'Сайт dark kitchen',
        ],
        'intro' => [
            'en' => 'Delivery-only restaurant web presence — compact menu, QR links, SEO for "pizza delivery" keywords and fast PHP hosting. Pair with Shop CMS for full checkout or Wolt/Bolt aggregator landing pages.',
            'no' => 'Leveringsonly restaurant — kompakt meny, QR, SEO for «pizza levering» og rask PHP-hosting. Kombiner med Shop CMS for checkout.',
            'uk' => 'Сайт для доставки без залу — компактне меню, QR, SEO під «доставка піци» та швидкий PHP-хостинг.',
            'ru' => 'Сайт для доставки без зала — компактное меню, QR, SEO под «доставка пиццы» и быстрый PHP-хостинг.',
        ],
        'related_usecases' => ['online-pizzeria', 'food-truck-website', 'pizzeria-script', 'pizza-franchise-website'],
        'related_markets' => ['ukraine', 'poland', 'germany', 'netherlands', 'ireland'],
    ],
    'food-truck-website' => [
        'icon' => 'truck',
        'names' => [
            'en' => 'Food truck website',
            'no' => 'Food truck nettside',
            'uk' => 'Сайт фуд-трака',
            'ru' => 'Сайт фуд-трака',
        ],
        'intro' => [
            'en' => 'Lightweight mobile menu site for pizza trucks and street food — QR-first, Google Maps, Instagram links and event catering CTA. Low hosting cost on shared PHP servers.',
            'no' => 'Lett mobilmeny for pizza-truck og street food — QR, Google Maps, Instagram og catering-CTA. Lav hostingkostnad.',
            'uk' => 'Легкий мобільний сайт для pizza truck — QR, Google Maps, Instagram та catering CTA.',
            'ru' => 'Лёгкий мобильный сайт для pizza truck — QR, Google Maps, Instagram и catering CTA.',
        ],
        'related_usecases' => ['dark-kitchen-menu', 'online-pizzeria', 'pizzeria-script', 'restaurant-website'],
        'related_markets' => ['usa', 'norway', 'sweden', 'spain', 'lithuania'],
    ],
    'hotel-restaurant-menu' => [
        'icon' => 'hotel',
        'names' => [
            'en' => 'Hotel restaurant menu site',
            'no' => 'Hotellrestaurant meny-side',
            'uk' => 'Сайт меню ресторану готелю',
            'ru' => 'Сайт меню ресторана отеля',
        ],
        'intro' => [
            'en' => 'Elegant menu and reservation microsite for hotel restaurants and resort dining — multilingual guests, breakfast/lunch/dinner categories and Bilohash Booking CMS cross-sell for room+table packages.',
            'no' => 'Elegant meny og reservasjon for hotellrestauranter — flerspråklige gjester og Booking CMS for rom+bord.',
            'uk' => 'Елегантне меню та бронювання для ресторанів готелів — багатомовні гості та інтеграція з Booking CMS.',
            'ru' => 'Элегантное меню и бронирование для ресторанов отелей — многоязычные гости и интеграция с Booking CMS.',
        ],
        'related_usecases' => ['restaurant-website', 'table-reservation-system', 'italian-restaurant-cms', 'pizzeria-script'],
        'related_markets' => ['switzerland', 'austria', 'norway', 'finland', 'france'],
    ],
];