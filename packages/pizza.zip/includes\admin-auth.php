<?php
define('PZ_ADMIN_USER', 'demo');
define('PZ_ADMIN_PASS', 'pizza2026');
define('PZ_ADMIN_SESSION_KEY', 'pz_admin_logged');

function pz_admin_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function pz_admin_logged(): bool
{
    pz_admin_start();
    return !empty($_SESSION[PZ_ADMIN_SESSION_KEY]);
}

function pz_admin_login(string $user, string $pass): bool
{
    if ($user === PZ_ADMIN_USER && $pass === PZ_ADMIN_PASS) {
        pz_admin_start();
        $_SESSION[PZ_ADMIN_SESSION_KEY] = true;
        $_SESSION['pz_admin_user'] = $user;
        return true;
    }
    return false;
}

function pz_admin_logout(): void
{
    pz_admin_start();
    unset($_SESSION[PZ_ADMIN_SESSION_KEY], $_SESSION['pz_admin_user']);
}

function pz_admin_require(): void
{
    if (!pz_admin_logged()) {
        header('Location: ' . pz_admin_url('login.php'), true, 302);
        exit;
    }
}