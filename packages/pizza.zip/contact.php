<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';
require_once __DIR__ . '/includes/site-integrations.php';
pz_boot_public_integrations();

$current_page = 'contact';
$product = 'pizza';
$cms_t = cms_contact_texts($product, $lang);
$cms_alert = '';
$cms_alert_type = '';
$cms_values = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = cms_contact_handle_post($product, $lang, 'https://bilohash.com/pizza/contact.php');
    $cms_alert = $result['alert'];
    $cms_alert_type = $result['alert_type'];
    $cms_values = $result['values'];
}

$cms_csrf = cms_contact_ensure_csrf();
$page_title = $cms_t['page_title'];
$page_desc  = $cms_t['meta_description'];
$canonical  = $site_url . '/contact.php' . ($lang !== 'en' ? '?lang=' . $lang : '');
$canon_abs  = pz_absolute_url($canonical);
$seo_schemas = [
    pz_seo_organization(),
    pz_seo_webpage($canon_abs, $page_title, $page_desc),
    pz_seo_restaurant(),
    pz_seo_contact_page($canon_abs, $page_title, $page_desc),
    pz_seo_breadcrumbs([
        ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => pz_absolute_url(pz_url('index.php'))],
        ['name' => $t['nav_contact'] ?? 'Contact', 'url' => $canon_abs],
    ]),
];

$cms_prefix = 'pz';
$body_class = 'pz-page-contact';
$cms_action = pz_url('contact.php') . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');
$pz_skip_ecosystem = true;

require __DIR__ . '/includes/header.php';
require dirname(__DIR__) . '/includes/cms-contact-form.php';
require __DIR__ . '/includes/footer.php';