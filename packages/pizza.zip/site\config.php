<?php
require_once dirname(__DIR__) . '/config.php';

define('PZS_BASE_PATH', '/pizza/site');
define('PZS_PRODUCT_NAME', 'Pizza CMS');
define('PZS_PARENT_PATH', '/pizza');

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, PZ_DOMAIN) !== false) ? PZS_BASE_PATH : ($detected ?: PZS_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function pzs_url(string $path = ''): string
{
    global $base_path;
    return rtrim($base_path, '/') . '/' . ltrim($path, '/');
}

function pzs_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function pzs_demo_url(string $path = ''): string
{
    global $host, $protocol;
    return rtrim($protocol . '://' . $host . PZS_PARENT_PATH, '/') . '/' . ltrim($path, '/');
}