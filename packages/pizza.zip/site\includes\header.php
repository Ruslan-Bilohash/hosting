<?php
require_once dirname(__DIR__, 3) . '/includes/cms-contact.php';
$cms_nav_discuss = cms_contact_texts('pizza', $lang)['nav_discuss'];
$page_title = $page_title ?? $t['meta']['title'];
$page_desc  = $page_desc ?? $t['meta']['description'];
$canonical  = $canonical ?? $site_url . '/';
$seo_schemas = $seo_schemas ?? pzs_seo_schemas(pzs_absolute_url($canonical), $page_title, $page_desc);
$page_keywords = $page_keywords ?? null;
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php pzs_render_seo_head($page_title, $page_desc, $canonical, $seo_schemas, $page_keywords); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(pzs_asset('css/site.css')) ?>?v=2">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%23fff7ed' width='100' height='100' rx='12'/><text x='50' y='58' font-size='36' text-anchor='middle' fill='%23c2410c' font-family='sans-serif' font-weight='bold'>P</text></svg>">
</head>
<body<?= !empty($body_class) ? ' class="' . htmlspecialchars($body_class) . '"' : '' ?>>
<?php require dirname(__DIR__, 3) . '/includes/ecosystem-top-bar.php'; ?>
<header class="shs-header" id="shsHeader">
    <div class="shs-header-inner">
        <a href="<?= pzs_url('index.php') ?>" class="shs-logo">
            <span class="shs-logo-icon">P</span>
            <span class="shs-logo-text">Pizza <em>CMS</em></span>
        </a>
        <nav class="shs-nav" aria-label="<?= htmlspecialchars($t['nav']['main_nav'] ?? 'Main') ?>">
            <a href="<?= pzs_url('solutions.php') ?>"><?= htmlspecialchars($t['nav']['solutions'] ?? 'Solutions') ?></a>
            <a href="<?= pzs_url('markets.php') ?>"><?= htmlspecialchars($t['nav']['markets'] ?? 'Countries') ?></a>
            <a href="<?= pzs_url('index.php#features') ?>"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="<?= pzs_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a>
        </nav>
        <div class="shs-header-tools">
            <?php require __DIR__ . '/lang-dropdown.php'; ?>
            <button class="shs-menu-toggle" id="shsMenuBtn" aria-label="<?= htmlspecialchars($t['nav']['menu'] ?? 'Menu') ?>" type="button" aria-expanded="false">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="shs-header-actions">
            <a href="<?= pzs_demo_url() ?>" class="shs-btn-ghost"><i class="fas fa-pizza-slice"></i> <?= htmlspecialchars($t['demo']['frontend']) ?></a>
            <a href="<?= pzs_demo_url('admin/login.php') ?>" class="shs-btn-ghost"><i class="fas fa-lock"></i> <?= htmlspecialchars($t['nav']['admin']) ?></a>
            <a href="<?= pzs_demo_url('contact.php') ?>" class="shs-btn-primary"><i class="fas fa-comments"></i> <?= htmlspecialchars($cms_nav_discuss) ?></a>
        </div>
    </div>
    <div class="shs-mobile-panel" id="shsMobilePanel" hidden>
        <nav class="shs-nav-mobile">
            <a href="<?= pzs_url('solutions.php') ?>"><?= htmlspecialchars($t['nav']['solutions'] ?? 'Solutions') ?></a>
            <a href="<?= pzs_url('markets.php') ?>"><?= htmlspecialchars($t['nav']['markets'] ?? 'Countries') ?></a>
            <a href="<?= pzs_url('index.php#features') ?>"><?= htmlspecialchars($t['nav']['features']) ?></a>
            <a href="<?= pzs_url('index.php#demo') ?>"><?= htmlspecialchars($t['nav']['demo']) ?></a>
            <a href="<?= pzs_demo_url() ?>"><?= htmlspecialchars($t['demo']['frontend']) ?></a>
            <a href="<?= pzs_demo_url('contact.php') ?>"><?= htmlspecialchars($cms_nav_discuss) ?></a>
        </nav>
    </div>
</header>