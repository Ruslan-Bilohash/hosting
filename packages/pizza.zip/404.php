<?php
$cms_404_home = '/pizza/';
$cms_404_name = 'Pizza CMS';
require dirname(__DIR__) . '/includes/cms-404.php';