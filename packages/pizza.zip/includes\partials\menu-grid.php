<?php
/** @var array $menu */
?>
<section class="pz-section" id="menu">
    <div class="pz-container">
        <div class="pz-filters-wrap">
            <div class="pz-filters" role="tablist" aria-label="<?= htmlspecialchars($t['menu_categories'] ?? 'Menu categories') ?>">
                <button type="button" class="pz-filter is-active" id="menu-all" data-filter="all"><?= htmlspecialchars($t['filter_all']) ?></button>
                <button type="button" class="pz-filter" id="menu-pizza" data-filter="pizza"><?= htmlspecialchars($t['filter_pizza']) ?></button>
                <button type="button" class="pz-filter" id="menu-pasta" data-filter="pasta"><?= htmlspecialchars($t['filter_pasta']) ?></button>
                <button type="button" class="pz-filter" id="menu-starters" data-filter="starters"><?= htmlspecialchars($t['filter_starters']) ?></button>
                <button type="button" class="pz-filter" id="menu-dessert" data-filter="dessert"><?= htmlspecialchars($t['filter_dessert']) ?></button>
                <button type="button" class="pz-filter" id="menu-drinks" data-filter="drinks"><?= htmlspecialchars($t['filter_drinks']) ?></button>
            </div>
        </div>
        <div class="pz-menu-grid">
            <?php foreach ($menu as $item):
                $tags = $item['tags'] ?? [];
            ?>
            <article class="pz-menu-card" data-cat="<?= htmlspecialchars($item['cat']) ?>">
                <?php $pz_menu_img = pz_menu_image($item); if ($pz_menu_img): ?>
                <div class="pz-menu-media">
                    <img
                        src="<?= htmlspecialchars($pz_menu_img) ?>"
                        alt="<?= htmlspecialchars(pz_localized($item, 'name')) ?>"
                        width="640"
                        height="480"
                        loading="lazy"
                        decoding="async"
                    >
                </div>
                <?php endif; ?>
                <div class="pz-menu-body">
                    <div class="pz-menu-top">
                        <h3><?= htmlspecialchars(pz_localized($item, 'name')) ?></h3>
                        <span class="pz-menu-price"><?= pz_price((int) $item['price']) ?></span>
                    </div>
                    <p class="pz-menu-desc"><?= htmlspecialchars(pz_localized($item, 'desc')) ?></p>
                    <?php if ($tags): ?>
                    <div class="pz-tags">
                        <?php foreach ($tags as $tag):
                            $label = $tag === 'veg' ? $t['badge_veg'] : ($tag === 'spicy' ? $t['badge_spicy'] : $t['badge_chef']);
                            $cls = $tag === 'spicy' ? ' pz-tag--spicy' : ($tag === 'chef' ? ' pz-tag--chef' : '');
                        ?>
                        <span class="pz-tag<?= $cls ?>"><?= htmlspecialchars($label) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>