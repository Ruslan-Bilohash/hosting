(function () {
    'use strict';
    var btn = document.getElementById('shsMenuBtn');
    var panel = document.getElementById('shsMobilePanel');
    if (btn && panel) {
        btn.addEventListener('click', function () {
            var open = panel.hidden;
            panel.hidden = !open;
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }
    var langBtn = document.getElementById('shsLangBtn');
    var langMenu = document.getElementById('shsLangMenu');
    if (langBtn && langMenu) {
        langBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            langMenu.hidden = !langMenu.hidden;
        });
        document.addEventListener('click', function () { langMenu.hidden = true; });
    }
})();