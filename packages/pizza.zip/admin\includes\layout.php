<?php
/** @var string $admin_page @var array $ta @var string $page_title */
$layout_title = $page_title ?? ($ta['dashboard'] ?? 'Admin');
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= htmlspecialchars($layout_title) ?> — <?= htmlspecialchars($ta['title_suffix'] ?? 'Pizza CMS Admin') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(pz_asset('css/admin.css')) ?>?v=2">
    <link rel="stylesheet" href="<?= htmlspecialchars(bh_cms_admin_settings_css_href()) ?>">
</head>
<body class="adm-body">
<div class="adm-sidebar-overlay" id="admOverlay" hidden></div>
<div class="adm-layout">
    <aside class="adm-sidebar" id="admSidebar">
        <a href="<?= pz_admin_url('index.php') ?>" class="adm-sidebar-brand">
            <div class="icon">P</div>
            <div>
                <span>Pizza CMS</span>
                <small><?= htmlspecialchars($ta['title'] ?? 'Admin') ?></small>
            </div>
        </a>
        <nav class="adm-nav">
            <a href="<?= pz_admin_url('index.php') ?>" class="<?= $admin_page === 'dashboard' ? 'active' : '' ?>">
                <i class="fas fa-chart-pie"></i> <?= htmlspecialchars($ta['dashboard'] ?? 'Dashboard') ?>
            </a>
            <a href="<?= pz_admin_url('menu.php') ?>" class="<?= $admin_page === 'menu' ? 'active' : '' ?>">
                <i class="fas fa-utensils"></i> <?= htmlspecialchars($ta['menu_manage'] ?? 'Menu') ?>
            </a>
            <a href="<?= pz_admin_url('settings-appearance.php') ?>" class="<?= ($admin_page ?? '') === 'settings' ? 'active' : '' ?>">
                <i class="fas fa-palette"></i> <?= htmlspecialchars($ta['site_settings'] ?? 'Site & chat') ?>
            </a>
            <a href="<?= pz_url('index.php') ?>" target="_blank">
                <i class="fas fa-external-link-alt"></i> <?= htmlspecialchars($ta['view_site'] ?? 'View site') ?>
            </a>
        </nav>
        <div class="adm-sidebar-foot">
            <div class="adm-lang-mini">
                <?php foreach (pz_langs() as $code => $info): ?>
                <a href="<?= htmlspecialchars(pz_admin_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['label'] ?></a>
                <?php endforeach; ?>
            </div>
            <a href="<?= pz_admin_url('logout.php') ?>" style="color:rgba(255,255,255,.7);font-size:12px;text-decoration:none">
                <i class="fas fa-sign-out-alt"></i> <?= htmlspecialchars($ta['logout'] ?? 'Log out') ?>
            </a>
        </div>
    </aside>
    <main class="adm-main">
        <header class="adm-topbar">
            <button type="button" class="adm-menu-btn" id="admMenuBtn" aria-label="<?= htmlspecialchars($ta['menu'] ?? 'Menu') ?>"><i class="fas fa-bars"></i></button>
            <h1><?= htmlspecialchars($layout_title) ?></h1>
            <span class="adm-user"><i class="fas fa-user-circle"></i> demo</span>
        </header>
        <div class="adm-content">