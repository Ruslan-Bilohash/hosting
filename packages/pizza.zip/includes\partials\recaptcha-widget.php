<?php
if (!function_exists('cms_recaptcha_site_key')) {
    require_once dirname(__DIR__, 3) . '/includes/cms-contact.php';
}
$pz_recap_key = cms_recaptcha_site_key();
if ($pz_recap_key === '') {
    return;
}
?>
<div class="pz-field pz-field--full">
    <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($pz_recap_key) ?>"></div>
</div>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>