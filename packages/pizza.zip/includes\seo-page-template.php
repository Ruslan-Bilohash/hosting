<?php
/** @var string $slug @var array $v @var array $config @var string $body_class */
$seo_schemas = $seo_schemas ?? [];
$seo_keywords_override = $seo_keywords_override ?? null;
$seo_og_image_rel = $seo_og_image_rel ?? null;
require __DIR__ . '/header.php';
?>

        <section class="pz-seo-hero">
            <div class="pz-container">
                <nav class="pz-breadcrumb" aria-label="Breadcrumb">
                    <a href="<?= htmlspecialchars(pz_url('index.php')) ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a>
                    <span aria-hidden="true">/</span>
                    <span><?= htmlspecialchars($v['h1'] ?? $slug) ?></span>
                </nav>
                <h1><?= htmlspecialchars($v['h1'] ?? $slug) ?></h1>
                <?php if (!empty($v['lead'])): ?>
                <p class="pz-seo-lead"><?= htmlspecialchars($v['lead']) ?></p>
                <?php endif; ?>
                <?php if (!empty($v['intro'])): ?>
                <p class="pz-seo-intro"><?= htmlspecialchars($v['intro']) ?></p>
                <?php endif; ?>
                <?php if (!empty($v['bullets'])): ?>
                <ul class="pz-seo-bullets">
                    <?php foreach ($v['bullets'] as $bullet): ?>
                    <li><i class="fas fa-check" aria-hidden="true"></i><?= htmlspecialchars($bullet) ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <?php
                if (!empty($v['cta_label'])):
                    $pz_cta_href = $v['cta_href'] ?? '';
                    if (!empty($v['cta_slug'])) {
                        $pz_cta_href = pz_page_url((string) $v['cta_slug']);
                    } elseif (preg_match('#^/pizza/([a-z-]+)#', $pz_cta_href, $pz_cta_match)) {
                        $pz_cta_href = pz_page_url($pz_cta_match[1]);
                    }
                    if ($pz_cta_href !== ''):
                ?>
                <a href="<?= htmlspecialchars($pz_cta_href) ?>" class="pz-btn pz-btn-primary pz-seo-cta">
                    <?= htmlspecialchars($v['cta_label']) ?>
                </a>
                <?php endif; endif; ?>
            </div>
        </section>

        <?php
        $section = $config['section'] ?? $slug;
        if ($section === 'menu') {
            require __DIR__ . '/partials/menu-grid.php';
        } elseif ($section === 'about') {
        ?>
        <section class="pz-section">
            <div class="pz-container pz-about-grid">
                <div class="pz-about-copy">
                    <?php foreach ($v['paragraphs'] ?? [] as $para): ?>
                    <p><?= htmlspecialchars($para) ?></p>
                    <?php endforeach; ?>
                    <?php if (!empty($v['list'])): ?>
                    <ul class="pz-about-list">
                        <?php foreach ($v['list'] as $li): ?>
                        <li><i class="fas fa-circle" aria-hidden="true"></i><?= htmlspecialchars($li) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
                <div class="pz-oven-card">
                    <strong><?= htmlspecialchars($brand['name']) ?></strong>
                    <span><?= htmlspecialchars($brand['address']) ?></span>
                    <?php if ($about_img = pz_brand_image('hero_image')): ?>
                    <img
                        src="<?= htmlspecialchars($about_img) ?>"
                        alt="<?= htmlspecialchars($t['hero_image_alt']) ?>"
                        width="640"
                        height="480"
                        loading="lazy"
                        decoding="async"
                        class="pz-about-photo"
                    >
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
        } elseif ($section === 'terrace') {
        ?>
        <section class="pz-solaskinner pz-solaskinner--page" id="solaskinner">
            <div class="pz-container pz-sol-inner">
                <p class="pz-sol-text"><?= htmlspecialchars($v['body'] ?? $t['sol_p1']) ?></p>
                <ul class="pz-sol-list">
                    <li><i class="fas fa-sun" aria-hidden="true"></i><?= htmlspecialchars($t['sol_li1']) ?></li>
                    <li><i class="fas fa-wine-glass" aria-hidden="true"></i><?= htmlspecialchars($t['sol_li2']) ?></li>
                    <li><i class="fas fa-umbrella-beach" aria-hidden="true"></i><?= htmlspecialchars($t['sol_li3']) ?></li>
                </ul>
                <?php if ($terrace_img = pz_asset('images/gallery-terrace.jpg')): ?>
                <figure class="pz-seo-figure">
                    <img
                        src="<?= htmlspecialchars($terrace_img) ?>"
                        alt="<?= htmlspecialchars($t['gallery_alt'][3] ?? $t['sol_title']) ?>"
                        width="1200"
                        height="800"
                        loading="lazy"
                        decoding="async"
                    >
                </figure>
                <?php endif; ?>
                <a href="<?= htmlspecialchars(pz_page_url('reservations')) ?>" class="pz-btn pz-btn-primary pz-sol-cta">
                    <i class="fas fa-chair" aria-hidden="true"></i>
                    <?= htmlspecialchars($t['sol_cta']) ?>
                </a>
            </div>
        </section>
        <?php
        } elseif ($section === 'reservations') {
            $pz_qr_url = pz_absolute_url(pz_page_url('menu'));
            $pz_qr_img = pz_qr_code_url($pz_qr_url, 200);
            require __DIR__ . '/partials/reserve-form.php';
        } elseif ($section === 'gallery') {
            require __DIR__ . '/partials/gallery-grid.php';
        }
        ?>

        <?php
        $faq_items = $v['faq'] ?? [];
        $faq_title = $t['faq_title'] ?? 'FAQ';
        require __DIR__ . '/partials/faq-section.php';
        ?>

<?php require __DIR__ . '/footer.php'; ?>