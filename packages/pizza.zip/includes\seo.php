<?php

function pz_protocol(): string
{
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    ) ? 'https' : 'http';
}

function pz_host(): string
{
    return $_SERVER['HTTP_HOST'] ?? PZ_DOMAIN;
}

function pz_absolute_url(string $path): string
{
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    return pz_protocol() . '://' . pz_host() . (str_starts_with($path, '/') ? $path : '/' . $path);
}

function pz_full_lang_url(string $code): string
{
    return pz_absolute_url(pz_lang_url($code, true));
}

function pz_seo_organization(): array
{
    global $brand;
    return [
        '@type' => 'Organization',
        '@id'   => 'https://bilohash.com/pizza/#organization',
        'name'  => PZ_SITE_NAME,
        'url'   => 'https://bilohash.com/pizza/',
        'logo'  => 'https://bilohash.com/favicon.ico',
        'areaServed' => ['NO', 'UA', 'EU'],
        'knowsAbout' => [
            'Restaurant website development',
            'Pizzeria CMS Norway',
            'Multilingual restaurant SEO',
            'Schema.org Restaurant markup',
        ],
    ];
}

function pz_seo_restaurant(): array
{
    global $brand, $site_url, $t;
    $image = pz_brand_image('hero_image') ?: pz_brand_image('logo_image');
    $schema = [
        '@type' => 'Restaurant',
        '@id'   => rtrim($site_url, '/') . '/#restaurant',
        'name'  => $brand['name'],
        'servesCuisine' => ['Italian', 'Pizza', 'Neapolitan'],
        'priceRange' => '$$',
        'telephone' => $brand['phone'],
        'email' => $brand['email'],
        'address' => [
            '@type' => 'PostalAddress',
            'streetAddress' => $brand['address'],
            'addressLocality' => $brand['city'],
            'addressCountry' => 'NO',
        ],
        'url' => rtrim($site_url, '/') . '/',
        'sameAs' => array_values(array_filter([
            $brand['instagram'] ?? '',
            $brand['facebook'] ?? '',
            $brand['google_review_url'] ?? '',
        ])),
        'openingHoursSpecification' => [
            ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday'], 'opens' => '11:00', 'closes' => '22:00'],
            ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => ['Friday','Saturday'], 'opens' => '11:00', 'closes' => '23:00'],
            ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => 'Sunday', 'opens' => '12:00', 'closes' => '21:00'],
        ],
        'aggregateRating' => [
            '@type' => 'AggregateRating',
            'ratingValue' => (string) ($brand['google_rating'] ?? 4.8),
            'reviewCount' => (int) ($brand['google_reviews_count'] ?? 0),
            'bestRating' => 5,
            'worstRating' => 1,
        ],
    ];
    if ($image !== null) {
        $schema['image'] = pz_absolute_url($image);
    }
    $reviews = [];
    foreach ($t['reviews_samples'] ?? [] as $sample) {
        if (empty($sample['text'])) {
            continue;
        }
        $reviews[] = [
            '@type' => 'Review',
            'author' => ['@type' => 'Person', 'name' => $sample['name'] ?? 'Guest'],
            'reviewRating' => [
                '@type' => 'Rating',
                'ratingValue' => (int) ($sample['stars'] ?? 5),
                'bestRating' => 5,
            ],
            'reviewBody' => $sample['text'],
        ];
    }
    if ($reviews !== []) {
        $schema['review'] = array_slice($reviews, 0, 3);
    }
    return $schema;
}

function pz_seo_breadcrumbs(array $items): array
{
    $list = [];
    $pos = 1;
    foreach ($items as $item) {
        $entry = [
            '@type' => 'ListItem',
            'position' => $pos++,
            'name' => $item['name'],
        ];
        if (!empty($item['url'])) {
            $entry['item'] = $item['url'];
        }
        $list[] = $entry;
    }
    return [
        '@type' => 'BreadcrumbList',
        'itemListElement' => $list,
    ];
}

function pz_seo_faq_page(array $faq): ?array
{
    $entities = [];
    foreach ($faq as $item) {
        $q = trim((string) ($item['q'] ?? $item['question'] ?? ''));
        $a = trim((string) ($item['a'] ?? $item['answer'] ?? ''));
        if ($q === '' || $a === '') {
            continue;
        }
        $entities[] = [
            '@type' => 'Question',
            'name' => $q,
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $a,
            ],
        ];
    }
    if ($entities === []) {
        return null;
    }
    return [
        '@type' => 'FAQPage',
        'mainEntity' => $entities,
    ];
}

function pz_seo_menu_schema(array $items, string $menuUrl): array
{
    global $lang, $brand, $t;
    $sections = [];
    foreach (pz_categories() as $cat) {
        $catItems = array_values(array_filter($items, fn($item) => ($item['cat'] ?? '') === $cat));
        if ($catItems === []) {
            continue;
        }
        $menuItems = [];
        foreach ($catItems as $item) {
            $entry = [
                '@type' => 'MenuItem',
                'name' => pz_localized($item, 'name', $lang),
                'description' => pz_localized($item, 'desc', $lang),
                'offers' => [
                    '@type' => 'Offer',
                    'price' => (string) ((int) ($item['price'] ?? 0)),
                    'priceCurrency' => PZ_CURRENCY,
                ],
            ];
            if ($img = pz_menu_image($item)) {
                $entry['image'] = pz_absolute_url($img);
            }
            $menuItems[] = $entry;
        }
        $sections[] = [
            '@type' => 'MenuSection',
            'name' => $t['categories'][$cat] ?? ucfirst($cat),
            'hasMenuItem' => $menuItems,
        ];
    }
    return [
        '@type' => 'Menu',
        '@id' => rtrim($menuUrl, '/') . '#menu',
        'name' => $brand['name'] . ' — ' . ($t['menu_title'] ?? 'Menu'),
        'url' => $menuUrl,
        'hasMenuSection' => $sections,
    ];
}

function pz_seo_contact_page(string $canonical, string $title, string $description): array
{
    global $brand;
    return [
        '@type' => 'ContactPage',
        '@id' => $canonical . '#contactpage',
        'url' => $canonical,
        'name' => $title,
        'description' => $description,
        'mainEntity' => [
            '@type' => 'Restaurant',
            '@id' => 'https://bilohash.com/pizza/#restaurant',
            'name' => $brand['name'],
            'telephone' => $brand['phone'],
            'email' => $brand['email'],
        ],
    ];
}

function pz_seo_og_image(?string $relative = null): array
{
    $rel = $relative ?: (is_file(__DIR__ . '/../assets/images/hero-pizza.jpg') ? 'images/hero-pizza.jpg' : 'images/og-default.svg');
    $path = __DIR__ . '/../assets/' . ltrim($rel, '/');
    $width = 1200;
    $height = 630;
    if (is_file($path) && function_exists('getimagesize')) {
        $info = @getimagesize($path);
        if (is_array($info)) {
            $width = (int) ($info[0] ?? $width);
            $height = (int) ($info[1] ?? $height);
        }
    }
    return [
        'url' => pz_absolute_url(pz_asset($rel)),
        'width' => $width,
        'height' => $height,
        'rel' => $rel,
    ];
}

function pz_seo_software_app(string $canonical, string $description): array
{
    return [
        '@type' => 'SoftwareApplication',
        '@id' => $canonical . '#software',
        'name' => PZ_SITE_NAME,
        'applicationCategory' => 'BusinessApplication',
        'applicationSubCategory' => 'Restaurant and pizzeria website software',
        'operatingSystem' => 'Web',
        'description' => $description,
        'url' => $canonical,
        'inLanguage' => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'offers' => [
            '@type' => 'Offer',
            'price' => '0',
            'priceCurrency' => 'NOK',
            'availability' => 'https://schema.org/InStock',
            'url' => 'https://bilohash.com/pizza/site/',
        ],
        'author' => pz_seo_organization(),
        'publisher' => pz_seo_organization(),
        'featureList' => 'Multilingual menu, table reservations, admin panel, JSON storage, Schema.org Restaurant SEO, responsive UI',
    ];
}

function pz_seo_website(string $canonical): array
{
    return [
        '@type' => 'WebSite',
        '@id' => $canonical . '#website',
        'name' => PZ_SITE_NAME,
        'url' => $canonical,
        'inLanguage' => ['nb-NO', 'en-GB', 'uk-UA', 'ru-RU'],
        'publisher' => ['@id' => 'https://bilohash.com/pizza/#organization'],
    ];
}

function pz_seo_webpage(string $canonical, string $title, string $description): array
{
    global $lang_meta;
    return [
        '@type' => 'WebPage',
        '@id' => $canonical . '#webpage',
        'url' => $canonical,
        'name' => $title,
        'description' => $description,
        'isPartOf' => ['@id' => rtrim($canonical, '/') . '/#website'],
        'about' => ['@id' => 'https://bilohash.com/pizza/#software'],
        'inLanguage' => $lang_meta['locale'] ?? 'en-GB',
    ];
}

function pz_seo_menu_list(array $items, string $listUrl): array
{
    global $lang;
    $elements = [];
    $pos = 1;
    foreach (array_slice($items, 0, 20) as $item) {
        $elements[] = [
            '@type' => 'ListItem',
            'position' => $pos++,
            'name' => pz_localized($item, 'name', $lang),
            'url' => $listUrl . '#menu',
        ];
    }
    return [
        '@type' => 'ItemList',
        'url' => $listUrl,
        'numberOfItems' => count($items),
        'itemListElement' => $elements,
    ];
}

function pz_seo_json(array $graphs): string
{
    $graphs = array_values(array_filter($graphs));
    if (count($graphs) === 1) {
        $data = array_merge(['@context' => 'https://schema.org'], $graphs[0]);
    } else {
        $data = ['@context' => 'https://schema.org', '@graph' => $graphs];
    }
    return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function pz_render_seo_head(
    string $page_title,
    string $page_desc,
    string $canonical,
    array $schema_graphs = [],
    ?string $og_type = 'website',
    bool $noindex = false,
    ?string $keywords_override = null,
    ?string $og_image_rel = null
): void {
    global $lang_meta, $lang;
    $canonical_abs = pz_absolute_url($canonical);
    $keywords = $keywords_override ?? ($GLOBALS['t']['meta']['keywords'] ?? '');
    $robots = $noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    $og = pz_seo_og_image($og_image_rel);
    $og_image = $og['url'];
    ?>
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
    <?php if ($keywords !== ''): ?>
    <meta name="keywords" content="<?= htmlspecialchars($keywords) ?>">
    <?php endif; ?>
    <meta name="robots" content="<?= $robots ?>">
    <meta name="author" content="Pizza CMS · Bilohash">
    <meta name="geo.region" content="NO-06">
    <meta name="geo.placename" content="Drammen, Norway">
    <meta name="theme-color" content="#120e0b">
    <link rel="canonical" href="<?= htmlspecialchars($canonical_abs) ?>">
    <link rel="alternate" hreflang="x-default" href="<?= htmlspecialchars(pz_full_lang_url('en')) ?>">
    <?php foreach (pz_langs() as $code => $info): ?>
    <link rel="alternate" hreflang="<?= $code === 'uk' ? 'uk' : $code ?>" href="<?= htmlspecialchars(pz_full_lang_url($code)) ?>">
    <?php endforeach; ?>
    <meta property="og:type" content="<?= htmlspecialchars($og_type) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta property="og:url" content="<?= htmlspecialchars($canonical_abs) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars(PZ_BRAND_NAME) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:secure_url" content="<?= htmlspecialchars($og_image) ?>">
    <meta property="og:image:width" content="<?= (int) $og['width'] ?>">
    <meta property="og:image:height" content="<?= (int) $og['height'] ?>">
    <meta property="og:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <meta property="og:locale" content="<?= htmlspecialchars(str_replace('-', '_', $lang_meta['locale'])) ?>">
    <?php foreach (pz_langs() as $code => $info):
        if ($code === $lang) continue; ?>
    <meta property="og:locale:alternate" content="<?= htmlspecialchars(str_replace('-', '_', $info['locale'])) ?>">
    <?php endforeach; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>">
    <meta name="twitter:image:alt" content="<?= htmlspecialchars($page_title) ?>">
    <?php if (!empty($schema_graphs)): ?>
    <script type="application/ld+json"><?= pz_seo_json($schema_graphs) ?></script>
    <?php endif;
}