<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/landing-lib.php';

$current_page = 'solutions';
$page_title = $t['solutions']['meta_title'] ?? 'Pizza CMS solutions';
$page_desc  = $t['solutions']['meta_desc'] ?? '';
$canonical  = pzs_url('solutions.php');
$canon_abs  = pzs_absolute_url($canonical);
$all = pzs_usecases_all();

$seo_schemas = pzs_landing_seo_schemas($canon_abs, $page_title, $page_desc, [
    'h1' => $t['solutions']['hub_title'] ?? 'Solutions',
    'intro' => $t['solutions']['hub_desc'] ?? '',
    'faq' => [],
], [
    ['name' => $t['breadcrumb_home'] ?? 'Home', 'url' => pzs_absolute_url(pzs_url('index.php'))],
    ['name' => $t['solutions']['hub_title'] ?? 'Solutions', 'url' => $canon_abs],
]);

require __DIR__ . '/includes/header.php';
?>

<main class="shs-container shs-hub-main">
    <nav class="shs-breadcrumb" aria-label="Breadcrumb">
        <a href="<?= pzs_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a>
        <span>/</span>
        <span><?= htmlspecialchars($t['solutions']['hub_title'] ?? 'Solutions') ?></span>
    </nav>
    <h1><?= htmlspecialchars($t['solutions']['hub_title'] ?? 'Solutions') ?></h1>
    <p class="shs-hub-lead"><?= htmlspecialchars($t['solutions']['hub_desc'] ?? '') ?></p>

    <div class="shs-hub-grid">
        <?php foreach ($all as $slug => $item):
            $lv = pzs_landing_lang($item, $lang);
        ?>
        <a href="<?= htmlspecialchars(pzs_landing_url($slug)) ?>" class="shs-hub-card">
            <i class="fas fa-<?= htmlspecialchars($item['icon'] ?? 'pizza-slice') ?>" aria-hidden="true"></i>
            <strong><?= htmlspecialchars($lv['h1']) ?></strong>
            <span><?= htmlspecialchars(mb_substr($lv['intro'], 0, 120)) ?>…</span>
        </a>
        <?php endforeach; ?>
    </div>

    <section class="shs-hub-cross">
        <h2><?= htmlspecialchars($t['markets']['hub_title'] ?? 'Countries') ?></h2>
        <div class="shs-hub-tags">
            <?php foreach (array_slice(pzs_markets_all(), 0, 12) as $mslug => $mitem):
                $mv = pzs_landing_lang($mitem, $lang);
            ?>
            <a href="<?= htmlspecialchars(pzs_landing_url($mslug)) ?>"><?= htmlspecialchars(($mitem['flag'] ?? '') . ' ' . $mv['h1']) ?></a>
            <?php endforeach; ?>
            <a href="<?= pzs_url('markets.php') ?>" class="shs-hub-more"><?= htmlspecialchars($t['landing']['all_markets'] ?? 'All countries →') ?></a>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>