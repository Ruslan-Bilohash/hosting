<?php
$current = pzs_langs()[$lang] ?? pzs_langs()['en'];
?>
<div class="shs-lang-dropdown" id="shsLangDropdown">
    <button type="button" class="shs-lang-btn" id="shsLangBtn" aria-expanded="false">
        <?= $current['flag'] ?> <?= htmlspecialchars($current['label']) ?> <i class="fas fa-chevron-down"></i>
    </button>
    <ul class="shs-lang-menu" id="shsLangMenu" hidden>
        <?php foreach (pzs_langs() as $code => $info): ?>
        <li><a href="<?= htmlspecialchars(pzs_lang_url($code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>"><?= $info['flag'] ?> <?= htmlspecialchars($info['name']) ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>