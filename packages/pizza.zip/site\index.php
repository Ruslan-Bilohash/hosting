<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/landing-lib.php';
require_once dirname(__DIR__, 2) . '/includes/cms-contact.php';
$canonical = $site_url . '/';
$page_title = $t['meta']['title'];
$page_desc  = $t['meta']['description'];
require __DIR__ . '/includes/header.php';
?>

<section class="shs-hero">
    <div class="shs-container shs-hero-inner">
        <div class="shs-hero-content">
            <span class="shs-badge"><?= htmlspecialchars($t['hero']['badge']) ?></span>
            <h1><?= htmlspecialchars($t['hero']['title']) ?></h1>
            <p class="shs-hero-sub"><?= htmlspecialchars($t['hero']['subtitle']) ?></p>
            <div class="shs-hero-cta">
                <a href="<?= pzs_demo_url() ?>" class="shs-btn-primary shs-btn-lg"><i class="fas fa-pizza-slice"></i> <?= htmlspecialchars($t['hero']['cta_demo']) ?></a>
                <a href="<?= pzs_demo_url('admin/login.php') ?>" class="shs-btn-outline shs-btn-lg"><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['hero']['cta_admin']) ?></a>
                <a href="<?= pzs_demo_url('contact.php') ?>" class="shs-btn-ghost shs-btn-lg"><i class="fas fa-comments"></i> <?= htmlspecialchars(cms_contact_texts('pizza', $lang)['nav_discuss']) ?></a>
            </div>
        </div>
        <div class="shs-hero-preview" aria-hidden="true">
            <div class="shs-mockup">
                <div class="shs-mockup-header">
                    <span></span><span></span><span></span>
                    <span class="shs-mockup-title">Forno Romano · Menu</span>
                </div>
                <div class="shs-mockup-body">
                    <article class="shs-mockup-item active"><div class="shs-mock-thumb"></div><div><strong>Margherita DOP</strong><span>189 kr</span></div></article>
                    <article class="shs-mockup-item"><div class="shs-mock-thumb"></div><div><strong>Diavola</strong><span>219 kr</span></div></article>
                    <article class="shs-mockup-item"><div class="shs-mock-thumb"></div><div><strong>Tagliatelle</strong><span>199 kr</span></div></article>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="shs-section shs-intro">
    <div class="shs-container">
        <h2><?= htmlspecialchars($t['intro']['title']) ?></h2>
        <p class="shs-lead"><?= htmlspecialchars($t['intro']['text']) ?></p>
        <p class="shs-use-label"><?= htmlspecialchars($t['intro']['use_label'] ?? '') ?></p>
        <div class="shs-usecases">
            <?php foreach ($t['intro']['use_cases'] as $case): ?>
            <span class="shs-usecase"><?= htmlspecialchars($case) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="shs-section" id="features">
    <div class="shs-container">
        <h2 class="shs-section-title"><?= htmlspecialchars($t['features']['title']) ?></h2>
        <div class="shs-features-grid">
            <?php foreach ($t['features']['items'] as $f): ?>
            <article class="shs-feature-card">
                <div class="shs-feature-icon"><i class="fas fa-<?= htmlspecialchars($f['icon']) ?>"></i></div>
                <h3><?= htmlspecialchars($f['title']) ?></h3>
                <p><?= htmlspecialchars($f['desc']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="shs-section shs-tech" id="tech">
    <div class="shs-container">
        <h2 class="shs-section-title"><?= htmlspecialchars($t['tech']['title']) ?></h2>
        <ul class="shs-tech-list">
            <?php foreach ($t['tech']['items'] as $item): ?>
            <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars($item) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<section class="shs-section shs-demo-block" id="demo">
    <div class="shs-container">
        <h2 class="shs-section-title"><?= htmlspecialchars($t['demo']['title']) ?></h2>
        <div class="shs-demo-grid">
            <article class="shs-demo-card">
                <h3><i class="fas fa-store"></i> <?= htmlspecialchars($t['demo']['frontend']) ?></h3>
                <p><?= htmlspecialchars($t['demo']['frontend_desc']) ?></p>
                <a href="<?= pzs_demo_url() ?>" class="shs-btn-primary"><?= htmlspecialchars($t['demo']['open']) ?> →</a>
            </article>
            <article class="shs-demo-card">
                <h3><i class="fas fa-user-shield"></i> <?= htmlspecialchars($t['demo']['admin']) ?></h3>
                <p><?= htmlspecialchars($t['demo']['admin_desc']) ?></p>
                <a href="<?= pzs_demo_url('admin/login.php') ?>" class="shs-btn-outline"><?= htmlspecialchars($t['demo']['open']) ?> →</a>
            </article>
        </div>
    </div>
</section>

<section class="shs-section shs-hubs" id="solutions">
    <div class="shs-container">
        <h2 class="shs-section-title"><?= htmlspecialchars($t['index_hubs']['solutions_title'] ?? 'Solutions') ?></h2>
        <p class="shs-hub-lead"><?= htmlspecialchars($t['index_hubs']['solutions_desc'] ?? '') ?></p>
        <div class="shs-hub-grid shs-hub-grid--compact">
            <?php foreach (array_slice(pzs_usecases_all(), 0, 6, true) as $slug => $item):
                $lv = pzs_landing_lang($item, $lang);
            ?>
            <a href="<?= htmlspecialchars(pzs_landing_url($slug)) ?>" class="shs-hub-card">
                <i class="fas fa-<?= htmlspecialchars($item['icon'] ?? 'pizza-slice') ?>" aria-hidden="true"></i>
                <strong><?= htmlspecialchars($lv['h1']) ?></strong>
            </a>
            <?php endforeach; ?>
        </div>
        <p class="shs-hub-more-row"><a href="<?= pzs_url('solutions.php') ?>" class="shs-link-arrow"><?= htmlspecialchars($t['footer']['solutions'] ?? 'All solutions') ?> →</a></p>
    </div>
</section>

<section class="shs-section shs-hubs" id="markets">
    <div class="shs-container">
        <h2 class="shs-section-title"><?= htmlspecialchars($t['index_hubs']['markets_title'] ?? 'Countries') ?></h2>
        <p class="shs-hub-lead"><?= htmlspecialchars($t['index_hubs']['markets_desc'] ?? '') ?></p>
        <div class="shs-hub-tags">
            <?php foreach (pzs_markets_all() as $mslug => $mitem):
                $mv = pzs_landing_lang($mitem, $lang);
            ?>
            <a href="<?= htmlspecialchars(pzs_landing_url($mslug)) ?>"><?= ($mitem['flag'] ?? '') . ' ' . htmlspecialchars($mv['h1']) ?></a>
            <?php endforeach; ?>
        </div>
        <p class="shs-hub-more-row"><a href="<?= pzs_url('markets.php') ?>" class="shs-link-arrow"><?= htmlspecialchars($t['footer']['markets'] ?? 'All countries') ?> →</a></p>
    </div>
</section>

<section class="shs-section shs-cta-block">
    <div class="shs-container shs-cta-inner">
        <h2><?= htmlspecialchars($t['cta']['title']) ?></h2>
        <p><?= htmlspecialchars($t['cta']['text']) ?></p>
        <a href="<?= pzs_demo_url('contact.php') ?>" class="shs-btn-primary shs-btn-lg"><i class="fas fa-comments"></i> <?= htmlspecialchars($t['cta']['btn']) ?></a>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>