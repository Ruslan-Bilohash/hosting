<?php

function pz_data_path(string $file): string
{
    return __DIR__ . '/../data/' . $file;
}

function pz_menu_file(): string
{
    return pz_data_path('menu.json');
}

function pz_reservations_file(): string
{
    return pz_data_path('pizza-reservations.json');
}

function pz_settings_file(): string
{
    return pz_data_path('settings.json');
}

function pz_load_settings(): array
{
    require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
    $defaults = bh_cms_site_settings_defaults(bh_cms_product_accent('pizza'));
    if (!is_file(pz_settings_file())) {
        pz_save_settings($defaults);
        return $defaults;
    }
    $data = json_decode(file_get_contents(pz_settings_file()) ?: '{}', true);
    return is_array($data) ? array_merge($defaults, $data) : $defaults;
}

function pz_save_settings(array $settings): bool
{
    require_once dirname(__DIR__, 2) . '/includes/bh-cms-site-settings.php';
    $merged = bh_cms_merge_site_settings($settings, 'pizza');
    return file_put_contents(pz_settings_file(), json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) !== false;
}

function pz_default_menu_from_seed(): ?array
{
    $seedFile = __DIR__ . '/../data/menu.php';
    if (!is_readable($seedFile)) {
        return null;
    }
    $defaults = require $seedFile;
    if (!is_array($defaults)) {
        return null;
    }
    foreach ($defaults as &$item) {
        $item['active'] = $item['active'] ?? true;
    }
    unset($item);
    return $defaults;
}

function pz_save_menu(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(pz_menu_file(), $json, LOCK_EX) !== false;
}

function pz_ensure_menu_json(): void
{
    $json = pz_menu_file();
    if (!is_file($json)) {
        $defaults = pz_default_menu_from_seed();
        if ($defaults !== null) {
            pz_save_menu($defaults);
        }
        return;
    }

    $defaults = pz_default_menu_from_seed();
    if ($defaults === null) {
        return;
    }

    $existing = json_decode(file_get_contents($json) ?: '[]', true);
    if (!is_array($existing)) {
        pz_save_menu($defaults);
        return;
    }

    $seedById = [];
    foreach ($defaults as $seed) {
        $sid = $seed['id'] ?? '';
        if ($sid !== '') {
            $seedById[$sid] = $seed;
        }
    }

    $ids = array_column($existing, 'id');
    $merged = $existing;
    $changed = false;
    foreach ($defaults as $item) {
        if (!in_array($item['id'] ?? '', $ids, true)) {
            $merged[] = $item;
            $changed = true;
        }
    }
    foreach ($merged as $i => $row) {
        $rid = $row['id'] ?? '';
        if ($rid === '' || empty($seedById[$rid]['image'])) {
            continue;
        }
        if (empty($row['image'])) {
            $merged[$i]['image'] = $seedById[$rid]['image'];
            $changed = true;
        }
    }
    if ($changed) {
        pz_save_menu($merged);
    }
}

function pz_load_menu_raw(): array
{
    $file = pz_menu_file();
    if (is_readable($file)) {
        $data = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($data) && $data !== []) {
            return $data;
        }
    }

    pz_ensure_menu_json();
    if (is_readable($file)) {
        $data = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($data) && $data !== []) {
            return $data;
        }
    }

    return pz_default_menu_from_seed() ?? [];
}

function pz_bootstrap_data(): void
{
    pz_ensure_menu_json();
    pz_ensure_demo_reservations();
}

function pz_default_reservations_from_seed(): ?array
{
    $seedFile = __DIR__ . '/../data/reservations-seed.php';
    if (!is_readable($seedFile)) {
        return null;
    }
    $defaults = require $seedFile;
    return is_array($defaults) ? $defaults : null;
}

function pz_save_reservations(array $list): bool
{
    $json = json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(pz_reservations_file(), $json, LOCK_EX) !== false;
}

function pz_load_reservations(): array
{
    $file = pz_reservations_file();
    if (!is_readable($file)) {
        pz_ensure_demo_reservations();
        if (!is_readable($file)) {
            return [];
        }
    }
    $data = json_decode(file_get_contents($file) ?: '[]', true);
    if (!is_array($data)) {
        return [];
    }
    return $data;
}

function pz_ensure_demo_reservations(): void
{
    $file = pz_reservations_file();
    if (is_file($file)) {
        $existing = json_decode(file_get_contents($file) ?: '[]', true);
        if (is_array($existing) && $existing !== []) {
            return;
        }
    }
    $defaults = pz_default_reservations_from_seed();
    if ($defaults !== null) {
        pz_save_reservations($defaults);
    }
}

function pz_normalize_reservation(array $row): array
{
    $row['status'] = $row['status'] ?? 'pending';
    $row['type'] = $row['type'] ?? 'table';
    $row['amount_nok'] = (int) ($row['amount_nok'] ?? 200);
    $row['payment'] = $row['payment'] ?? 'none';
    return $row;
}

function pz_update_reservation_status(string $id, string $status, string $payment = 'none'): bool
{
    $list = pz_load_reservations();
    $found = false;
    foreach ($list as $i => $row) {
        if (($row['id'] ?? '') !== $id) {
            continue;
        }
        $list[$i]['status'] = $status;
        $list[$i]['payment'] = $payment;
        $found = true;
        break;
    }
    if (!$found) {
        return false;
    }
    return pz_save_reservations($list);
}

function pz_save_reservation(array $entry): bool
{
    $entry = pz_normalize_reservation($entry);
    $list = pz_load_reservations();
    $list[] = $entry;
    return pz_save_reservations($list);
}