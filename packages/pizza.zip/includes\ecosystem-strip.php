<?php
if (empty($t['ecosystem']['items'])) {
    return;
}
$eco = $t['ecosystem'];
?>
<section class="pz-ecosystem-section">
    <div class="pz-container">
        <div class="pz-section-head">
            <h2><?= htmlspecialchars($eco['title']) ?></h2>
            <p><?= htmlspecialchars($eco['subtitle']) ?></p>
        </div>
        <div class="pz-ecosystem-grid">
            <?php foreach ($eco['items'] as $item): ?>
            <article class="pz-ecosystem-card">
                <div class="pz-ecosystem-icon">
                    <?php if (($item['icon'] ?? '') === 'wordpress'): ?>
                    <i class="fab fa-wordpress" aria-hidden="true"></i>
                    <?php else: ?>
                    <i class="fas fa-<?= htmlspecialchars($item['icon']) ?>" aria-hidden="true"></i>
                    <?php endif; ?>
                </div>
                <h3><?= htmlspecialchars($item['name']) ?></h3>
                <p><?= htmlspecialchars($item['desc']) ?></p>
                <div class="pz-ecosystem-links">
                    <a href="<?= htmlspecialchars($item['url']) ?>" class="pz-btn pz-btn-ghost pz-btn-sm" rel="related"><?= htmlspecialchars($eco['product_btn']) ?></a>
                    <a href="<?= htmlspecialchars($item['demo']) ?>" class="pz-btn pz-btn-primary pz-btn-sm" rel="related"><?= htmlspecialchars($eco['demo_btn']) ?></a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>