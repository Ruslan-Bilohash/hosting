<?php
require_once __DIR__ . '/../config.php';

define('PZ_LANG_COOKIE', 'pz_lang');

$PZ_LANGS = [
    'en' => ['label' => 'EN', 'name' => 'English', 'flag' => '🇬🇧', 'locale' => 'en-GB', 'html' => 'en'],
    'no' => ['label' => 'NO', 'name' => 'Norsk', 'flag' => '🇳🇴', 'locale' => 'nb-NO', 'html' => 'no'],
    'uk' => ['label' => 'UA', 'name' => 'Українська', 'flag' => '🇺🇦', 'locale' => 'uk-UA', 'html' => 'uk'],
    'ru' => ['label' => 'RU', 'name' => 'Русский', 'flag' => '🇷🇺', 'locale' => 'ru-RU', 'html' => 'ru'],
];

function pz_langs(): array
{
    global $PZ_LANGS;
    return $PZ_LANGS;
}

function pz_detect_lang(): string
{
    global $base_path, $PZ_LANGS;
    $codes = array_keys($PZ_LANGS);

    if (!empty($_GET['lang'])) {
        $raw = strtolower((string) $_GET['lang']);
        if ($raw === 'ua') {
            $raw = 'uk';
        }
        if (in_array($raw, $codes, true)) {
            $chosen = $raw;
            setcookie(PZ_LANG_COOKIE, $chosen, [
                'expires' => time() + 365 * 86400,
                'path'    => rtrim($base_path, '/') . '/' ?: '/',
                'secure'  => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                'samesite'=> 'Lax',
            ]);
            if ($chosen === 'en') {
                $uri = $_SERVER['REQUEST_URI'] ?? '/';
                $parts = parse_url($uri);
                parse_str($parts['query'] ?? '', $q);
                unset($q['lang']);
                $clean = ($parts['path'] ?? '/') . ($q ? '?' . http_build_query($q) : '');
                if ($clean !== $uri) {
                    header('Location: ' . $clean, true, 302);
                    exit;
                }
            }
            return $chosen;
        }
    }

    if (!empty($_COOKIE[PZ_LANG_COOKIE]) && in_array($_COOKIE[PZ_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[PZ_LANG_COOKIE];
    }

    return 'en';
}

$lang      = pz_detect_lang();
$lang_meta = $PZ_LANGS[$lang] ?? $PZ_LANGS['en'];
$html_lang = $lang_meta['html'];

$lang_file = __DIR__ . '/../lang/' . $lang . '.php';
if (!is_file($lang_file)) {
    $lang_file = __DIR__ . '/../lang/en.php';
}
$t = require $lang_file;

require_once dirname(__DIR__, 2) . '/includes/ecosystem-i18n.php';
$t = bh_apply_ecosystem_translations($t, $lang, 'pizza');

require_once __DIR__ . '/helpers.php';