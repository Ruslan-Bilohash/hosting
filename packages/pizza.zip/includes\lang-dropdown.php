<?php
/** Language dropdown — expects $lang, pz_langs(), pz_url() */
$current = pz_langs()[$lang] ?? pz_langs()['en'];
$dropdown_id = $dropdown_id ?? 'pzLangDropdown';
$btn_id = $btn_id ?? 'pzLangBtn';
$menu_id = $menu_id ?? 'pzLangMenu';
?>
<div class="pz-lang-dropdown" id="<?= htmlspecialchars($dropdown_id) ?>">
    <button type="button" class="pz-lang-dropdown-btn" id="<?= htmlspecialchars($btn_id) ?>" aria-expanded="false" aria-haspopup="listbox" aria-controls="<?= htmlspecialchars($menu_id) ?>" aria-label="<?= htmlspecialchars($t['lang_label'] ?? 'Language') ?>">
        <span class="pz-lang-flag"><?= $current['flag'] ?></span>
        <span class="pz-lang-current"><?= htmlspecialchars($current['label']) ?></span>
        <i class="fas fa-chevron-down" aria-hidden="true"></i>
    </button>
    <ul class="pz-lang-dropdown-menu" id="<?= htmlspecialchars($menu_id) ?>" role="listbox" hidden>
        <?php foreach (pz_langs() as $code => $info): ?>
        <li role="option">
            <a href="<?= htmlspecialchars(pz_url('', $code)) ?>" class="<?= $lang === $code ? 'active' : '' ?>" <?= $lang === $code ? 'aria-current="true"' : '' ?>>
                <span class="pz-lang-flag"><?= $info['flag'] ?></span>
                <span class="pz-lang-name"><?= htmlspecialchars($info['name']) ?></span>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
</div>