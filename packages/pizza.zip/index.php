<?php
declare(strict_types=1);
require __DIR__ . '/init.php';

$menu = pz_menu_items();
$pz_qr_url = pz_page_menu_url($lang);
$pz_qr_img = pz_qr_code_url($pz_qr_url, 200);
$page_title = $t['meta_title'];
$page_desc  = $t['meta_desc'];
$canonical  = $site_url . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');
$canon_abs  = pz_absolute_url($canonical);
$seo_schemas = [
    pz_seo_organization(),
    pz_seo_software_app($canon_abs, $page_desc),
    pz_seo_website(pz_absolute_url($site_url . '/')),
    pz_seo_webpage($canon_abs, $page_title, $page_desc),
    pz_seo_restaurant(),
    pz_seo_menu_schema($menu, $canon_abs),
    pz_seo_menu_list($menu, $canon_abs),
];
if (!empty($t['home_faq']) && ($home_faq = pz_seo_faq_page($t['home_faq'])) !== null) {
    $seo_schemas[] = $home_faq;
}

require __DIR__ . '/includes/header.php';
?>

        <section class="pz-hero">
            <div class="pz-sun-stage" aria-hidden="true">
                <div class="pz-sun-glow"></div>
                <div class="pz-sun-rays"></div>
                <div class="pz-sun-core"></div>
            </div>
            <div class="pz-hero-bg" aria-hidden="true"></div>
            <div class="pz-hero-pattern" aria-hidden="true"></div>
            <div class="pz-container pz-hero-grid">
                <div>
                    <div class="pz-hero-badge">
                        <i class="fas fa-fire" aria-hidden="true"></i>
                        <?= htmlspecialchars($t['hero_badge']) ?>
                    </div>
                    <h1><?= htmlspecialchars($t['hero_title']) ?></h1>
                    <p class="pz-hero-lead"><?= htmlspecialchars($t['hero_sub']) ?></p>
                    <div class="pz-hero-cta">
                        <a href="#menu" class="pz-btn pz-btn-primary">
                            <i class="fas fa-utensils" aria-hidden="true"></i>
                            <?= htmlspecialchars($t['hero_cta_menu']) ?>
                        </a>
                        <a href="#reserve" class="pz-btn pz-btn-ghost">
                            <i class="fas fa-calendar-check" aria-hidden="true"></i>
                            <?= htmlspecialchars($t['hero_cta_reserve']) ?>
                        </a>
                    </div>
                    <p class="pz-hero-note"><?= htmlspecialchars($t['hero_note']) ?></p>
                    <div class="pz-stats">
                        <div class="pz-stat">
                            <strong><?= htmlspecialchars($t['stats_oven']) ?></strong>
                            <span><?= htmlspecialchars($t['stats_label_oven'] ?? 'oven') ?></span>
                        </div>
                        <div class="pz-stat">
                            <strong><?= htmlspecialchars($t['stats_dough']) ?></strong>
                            <span><?= htmlspecialchars($t['stats_label_dough'] ?? 'dough') ?></span>
                        </div>
                        <div class="pz-stat">
                            <strong><?= htmlspecialchars($t['stats_rating']) ?></strong>
                            <span><?= htmlspecialchars($t['stats_label_guests'] ?? 'guests') ?></span>
                        </div>
                    </div>
                </div>
                <div class="pz-hero-visual">
                    <figure class="pz-hero-photo">
                        <?php $pz_hero_src = pz_brand_image('hero_image') ?: pz_asset('images/og-default.svg'); ?>
                        <img
                            src="<?= htmlspecialchars($pz_hero_src) ?>"
                            alt="<?= htmlspecialchars($t['hero_image_alt']) ?>"
                            width="900"
                            height="900"
                            fetchpriority="high"
                            decoding="async"
                        >
                    </figure>
                </div>
            </div>
        </section>

        <section class="pz-section" id="menu">
            <div class="pz-container">
                <div class="pz-section-head">
                    <h2><?= htmlspecialchars($t['menu_title']) ?></h2>
                    <p><?= htmlspecialchars($t['menu_sub']) ?></p>
                </div>
                <div class="pz-filters-wrap">
                    <div class="pz-filters" role="tablist" aria-label="<?= htmlspecialchars($t['menu_categories'] ?? 'Menu categories') ?>">
                        <button type="button" class="pz-filter is-active" id="menu-all" data-filter="all"><?= htmlspecialchars($t['filter_all']) ?></button>
                        <button type="button" class="pz-filter" id="menu-pizza" data-filter="pizza"><?= htmlspecialchars($t['filter_pizza']) ?></button>
                        <button type="button" class="pz-filter" id="menu-pasta" data-filter="pasta"><?= htmlspecialchars($t['filter_pasta']) ?></button>
                        <button type="button" class="pz-filter" id="menu-starters" data-filter="starters"><?= htmlspecialchars($t['filter_starters']) ?></button>
                        <button type="button" class="pz-filter" id="menu-dessert" data-filter="dessert"><?= htmlspecialchars($t['filter_dessert']) ?></button>
                        <button type="button" class="pz-filter" id="menu-drinks" data-filter="drinks"><?= htmlspecialchars($t['filter_drinks']) ?></button>
                    </div>
                </div>
                <div class="pz-menu-grid">
                    <?php foreach ($menu as $item):
                        $tags = $item['tags'] ?? [];
                    ?>
                    <article class="pz-menu-card" data-cat="<?= htmlspecialchars($item['cat']) ?>">
                        <?php $pz_menu_img = pz_menu_image($item); if ($pz_menu_img): ?>
                        <div class="pz-menu-media">
                            <img
                                src="<?= htmlspecialchars($pz_menu_img) ?>"
                                alt="<?= htmlspecialchars(pz_localized($item, 'name')) ?>"
                                width="640"
                                height="480"
                                loading="lazy"
                                decoding="async"
                            >
                        </div>
                        <?php endif; ?>
                        <div class="pz-menu-body">
                            <div class="pz-menu-top">
                                <h3><?= htmlspecialchars(pz_localized($item, 'name')) ?></h3>
                                <span class="pz-menu-price"><?= pz_price((int) $item['price']) ?></span>
                            </div>
                            <p class="pz-menu-desc"><?= htmlspecialchars(pz_localized($item, 'desc')) ?></p>
                            <?php if ($tags): ?>
                            <div class="pz-tags">
                                <?php foreach ($tags as $tag):
                                    $label = $tag === 'veg' ? $t['badge_veg'] : ($tag === 'spicy' ? $t['badge_spicy'] : $t['badge_chef']);
                                    $cls = $tag === 'spicy' ? ' pz-tag--spicy' : ($tag === 'chef' ? ' pz-tag--chef' : '');
                                ?>
                                <span class="pz-tag<?= $cls ?>"><?= htmlspecialchars($label) ?></span>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="pz-section" id="about">
            <div class="pz-container pz-about-grid">
                <div class="pz-about-copy">
                    <h2><?= htmlspecialchars($t['about_title']) ?></h2>
                    <p><?= htmlspecialchars($t['about_p1']) ?></p>
                    <p><?= htmlspecialchars($t['about_p2']) ?></p>
                    <ul class="pz-about-list">
                        <li><i class="fas fa-fire-burner" aria-hidden="true"></i><?= htmlspecialchars($t['about_li1']) ?></li>
                        <li><i class="fas fa-leaf" aria-hidden="true"></i><?= htmlspecialchars($t['about_li2']) ?></li>
                        <li><i class="fas fa-child-reaching" aria-hidden="true"></i><?= htmlspecialchars($t['about_li3']) ?></li>
                    </ul>
                </div>
                <div class="pz-oven-card">
                    <strong><?= htmlspecialchars($brand['name']) ?></strong>
                    <span><?= htmlspecialchars($brand['address']) ?></span>
                </div>
            </div>
        </section>

        <section class="pz-solaskinner" id="solaskinner">
            <div class="pz-sol-sun-stage" aria-hidden="true">
                <div class="pz-sol-sun-glow"></div>
                <div class="pz-sol-sun-rays"></div>
                <div class="pz-sol-sun-core"></div>
            </div>
            <div class="pz-container pz-sol-inner">
                <h2><?= htmlspecialchars($t['sol_title']) ?></h2>
                <p class="pz-sol-lead"><?= htmlspecialchars($t['sol_sub']) ?></p>
                <p class="pz-sol-text"><?= htmlspecialchars($t['sol_p1']) ?></p>
                <ul class="pz-sol-list">
                    <li><i class="fas fa-sun" aria-hidden="true"></i><?= htmlspecialchars($t['sol_li1']) ?></li>
                    <li><i class="fas fa-wine-glass" aria-hidden="true"></i><?= htmlspecialchars($t['sol_li2']) ?></li>
                    <li><i class="fas fa-umbrella-beach" aria-hidden="true"></i><?= htmlspecialchars($t['sol_li3']) ?></li>
                </ul>
                <a href="#reserve" class="pz-btn pz-btn-primary pz-sol-cta">
                    <i class="fas fa-chair" aria-hidden="true"></i>
                    <?= htmlspecialchars($t['sol_cta']) ?>
                </a>
            </div>
        </section>

        <section class="pz-section pz-admin-section" id="admin-demo">
            <div class="pz-container pz-admin-section-grid">
                <div class="pz-admin-demo-col">
                    <span class="pz-admin-demo-badge"><?= htmlspecialchars($t['admin_demo']['badge'] ?? 'Pizza CMS') ?></span>
                    <h2><?= htmlspecialchars($t['admin_demo']['title'] ?? 'Admin panel demo') ?></h2>
                    <p><?= htmlspecialchars($t['admin_demo']['sub'] ?? '') ?></p>
                </div>
                <div>
                    <?php require __DIR__ . '/includes/admin-demo-preview.php'; ?>
                </div>
            </div>
        </section>

        <section class="pz-section" id="gallery">
            <div class="pz-container">
                <div class="pz-section-head">
                    <h2><?= htmlspecialchars($t['gallery_title']) ?></h2>
                    <p><?= htmlspecialchars($t['gallery_sub']) ?></p>
                </div>
                <div class="pz-gallery">
                    <?php foreach ($brand['gallery_images'] as $i => $shot): ?>
                    <div class="pz-gallery-item">
                        <img
                            src="<?= htmlspecialchars(pz_asset($shot['file'])) ?>"
                            alt="<?= htmlspecialchars($t['gallery_alt'][$i] ?? $t['gallery_title']) ?>"
                            loading="lazy"
                            decoding="async"
                        >
                        <?php if (!empty($shot['label'])): ?>
                        <span class="pz-gallery-label"><?= htmlspecialchars($brand['name']) ?> · <?= htmlspecialchars($shot['label']) ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="pz-section" id="reserve">
            <div class="pz-container">
                <div class="pz-section-head">
                    <h2><?= htmlspecialchars($t['reserve_title']) ?></h2>
                    <p><?= htmlspecialchars($t['reserve_sub']) ?></p>
                </div>
                <div class="pz-split">
                    <form class="pz-form" id="pzReserveForm" action="<?= htmlspecialchars(pz_url('reserve.php')) ?>" method="post" data-error="<?= htmlspecialchars($t['form_error']) ?>" data-success="<?= htmlspecialchars($t['form_success']) ?>">
                        <div class="pz-form-grid">
                            <div class="pz-field">
                                <label for="pz-name"><?= htmlspecialchars($t['form_name']) ?></label>
                                <input type="text" id="pz-name" name="name" required maxlength="120" autocomplete="name">
                            </div>
                            <div class="pz-field">
                                <label for="pz-phone"><?= htmlspecialchars($t['form_phone']) ?></label>
                                <input type="tel" id="pz-phone" name="phone" required maxlength="40" autocomplete="tel">
                            </div>
                            <div class="pz-field pz-field--full">
                                <label for="pz-email"><?= htmlspecialchars($t['form_email']) ?></label>
                                <input type="email" id="pz-email" name="email" maxlength="160" autocomplete="email">
                            </div>
                            <div class="pz-field">
                                <label for="pz-date"><?= htmlspecialchars($t['form_date']) ?></label>
                                <input type="date" id="pz-date" name="date" required>
                            </div>
                            <div class="pz-field">
                                <label for="pz-time"><?= htmlspecialchars($t['form_time']) ?></label>
                                <input type="time" id="pz-time" name="time" value="19:00">
                            </div>
                            <div class="pz-field">
                                <label for="pz-guests"><?= htmlspecialchars($t['form_guests']) ?></label>
                                <select id="pz-guests" name="guests" required>
                                    <?php for ($g = 1; $g <= 12; $g++): ?>
                                    <option value="<?= $g ?>"<?= $g === 2 ? ' selected' : '' ?>><?= $g ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="pz-field pz-field--full">
                                <label for="pz-note"><?= htmlspecialchars($t['form_note']) ?></label>
                                <textarea id="pz-note" name="note" rows="3" maxlength="500" placeholder="<?= htmlspecialchars($t['form_note_placeholder'] ?? '') ?>"></textarea>
                            </div>
                        </div>
                        <?php require __DIR__ . '/includes/partials/recaptcha-widget.php'; ?>
                        <button type="submit" class="pz-btn pz-btn-primary" style="margin-top:1.25rem;width:100%">
                            <i class="fas fa-paper-plane" aria-hidden="true"></i>
                            <?= htmlspecialchars($t['form_submit']) ?>
                        </button>
                        <div class="pz-form-msg" id="pzFormMsg" role="status"></div>
                    </form>
                    <div class="pz-info-card" id="contact">
                        <div class="pz-qr-block" id="qr">
                            <div class="pz-qr-copy">
                                <h4 class="pz-qr-title">
                                    <i class="fas fa-qrcode" aria-hidden="true"></i>
                                    <?= htmlspecialchars($t['qr_title']) ?>
                                </h4>
                                <p class="pz-qr-sub"><?= htmlspecialchars($t['qr_sub']) ?></p>
                            </div>
                            <a href="<?= htmlspecialchars($pz_qr_url) ?>" class="pz-qr-frame" aria-label="<?= htmlspecialchars($t['qr_alt']) ?>">
                                <img
                                    src="<?= htmlspecialchars($pz_qr_img) ?>"
                                    alt="<?= htmlspecialchars($t['qr_alt']) ?>"
                                    width="200"
                                    height="200"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </a>
                        </div>
                        <h3><?= htmlspecialchars($t['contact_title']) ?></h3>
                        <p class="pz-contact-sub"><?= htmlspecialchars($t['contact_sub']) ?></p>
                        <h3 style="font-size:1.1rem;margin-top:1.5rem"><?= htmlspecialchars($t['hours_title']) ?></h3>
                        <div class="pz-hours-row"><span><?= htmlspecialchars($t['hours_week']) ?></span><span><?= htmlspecialchars($t['hours_week_val']) ?></span></div>
                        <div class="pz-hours-row"><span><?= htmlspecialchars($t['hours_fri']) ?></span><span><?= htmlspecialchars($t['hours_fri_val']) ?></span></div>
                        <div class="pz-hours-row"><span><?= htmlspecialchars($t['hours_sun']) ?></span><span><?= htmlspecialchars($t['hours_sun_val']) ?></span></div>
                        <div class="pz-contact-lines">
                            <div class="pz-contact-line">
                                <i class="fas fa-location-dot" aria-hidden="true"></i>
                                <span><?= htmlspecialchars($brand['address']) ?></span>
                            </div>
                            <div class="pz-contact-line">
                                <i class="fas fa-phone" aria-hidden="true"></i>
                                <a href="tel:<?= htmlspecialchars($brand['phone']) ?>"><?= htmlspecialchars($brand['phone']) ?></a>
                            </div>
                            <div class="pz-contact-line">
                                <i class="fas fa-envelope" aria-hidden="true"></i>
                                <a href="mailto:<?= htmlspecialchars($brand['email']) ?>"><?= htmlspecialchars($brand['email']) ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pz-maps-block" id="maps">
                    <div class="pz-maps-head">
                        <h3>
                            <i class="fab fa-google" aria-hidden="true"></i>
                            <?= htmlspecialchars($t['maps_title']) ?>
                        </h3>
                        <a href="<?= htmlspecialchars($brand['maps']) ?>" class="pz-btn pz-btn-ghost pz-btn-sm" target="_blank" rel="noopener noreferrer">
                            <i class="fas fa-location-arrow" aria-hidden="true"></i>
                            <?= htmlspecialchars($t['maps_open']) ?>
                        </a>
                    </div>
                    <div class="pz-maps-grid">
                        <div class="pz-maps-embed">
                            <iframe
                                src="<?= htmlspecialchars($brand['maps_embed']) ?>"
                                class="pz-maps-iframe"
                                allowfullscreen
                                loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"
                                title="<?= htmlspecialchars($t['maps_iframe_title']) ?>"
                            ></iframe>
                        </div>
                        <div class="pz-google-reviews">
                            <div class="pz-reviews-summary">
                                <div class="pz-reviews-place">
                                    <?php if ($pz_place_img = pz_brand_image('logo_image') ?: pz_brand_image('hero_image')): ?>
                                    <img
                                        class="pz-reviews-place-photo"
                                        src="<?= htmlspecialchars($pz_place_img) ?>"
                                        alt="<?= htmlspecialchars($brand['name'] . ', ' . $brand['city'] . ', ' . $brand['country']) ?>"
                                        width="56"
                                        height="56"
                                        loading="lazy"
                                        decoding="async"
                                    >
                                    <?php endif; ?>
                                    <div class="pz-reviews-place-meta">
                                        <strong><?= htmlspecialchars($brand['name']) ?></strong>
                                        <span><?= htmlspecialchars($brand['city']) ?>, <?= htmlspecialchars($brand['country']) ?></span>
                                        <span class="pz-reviews-google-badge">
                                            <i class="fab fa-google" aria-hidden="true"></i> Google
                                        </span>
                                    </div>
                                </div>
                                <div class="pz-reviews-score">
                                    <strong><?= number_format((float) $brand['google_rating'], 1, ',', '') ?></strong>
                                    <div class="pz-stars" aria-label="<?= htmlspecialchars((string) $brand['google_rating']) ?> / 5">
                                        <?php for ($s = 1; $s <= 5; $s++): ?>
                                        <i class="fas fa-star<?= $s <= round($brand['google_rating']) ? '' : ' pz-star--dim' ?>" aria-hidden="true"></i>
                                        <?php endfor; ?>
                                    </div>
                                    <span><?= htmlspecialchars(sprintf($t['reviews_count'], number_format((int) $brand['google_reviews_count'], 0, ',', ' '))) ?></span>
                                </div>
                            </div>
                            <p class="pz-reviews-demo"><?= htmlspecialchars($t['reviews_demo']) ?></p>
                            <div class="pz-reviews-list">
                                <?php foreach ($t['reviews_samples'] as $review): ?>
                                <article class="pz-review-card">
                                    <div class="pz-review-top">
                                        <strong><?= htmlspecialchars($review['name']) ?></strong>
                                        <div class="pz-stars pz-stars--sm" aria-hidden="true">
                                            <?php for ($s = 1; $s <= 5; $s++): ?>
                                            <i class="fas fa-star<?= $s <= (int) ($review['stars'] ?? 5) ? '' : ' pz-star--dim' ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <p><?= htmlspecialchars($review['text']) ?></p>
                                </article>
                                <?php endforeach; ?>
                            </div>
                            <a href="<?= htmlspecialchars($brand['google_review_url']) ?>" class="pz-btn pz-btn-google" target="_blank" rel="noopener noreferrer">
                                <i class="fab fa-google" aria-hidden="true"></i>
                                <?= htmlspecialchars($t['review_btn']) ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php
        $faq_items = $t['home_faq'] ?? [];
        $faq_title = $t['faq_title'] ?? 'FAQ';
        require __DIR__ . '/includes/partials/faq-section.php';
        ?>

<?php require __DIR__ . '/includes/footer.php'; ?>