<?php
require_once dirname(__DIR__, 3) . '/includes/cms-contact.php';
/** @var string $slug @var array $item @var array $v @var string $canonical */
$landing_type = $GLOBALS['landing_type'] ?? 'usecase';
$landing_slug = $GLOBALS['landing_slug'] ?? '';
$body_class = 'shs-landing shs-landing--' . $landing_type;
$hub_solutions = $t['solutions']['hub_title'] ?? 'Solutions';
$hub_markets = $t['markets']['hub_title'] ?? 'Countries';
$related_same = pzs_landing_related($item, $lang, 6);
$cross_kind = $landing_type === 'market' ? 'usecases' : 'markets';
$cross_slugs = $item['related_' . $cross_kind] ?? [];
$cross_pool = $cross_kind === 'markets' ? pzs_markets_all() : pzs_usecases_all();
$cross_links = [];
foreach ($cross_slugs as $cs) {
    if (!isset($cross_pool[$cs]) || $cs === $landing_slug) {
        continue;
    }
    $cross_links[] = ['slug' => $cs, 'v' => pzs_landing_lang($cross_pool[$cs], $lang), 'meta' => $cross_pool[$cs]];
}
$demo_url = pzs_demo_url();
$contact_label = cms_contact_texts('pizza', $lang)['nav_discuss'];

require __DIR__ . '/header.php';
?>

<main class="shs-container shs-landing-main">
    <nav class="shs-breadcrumb" aria-label="Breadcrumb">
        <a href="<?= pzs_url('index.php') ?>"><?= htmlspecialchars($t['breadcrumb_home'] ?? 'Home') ?></a>
        <span>→</span>
        <a href="<?= pzs_url($landing_type === 'market' ? 'markets.php' : 'solutions.php') ?>"><?= htmlspecialchars($landing_type === 'market' ? $hub_markets : $hub_solutions) ?></a>
        <span>→</span>
        <span><?= htmlspecialchars($v['h1']) ?></span>
    </nav>

    <section class="shs-landing-hero">
        <?php if ($landing_type === 'market' && !empty($v['flag'])): ?>
        <span class="shs-landing-flag" aria-hidden="true"><?= $v['flag'] ?></span>
        <?php else: ?>
        <div class="shs-landing-icon"><i class="fas fa-<?= htmlspecialchars($item['icon'] ?? 'pizza-slice') ?>" aria-hidden="true"></i></div>
        <?php endif; ?>
        <h1><?= htmlspecialchars($v['h1']) ?></h1>
        <p class="shs-landing-sub"><?= htmlspecialchars($v['subtitle']) ?></p>
        <p class="shs-landing-intro"><?= htmlspecialchars($v['intro']) ?></p>

        <?php if ($landing_type === 'market' && (!empty($v['cities']) || !empty($v['payments']))): ?>
        <div class="shs-landing-meta">
            <?php if (!empty($v['cities'])): ?>
            <div>
                <strong><?= htmlspecialchars($t['landing']['cities_label'] ?? 'Cities') ?></strong>
                <span><?= htmlspecialchars(implode(', ', $v['cities'])) ?></span>
            </div>
            <?php endif; ?>
            <?php if (!empty($v['payments'])): ?>
            <div>
                <strong><?= htmlspecialchars($t['landing']['payments_label'] ?? 'Payments') ?></strong>
                <span><?= htmlspecialchars(implode(', ', $v['payments'])) ?></span>
            </div>
            <?php endif; ?>
            <?php if (!empty($v['currency'])): ?>
            <div>
                <strong><?= htmlspecialchars($t['landing']['currency_label'] ?? 'Currency') ?></strong>
                <span><?= htmlspecialchars($v['currency']) ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="shs-landing-cta-row">
            <a href="<?= htmlspecialchars($demo_url) ?>" class="shs-btn-primary"><i class="fas fa-play-circle" aria-hidden="true"></i> <?= htmlspecialchars($t['landing']['demo_btn'] ?? 'Live demo') ?></a>
            <a href="<?= pzs_demo_url('contact.php') ?>" class="shs-btn-outline"><i class="fas fa-comments" aria-hidden="true"></i> <?= htmlspecialchars($contact_label) ?></a>
        </div>
    </section>

    <section class="shs-landing-section">
        <h2><?= htmlspecialchars($t['landing']['benefits_title'] ?? 'Why Pizza CMS') ?></h2>
        <div class="shs-landing-benefits">
            <?php foreach ($v['benefits'] ?? [] as $b): ?>
            <article class="shs-landing-benefit">
                <h3><?= htmlspecialchars($b['title']) ?></h3>
                <p><?= htmlspecialchars($b['text']) ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="shs-landing-section">
        <h2><?= htmlspecialchars($t['landing']['features_title'] ?? 'Platform features') ?></h2>
        <ul class="shs-landing-features">
            <?php foreach ($v['features'] ?? [] as $f): ?>
            <li><i class="fas fa-check" aria-hidden="true"></i> <?= htmlspecialchars($f) ?></li>
            <?php endforeach; ?>
        </ul>
    </section>

    <?php if (!empty($v['faq'])): ?>
    <section class="shs-landing-section shs-faq-section">
        <h2><?= htmlspecialchars($t['faq']['title'] ?? 'FAQ') ?></h2>
        <div class="shs-faq-list">
            <?php foreach ($v['faq'] as $fq): ?>
            <details class="shs-faq-item">
                <summary><?= htmlspecialchars($fq['q']) ?></summary>
                <p><?= htmlspecialchars($fq['a']) ?></p>
            </details>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($related_same !== []): ?>
    <section class="shs-landing-section shs-landing-related">
        <h2><?= htmlspecialchars($landing_type === 'market' ? ($t['landing']['more_markets'] ?? 'More countries') : ($t['landing']['more_solutions'] ?? 'More solutions')) ?></h2>
        <div class="shs-hub-tags">
            <?php foreach ($related_same as $rel): ?>
            <a href="<?= htmlspecialchars(pzs_landing_url($rel['slug'])) ?>">
                <?php if ($landing_type === 'market' && !empty($rel['meta']['flag'])): ?><?= $rel['meta']['flag'] ?> <?php endif; ?>
                <?= htmlspecialchars($rel['v']['h1']) ?>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($cross_links !== []): ?>
    <section class="shs-landing-section shs-landing-related">
        <h2><?= htmlspecialchars($landing_type === 'market' ? ($t['landing']['related_solutions'] ?? 'Restaurant solutions') : ($t['landing']['related_markets'] ?? 'Pizza CMS by country')) ?></h2>
        <div class="shs-hub-tags">
            <?php foreach ($cross_links as $rel): ?>
            <a href="<?= htmlspecialchars(pzs_landing_url($rel['slug'])) ?>">
                <?php if ($cross_kind === 'markets' && !empty($rel['meta']['flag'])): ?><?= $rel['meta']['flag'] ?> <?php endif; ?>
                <?= htmlspecialchars($rel['v']['h1']) ?>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <section class="shs-landing-cta-band">
        <h2><?= htmlspecialchars($v['cta'] ?? '') ?></h2>
        <a href="<?= pzs_demo_url('contact.php') ?>" class="shs-btn-primary shs-btn-lg"><?= htmlspecialchars($contact_label) ?></a>
    </section>
</main>

<?php require __DIR__ . '/footer.php'; ?>