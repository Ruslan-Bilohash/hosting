<?php
require_once __DIR__ . '/init.php';
header('Content-Type: application/xml; charset=UTF-8');

$base = 'https://bilohash.com/pizza';
$site_langs = ['no', 'uk', 'ru'];
$lastmod = date('Y-m-d', max(
    filemtime(__DIR__ . '/index.php'),
    filemtime(__DIR__ . '/page.php'),
    filemtime(__DIR__ . '/contact.php')
));

$seo_slugs = array_keys(pz_seo_pages());

$urls = [
    ['loc' => $base . '/', 'priority' => '1.0', 'changefreq' => 'weekly', 'hreflang' => true, 'path' => '/pizza/'],
    ['loc' => $base . '/site/', 'priority' => '0.95', 'changefreq' => 'weekly', 'hreflang' => true, 'path' => '/pizza/site/'],
    ['loc' => $base . '/site/solutions', 'priority' => '0.94', 'changefreq' => 'weekly', 'hreflang' => true, 'path' => '/pizza/site/solutions'],
    ['loc' => $base . '/site/markets', 'priority' => '0.94', 'changefreq' => 'weekly', 'hreflang' => true, 'path' => '/pizza/site/markets'],
    ['loc' => $base . '/site/sitemap.php', 'priority' => '0.5', 'changefreq' => 'weekly'],
    ['loc' => $base . '/contact.php', 'priority' => '0.88', 'changefreq' => 'monthly', 'hreflang' => true, 'path' => '/pizza/contact.php'],
    ['loc' => $base . '/llms.txt', 'priority' => '0.5', 'changefreq' => 'monthly'],
];

foreach ($seo_slugs as $slug) {
    $urls[] = [
        'loc' => $base . '/' . $slug,
        'priority' => '0.9',
        'changefreq' => 'weekly',
        'hreflang' => true,
        'path' => '/pizza/' . $slug,
    ];
}

foreach ($site_langs as $lng) {
    $urls[] = ['loc' => $base . '/?lang=' . $lng, 'priority' => '0.85', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => $base . '/site/?lang=' . $lng, 'priority' => '0.85', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => $base . '/contact.php?lang=' . $lng, 'priority' => '0.84', 'changefreq' => 'monthly'];
    foreach ($seo_slugs as $slug) {
        $urls[] = ['loc' => $base . '/' . $slug . '?lang=' . $lng, 'priority' => '0.86', 'changefreq' => 'weekly'];
    }
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
<?php foreach ($urls as $u): ?>
    <url>
        <loc><?= htmlspecialchars($u['loc']) ?></loc>
        <lastmod><?= htmlspecialchars($lastmod) ?></lastmod>
        <changefreq><?= $u['changefreq'] ?? 'monthly' ?></changefreq>
        <priority><?= $u['priority'] ?? '0.5' ?></priority>
        <?php if (!empty($u['hreflang']) && !empty($u['path'])):
            $path = $u['path'];
        ?>
        <xhtml:link rel="alternate" hreflang="x-default" href="https://bilohash.com<?= htmlspecialchars($path) ?>"/>
        <xhtml:link rel="alternate" hreflang="en" href="https://bilohash.com<?= htmlspecialchars($path) ?>"/>
        <xhtml:link rel="alternate" hreflang="no" href="https://bilohash.com<?= htmlspecialchars($path) ?>?lang=no"/>
        <xhtml:link rel="alternate" hreflang="uk" href="https://bilohash.com<?= htmlspecialchars($path) ?>?lang=uk"/>
        <xhtml:link rel="alternate" hreflang="ru" href="https://bilohash.com<?= htmlspecialchars($path) ?>?lang=ru"/>
        <?php endif; ?>
    </url>
<?php endforeach; ?>
</urlset>