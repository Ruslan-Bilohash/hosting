<?php
?>
<section class="pz-section" id="gallery">
    <div class="pz-container">
        <div class="pz-gallery">
            <?php foreach ($brand['gallery_images'] as $i => $shot): ?>
            <div class="pz-gallery-item">
                <img
                    src="<?= htmlspecialchars(pz_asset($shot['file'])) ?>"
                    alt="<?= htmlspecialchars($t['gallery_alt'][$i] ?? $t['gallery_title']) ?>"
                    loading="lazy"
                    decoding="async"
                >
                <?php if (!empty($shot['label'])): ?>
                <span class="pz-gallery-label"><?= htmlspecialchars($brand['name']) ?> · <?= htmlspecialchars($shot['label']) ?></span>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>