<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/init.php';
require_once __DIR__ . '/includes/site-integrations.php';
pz_boot_public_integrations();
require_once dirname(__DIR__) . '/includes/bh-cms-site-settings.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed']);
    exit;
}

$name = trim(strip_tags($_POST['name'] ?? ''));
$phone = trim(strip_tags($_POST['phone'] ?? ''));
$email = trim($_POST['email'] ?? '');
$date = trim($_POST['date'] ?? '');
$time = trim($_POST['time'] ?? '');
$guests = (int) ($_POST['guests'] ?? 0);
$note = trim(strip_tags($_POST['note'] ?? ''));

if ($name === '' || $phone === '' || $date === '' || $guests < 1 || $guests > 20) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => $t['form_error']]);
    exit;
}

if (!bh_cms_verify_recaptcha($_POST['g-recaptcha-response'] ?? '', pz_site_settings())) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => $t['error_captcha'] ?? 'Please complete reCAPTCHA.']);
    exit;
}

$row = [
    'id' => 'pz_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)),
    'name' => $name,
    'phone' => $phone,
    'email' => $email,
    'date' => $date,
    'time' => $time,
    'guests' => $guests,
    'note' => $note,
    'lang' => $lang,
    'created' => date('c'),
    'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
    'status' => 'pending',
    'type' => 'table',
    'amount_nok' => 200,
    'payment' => 'none',
];

if (!pz_save_reservation($row)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => $t['form_error']]);
    exit;
}

echo json_encode(['ok' => true, 'message' => $t['form_success']]);