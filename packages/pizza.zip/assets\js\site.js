(function () {
    'use strict';

    var header = document.querySelector('.pz-header');
    if (header) {
        var syncHeaderHeight = function () {
            document.documentElement.style.setProperty('--pz-header-h', header.offsetHeight + 'px');
        };
        syncHeaderHeight();
        window.addEventListener('resize', syncHeaderHeight, { passive: true });
        if (typeof ResizeObserver !== 'undefined') {
            new ResizeObserver(syncHeaderHeight).observe(header);
        }
    }

    var burger = document.getElementById('pzBurger');
    var panel = document.getElementById('pzMobilePanel');
    var overlay = document.getElementById('pzNavOverlay');

    function setNavOpen(open) {
        if (!burger || !panel || !overlay) return;
        burger.classList.toggle('is-open', open);
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
        panel.hidden = !open;
        overlay.hidden = !open;
        document.body.classList.toggle('pz-nav-open', open);
    }

    function initLangDropdown(dropdown) {
        if (!dropdown) return;
        var btn = dropdown.querySelector('.pz-lang-dropdown-btn');
        var menu = dropdown.querySelector('.pz-lang-dropdown-menu');
        if (!btn || !menu) return;
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            document.querySelectorAll('.pz-lang-dropdown.is-open').forEach(function (other) {
                if (other !== dropdown) {
                    other.classList.remove('is-open');
                    var ob = other.querySelector('.pz-lang-dropdown-btn');
                    var om = other.querySelector('.pz-lang-dropdown-menu');
                    if (ob) ob.setAttribute('aria-expanded', 'false');
                    if (om) om.hidden = true;
                }
            });
            var open = dropdown.classList.toggle('is-open');
            menu.hidden = !open;
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        menu.addEventListener('click', function (e) { e.stopPropagation(); });
    }

    document.querySelectorAll('.pz-lang-dropdown').forEach(initLangDropdown);
    document.addEventListener('click', function () {
        document.querySelectorAll('.pz-lang-dropdown.is-open').forEach(function (dd) {
            dd.classList.remove('is-open');
            var b = dd.querySelector('.pz-lang-dropdown-btn');
            var m = dd.querySelector('.pz-lang-dropdown-menu');
            if (b) b.setAttribute('aria-expanded', 'false');
            if (m) m.hidden = true;
        });
    });

    if (burger && panel && overlay) {
        burger.addEventListener('click', function () {
            setNavOpen(panel.hidden);
        });
        overlay.addEventListener('click', function () {
            setNavOpen(false);
        });
        panel.querySelectorAll('a[href^="#"]').forEach(function (link) {
            link.addEventListener('click', function () {
                setNavOpen(false);
            });
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                if (!panel.hidden) setNavOpen(false);
                document.querySelectorAll('.pz-lang-dropdown.is-open').forEach(function (dd) {
                    dd.classList.remove('is-open');
                    var b = dd.querySelector('.pz-lang-dropdown-btn');
                    var m = dd.querySelector('.pz-lang-dropdown-menu');
                    if (b) b.setAttribute('aria-expanded', 'false');
                    if (m) m.hidden = true;
                });
            }
        });
    }

    var filters = document.querySelectorAll('.pz-filter');
    var cards = document.querySelectorAll('.pz-menu-card');

    function applyMenuFilter(cat) {
        if (!filters.length) return;
        filters.forEach(function (btn) {
            var match = btn.getAttribute('data-filter') === cat;
            btn.classList.toggle('is-active', match);
        });
        cards.forEach(function (card) {
            var show = cat === 'all' || card.getAttribute('data-cat') === cat;
            card.classList.toggle('is-hidden', !show);
        });
    }

    filters.forEach(function (btn) {
        btn.addEventListener('click', function () {
            applyMenuFilter(btn.getAttribute('data-filter') || 'all');
        });
    });

    document.querySelectorAll('[data-menu-filter]').forEach(function (link) {
        link.addEventListener('click', function () {
            var cat = link.getAttribute('data-menu-filter');
            if (cat) applyMenuFilter(cat);
        });
    });

    function handleMenuHash() {
        var hash = window.location.hash;
        if (!hash || hash === '#menu') {
            applyMenuFilter('all');
            return;
        }
        var m = hash.match(/^#menu-(.+)$/);
        if (m) applyMenuFilter(m[1]);
    }

    window.addEventListener('hashchange', handleMenuHash);
    handleMenuHash();

    var form = document.getElementById('pzReserveForm');
    var msg = document.getElementById('pzFormMsg');
    if (form && msg) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            msg.classList.remove('is-show', 'pz-form-msg--ok', 'pz-form-msg--err');
            var fd = new FormData(form);
            fetch(form.getAttribute('action'), { method: 'POST', body: fd })
                .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, data: d }; }); })
                .then(function (res) {
                    msg.textContent = res.data.message || '';
                    msg.classList.add('is-show', res.ok ? 'pz-form-msg--ok' : 'pz-form-msg--err');
                    if (res.ok) form.reset();
                })
                .catch(function () {
                    msg.textContent = form.getAttribute('data-error') || 'Error';
                    msg.classList.add('is-show', 'pz-form-msg--err');
                });
        });
    }

    if (header) {
        window.addEventListener('scroll', function () {
            header.style.boxShadow = window.scrollY > 40
                ? '0 8px 32px rgba(0,0,0,.35)' : 'none';
        }, { passive: true });
    }
})();