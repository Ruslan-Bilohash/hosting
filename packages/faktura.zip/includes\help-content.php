<?php
/**
 * Instructions — all 7 UI languages (EN, UA, LT, PL, DE, SV, NO)
 */
function fk_help_lang(string $lang): string
{
    $map = ['uk' => 'uk', 'ua' => 'uk', 'no' => 'no', 'lt' => 'lt', 'pl' => 'pl', 'de' => 'de', 'sv' => 'sv'];
    return $map[$lang] ?? 'en';
}

function fk_help_content(string $hl): array
{
    $all = [
        'en' => fk_help_pack_en(),
        'uk' => fk_help_pack_uk(),
        'no' => fk_help_pack_no(),
        'lt' => fk_help_pack_lt(),
        'pl' => fk_help_pack_pl(),
        'de' => fk_help_pack_de(),
        'sv' => fk_help_pack_sv(),
    ];
    $h = $all[$hl] ?? $all['en'];
    return fk_help_augment($h, $hl);
}

/**
 * Video guide steps — 7 languages.
 *
 * @return array<int, array<string, string>>
 */
function fk_help_video_steps(string $hl, callable $shot): array
{
    $all = [
        'en' => [
            ['t' => 'Demo invoices on homepage', 'd' => 'Pick a sample from the dropdown — print layout screenshot updates instantly.', 'link_label' => 'Open demos'],
            ['t' => 'Clients in admin', 'd' => 'Add a client once — data fills every new invoice.', 'link_label' => 'Admin → Clients'],
            ['t' => 'Create & print', 'd' => '12 designs, QR, Pay buttons — save and print PDF in the browser.', 'link_label' => 'Create invoice'],
            ['t' => 'Send email + AI', 'd' => 'SMTP from admin, “Generate with AI” for email text — 2 clicks from phone.', 'link_label' => 'Admin → Send email'],
        ],
        'uk' => [
            ['t' => 'Демо-фактури на головній', 'd' => 'Оберіть приклад у випадаючому списку — зʼявиться скриншот макету друку.', 'link_label' => 'Відкрити демо'],
            ['t' => 'Клієнти в адмінці', 'd' => 'Додайте клієнта один раз — дані підставляються в кожну фактуру.', 'link_label' => 'Адмін → Клієнти'],
            ['t' => 'Створення та друк', 'd' => '12 дизайнів, QR, кнопки Pay — збережіть і надрукуйте PDF у браузері.', 'link_label' => 'Створити рахунок'],
            ['t' => 'Відправка email + AI', 'd' => 'SMTP з адмінки, «Згенерувати AI» для тексту листа — 2 кліки з телефону.', 'link_label' => 'Адмін → Надіслати email'],
        ],
        'no' => [
            ['t' => 'Demofakturaer på forsiden', 'd' => 'Velg et eksempel i nedtrekkslisten — skjermbilde av utskriftslayout oppdateres.', 'link_label' => 'Åpne demoer'],
            ['t' => 'Kunder i admin', 'd' => 'Legg til kunde én gang — data fylles i hver ny faktura.', 'link_label' => 'Admin → Kunder'],
            ['t' => 'Opprett og skriv ut', 'd' => '12 design, QR, Pay-knapper — lagre og skriv ut PDF i nettleseren.', 'link_label' => 'Opprett faktura'],
            ['t' => 'Send e-post + AI', 'd' => 'SMTP fra admin, «Generer med AI» for e-posttekst — 2 klikk fra mobilen.', 'link_label' => 'Admin → Send e-post'],
        ],
        'lt' => [
            ['t' => 'Demo sąskaitos pagrindiniame', 'd' => 'Pasirinkite pavyzdį — atsinaujina spausdinimo maketo ekrano nuotrauka.', 'link_label' => 'Atidaryti demo'],
            ['t' => 'Klientai admin', 'd' => 'Pridėkite klientą vieną kartą — duomenys užpildo kiekvieną sąskaitą.', 'link_label' => 'Admin → Klientai'],
            ['t' => 'Kurti ir spausdinti', 'd' => '12 dizainų, QR, Pay mygtukai — išsaugokite ir spausdinkite PDF naršyklėje.', 'link_label' => 'Sukurti sąskaitą'],
            ['t' => 'Siųsti el. paštą + DI', 'd' => 'SMTP iš admin, „Generuoti DI“ laiško tekstui — 2 paspaudimai iš telefono.', 'link_label' => 'Admin → Siųsti el. paštą'],
        ],
        'pl' => [
            ['t' => 'Faktury demo na stronie głównej', 'd' => 'Wybierz przykład z listy — aktualizuje się podgląd układu wydruku.', 'link_label' => 'Otwórz demo'],
            ['t' => 'Klienci w panelu', 'd' => 'Dodaj klienta raz — dane wypełniają każdą nową fakturę.', 'link_label' => 'Admin → Klienci'],
            ['t' => 'Utwórz i drukuj', 'd' => '12 projektów, QR, przyciski Pay — zapisz i drukuj PDF w przeglądarce.', 'link_label' => 'Utwórz fakturę'],
            ['t' => 'Wyślij e-mail + AI', 'd' => 'SMTP z panelu, „Generuj AI” do treści listu — 2 kliknięcia z telefonu.', 'link_label' => 'Admin → Wyślij e-mail'],
        ],
        'de' => [
            ['t' => 'Demo-Rechnungen auf der Startseite', 'd' => 'Beispiel aus der Liste wählen — Drucklayout-Vorschau aktualisiert sich.', 'link_label' => 'Demos öffnen'],
            ['t' => 'Kunden im Admin', 'd' => 'Kunde einmal anlegen — Daten füllen jede neue Rechnung.', 'link_label' => 'Admin → Kunden'],
            ['t' => 'Erstellen & drucken', 'd' => '12 Designs, QR, Pay-Buttons — PDF im Browser speichern und drucken.', 'link_label' => 'Rechnung erstellen'],
            ['t' => 'E-Mail senden + KI', 'd' => 'SMTP aus dem Admin, „Mit KI generieren“ für E-Mail-Text — 2 Klicks vom Handy.', 'link_label' => 'Admin → E-Mail senden'],
        ],
        'sv' => [
            ['t' => 'Demofakturor på startsidan', 'd' => 'Välj ett exempel i listan — förhandsvisning av utskriftslayout uppdateras.', 'link_label' => 'Öppna demo'],
            ['t' => 'Kunder i admin', 'd' => 'Lägg till kund en gång — data fyller varje ny faktura.', 'link_label' => 'Admin → Kunder'],
            ['t' => 'Skapa och skriv ut', 'd' => '12 designer, QR, Pay-knappar — spara och skriv ut PDF i webbläsaren.', 'link_label' => 'Skapa faktura'],
            ['t' => 'Skicka e-post + AI', 'd' => 'SMTP från admin, „Generera med AI” för e-posttext — 2 klick från mobilen.', 'link_label' => 'Admin → Skicka e-post'],
        ],
    ];
    $steps = $all[$hl] ?? $all['en'];
    $imgs = ['demo-no-cleaning.svg', 'demo-uk-consulting.svg', 'demo-lt-cleaning.svg', 'demo-ua-webdev.svg'];
    $links = [fk_url('index.php#demo-invoices'), fk_admin_url('clients.php'), fk_url('create.php'), fk_admin_url('send-mail.php')];
    $out = [];
    foreach ($steps as $i => $step) {
        $out[] = [
            'n' => (string) ($i + 1),
            't' => $step['t'],
            'd' => $step['d'],
            'img' => $shot($imgs[$i]),
            'link' => $links[$i],
            'link_label' => $step['link_label'],
        ];
    }
    return $out;
}

function fk_help_augment(array $h, string $hl): array
{
    $isUk = $hl === 'uk';
    $menuTitles = ['en' => 'Contents', 'uk' => 'Зміст', 'no' => 'Innhold', 'lt' => 'Turinys', 'pl' => 'Spis treści', 'de' => 'Inhalt', 'sv' => 'Innehåll'];
    $stepsLabels = ['en' => 'Step-by-step', 'uk' => 'Покроково', 'no' => 'Trinn for trinn', 'lt' => 'Žingsnis po žingsnio', 'pl' => 'Krok po kroku', 'de' => 'Schritt für Schritt', 'sv' => 'Steg för steg'];
    $h['menu_title'] = $menuTitles[$hl] ?? 'Contents';
    $h['menu'] = [
        ['href' => '#video', 'icon' => 'fa-play-circle', 'label' => $h['video_title'] ?? ($isUk ? 'Відео-інструкція' : 'Video guide')],
        ['href' => '#countries', 'icon' => 'fa-globe-europe', 'label' => $h['countries_title'] ?? ($isUk ? '7 країн' : '7 countries')],
        ['href' => '#steps', 'icon' => 'fa-list-ol', 'label' => $stepsLabels[$hl] ?? 'Step-by-step'],
        ['href' => '#features', 'icon' => 'fa-user-shield', 'label' => $h['admin_features_title'] ?? ($isUk ? 'Можливості адмінки' : 'Admin features')],
        ['href' => '#clients', 'icon' => 'fa-users', 'label' => $h['clients_title'] ?? 'Clients'],
        ['href' => '#ai', 'icon' => 'fa-wand-magic-sparkles', 'label' => $h['ai_title'] ?? 'AI'],
        ['href' => '#qr', 'icon' => 'fa-qrcode', 'label' => $h['qr_title'] ?? 'QR'],
        ['href' => '#email', 'icon' => 'fa-envelope', 'label' => $h['email_title'] ?? 'Email'],
        ['href' => '#devices', 'icon' => 'fa-mobile-alt', 'label' => $h['devices_title'] ?? 'Responsive'],
        ['href' => '#smtp', 'icon' => 'fa-server', 'label' => $h['smtp_title'] ?? 'SMTP'],
        ['href' => '#subscription', 'icon' => 'fa-handshake', 'label' => $h['sub_title'] ?? 'Subscription'],
    ];
    $shot = static fn(string $file) => fk_asset('images/demo/' . $file);
    $h['video_steps'] = fk_help_video_steps($hl, $shot);
    $demoShots = fk_demo_shots_map();
    $countryFlags = ['en' => '🇬🇧', 'no' => '🇳🇴', 'lt' => '🇱🇹', 'pl' => '🇵🇱', 'de' => '🇩🇪', 'sv' => '🇸🇪', 'uk' => '🇺🇦'];
    $h['country_demos'] = [];
    foreach (fk_demo_invoices_seed() as $demo) {
        $cid = $demo['country_id'] ?? '';
        $id = $demo['id'] ?? '';
        $shotFile = $demoShots[$id] ?? '';
        $h['country_demos'][] = [
            'flag' => $countryFlags[$cid] ?? '🌐',
            'label' => fk_demo_invoice_label($demo, $hl),
            'no' => $demo['invoice_no'] ?? '',
            'currency' => $demo['currency'] ?? '',
            'rate' => (float) ($demo['totals']['tax_rate'] ?? 0),
            'img' => $shotFile !== '' ? fk_asset('images/demo/' . $shotFile) : '',
            'link' => fk_url('invoice.php?id=' . urlencode($id)),
        ];
    }
    $h['admin_features'] = [
        ['icon' => 'fa-users', 't' => $h['clients_title'] ?? 'Clients', 'd' => $h['clients_text'] ?? '', 'link' => fk_admin_url('clients.php'), 'link_label' => $isUk ? 'Клієнти' : 'Clients'],
        ['icon' => 'fa-file-invoice', 't' => $isUk ? 'Збережені рахунки' : 'Saved invoices', 'd' => $isUk ? 'Демо на головній, перегляд, видалення, посилання на друк.' : 'Homepage demos, view, delete, print links.', 'link' => fk_admin_url('invoices.php'), 'link_label' => $isUk ? 'Рахунки' : 'Invoices'],
        ['icon' => 'fa-wand-magic-sparkles', 't' => $h['ai_title'] ?? 'AI', 'd' => $h['ai_text'] ?? '', 'link' => fk_admin_url('ai.php'), 'link_label' => 'AI'],
        ['icon' => 'fa-qrcode', 't' => $h['qr_title'] ?? 'QR', 'd' => $h['qr_text'] ?? '', 'link' => fk_admin_url('settings.php'), 'link_label' => $isUk ? 'QR налаштування' : 'QR settings'],
        ['icon' => 'fa-envelope', 't' => $h['email_title'] ?? 'Email', 'd' => $h['email_text'] ?? '', 'link' => fk_admin_url('send-mail.php'), 'link_label' => $isUk ? 'Надіслати' : 'Send'],
        ['icon' => 'fa-server', 't' => $h['smtp_title'] ?? 'SMTP', 'd' => $h['smtp_text'] ?? '', 'link' => fk_admin_url('smtp.php'), 'link_label' => 'SMTP'],
    ];
    return $h;
}

function fk_help_pack_en(): array
{
    return [
        'title' => 'How to use Faktura Creator',
        'intro' => 'Send invoices from your phone in 2 clicks. Manage clients, calculate VAT, add QR codes, generate email text with AI, print in 12 designs and email via SMTP from admin.',
        'steps' => [
            ['t' => 'Homepage & demo invoices', 'd' => 'Overview on the homepage. Demo fakturas: Admin → Saved invoices → toggle “Show on homepage”.'],
            ['t' => 'Clients (admin)', 'd' => 'Admin → Clients: add name, email, address. On Create invoice pick a client — buyer fields fill automatically.'],
            ['t' => 'Create invoice', 'd' => 'Choose country (VAT/MVA), template or empty. Fill seller/buyer, line items, notes. Pick print design (1 of 12) and format (A4, A5, Letter, Legal).'],
            ['t' => 'QR code', 'd' => 'Admin → Settings → QR: enable, choose invoice link, payment URL template ({amount}, {invoice_no}) or custom URL. Optional per-invoice payment link on create page.'],
            ['t' => 'AI text', 'd' => 'Admin → AI: API key + prompts. “AI notes” on create page; “Generate with AI” when sending email. Without key — templates in your UI language.'],
            ['t' => 'Save, print & share', 'd' => 'Save invoice → JSON storage. Open link, print PDF in browser. QR encodes view or payment URL.'],
            ['t' => 'Email from admin', 'd' => 'Admin → Clients → Send, or Send email: pick client + saved invoice, add AI note, send via SMTP (or demo log).'],
            ['t' => 'SMTP & subscription', 'd' => 'Admin → SMTP: host, TLS, sender. Subscription text on this Help page (editable in admin).'],
        ],
        'devices_title' => 'Responsive layout',
        'devices_intro' => 'Phone, tablet and desktop.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Phone', 'd' => 'Client picker, scrollable lines, mobile menu — 2-click workflow.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Tablet', 'd' => 'Two-column seller/buyer, comfortable forms.'],
            ['icon' => 'fa-desktop', 't' => 'Desktop', 'd' => 'Form left, live preview + QR right (sticky).'],
        ],
        'clients_title' => 'Client database',
        'clients_text' => 'Store customers in admin. Reuse on every invoice. Send saved invoices to client email in two clicks from your phone.',
        'ai_title' => 'AI assistant',
        'ai_text' => 'OpenAI (gpt-4o-mini, gpt-4o) or xAI Grok (grok-3-mini, grok-3) — pick provider and model in Admin → AI. OpenAI-compatible base URL supported. Prompts for email note, subject and payment terms. Placeholders: {client_name}, {invoice_no}, {total}, {currency}, {due_date}, {iban}, {lang}. Without API key — templates in all 7 UI languages.',
        'countries_title' => 'Frontend for 7 countries',
        'countries_intro' => 'Each country has VAT/MVA rules, currency, company defaults and a homepage demo invoice. Pick country on Create invoice — tax and seller data fill automatically.',
        'qr_title' => 'QR on invoices',
        'qr_text' => 'Modes: (1) Invoice view link after save. (2) Payment URL — global template e.g. Vipps/Stripe with {amount}, {invoice_no}, {reference}, or per-invoice URL field. (3) Custom fixed URL. Toggle print and URL label under QR in Settings.',
        'smtp_title' => 'SMTP (admin)',
        'smtp_text' => 'Admin → SMTP: enable, host, port, TLS, username, from address. Demo: emails logged to email-log.json until SMTP is enabled.',
        'email_title' => 'Send invoice email',
        'email_text' => 'HTML email with invoice number, total, due date, personal note (AI optional) and button to view & print. Language follows UI lang switcher.',
        'sub_title' => 'Subscription',
        'sub_text' => 'BILOHASH ecosystem: 49 NOK/month (1 CMS · 1 domain) or 249 NOK/month (all CMS). Editable in admin.',
        'video_title' => 'Video guide (screenshots)',
        'video_intro' => 'Follow these 4 steps with live screenshots — same workflow as a short video tutorial. Works on phone, tablet and desktop.',
        'admin_features_title' => 'Admin panel features',
    ];
}

function fk_help_pack_uk(): array
{
    return [
        'title' => 'Як користуватися Faktura Creator',
        'intro' => 'Надсилайте фактури з телефону за 2 кліки. Клієнти, ПДВ, QR-коди, AI для листів, 12 макетів друку та SMTP з адмінки.',
        'steps' => [
            ['t' => 'Головна та демо', 'd' => 'Опис на головній. Демо: Адмін → Збережені рахунки → «Показати на головній».'],
            ['t' => 'Клієнти (адмін)', 'd' => 'Адмін → Клієнти: ім\'я, email, адреса. На сторінці створення — оберіть клієнта, поля покупця заповняться.'],
            ['t' => 'Створити рахунок', 'd' => 'Країна (ПДВ), шаблон, позиції, нотатки. Дизайн друку (1 з 12) і формат A4/A5/Letter/Legal.'],
            ['t' => 'QR-код', 'd' => 'Адмін → Налаштування → QR: увімкнути, посилання на рахунок, шаблон оплати ({amount}, {invoice_no}) або своє URL. Опційно — посилання на оплату в формі.'],
            ['t' => 'AI текст', 'd' => 'Адмін → AI: API-ключ і промпти. «AI нотатки» при створенні; «Згенерувати AI» при відправці email. Без ключа — шаблони вашою мовою.'],
            ['t' => 'Зберегти, друк, посилання', 'd' => 'Зберегти → JSON. Відкрити посилання, друк PDF. QR веде на перегляд або оплату.'],
            ['t' => 'Email з адмінки', 'd' => 'Адмін → Надіслати email: клієнт + рахунок, нотатка (AI), SMTP або демо-лог.'],
            ['t' => 'SMTP і підписка', 'd' => 'Адмін → SMTP: хост, TLS, відправник. Текст підписки на цій сторінці.'],
        ],
        'devices_title' => 'Адаптивність',
        'devices_intro' => 'Телефон, планшет, ПК.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Телефон', 'd' => 'Вибір клієнта, прокрутка таблиці — 2 кліки.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Планшет', 'd' => 'Два блоки продавець/покупець.'],
            ['icon' => 'fa-desktop', 't' => 'ПК', 'd' => 'Форма зліва, preview і QR справа.'],
        ],
        'clients_title' => 'База клієнтів',
        'clients_text' => 'Зберігайте клієнтів в адмінці. Повторне використання на кожній фактурі. Відправка email у 2 кліки.',
        'ai_title' => 'AI-асистент',
        'ai_text' => 'OpenAI (gpt-4o-mini) або xAI Grok (grok-3-mini, grok-3) — оберіть провайдера й модель в Адмін → AI. Промпти для листа та умов оплати. Без API-ключа — шаблони 7 мовами.',
        'countries_title' => 'Фронтенд для 7 країн',
        'countries_intro' => 'Кожна країна має правила ПДВ/MVA, валюту, дані компанії та демо-фактуру на головній. Оберіть країну при створенні рахунку — податок і продавець підставляться автоматично.',
        'qr_title' => 'QR на фактурі',
        'qr_text' => 'Режими: посилання на рахунок; шаблон оплати (Vipps/Stripe) з {amount}, {invoice_no}; своє URL. Налаштування друку та підпису URL в Settings.',
        'smtp_title' => 'SMTP (адмін)',
        'smtp_text' => 'Адмін → SMTP: увімкнути, хост, TLS, логін. Демо: лог у email-log.json.',
        'email_title' => 'Відправка рахунку email',
        'email_text' => 'HTML-лист: номер, сума, термін, нотатка (AI) і кнопка перегляду. Мова — за перемикачем UI.',
        'sub_title' => 'Підписка',
        'sub_text' => 'BILOHASH: 49 NOK/міс (1 CMS · 1 домен) або 249 NOK/міс (усі CMS). Редагується в адмінці.',
        'video_title' => 'Відео-інструкція (скриншоти)',
        'video_intro' => '4 кроки зі скриншотами реальних макетів — як коротке відео. Працює на телефоні, планшеті та ПК.',
        'admin_features_title' => 'Можливості адмін-панелі',
    ];
}

function fk_help_pack_no(): array
{
    return [
        'title' => 'Slik bruker du Faktura Creator',
        'intro' => 'Send fakturaer fra mobilen på 2 klikk. Kunder, MVA, QR-koder, AI-tekst, 12 utskriftsdesign og SMTP fra admin.',
        'steps' => [
            ['t' => 'Forside og demo', 'd' => 'Oversikt på forsiden. Demo: Admin → Lagrede fakturaer → «Vis på forsiden».'],
            ['t' => 'Kunder (admin)', 'd' => 'Admin → Kunder: navn, e-post, adresse. På Opprett faktura — velg kunde, kjøper fylles ut.'],
            ['t' => 'Opprett faktura', 'd' => 'Land (MVA), mal, linjer, notater. Utskriftsdesign (1 av 12) og format A4/A5/Letter/Legal.'],
            ['t' => 'QR-kode', 'd' => 'Admin → Innstillinger → QR: aktiver, fakturalenke, betalingsmal ({amount}, {invoice_no}) eller egen URL.'],
            ['t' => 'AI-tekst', 'd' => 'Admin → AI: API-nøkkel og prompts. «AI-notater» ved opprettelse; «Generer med AI» ved e-post. Uten nøkkel — maler på ditt språk.'],
            ['t' => 'Lagre, skriv ut, del', 'd' => 'Lagre → JSON. Åpne lenke, skriv ut PDF. QR peker til visning eller betaling.'],
            ['t' => 'E-post fra admin', 'd' => 'Admin → Send e-post: kunde + faktura, notat (AI), SMTP eller demo-logg.'],
            ['t' => 'SMTP og abonnement', 'd' => 'Admin → SMTP: vert, TLS, avsender. Abonnementstekst redigeres i admin.'],
        ],
        'devices_title' => 'Responsivt design',
        'devices_intro' => 'Mobil, nettbrett og PC.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Mobil', 'd' => 'Kundevelger, rullbar tabell — 2 klikk.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Nettbrett', 'd' => 'To kolonner selger/kjøper.'],
            ['icon' => 'fa-desktop', 't' => 'PC', 'd' => 'Skjema venstre, forhåndsvisning og QR høyre.'],
        ],
        'clients_title' => 'Kundedatabase',
        'clients_text' => 'Lagre kunder i admin. Gjenbruk på hver faktura. Send lagrede fakturaer på 2 klikk.',
        'ai_title' => 'AI-assistent',
        'ai_text' => 'OpenAI (gpt-4o-mini) eller xAI Grok (grok-3-mini, grok-3) — velg leverandør og modell i Admin → AI. Prompts for e-postnotat, emne og betalingsvilkår. Uten API-nøkkel — maler på 7 språk.',
        'countries_title' => 'Frontend for 7 land',
        'countries_intro' => 'Hvert land har MVA-regler, valuta, firmadata og demofaktura på forsiden. Velg land ved opprettelse — skatt og selger fylles automatisk.',
        'video_title' => 'Videoguide (skjermbilder)',
        'video_intro' => 'Følg disse 4 trinnene med skjermbilder — samme arbeidsflyt som en kort video. Fungerer på mobil, nettbrett og PC.',
        'admin_features_title' => 'Adminpanel-funksjoner',
        'qr_title' => 'QR på faktura',
        'qr_text' => 'Modus: fakturalenke; betalingsmal (Vipps e.l.) med {amount}, {invoice_no}; eller fast URL. Utskrift og URL-tekst i Innstillinger.',
        'smtp_title' => 'SMTP (admin)',
        'smtp_text' => 'Admin → SMTP: aktiver, vert, TLS, bruker. Demo: logg i email-log.json.',
        'email_title' => 'Send faktura på e-post',
        'email_text' => 'HTML-e-post med nummer, beløp, forfall, notat (AI) og knapp for visning. Språk følger UI.',
        'sub_title' => 'Abonnement',
        'sub_text' => 'BILOHASH: 49 kr/mnd (1 CMS · 1 domene) eller 249 kr/mnd (alle CMS).',
    ];
}

function fk_help_pack_lt(): array
{
    return [
        'title' => 'Kaip naudoti Faktura Creator',
        'intro' => 'Siųskite sąskaitas iš telefono 2 paspaudimais. Klientai, PVM, QR kodai, AI tekstas, 12 spausdinimo dizainų ir SMTP.',
        'steps' => [
            ['t' => 'Pradžia ir demo', 'd' => 'Apžvalga pagrindiniame puslapyje. Demo: Admin → Išsaugotos sąskaitos → «Rodyti pagrindiniame».'],
            ['t' => 'Klientai (admin)', 'd' => 'Admin → Klientai: vardas, el. paštas, adresas. Kuriant sąskaitą pasirinkite klientą — pirkėjo laukai užsipildo.'],
            ['t' => 'Sukurti sąskaitą', 'd' => 'Šalis (PVM), šablonas, eilutės, pastabos. Spausdinimo dizainas (1 iš 12) ir formatas A4/A5/Letter/Legal.'],
            ['t' => 'QR kodas', 'd' => 'Admin → Nustatymai → QR: įjungti, sąskaitos nuoroda, mokėjimo šablonas ({amount}, {invoice_no}) arba savo URL.'],
            ['t' => 'AI tekstas', 'd' => 'Admin → AI: API raktas ir promptai. «AI pastabos» kuriant; «Generuoti AI» siunčiant el. laišką. Be rakto — šablonai jūsų kalba.'],
            ['t' => 'Išsaugoti, spausdinti', 'd' => 'Išsaugoti → JSON. Atidaryti nuorodą, spausdinti PDF. QR – peržiūrai ar mokėjimui.'],
            ['t' => 'El. paštas iš admin', 'd' => 'Admin → Siųsti el. laišką: klientas + sąskaita, pastaba (AI), SMTP arba demo žurnalas.'],
            ['t' => 'SMTP ir prenumerata', 'd' => 'Admin → SMTP: serveris, TLS, siuntėjas. Prenumeratos tekstas redaguojamas admin.'],
        ],
        'devices_title' => 'Adaptyvus dizainas',
        'devices_intro' => 'Telefonas, planšetė, kompiuteris.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Telefonas', 'd' => 'Kliento pasirinkimas, slenkama lentelė — 2 paspaudimai.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Planšetė', 'd' => 'Du stulpeliai pardavėjas/pirkėjas.'],
            ['icon' => 'fa-desktop', 't' => 'Kompiuteris', 'd' => 'Forma kairėje, peržiūra ir QR dešinėje.'],
        ],
        'clients_title' => 'Klientų bazė',
        'clients_text' => 'Saugokite klientus admin. Naudokite kiekvienoje sąskaitoje. Siųskite el. paštu 2 paspaudimais.',
        'ai_title' => 'AI asistentas',
        'ai_text' => 'OpenAI (gpt-4o-mini) arba xAI Grok (grok-3-mini, grok-3) — pasirinkite tiekėją ir modelį Admin → DI. Promptai el. laiško pastabai, temai ir mokėjimo sąlygoms. Be API rakto — šablonai 7 kalbomis.',
        'countries_title' => 'Frontend 7 šalims',
        'countries_intro' => 'Kiekviena šalis turi PVM taisykles, valiutą, įmonės duomenis ir demo sąskaitą pagrindiniame puslapyje. Pasirinkite šalį kuriant — mokesčiai ir pardavėjas užsipildo automatiškai.',
        'video_title' => 'Vaizdo gidas (ekrano nuotraukos)',
        'video_intro' => '4 žingsniai su ekrano nuotraukomis — kaip trumpas vaizdo įrašas. Veikia telefone, planšetėje ir kompiuteryje.',
        'admin_features_title' => 'Admin skydelio funkcijos',
        'qr_title' => 'QR sąskaitoje',
        'qr_text' => 'Režimai: sąskaitos nuoroda; mokėjimo šablonas su {amount}, {invoice_no}; arba fiksuotas URL. Spausdinimas ir URL tekstas Nustatymuose.',
        'smtp_title' => 'SMTP (admin)',
        'smtp_text' => 'Admin → SMTP: įjungti, serveris, TLS, prisijungimas. Demo: įrašai email-log.json.',
        'email_title' => 'Siųsti sąskaitą el. paštu',
        'email_text' => 'HTML laiškas: numeris, suma, terminas, pastaba (AI) ir mygtukas peržiūrai. Kalba pagal UI.',
        'sub_title' => 'Prenumerata',
        'sub_text' => 'BILOHASH: 49 NOK/mėn. (1 CMS · 1 domenas) arba 249 NOK/mėn. (visi CMS).',
    ];
}

function fk_help_pack_pl(): array
{
    return [
        'title' => 'Jak używać Faktura Creator',
        'intro' => 'Wysyłaj faktury z telefonu w 2 kliknięcia. Klienci, VAT, kody QR, tekst AI, 12 wzorów druku i SMTP z panelu admin.',
        'steps' => [
            ['t' => 'Strona główna i demo', 'd' => 'Opis na stronie głównej. Demo: Admin → Zapisane faktury → «Pokaż na stronie głównej».'],
            ['t' => 'Klienci (admin)', 'd' => 'Admin → Klienci: nazwa, e-mail, adres. Przy tworzeniu faktury wybierz klienta — pola nabywcy się wypełnią.'],
            ['t' => 'Utwórz fakturę', 'd' => 'Kraj (VAT), szablon, pozycje, uwagi. Wzór druku (1 z 12) i format A4/A5/Letter/Legal.'],
            ['t' => 'Kod QR', 'd' => 'Admin → Ustawienia → QR: włącz, link do faktury, szablon płatności ({amount}, {invoice_no}) lub własny URL.'],
            ['t' => 'Tekst AI', 'd' => 'Admin → AI: klucz API i prompty. «Uwagi AI» przy tworzeniu; «Generuj AI» przy wysyłce e-mail. Bez klucza — szablony w Twoim języku.'],
            ['t' => 'Zapisz, drukuj, udostępnij', 'd' => 'Zapisz → JSON. Otwórz link, drukuj PDF. QR prowadzi do podglądu lub płatności.'],
            ['t' => 'E-mail z admin', 'd' => 'Admin → Wyślij e-mail: klient + faktura, notatka (AI), SMTP lub log demo.'],
            ['t' => 'SMTP i subskrypcja', 'd' => 'Admin → SMTP: host, TLS, nadawca. Tekst subskrypcji edytowalny w admin.'],
        ],
        'devices_title' => 'Układ responsywny',
        'devices_intro' => 'Telefon, tablet i komputer.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Telefon', 'd' => 'Wybór klienta, przewijana tabela — 2 kliknięcia.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Tablet', 'd' => 'Dwie kolumny sprzedawca/nabywca.'],
            ['icon' => 'fa-desktop', 't' => 'Komputer', 'd' => 'Formularz po lewej, podgląd i QR po prawej.'],
        ],
        'clients_title' => 'Baza klientów',
        'clients_text' => 'Przechowuj klientów w admin. Używaj na każdej fakturze. Wysyłaj e-mailem w 2 kliknięcia.',
        'ai_title' => 'Asystent AI',
        'ai_text' => 'OpenAI (gpt-4o-mini) lub xAI Grok (grok-3-mini, grok-3) — wybierz dostawcę i model w Admin → AI. Prompty: notatka e-mail, temat, warunki płatności. Bez klucza API — szablony w 7 językach.',
        'countries_title' => 'Frontend dla 7 krajów',
        'countries_intro' => 'Każdy kraj ma zasady VAT, walutę, dane firmy i demo fakturę na stronie głównej. Wybierz kraj przy tworzeniu — podatek i sprzedawca wypełnią się automatycznie.',
        'video_title' => 'Przewodnik wideo (zrzuty ekranu)',
        'video_intro' => '4 kroki ze zrzutami ekranu — jak krótki film. Działa na telefonie, tablecie i komputerze.',
        'admin_features_title' => 'Funkcje panelu admin',
        'qr_title' => 'QR na fakturze',
        'qr_text' => 'Tryby: link do faktury; szablon płatności z {amount}, {invoice_no}; lub stały URL. Druk i tekst URL w Ustawieniach.',
        'smtp_title' => 'SMTP (admin)',
        'smtp_text' => 'Admin → SMTP: włącz, host, TLS, login. Demo: log w email-log.json.',
        'email_title' => 'Wyślij fakturę e-mailem',
        'email_text' => 'HTML: numer, kwota, termin, notatka (AI) i przycisk podglądu. Język zgodny z UI.',
        'sub_title' => 'Subskrypcja',
        'sub_text' => 'BILOHASH: 49 NOK/mies. (1 CMS · 1 domena) lub 249 NOK/mies. (wszystkie CMS).',
    ];
}

function fk_help_pack_de(): array
{
    return [
        'title' => 'Faktura Creator — Anleitung',
        'intro' => 'Rechnungen vom Handy in 2 Klicks senden. Kunden, USt, QR-Codes, KI-Text, 12 Drucklayouts und SMTP im Admin.',
        'steps' => [
            ['t' => 'Startseite & Demo', 'd' => 'Übersicht auf der Startseite. Demo: Admin → Gespeicherte Rechnungen → «Auf Startseite anzeigen».'],
            ['t' => 'Kunden (Admin)', 'd' => 'Admin → Kunden: Name, E-Mail, Adresse. Beim Erstellen Kunde wählen — Käuferfelder werden ausgefüllt.'],
            ['t' => 'Rechnung erstellen', 'd' => 'Land (USt), Vorlage, Positionen, Notizen. Druckdesign (1 von 12) und Format A4/A5/Letter/Legal.'],
            ['t' => 'QR-Code', 'd' => 'Admin → Einstellungen → QR: aktivieren, Rechnungslink, Zahlungs-URL-Vorlage ({amount}, {invoice_no}) oder eigene URL.'],
            ['t' => 'KI-Text', 'd' => 'Admin → KI: API-Schlüssel und Prompts. «KI-Notizen» beim Erstellen; «Mit KI generieren» beim E-Mail-Versand. Ohne Schlüssel — Vorlagen in Ihrer Sprache.'],
            ['t' => 'Speichern, drucken, teilen', 'd' => 'Speichern → JSON. Link öffnen, PDF drucken. QR für Ansicht oder Zahlung.'],
            ['t' => 'E-Mail aus Admin', 'd' => 'Admin → E-Mail senden: Kunde + Rechnung, Notiz (KI), SMTP oder Demo-Log.'],
            ['t' => 'SMTP & Abo', 'd' => 'Admin → SMTP: Host, TLS, Absender. Abo-Text in Admin bearbeitbar.'],
        ],
        'devices_title' => 'Responsives Layout',
        'devices_intro' => 'Handy, Tablet und Desktop.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Handy', 'd' => 'Kundenauswahl, scrollbare Tabelle — 2 Klicks.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Tablet', 'd' => 'Zwei Spalten Verkäufer/Käufer.'],
            ['icon' => 'fa-desktop', 't' => 'Desktop', 'd' => 'Formular links, Vorschau und QR rechts.'],
        ],
        'clients_title' => 'Kundendatenbank',
        'clients_text' => 'Kunden im Admin speichern. Bei jeder Rechnung wiederverwenden. Versand per E-Mail in 2 Klicks.',
        'ai_title' => 'KI-Assistent',
        'ai_text' => 'OpenAI (gpt-4o-mini) oder xAI Grok (grok-3-mini, grok-3) — Anbieter und Modell in Admin → KI wählen. Prompts für E-Mail-Notiz, Betreff und Zahlungsbedingungen. Ohne API-Schlüssel — Vorlagen in 7 Sprachen.',
        'countries_title' => 'Frontend für 7 Länder',
        'countries_intro' => 'Jedes Land hat USt-Regeln, Währung, Firmendaten und Demo-Rechnung auf der Startseite. Land beim Erstellen wählen — Steuer und Verkäufer werden automatisch ausgefüllt.',
        'video_title' => 'Video-Anleitung (Screenshots)',
        'video_intro' => '4 Schritte mit Screenshots — wie ein kurzes Video. Funktioniert auf Handy, Tablet und Desktop.',
        'admin_features_title' => 'Admin-Panel-Funktionen',
        'qr_title' => 'QR auf Rechnung',
        'qr_text' => 'Modi: Rechnungslink; Zahlungs-URL-Vorlage mit {amount}, {invoice_no}; oder feste URL. Druck und URL-Text in Einstellungen.',
        'smtp_title' => 'SMTP (Admin)',
        'smtp_text' => 'Admin → SMTP: aktivieren, Host, TLS, Benutzer. Demo: Log in email-log.json.',
        'email_title' => 'Rechnung per E-Mail',
        'email_text' => 'HTML mit Nummer, Betrag, Fälligkeit, Notiz (KI) und Schaltfläche zur Ansicht. Sprache folgt der UI.',
        'sub_title' => 'Abonnement',
        'sub_text' => 'BILOHASH: 49 NOK/Monat (1 CMS · 1 Domain) oder 249 NOK/Monat (alle CMS).',
    ];
}

function fk_help_pack_sv(): array
{
    return [
        'title' => 'Så använder du Faktura Creator',
        'intro' => 'Skicka fakturor från mobilen på 2 klick. Kunder, moms, QR-koder, AI-text, 12 utskriftsdesign och SMTP från admin.',
        'steps' => [
            ['t' => 'Startsida och demo', 'd' => 'Översikt på startsidan. Demo: Admin → Sparade fakturor → «Visa på startsidan».'],
            ['t' => 'Kunder (admin)', 'd' => 'Admin → Kunder: namn, e-post, adress. Vid Skapa faktura — välj kund, köpare fylls i.'],
            ['t' => 'Skapa faktura', 'd' => 'Land (moms), mall, rader, anteckningar. Utskriftsdesign (1 av 12) och format A4/A5/Letter/Legal.'],
            ['t' => 'QR-kod', 'd' => 'Admin → Inställningar → QR: aktivera, fakturalänk, betalningsmall ({amount}, {invoice_no}) eller egen URL.'],
            ['t' => 'AI-text', 'd' => 'Admin → AI: API-nyckel och prompts. «AI-anteckningar» vid skapande; «Generera med AI» vid e-post. Utan nyckel — mallar på ditt språk.'],
            ['t' => 'Spara, skriv ut, dela', 'd' => 'Spara → JSON. Öppna länk, skriv ut PDF. QR till visning eller betalning.'],
            ['t' => 'E-post från admin', 'd' => 'Admin → Skicka e-post: kund + faktura, anteckning (AI), SMTP eller demo-logg.'],
            ['t' => 'SMTP och prenumeration', 'd' => 'Admin → SMTP: värd, TLS, avsändare. Prenumerationstext redigeras i admin.'],
        ],
        'devices_title' => 'Responsiv layout',
        'devices_intro' => 'Mobil, surfplatta och dator.',
        'devices' => [
            ['icon' => 'fa-mobile-alt', 't' => 'Mobil', 'd' => 'Kundval, rullbar tabell — 2 klick.'],
            ['icon' => 'fa-tablet-alt', 't' => 'Surfplatta', 'd' => 'Två kolumner säljare/köpare.'],
            ['icon' => 'fa-desktop', 't' => 'Dator', 'd' => 'Formulär vänster, förhandsvisning och QR höger.'],
        ],
        'clients_title' => 'Kunddatabas',
        'clients_text' => 'Spara kunder i admin. Återanvänd på varje faktura. Skicka sparade fakturor på 2 klick.',
        'ai_title' => 'AI-assistent',
        'ai_text' => 'OpenAI (gpt-4o-mini) eller xAI Grok (grok-3-mini, grok-3) — välj leverantör och modell i Admin → AI. Prompts för e-postanteckning, ämne och betalningsvillkor. Utan API-nyckel — mallar på 7 språk.',
        'countries_title' => 'Frontend för 7 länder',
        'countries_intro' => 'Varje land har momsregler, valuta, företagsdata och demofaktura på startsidan. Välj land vid skapande — skatt och säljare fylls i automatiskt.',
        'video_title' => 'Videoguide (skärmdumpar)',
        'video_intro' => '4 steg med skärmdumpar — som en kort video. Fungerar på mobil, surfplatta och dator.',
        'admin_features_title' => 'Adminpanel-funktioner',
        'qr_title' => 'QR på faktura',
        'qr_text' => 'Lägen: fakturalänk; betalningsmall med {amount}, {invoice_no}; eller fast URL. Utskrift och URL-text i Inställningar.',
        'smtp_title' => 'SMTP (admin)',
        'smtp_text' => 'Admin → SMTP: aktivera, värd, TLS, användare. Demo: logg i email-log.json.',
        'email_title' => 'Skicka faktura via e-post',
        'email_text' => 'HTML med nummer, belopp, förfallodatum, anteckning (AI) och knapp för visning. Språk följer UI.',
        'sub_title' => 'Prenumeration',
        'sub_text' => 'BILOHASH: 49 NOK/mån (1 CMS · 1 domän) eller 249 NOK/mån (alla CMS).',
    ];
}