<?php
require_once __DIR__ . '/init.php';
$adm_title = $t['admin']['dashboard'] ?? 'Dashboard';
$adm_nav_active = 'dashboard';
$settings = fk_load_settings();
$templates = fk_load_templates_all();
$countries = $settings['countries'] ?? [];
$invoices = fk_load_invoices();
$clients = fk_load_clients();
$demoCount = count(fk_get_demo_invoices());
$recentInvoices = array_slice($invoices, 0, 6);
$ta = $t['admin'] ?? [];
require __DIR__ . '/includes/layout.php';
?>
<div class="adm-stat-grid adm-stat-grid--icons">
    <a href="<?= fk_admin_url('clients.php') ?>" class="adm-stat adm-stat--link"><i class="fas fa-users" aria-hidden="true"></i><strong><?= count($clients) ?></strong><span><?= fk_h($ta['clients'] ?? 'Clients') ?></span></a>
    <a href="<?= fk_admin_url('invoices.php') ?>" class="adm-stat adm-stat--link"><i class="fas fa-file-invoice" aria-hidden="true"></i><strong><?= count($invoices) ?></strong><span><?= fk_h($ta['invoices'] ?? 'Saved invoices') ?></span></a>
    <a href="<?= fk_admin_url('invoices.php') ?>" class="adm-stat adm-stat--link"><i class="fas fa-home" aria-hidden="true"></i><strong><?= $demoCount ?></strong><span><?= fk_h($ta['demo_homepage'] ?? 'Homepage demos') ?></span></a>
    <a href="<?= fk_admin_url('countries.php') ?>" class="adm-stat adm-stat--link"><i class="fas fa-globe-europe" aria-hidden="true"></i><strong><?= count(array_filter($countries, static fn($c) => !empty($c['active']))) ?></strong><span><?= fk_h($ta['countries'] ?? 'Countries') ?></span></a>
    <div class="adm-stat"><i class="fas fa-language" aria-hidden="true"></i><strong>7</strong><span><?= fk_h($ta['languages'] ?? 'Languages') ?></span></div>
</div>

<?php if (!empty($recentInvoices)): ?>
<div class="adm-card adm-card--recent">
    <div class="adm-doc-head adm-doc-head--compact">
        <div class="adm-doc-head-text">
            <h2><i class="fas fa-clock-rotate-left" aria-hidden="true"></i> <?= fk_h($ta['inv_recent'] ?? 'Recent documents') ?></h2>
            <p><?= fk_h($ta['inv_recent_hint'] ?? 'Latest saved invoices — open full list on PC.') ?></p>
        </div>
        <a href="<?= fk_admin_url('invoices.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><i class="fas fa-folder-open" aria-hidden="true"></i> <?= fk_h($ta['inv_all'] ?? 'All documents') ?></a>
    </div>
    <div class="adm-recent-grid">
        <?php foreach ($recentInvoices as $row):
            $viewUrl = fk_url('invoice.php?id=' . urlencode($row['id'] ?? ''));
            $buyerName = $row['buyer']['name'] ?? '—';
            $total = $row['totals']['total'] ?? 0;
            $currency = $row['currency'] ?? '';
            $isDemo = !empty($row['is_demo']);
        ?>
        <a href="<?= fk_h($viewUrl) ?>" class="adm-recent-card" target="_blank" rel="noopener">
            <span class="adm-recent-icon"><i class="fas fa-file-invoice" aria-hidden="true"></i></span>
            <span class="adm-recent-body">
                <strong><?= fk_h($row['invoice_no'] ?? '') ?></strong>
                <span><?= fk_h($buyerName) ?></span>
                <em><?= fk_h(fk_money((float) $total, $currency)) ?></em>
            </span>
            <?php if ($isDemo): ?><span class="adm-badge-demo adm-badge-demo--sm"><i class="fas fa-home" aria-hidden="true"></i></span><?php endif; ?>
            <i class="fas fa-arrow-up-right-from-square adm-recent-go" aria-hidden="true"></i>
        </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="adm-pc-grid">
<div class="adm-card">
    <h2><i class="fas fa-globe" aria-hidden="true"></i> <?= fk_h($ta['view_site'] ?? 'Public site') ?></h2>
    <p class="adm-card-lead"><?= fk_h($ta['dashboard_hint'] ?? '') ?> <code>demo / bilofaktura2026</code></p>
    <div class="adm-actions-row adm-actions-row--pc">
        <a href="<?= fk_url('index.php') ?>" class="adm-btn adm-btn-primary adm-btn-sm" target="_blank" rel="noopener"><i class="fas fa-home"></i> <?= fk_h($ta['view_homepage'] ?? 'Homepage') ?></a>
        <a href="<?= fk_url('create.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank" rel="noopener"><i class="fas fa-plus"></i> <?= fk_h($t['nav']['create'] ?? 'Create') ?></a>
        <a href="<?= fk_admin_url('clients.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><i class="fas fa-users"></i> <?= fk_h($ta['clients'] ?? 'Clients') ?></a>
        <a href="<?= fk_admin_url('invoices.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><i class="fas fa-file-invoice"></i> <?= fk_h($ta['invoices'] ?? 'Invoices') ?></a>
        <a href="<?= fk_admin_url('smtp.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><i class="fas fa-envelope"></i> SMTP</a>
    </div>
</div>
<div class="adm-card">
    <h2><i class="fas fa-star" aria-hidden="true"></i> <?= fk_h($ta['features_title'] ?? 'Special features') ?></h2>
    <p class="adm-card-lead"><?= fk_h($ta['features_hint'] ?? '') ?></p>
    <div class="adm-feature-grid">
        <a href="<?= fk_admin_url('clients.php') ?>" class="adm-feature-card"><i class="fas fa-users"></i><strong><?= fk_h($ta['clients'] ?? 'Clients') ?></strong><span><?= fk_h($ta['feat_clients'] ?? '') ?></span></a>
        <a href="<?= fk_admin_url('send-mail.php') ?>" class="adm-feature-card"><i class="fas fa-paper-plane"></i><strong><?= fk_h($ta['send_email'] ?? 'Send email') ?></strong><span><?= fk_h($ta['feat_email'] ?? '') ?></span></a>
        <a href="<?= fk_admin_url('ai.php') ?>" class="adm-feature-card"><i class="fas fa-wand-magic-sparkles"></i><strong><?= fk_h($ta['ai_nav'] ?? 'AI') ?></strong><span><?= fk_h($ta['feat_ai'] ?? '') ?></span></a>
        <a href="<?= fk_admin_url('support.php') ?>" class="adm-feature-card"><i class="fas fa-headset"></i><strong><?= fk_h($ta['support'] ?? 'Support') ?></strong><span><?= fk_h($ta['feat_support'] ?? '') ?></span></a>
        <a href="<?= fk_admin_url('settings.php') ?>" class="adm-feature-card"><i class="fas fa-qrcode"></i><strong>QR</strong><span><?= fk_h($ta['feat_qr'] ?? '') ?></span></a>
        <a href="<?= fk_admin_url('invoices.php') ?>" class="adm-feature-card"><i class="fas fa-star"></i><strong><?= fk_h($ta['demo_homepage'] ?? 'Homepage demo') ?></strong><span><?= fk_h($ta['feat_demo'] ?? '') ?></span></a>
        <a href="<?= fk_url('help.php#video') ?>" class="adm-feature-card" target="_blank" rel="noopener"><i class="fas fa-play-circle"></i><strong><?= fk_h($ta['feat_video'] ?? 'Video guide') ?></strong><span><?= fk_h($ta['feat_video_hint'] ?? '') ?></span></a>
    </div>
</div>
</div>

<div class="adm-card">
    <h2><i class="fas fa-percent" aria-hidden="true"></i> <?= fk_h($ta['tax_table_title'] ?? 'VAT / tax rates') ?></h2>
    <div class="adm-table-wrap">
    <table class="adm-table adm-table--icons">
        <thead><tr>
            <th><i class="fas fa-flag" aria-hidden="true"></i> <?= fk_h($ta['country_col'] ?? 'Country') ?></th>
            <th><i class="fas fa-sliders" aria-hidden="true"></i> <?= fk_h($ta['mode_col'] ?? 'Mode') ?></th>
            <th><i class="fas fa-percent" aria-hidden="true"></i> <?= fk_h($ta['rate_col'] ?? 'Rate') ?></th>
            <th><i class="fas fa-coins" aria-hidden="true"></i> <?= fk_h($ta['currency_col'] ?? 'Currency') ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($countries as $c): if (empty($c['active'])) continue; ?>
        <tr>
            <td><?= fk_h(fk_localized($c, 'name', $lang)) ?></td>
            <td><?= fk_h($c['tax_mode'] ?? 'vat') ?></td>
            <td><?= (float)(($c['tax_mode'] ?? 'vat') === 'single' ? ($c['single_tax_rate'] ?? 0) : ($c['vat_rate'] ?? 0)) ?>%</td>
            <td><?= fk_h($c['currency'] ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/includes/layout-end.php'; ?>