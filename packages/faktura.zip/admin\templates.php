<?php
require_once __DIR__ . '/init.php';
$adm_title = $t['admin']['templates'] ?? 'Templates';
$adm_nav_active = 'templates';
$templates = fk_load_templates_all();
$settings = fk_load_settings();
$adm_saved = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $action = $_POST['action'] ?? 'save';
    if ($action === 'add') {
        $newId = 'tpl-' . bin2hex(random_bytes(4));
        $templates[] = [
            'id' => $newId,
            'country_id' => $_POST['new_country_id'] ?? 'en',
            'active' => true,
            'name' => ['en' => trim($_POST['new_name_en'] ?? 'New template')],
            'lines' => [
                ['desc' => ['en' => 'Service'], 'qty' => 1, 'unit' => 'pcs', 'price' => 100],
            ],
        ];
        fk_save_templates($templates);
        $adm_saved = true;
    } elseif ($action === 'save') {
        foreach ($templates as $i => $tpl) {
            $id = $tpl['id'];
            if (!isset($_POST['tpl'][$id])) continue;
            $p = $_POST['tpl'][$id];
            $templates[$i]['active'] = !empty($p['active']);
            $templates[$i]['country_id'] = $p['country_id'] ?? 'en';
            $templates[$i]['name']['en'] = trim($p['name_en'] ?? '');
        }
        fk_save_templates($templates);
        $adm_saved = true;
    }
    $templates = fk_load_templates_all();
}

require __DIR__ . '/includes/layout.php';
?>
<form method="post" class="adm-card">
    <h2><?= fk_h($t['admin']['add_template'] ?? 'Add template') ?></h2>
    <input type="hidden" name="action" value="add">
    <div class="adm-grid-2">
        <div class="adm-field"><label>Name (EN)</label><input type="text" name="new_name_en" required></div>
        <div class="adm-field">
            <label>Country</label>
            <select name="new_country_id">
                <?php foreach ($settings['countries'] ?? [] as $c): ?>
                <option value="<?= fk_h($c['id']) ?>"><?= fk_h(fk_localized($c, 'name', $lang)) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <button type="submit" class="adm-btn adm-btn-primary"><?= fk_h($t['admin']['add_template'] ?? 'Add') ?></button>
</form>

<form method="post">
<input type="hidden" name="action" value="save">
<?php foreach ($templates as $tpl): $id = $tpl['id']; ?>
<div class="adm-card">
    <div class="adm-grid-2">
        <div class="adm-field">
            <label><?= fk_h($t['admin']['template_name'] ?? 'Name') ?> (EN)</label>
            <input type="text" name="tpl[<?= fk_h($id) ?>][name_en]" value="<?= fk_h(fk_localized($tpl, 'name', 'en')) ?>">
        </div>
        <div class="adm-field">
            <label>Country</label>
            <select name="tpl[<?= fk_h($id) ?>][country_id]">
                <?php foreach ($settings['countries'] ?? [] as $c): ?>
                <option value="<?= fk_h($c['id']) ?>" <?= ($tpl['country_id'] ?? '') === $c['id'] ? 'selected' : '' ?>><?= fk_h(fk_localized($c, 'name', $lang)) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><input type="checkbox" name="tpl[<?= fk_h($id) ?>][active]" value="1" <?= !empty($tpl['active']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['active'] ?? 'Active') ?></label>
        </div>
    </div>
    <p style="font-size:.82rem;color:var(--adm-muted)"><?= count($tpl['lines'] ?? []) ?> <?= fk_h($t['admin']['lines'] ?? 'lines') ?> · ID: <?= fk_h($id) ?></p>
</div>
<?php endforeach; ?>
<button type="submit" class="adm-btn adm-btn-primary"><?= fk_h($t['admin']['save'] ?? 'Save') ?></button>
</form>
<?php require __DIR__ . '/includes/layout-end.php'; ?>