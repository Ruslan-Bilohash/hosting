<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/country-seo.php';

$slug = strtolower(trim((string) ($_GET['slug'] ?? '')));
$countryId = fk_country_id_from_slug($slug);
if ($countryId === null) {
    require __DIR__ . '/404.php';
    exit;
}

$settings = fk_load_settings();
$country = fk_country_by_id($settings, $countryId);
if ($country === null) {
    require __DIR__ . '/404.php';
    exit;
}

$registry = fk_country_seo_registry()[$countryId] ?? [];
$copy = fk_country_seo_copy($countryId, $lang, $country, $registry);
$businessNative = fk_country_seo_business_native()[$countryId] ?? [];
$nativeLang = (string) ($registry['native_lang'] ?? $lang);
$demoId = (string) ($registry['demo_id'] ?? '');
$demoInvoices = fk_get_demo_invoices();
$countryDemo = null;
foreach ($demoInvoices as $demo) {
    if (($demo['id'] ?? '') === $demoId) {
        $countryDemo = $demo;
        break;
    }
}

$cp = $t['country_page'] ?? [];
$current_page = 'country';
$page_title = $copy['meta_title'] ?? ('Faktura Creator — ' . fk_localized($country, 'name', $lang));
$page_desc = $copy['meta_desc'] ?? '';
$canonicalSlug = fk_country_canonical_slug($countryId);
$canonical = rtrim($site_url, '/') . '/' . $canonicalSlug . '/' . ($lang !== FK_LANG_DEFAULT ? '?lang=' . urlencode($lang) : '');
$hreflang_alternates = fk_country_hreflang_alternates($countryId);
$hreflang_default = rtrim($site_url, '/') . '/' . $canonicalSlug . '/';

$demoShots = fk_demo_shots_map();
$demoShot = $demoShots[$demoId] ?? '';
$demoLabelNative = $countryDemo ? fk_demo_invoice_label($countryDemo, $nativeLang) : '';
$demoViewUrl = fk_url('invoice.php?id=' . urlencode($demoId) . ($nativeLang !== FK_LANG_DEFAULT ? '&lang=' . urlencode($nativeLang) : ''));
$createUrl = fk_url('create.php?country=' . urlencode($countryId));
$nativeLangLabel = fk_country_native_lang_label($nativeLang);
$demoLangNote = str_replace('{lang}', $nativeLangLabel, $cp['demo_in_lang'] ?? 'Demo in {lang}');
$countryList = fk_country_seo_active_list($settings);
$flag = (string) ($registry['flag'] ?? '🌐');

require __DIR__ . '/includes/header.php';
?>

<section class="fk-home-hero fk-country-hero">
    <div class="fk-home-hero-inner">
        <p class="fk-home-badge">
            <span class="fk-country-hero-flag" aria-hidden="true"><?= $flag ?></span>
            <?= fk_h($copy['badge'] ?? '') ?>
        </p>
        <h1><?= fk_h($copy['h1'] ?? '') ?></h1>
        <p class="fk-home-lead"><?= fk_h($copy['lead'] ?? '') ?></p>
        <p class="fk-country-tax-line"><i class="fas fa-percent" aria-hidden="true"></i> <?= fk_h($copy['tax_line'] ?? '') ?></p>
        <div class="fk-home-cta">
            <a href="<?= fk_h($createUrl) ?>" class="fk-btn fk-btn-primary fk-btn-lg"><i class="fas fa-file-circle-plus"></i> <?= fk_h(str_replace('{country}', fk_localized($country, 'name', $lang), $cp['cta_create'] ?? 'Create invoice')) ?></a>
            <?php if ($countryDemo): ?>
            <a href="<?= fk_h($demoViewUrl) ?>" class="fk-btn fk-btn-ghost fk-btn-lg"><i class="fas fa-eye"></i> <?= fk_h($cp['cta_demo'] ?? 'View demo invoice') ?></a>
            <?php endif; ?>
            <a href="<?= fk_h(fk_url('index.php')) ?>" class="fk-btn fk-btn-ghost fk-btn-lg"><i class="fas fa-globe-europe"></i> <?= fk_h($cp['all_countries'] ?? 'All countries') ?></a>
        </div>
    </div>
</section>

<?php if (!empty($businessNative)): ?>
<section class="fk-home-section fk-country-business">
    <div class="fk-country-business-head">
        <h2><i class="fas fa-briefcase" style="color:var(--fk-primary)"></i> <?= fk_h($copy['business_heading'] ?? 'Business example') ?></h2>
        <span class="fk-country-lang-pill"><i class="fas fa-language" aria-hidden="true"></i> <?= fk_h($demoLangNote) ?></span>
    </div>
    <div class="fk-card fk-country-business-card" lang="<?= fk_h($nativeLang) ?>">
        <h3><?= fk_h($businessNative['title'] ?? '') ?></h3>
        <p class="fk-country-business-meta">
            <strong><?= fk_h($cp['seller'] ?? 'Seller') ?>:</strong> <?= fk_h($businessNative['seller'] ?? '') ?>
            · <strong><?= fk_h($cp['buyer'] ?? 'Buyer') ?>:</strong> <?= fk_h($businessNative['buyer'] ?? '') ?>
        </p>
        <p class="fk-home-text"><?= fk_h($businessNative['text'] ?? '') ?></p>
    </div>
</section>
<?php endif; ?>

<?php if ($countryDemo && $demoShot): ?>
<section class="fk-home-section fk-country-demo" id="demo">
    <h2><i class="fas fa-file-invoice" style="color:var(--fk-primary)"></i> <?= fk_h($cp['demo_title'] ?? 'Demo invoice') ?></h2>
    <p class="fk-home-text fk-text-muted"><?= fk_h($cp['demo_text'] ?? '') ?></p>
    <div class="fk-country-demo-wrap">
        <a href="<?= fk_h($demoViewUrl) ?>" class="fk-country-demo-shot">
            <img src="<?= fk_h(fk_asset('images/demo/' . $demoShot)) ?>" alt="<?= fk_h($demoLabelNative) ?>" width="400" height="520" loading="eager">
        </a>
        <div class="fk-country-demo-panel">
            <p class="fk-demo-preview-meta"><?= fk_h(($countryDemo['invoice_no'] ?? '') . ' — ' . $demoLabelNative) ?></p>
            <p class="fk-demo-preview-meta"><?= fk_h(fk_money((float) ($countryDemo['totals']['total'] ?? 0), $countryDemo['currency'] ?? '') . ' · ' . fk_print_design_name(fk_normalize_print_design($countryDemo['print_design'] ?? 'classic-blue'), $nativeLang)) ?></p>
            <div class="fk-demo-preview-actions">
                <a href="<?= fk_h($demoViewUrl) ?>" class="fk-btn fk-btn-primary"><i class="fas fa-eye"></i> <?= fk_h($cp['cta_demo'] ?? 'View demo invoice') ?></a>
                <a href="<?= fk_h(fk_url('create.php?country=' . urlencode($countryId))) ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-mobile-alt"></i> <?= fk_h($cp['cta_try'] ?? 'Try on mobile') ?></a>
            </div>
            <p class="fk-demo-preview-hint"><?= fk_h($cp['demo_hint'] ?? '') ?></p>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="fk-home-section" id="other-countries">
    <h2><i class="fas fa-map-marked-alt" aria-hidden="true"></i> <?= fk_h($cp['other_title'] ?? 'Other countries in Europe') ?></h2>
    <p class="fk-home-text fk-text-muted"><?= fk_h($cp['other_text'] ?? '') ?></p>
    <div class="fk-country-grid">
        <?php foreach ($countryList as $cid => $row):
            if ($cid === $countryId) {
                continue;
            }
            $c = $row['country'] ?? [];
            $rate = ($c['tax_mode'] ?? 'vat') === 'single' ? ($c['single_tax_rate'] ?? 0) : ($c['vat_rate'] ?? 0);
        ?>
        <a href="<?= fk_h(fk_country_page_url($cid, $lang)) ?>" class="fk-country-card">
            <span class="fk-country-flag" aria-hidden="true"><?= $row['flag'] ?? '🌐' ?></span>
            <strong><?= fk_h(fk_localized($c, 'name', $lang)) ?></strong>
            <span class="fk-menu-desc"><?= fk_h(fk_localized($c, 'tax_label', $lang)) ?> <?= fk_h((string) $rate) ?>% · <?= fk_h($c['currency'] ?? '') ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<section class="fk-home-section fk-home-section--cta">
    <div class="fk-card fk-home-cta-card">
        <h2><?= fk_h(str_replace('{country}', fk_localized($country, 'name', $lang), $cp['start_title'] ?? 'Get started')) ?></h2>
        <p><?= fk_h($cp['start_text'] ?? '') ?></p>
        <div class="fk-home-cta">
            <a href="<?= fk_h($createUrl) ?>" class="fk-btn fk-btn-primary"><?= fk_h(str_replace('{country}', fk_localized($country, 'name', $lang), $cp['cta_create'] ?? 'Create invoice')) ?></a>
            <a href="<?= fk_h(fk_url('demo-install.php')) ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-download"></i> <?= fk_h($t['nav']['demo_install'] ?? '30-day demo') ?></a>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>