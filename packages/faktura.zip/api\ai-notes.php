<?php
require_once dirname(__DIR__) . '/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fk_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$settings = fk_load_settings();
$composeLang = trim((string) ($payload['lang'] ?? $lang));
if (!in_array($composeLang, array_keys(fk_langs()), true)) {
    $composeLang = $lang;
}

$context = [
    'client_name' => trim((string) ($payload['client_name'] ?? '')),
    'invoice_no'  => trim((string) ($payload['invoice_no'] ?? '')),
    'total'       => trim((string) ($payload['total'] ?? '')),
    'currency'    => trim((string) ($payload['currency'] ?? '')),
    'due_date'    => trim((string) ($payload['due_date'] ?? '')),
    'company'     => (string) ($settings['company']['name'] ?? 'Faktura Creator'),
    'iban'        => trim((string) ($payload['iban'] ?? $settings['company']['iban'] ?? '')),
];

$provider = trim((string) ($payload['provider'] ?? fk_ai_referral_provider()));
$result = fk_ai_compose($settings, 'invoice_notes', $context, $composeLang, $provider);
fk_json_response([
    'ok'    => $result['ok'],
    'text'  => $result['text'],
    'demo'  => $result['demo'],
    'error' => $result['error'],
], $result['ok'] ? 200 : 500);