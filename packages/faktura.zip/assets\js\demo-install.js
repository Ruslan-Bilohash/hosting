(function () {
    var form = document.getElementById('fkDiDownloadForm');
    if (!form) return;
    var msg = document.getElementById('fkDiMessage');
    var api = form.getAttribute('data-api') || '';
    var cabinetUrl = form.getAttribute('data-cabinet') || '';
    var logged = form.getAttribute('data-logged') === '1';
    var filename = form.getAttribute('data-filename') || 'faktura-demo-30d.zip';

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!logged) {
            window.location.href = cabinetUrl;
            return;
        }
        var fd = new FormData(form);
        fd.append('terms_accept', fd.get('terms') ? '1' : '');
        if (msg) { msg.hidden = true; msg.textContent = ''; }
        fetch(api, { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function (res) {
                var ct = res.headers.get('content-type') || '';
                if (ct.indexOf('application/zip') !== -1) {
                    return res.blob().then(function (blob) {
                        var a = document.createElement('a');
                        a.href = URL.createObjectURL(blob);
                        a.download = filename;
                        a.click();
                        URL.revokeObjectURL(a.href);
                    });
                }
                return res.json().then(function (data) {
                    throw new Error(data.error || 'download_failed');
                });
            })
            .catch(function (err) {
                if (msg) {
                    msg.hidden = false;
                    msg.textContent = err.message || 'Error';
                    msg.style.color = '#f87171';
                }
            });
    });
})();