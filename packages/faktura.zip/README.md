# Faktura Creator

**PHP admin panel for accountants and business owners** — clients, VAT/MVA for 7 countries, invoice templates, SMTP delivery, AI payment notes, QR pay links and BILOHASH ecosystem support. Portfolio project by [Ruslan Bilohash](https://bilohash.com/).

**Version (this repo):** 1.0.0 · **Readme languages:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-built--in-purple)

---

## Important — demo repository only

> **This GitHub repository contains a demo / portfolio example of Faktura Creator.**
> It is **not** the complete commercial product and **not** guaranteed to be the latest version.
>
> The **latest full version**, updates and commercial support are available **only from the author**:
> - Live demo: https://bilohash.com/faktura/
> - 30-day self-install: https://bilohash.com/faktura/demo-install.php
> - Subscribe: https://bilohash.com/ecosystem/join.php
> - Contact: **rbilohash@gmail.com**

**Commercial use without written consent from the author is prohibited.** See [LICENSE](LICENSE).

---

## Live demo

| Resource | URL |
|----------|-----|
| **Homepage** | https://bilohash.com/faktura/ |
| **Create invoice** | https://bilohash.com/faktura/create.php |
| **Service calculator** | https://bilohash.com/faktura/calc.php |
| **Admin panel** | https://bilohash.com/faktura/admin/ |
| **Help & video guide** | https://bilohash.com/faktura/help.php |
| **30-day demo download** | https://bilohash.com/faktura/demo-install.php |
| **BILOHASH ecosystem** | https://bilohash.com/ecosystem/cabinet.php |

**Admin login (demo):** `demo` / `bilofaktura2026`

---

## AI out of the box

Faktura Creator ships with **built-in AI assistance** (OpenAI / xAI Grok — configure API key in admin):

| Area | What AI does |
|------|----------------|
| **Email notes** | Personal note when sending invoices to clients |
| **Email subject** | Concise subject lines for invoice emails |
| **Invoice notes** | Payment terms and bank-transfer text |
| **Support messages** | Draft ecosystem support tickets and client emails |

Demo mode works **without an API key** — multilingual template fallbacks let you explore the workflow immediately.

---

## Features

### Public frontend
- Mobile-first invoice creator with country VAT/MVA presets
- **7 markets:** UK, Norway, Lithuania, Poland, Germany, Sweden, Ukraine — currency and tax rules
- **12 print designs** — A4, Letter, Legal layouts; preview and browser print/PDF
- Service calculator with presets (cleaning, consulting, etc.)
- Save invoices and calculations; view & share links
- QR codes on invoices — payment URL template (Vipps/Stripe-style) or custom link
- Homepage demo invoices per country
- Help page with step-by-step screenshots and video section
- Multilingual UI: **English**, **Ukrainian**, **Lithuanian**, **Polish**, **German**, **Swedish**, **Norwegian** (`?lang=` + cookie)
- Contact page and BILOHASH ecosystem strip

### Admin panel
- **Dashboard** — clients, saved invoices, homepage demos, VAT table
- **Clients** — database for 2-click invoicing (name, email, address, notes)
- **Invoices** — browse, search, print, email, homepage demo toggle
- **Calculations** — saved service quotes
- **Service presets** — calculator templates and payment URLs
- **Send email** — SMTP delivery with AI-generated notes
- **Settings** — company profile, invoice numbering, QR options
- **Countries & tax** — VAT/single-rate modes per country
- **Templates** — default line items per template
- **SMTP** — host, port, TLS, credentials (demo logs to `email-log.json`)
- **AI** — provider, model, prompts, referral links per language
- **Support & mail** — BILOHASH ecosystem inbox, owner chat, client email drafts
- Multilingual admin UI

### BILOHASH ecosystem
- **30-day trial ZIP** — download from customer cabinet after subscription
- **Support messaging** — threads with BILOHASH support from admin
- **Subscription** — 49 kr/mo (one CMS) or 249 kr/mo (all scripts on one domain)

---

## Tech stack

- PHP 8+ (no framework)
- JSON storage (`data/*.json`, PHP seeds in `data/`)
- Modular i18n (`lang/*.php` — overlay merge for `uk`, `no`)
- Apache `.htaccess`, canonical URLs, hreflang
- Font Awesome 6, vanilla CSS & JS
- OpenAI-compatible API (OpenAI, xAI Grok)

---

## Requirements

- PHP 8.0 or newer
- Apache with `mod_rewrite` (or nginx equivalent)
- Writable `data/` directory
- SMTP host (optional — demo mode logs emails locally)

---

## Installation

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Copy the `faktura/` folder to your web root (e.g. `/faktura/`).
2. Set write permissions on `data/`:
   ```bash
   chmod 755 data
   ```
3. Open `https://your-domain.com/faktura/` — demo data loads from seeds.
4. Admin: `https://your-domain.com/faktura/admin/` — change credentials before production.

### Self-install (30-day trial)

1. Subscribe at https://bilohash.com/ecosystem/join.php
2. Sign in to the [customer cabinet](https://bilohash.com/ecosystem/cabinet.php) and download the demo ZIP
3. Upload to your hosting (e.g. `/public_html/faktura/`)
4. Follow https://bilohash.com/faktura/demo-install.php

### Local PHP server

```bash
cd faktura
php -S localhost:8080
```

Open http://localhost:8080/faktura/ (adjust `FK_BASE_PATH` in `config.php` if needed).

### Configuration (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
define('FK_DEMO_URL', 'https://bilohash.com/faktura/');
```

---

## Project structure

```
faktura/
├── index.php              # Homepage — country demos, CTAs
├── create.php             # Invoice creator
├── calc.php               # Service calculator
├── invoice.php            # View / print saved invoice
├── help.php / contact.php
├── demo-install.php       # 30-day package download guide
├── config.php / init.php
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR, i18n
├── assets/css|js|images/
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Full admin panel + support API
├── api/                   # save invoice, AI compose (public)
├── scripts/               # pack-demo.ps1, deploy, lang audit
└── LICENSE
```

---

## Demo mode

- Demo admin credentials shown on login page
- SMTP disabled by default — emails logged to `data/email-log.json`
- AI uses local templates without API key
- Homepage showcases sample invoices per country

### Build demo package

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

Creates `faktura-demo-30d.zip` and a versioned copy in `downloads/`.

### Translation check

```bash
node scripts/check-lang-keys.mjs
```

Overlay languages (`uk.php`, `no.php`) merge with `en.php` at runtime — missing overlay keys fall back to English.

---

## Author & commercial license

**Ruslan Bilohash**
- Website: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- Email: rbilohash@gmail.com

For **commercial licensing**, full source, custom development or the **latest production version**, contact the author directly. See [LICENSE](LICENSE).