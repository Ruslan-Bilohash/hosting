# Faktura Creator

**PHP-adminpanel för revisorer och företagare** — klienter, moms/MVA för 7 länder, fakturamallar, SMTP, AI-betalningsnoteringar, QR-betalning och BILOHASH-ekosystemstöd. Portfolio-projekt av [Ruslan Bilohash](https://bilohash.com/).

**Version (detta repo):** 1.0.0 · **Readme-språk:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-inbyggd-purple)

---

## Viktigt — endast demo-repository

> **Detta GitHub-repository innehåller ett demo / portfolio-exempel av Faktura Creator.**
> Det är **inte** den kompletta kommersiella produkten och **inte** nödvändigtvis den senaste versionen.
>
> **Senaste fullversionen**, uppdateringar och kommersiell support finns **endast hos författaren**:
> - Live demo: https://bilohash.com/faktura/
> - 30-dagars självinstallation: https://bilohash.com/faktura/demo-install.php
> - Prenumeration: https://bilohash.com/ecosystem/join.php
> - Kontakt: **rbilohash@gmail.com**

**Kommersiell användning utan skriftligt medgivande från författaren är förbjuden.** Se [LICENSE](LICENSE).

---

## Live demo

| Resurs | URL |
|--------|-----|
| **Startsida** | https://bilohash.com/faktura/ |
| **Skapa faktura** | https://bilohash.com/faktura/create.php |
| **Tjänstekalkylator** | https://bilohash.com/faktura/calc.php |
| **Adminpanel** | https://bilohash.com/faktura/admin/ |
| **Hjälp och video** | https://bilohash.com/faktura/help.php |
| **30-dagars demo-nedladdning** | https://bilohash.com/faktura/demo-install.php |
| **BILOHASH kundportal** | https://bilohash.com/ecosystem/cabinet.php |

**Admin-inloggning (demo):** `demo` / `bilofaktura2026`

---

## AI inbyggd från start

Faktura Creator har **inbyggd AI-hjälp** (OpenAI / xAI Grok — konfigurera API-nyckel i admin):

| Område | Vad AI gör |
|--------|------------|
| **E-postnoteringar** | Personlig notering vid fakturautskick |
| **E-postämne** | Korta ämnesrader för fakturmejl |
| **Fakturanoteringar** | Betalningsvillkor och banköverföringstext |
| **Support** | Utkast till ekosystemsupport och kundmejl |

Demoläge fungerar **utan API-nyckel** — flerspråkiga mallar för utvärdering.

---

## Funktioner

### Offentlig frontend
- Mobil-först fakturaskapare med moms-presets per land
- **7 marknader:** UK, Norge, Litauen, Polen, Tyskland, Sverige, Ukraina
- **12 utskriftsdesign** — A4, Letter, Legal; förhandsgranskning och utskrift/PDF
- Tjänstekalkylator med förinställningar
- Spara fakturor och kalkyler; delbara länkar
- QR på fakturor — betalnings-URL-mall eller egen länk
- Demofakturor på startsidan per land
- Hjälpsida med skärmdumpar och video
- Språk: **EN, UA, LT, PL, DE, SV, NO** (`?lang=` + cookie)
- Kontakt och BILOHASH-ekosystem

### Adminpanel
- **Dashboard** — klienter, fakturor, demo på startsidan, momstabell
- **Klienter** — databas för faktura på 2 klick
- **Fakturor** — sök, skriv ut, e-post, demo på startsidan
- **Kalkyler** — sparade tjänsteofferter
- **Tjänsteförinställningar** — kalkylatormallar och betalnings-URL
- **Skicka e-post** — SMTP med AI-noteringar
- **Inställningar** — företag, numrering, QR
- **Länder och skatt** — moms / enkel sats
- **Mallar** — standardrader
- **SMTP** — värd, port, TLS (demo loggar till `email-log.json`)
- **AI** — leverantör, modell, prompts, referenslänkar
- **Support och e-post** — BILOHASH-inkorg, ägarchatt, kundutkast
- Flerspråkig admin

### BILOHASH-ekosystem
- **30-dagars ZIP** — nedladdning från kundportal efter prenumeration
- **Supportmeddelanden** — trådar med BILOHASH från admin
- **Prenumeration** — 49 kr/mån (1 CMS) eller 249 kr/mån (alla skript på 1 domän)

---

## Teknisk stack

- PHP 8+ (utan ramverk)
- JSON-lagring (`data/*.json`)
- Modulär i18n (`lang/*.php`)
- Apache `.htaccess`, kanoniska URL:er, hreflang
- Font Awesome 6, vanlig CSS och JS
- OpenAI-kompatibel API (OpenAI, xAI Grok)

---

## Krav

- PHP 8.0 eller nyare
- Apache med `mod_rewrite`
- Skrivbar `data/`-katalog
- SMTP (valfritt — demo loggar e-post lokalt)

---

## Installation

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Kopiera `faktura/` till webbrot (t.ex. `/faktura/`).
2. Skrivrättigheter på `data/`:
   ```bash
   chmod 755 data
   ```
3. Öppna `https://din-domän.se/faktura/`.
4. Admin: `https://din-domän.se/faktura/admin/` — ändra inloggningsuppgifter före produktion.

### Självinstallation (30 dagar)

1. Prenumerera på https://bilohash.com/ecosystem/join.php
2. Logga in i [kundportalen](https://bilohash.com/ecosystem/cabinet.php) och ladda ner demo-ZIP
3. Ladda upp till hosting
4. Guide: https://bilohash.com/faktura/demo-install.php

### Lokal PHP-server

```bash
cd faktura
php -S localhost:8080
```

### Konfiguration (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
```

---

## Projektstruktur

```
faktura/
├── index.php              # Startsida — landdemoer
├── create.php             # Skapa faktura
├── calc.php               # Tjänstekalkylator
├── invoice.php            # Visa / skriv ut
├── help.php / contact.php
├── demo-install.php       # 30-dagars paket
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Admin + support API
├── api/                   # spara faktura, AI (offentlig)
└── LICENSE
```

---

## Demoläge

- Demoinloggning visas på inloggningssidan
- SMTP av — e-post loggas till `data/email-log.json`
- AI utan nyckel — lokala mallar
- Exempelfakturor på startsidan

### Bygg demo-paket

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

### Språkkontroll

```bash
node scripts/check-lang-keys.mjs
```

---

## Författare och kommersiell licens

**Ruslan Bilohash**
- Webbplats: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- E-post: rbilohash@gmail.com

För **kommersiell licens**, full källkod eller **senaste produktionsversionen**, kontakta författaren. Se [LICENSE](LICENSE).