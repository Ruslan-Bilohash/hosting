<?php

/**
 * QR code targets for invoices (view link, payment URL, custom).
 */

function fk_invoice_view_url(string $id): string
{
    global $site_url;
    return rtrim($site_url ?? '', '/') . '/invoice.php?id=' . rawurlencode($id);
}

/**
 * @param array<string, mixed> $invoice
 * @param array<string, mixed> $settings
 */
function fk_invoice_qr_target(array $invoice, array $settings, ?string $id = null): string
{
    $qr = $settings['qr'] ?? [];
    if (empty($qr['enabled'])) {
        return '';
    }

    $mode = $qr['mode'] ?? 'invoice_link';
    $invId = $id ?? (string) ($invoice['id'] ?? '');

    if ($mode === 'payment_url') {
        $perInvoice = trim((string) ($invoice['payment_url'] ?? ''));
        if ($perInvoice !== '') {
            return $perInvoice;
        }
        $template = trim((string) ($qr['payment_url_template'] ?? ''));
        if ($template !== '') {
            return str_replace(
                ['{amount}', '{invoice_no}', '{currency}', '{id}', '{reference}'],
                [
                    (string) ($invoice['totals']['total'] ?? ''),
                    (string) ($invoice['invoice_no'] ?? ''),
                    (string) ($invoice['currency'] ?? ''),
                    $invId,
                    (string) ($invoice['payment_purpose'] ?? $invoice['invoice_no'] ?? ''),
                ],
                $template
            );
        }
    }

    if ($mode === 'custom') {
        $custom = trim((string) ($qr['custom_url'] ?? ''));
        if ($custom !== '') {
            return $custom;
        }
    }

    if ($invId !== '') {
        return fk_invoice_view_url($invId);
    }

    return trim((string) ($invoice['preview_link'] ?? ''));
}

/**
 * @param array<string, mixed> $invoice
 * @param array<string, mixed> $settings
 */
function fk_resolve_payment_url(array $invoice, array $settings): string
{
    $perInvoice = trim((string) ($invoice['payment_url'] ?? ''));
    if ($perInvoice !== '') {
        return $perInvoice;
    }
    $qr = $settings['qr'] ?? [];
    $template = trim((string) ($qr['payment_url_template'] ?? ''));
    if ($template === '') {
        return '';
    }
    return str_replace(
        ['{amount}', '{invoice_no}', '{currency}', '{id}', '{reference}'],
        [
            (string) ($invoice['totals']['total'] ?? ''),
            (string) ($invoice['invoice_no'] ?? ''),
            (string) ($invoice['currency'] ?? ''),
            (string) ($invoice['id'] ?? ''),
            (string) ($invoice['payment_purpose'] ?? $invoice['invoice_no'] ?? ''),
        ],
        $template
    );
}

function fk_qr_image_url(string $data, int $size = 120): string
{
    $data = trim($data);
    if ($data === '') {
        return '';
    }
    $size = max(80, min(400, $size));
    return 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size
        . '&margin=8&data=' . rawurlencode($data);
}

/**
 * @param array<string, mixed> $invoice
 * @param array<string, mixed> $settings
 */
function fk_render_invoice_qr(array $invoice, array $settings, ?string $id = null, string $label = ''): void
{
    $qr = $settings['qr'] ?? [];
    if (empty($qr['enabled'])) {
        return;
    }

    $target = fk_invoice_qr_target($invoice, $settings, $id);
    if ($target === '') {
        return;
    }

    $img = fk_qr_image_url($target, (int) ($qr['size'] ?? 120));
    if ($img === '') {
        return;
    }

    $showUrl = !empty($qr['show_url_text']);
    ?>
    <div class="fk-preview-qr" role="img" aria-label="<?= fk_h($label !== '' ? $label : 'QR code') ?>">
        <img src="<?= fk_h($img) ?>" alt="<?= fk_h($label !== '' ? $label : 'QR') ?>" width="<?= (int) ($qr['size'] ?? 120) ?>" height="<?= (int) ($qr['size'] ?? 120) ?>" loading="lazy">
        <?php if ($showUrl): ?>
        <div class="fk-preview-qr-url"><?= fk_h($target) ?></div>
        <?php endif; ?>
    </div>
    <?php
}