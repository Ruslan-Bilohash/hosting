<?php
define('FK_ADMIN_USER', 'demo');
define('FK_ADMIN_PASS', 'bilofaktura2026');
define('FK_ADMIN_SESSION_KEY', 'fk_admin_logged');
define('FK_ADMIN_ROLE_KEY', 'fk_admin_role');

function fk_admin_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function fk_admin_logged(): bool
{
    fk_admin_start();
    return !empty($_SESSION[FK_ADMIN_SESSION_KEY]);
}

function fk_admin_login(string $user, string $pass): bool
{
    if ($user === FK_ADMIN_USER && $pass === FK_ADMIN_PASS) {
        fk_admin_start();
        $_SESSION[FK_ADMIN_SESSION_KEY] = true;
        $_SESSION['fk_admin_user'] = $user;
        $_SESSION[FK_ADMIN_ROLE_KEY] = 'demo';
        return true;
    }
    return false;
}

function fk_admin_logout(): void
{
    fk_admin_start();
    unset($_SESSION[FK_ADMIN_SESSION_KEY], $_SESSION['fk_admin_user'], $_SESSION[FK_ADMIN_ROLE_KEY], $_SESSION['fk_admin_email']);
}

function fk_admin_role(): string
{
    fk_admin_start();
    return (string) ($_SESSION[FK_ADMIN_ROLE_KEY] ?? 'demo');
}

function fk_admin_is_owner(): bool
{
    return fk_admin_role() === 'owner';
}

function fk_admin_display_name(): string
{
    fk_admin_start();
    $user = (string) ($_SESSION['fk_admin_user'] ?? '');
    return $user !== '' ? $user : 'Admin';
}

function fk_admin_client_ip(): string
{
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($keys as $key) {
        $raw = trim((string) ($_SERVER[$key] ?? ''));
        if ($raw === '') {
            continue;
        }
        if ($key === 'HTTP_X_FORWARDED_FOR') {
            $parts = array_map('trim', explode(',', $raw));
            $raw = $parts[0] ?? $raw;
        }
        if (filter_var($raw, FILTER_VALIDATE_IP)) {
            return $raw;
        }
    }
    return '0.0.0.0';
}

function fk_admin_require(): void
{
    if (!fk_admin_logged()) {
        header('Location: ' . fk_admin_url('login.php'), true, 302);
        exit;
    }
}

