<?php
require_once __DIR__ . '/init.php';

$ta = $t['admin'] ?? [];
$adm_title = $ta['service_presets'] ?? 'Service calculator';
$adm_nav_active = 'service_presets';
$adm_body_class = 'adm-page-service-presets';
$adm_saved = false;
$adm_error = '';
$settings = fk_load_settings();
$presets = fk_load_service_presets();
$defaultFacturaPreset = fk_default_service_preset_id($settings);
$editId = trim($_GET['edit'] ?? '');
$editing = null;

foreach ($presets as $p) {
    if (($p['id'] ?? '') === $editId) {
        $editing = $p;
        break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $action = $_POST['action'] ?? 'save';

    if ($action === 'delete') {
        $deleteId = trim($_POST['preset_id'] ?? '');
        $presets = array_values(array_filter(
            fk_load_service_presets(),
            static fn(array $p) => ($p['id'] ?? '') !== $deleteId
        ));
        if (fk_save_service_presets($presets)) {
            $adm_saved = true;
            $editId = '';
            $editing = null;
        } else {
            $adm_error = $ta['save_failed'] ?? 'Could not save.';
        }
    } else {
        $id = trim($_POST['preset_id'] ?? '');
        $slug = preg_replace('/[^a-z0-9\-]+/i', '-', strtolower(trim($_POST['preset_slug'] ?? $id)));
        $slug = trim($slug, '-') ?: ('preset-' . substr(bin2hex(random_bytes(3)), 0, 6));
        $docLang = trim($_POST['document_lang'] ?? 'en');
        if (!in_array($docLang, ['en', 'uk', 'lt', 'pl', 'de', 'sv', 'no'], true)) {
            $docLang = 'en';
        }

        $name = trim($_POST['preset_name'] ?? '');
        if ($name === '') {
            $adm_error = $ta['preset_name_required'] ?? 'Preset name required.';
        } else {
            $services = [];
            $postedServices = $_POST['services'] ?? [];
            if (is_array($postedServices)) {
                foreach ($postedServices as $svc) {
                    if (!is_array($svc)) {
                        continue;
                    }
                    $label = trim((string) ($svc['name'] ?? ''));
                    if ($label === '') {
                        continue;
                    }
                    $services[] = [
                        'desc'  => [$docLang => $label, 'en' => $label],
                        'qty'   => max(0.01, (float) ($svc['qty'] ?? 1)),
                        'price' => max(0, (float) ($svc['price'] ?? 0)),
                    ];
                }
            }

            $record = [
                'id'            => $id !== '' ? $id : $slug,
                'country_id'    => trim($_POST['country_id'] ?? 'lt'),
                'currency'      => strtoupper(trim($_POST['currency'] ?? 'EUR')),
                'active'        => !empty($_POST['active']),
                'document_lang' => $docLang,
                'name'          => [$docLang => $name, 'en' => $name],
                'seller'        => [
                    'name'    => trim($_POST['seller_name'] ?? ''),
                    'org_nr'  => trim($_POST['seller_org_nr'] ?? ''),
                    'license' => trim($_POST['seller_license'] ?? ''),
                    'address' => trim($_POST['seller_address'] ?? ''),
                    'bank'    => trim($_POST['seller_bank'] ?? ''),
                    'iban'    => trim($_POST['seller_iban'] ?? ''),
                ],
                'payment_url_template' => trim($_POST['payment_url_template'] ?? ''),
                'qr_enabled'    => !empty($_POST['qr_enabled']),
                'services'      => $services,
                'default_line'  => [
                    'desc'  => $services[0]['desc'][$docLang] ?? ($services[0]['desc']['en'] ?? ''),
                    'qty'   => (float) ($services[0]['qty'] ?? 1),
                    'price' => (float) ($services[0]['price'] ?? 0),
                ],
                'doc'           => is_array($editing['doc'] ?? null) ? $editing['doc'] : (fk_service_presets_seed()[0]['doc'] ?? []),
            ];

            $all = fk_load_service_presets();
            $found = false;
            foreach ($all as $i => $row) {
                if (($row['id'] ?? '') === $record['id']) {
                    $all[$i] = array_replace_recursive($row, $record);
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $all[] = $record;
            }

            if (fk_save_service_presets($all)) {
                if (!empty($_POST['set_default_factura'])) {
                    $settings = fk_load_settings();
                    $settings['default_service_preset'] = $record['id'];
                    fk_save_settings($settings);
                }
                if (!empty($_POST['sync_to_settings'])) {
                    fk_apply_service_preset_to_settings($record['id']);
                }
                $adm_saved = true;
                header('Location: ' . fk_admin_url('service-presets.php?edit=' . urlencode($record['id']) . '&saved=1'));
                exit;
            }
            $adm_error = $ta['save_failed'] ?? 'Could not save.';
        }
    }
}

if (!empty($_GET['saved'])) {
    $adm_saved = true;
}
$presets = fk_load_service_presets();
$editing = null;
foreach ($presets as $p) {
    if (($p['id'] ?? '') === $editId) {
        $editing = $p;
        break;
    }
}

$editing = is_array($editing) ? $editing : [];
$docLang = $editing['document_lang'] ?? 'lt';
$presetName = !empty($editing) ? fk_localized($editing, 'name', $docLang) : '';
$seller = $editing['seller'] ?? [];
$adm_extra_js = [fk_asset('js/admin-service-presets.js') . '?v=1'];

require __DIR__ . '/includes/layout.php';
?>

<?php if ($adm_error): ?><div class="adm-error"><?= fk_h($adm_error) ?></div><?php endif; ?>

<div class="adm-layout-split">
    <div class="adm-card adm-card--flush">
        <div class="adm-doc-head">
            <div class="adm-doc-head-text">
                <h2><i class="fas fa-list" aria-hidden="true"></i> <?= fk_h($ta['service_presets_list'] ?? 'Calculator presets') ?></h2>
                <p><?= fk_h($ta['service_presets_list_hint'] ?? 'Company, quick services and prices for calc.php.') ?></p>
            </div>
            <a href="<?= fk_admin_url('service-presets.php?edit=new') ?>" class="adm-btn adm-btn-primary adm-btn-sm">
                <i class="fas fa-plus" aria-hidden="true"></i> <?= fk_h($ta['preset_add'] ?? 'Add preset') ?>
            </a>
        </div>
        <?php if (empty($presets)): ?>
        <p class="adm-empty"><?= fk_h($ta['service_presets_empty'] ?? 'No presets yet.') ?></p>
        <?php else: ?>
        <div class="adm-table-wrap">
            <table class="adm-table">
                <thead>
                    <tr>
                        <th><?= fk_h($ta['preset_col_name'] ?? 'Name') ?></th>
                        <th><?= fk_h($ta['preset_col_services'] ?? 'Services') ?></th>
                        <th><?= fk_h($ta['preset_col_currency'] ?? 'Currency') ?></th>
                        <th><?= fk_h($ta['inv_actions'] ?? 'Actions') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($presets as $p): ?>
                    <tr>
                        <td>
                            <strong><?= fk_h(fk_localized($p, 'name', $lang)) ?></strong><br>
                            <span style="font-size:.78rem;color:var(--adm-muted)"><?= fk_h($p['id'] ?? '') ?></span>
                        </td>
                        <td><?= count($p['services'] ?? []) ?></td>
                        <td><?= fk_h($p['currency'] ?? 'EUR') ?></td>
                        <td class="adm-actions-cell">
                            <a href="<?= fk_admin_url('service-presets.php?edit=' . urlencode($p['id'] ?? '')) ?>" class="adm-btn adm-btn-ghost adm-btn-sm">
                                <i class="fas fa-pen" aria-hidden="true"></i> <?= fk_h($ta['edit'] ?? 'Edit') ?>
                            </a>
                            <a href="<?= fk_h(fk_url('calc.php?preset=' . urlencode($p['id'] ?? ''))) ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank" rel="noopener">
                                <i class="fas fa-calculator" aria-hidden="true"></i> <?= fk_h($ta['preview'] ?? 'Preview') ?>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($editId !== ''): ?>
    <form method="post" class="adm-card" id="adm-preset-form">
        <input type="hidden" name="preset_id" value="<?= fk_h($editId === 'new' ? '' : $editId) ?>">
        <h2><i class="fas fa-sliders" aria-hidden="true"></i> <?= fk_h($editId === 'new' ? ($ta['preset_add'] ?? 'Add preset') : ($ta['preset_edit'] ?? 'Edit preset')) ?></h2>

        <div class="adm-grid-2">
            <div class="adm-field">
                <label><?= fk_h($ta['preset_col_name'] ?? 'Name') ?></label>
                <input type="text" name="preset_name" value="<?= fk_h($presetName) ?>" required>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['preset_slug'] ?? 'ID (slug)') ?></label>
                <input type="text" name="preset_slug" value="<?= fk_h($editId === 'new' ? '' : $editId) ?>" placeholder="cleaning-lt" <?= $editId !== 'new' ? 'readonly' : '' ?>>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['document_lang'] ?? 'Document language') ?></label>
                <select name="document_lang">
                    <?php foreach (['lt' => 'LT', 'uk' => 'UA', 'en' => 'EN', 'pl' => 'PL', 'de' => 'DE', 'sv' => 'SV', 'no' => 'NO'] as $code => $label): ?>
                    <option value="<?= fk_h($code) ?>" <?= $docLang === $code ? 'selected' : '' ?>><?= fk_h($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['preset_col_currency'] ?? 'Currency') ?></label>
                <input type="text" name="currency" value="<?= fk_h($editing['currency'] ?? 'EUR') ?>" maxlength="3">
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['country_id'] ?? 'Country ID') ?></label>
                <input type="text" name="country_id" value="<?= fk_h($editing['country_id'] ?? 'lt') ?>">
            </div>
            <div class="adm-field">
                <label><input type="checkbox" name="active" value="1" <?= ($editId === 'new' || !empty($editing['active'])) ? 'checked' : '' ?>> <?= fk_h($ta['active'] ?? 'Active') ?></label>
            </div>
        </div>

        <h3 style="margin-top:1.25rem"><?= fk_h($ta['seller_block'] ?? 'Seller / company') ?></h3>
        <div class="adm-grid-2">
            <?php foreach (['name' => 'seller_name', 'org_nr' => 'seller_org_nr', 'license' => 'seller_license', 'address' => 'seller_address', 'bank' => 'seller_bank', 'iban' => 'seller_iban'] as $field => $input): ?>
            <div class="adm-field">
                <label><?= fk_h($t['invoice'][$field] ?? $field) ?></label>
                <input type="text" name="<?= fk_h($input) ?>" value="<?= fk_h($seller[$field] ?? '') ?>">
            </div>
            <?php endforeach; ?>
        </div>

        <h3 style="margin-top:1.25rem"><?= fk_h($ta['preset_services'] ?? 'Quick services & prices') ?></h3>
        <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 .75rem"><?= fk_h($ta['preset_services_hint'] ?? 'One-click buttons on the calculator. Name in document language above.') ?></p>
        <div id="adm-preset-services" class="adm-preset-services">
            <?php
            $svcRows = $editing['services'] ?? [['desc' => ['lt' => ''], 'qty' => 1, 'price' => 0]];
            foreach ($svcRows as $i => $svc):
                $svcName = is_array($svc['desc'] ?? null)
                    ? (string) ($svc['desc'][$docLang] ?? $svc['desc']['en'] ?? reset($svc['desc']) ?: '')
                    : (string) ($svc['desc'] ?? '');
            ?>
            <div class="adm-preset-service-row">
                <input type="text" name="services[<?= (int) $i ?>][name]" value="<?= fk_h($svcName) ?>" placeholder="<?= fk_h($ta['service_name_ph'] ?? 'Service name') ?>">
                <input type="number" name="services[<?= (int) $i ?>][qty]" value="<?= fk_h((string) ($svc['qty'] ?? 1)) ?>" min="0.01" step="0.01" title="<?= fk_h($t['invoice']['line_qty'] ?? 'Qty') ?>">
                <input type="number" name="services[<?= (int) $i ?>][price]" value="<?= fk_h((string) ($svc['price'] ?? 0)) ?>" min="0" step="0.01" title="<?= fk_h($t['invoice']['line_price'] ?? 'Price') ?>">
                <button type="button" class="adm-btn adm-btn-danger adm-btn-sm adm-svc-remove" aria-label="<?= fk_h($t['invoice']['remove_line'] ?? 'Remove') ?>"><i class="fas fa-trash"></i></button>
            </div>
            <?php endforeach; ?>
        </div>
        <button type="button" class="adm-btn adm-btn-ghost adm-btn-sm" id="adm-svc-add"><i class="fas fa-plus"></i> <?= fk_h($ta['service_add'] ?? 'Add service') ?></button>

        <h3 style="margin-top:1.25rem"><?= fk_h($ta['preset_payment'] ?? 'Payment link & QR') ?></h3>
        <div class="adm-field">
            <label><?= fk_h($ta['qr_payment_template'] ?? 'Payment URL template') ?></label>
            <input type="text" name="payment_url_template" value="<?= fk_h($editing['payment_url_template'] ?? '') ?>" placeholder="https://vipps.no/pay?amount={amount}&ref={invoice_no}">
            <p class="adm-field-hint"><?= fk_h($ta['qr_placeholders'] ?? '{amount}, {invoice_no}, {currency}, {reference}') ?></p>
        </div>
        <div class="adm-field">
            <label><input type="checkbox" name="qr_enabled" value="1" <?= ($editId === 'new' || !isset($editing['qr_enabled']) || !empty($editing['qr_enabled'])) ? 'checked' : '' ?>> <?= fk_h($ta['calc_qr_enabled'] ?? 'Show QR code on calculator') ?></label>
        </div>
        <div class="adm-field">
            <label><input type="checkbox" name="set_default_factura" value="1" <?= ($editId !== 'new' && $editId === $defaultFacturaPreset) ? 'checked' : '' ?>> <?= fk_h($ta['factura_set_default'] ?? 'Use as default for service calculator') ?></label>
        </div>
        <div class="adm-field">
            <label><input type="checkbox" name="sync_to_settings" value="1"> <?= fk_h($ta['factura_sync_settings'] ?? 'Sync seller to Admin → Settings (company & country)') ?></label>
        </div>
        <?php if ($editId !== 'new'): ?>
        <p style="font-size:.85rem;color:var(--adm-muted)">
            <a href="<?= fk_h(fk_url('calc.php?preset=' . urlencode($editId))) ?>" target="_blank" rel="noopener"><?= fk_h($ta['factura_preview'] ?? 'Preview service calculator') ?></a>
        </p>
        <?php endif; ?>

        <div style="display:flex;flex-wrap:wrap;gap:.5rem;margin-top:1rem">
            <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-save"></i> <?= fk_h($ta['save'] ?? 'Save') ?></button>
            <?php if ($editId !== 'new'): ?>
            <button type="submit" name="action" value="delete" class="adm-btn adm-btn-danger" onclick="return confirm('<?= fk_h($ta['preset_delete_confirm'] ?? 'Delete this preset?') ?>')">
                <i class="fas fa-trash"></i> <?= fk_h($ta['delete'] ?? 'Delete') ?>
            </button>
            <?php endif; ?>
            <a href="<?= fk_admin_url('service-presets.php') ?>" class="adm-btn adm-btn-ghost"><?= fk_h($ta['cancel'] ?? 'Cancel') ?></a>
        </div>
    </form>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>