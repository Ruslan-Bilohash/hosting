<?php
require_once __DIR__ . '/init.php';
require_once dirname(__DIR__) . '/includes/cms-contact.php';

$current_page = 'contact';
$product = 'faktura';
$cms_t = cms_contact_texts($product, $lang);
$cms_alert = '';
$cms_alert_type = '';
$cms_values = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postLang = trim((string) ($_POST['lang'] ?? $lang));
    $result = cms_contact_handle_post($product, $postLang, 'https://bilohash.com/faktura/contact.php');
    $cms_alert = $result['alert'];
    $cms_alert_type = $result['alert_type'];
    $cms_values = $result['values'];
}

$cms_csrf = cms_contact_ensure_csrf();
$page_title = $cms_t['page_title'];
$page_desc = $cms_t['meta_description'];
$canonicalQs = $lang !== 'en' ? '?lang=' . urlencode($lang) : '';
$canonical = $site_url . '/contact.php' . $canonicalQs;
$cms_prefix = 'fk';
$cms_embedded = true;
$cms_action = fk_url('contact.php') . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');

require __DIR__ . '/includes/header.php';
?>

<div class="fk-hero fk-hero--compact">
    <nav class="fk-breadcrumb" aria-label="Breadcrumb">
        <a href="<?= fk_h(fk_url('index.php')) ?>"><?= fk_h($t['breadcrumb_home'] ?? 'Home') ?></a>
        <span aria-hidden="true">→</span>
        <span><?= fk_h($cms_t['h1']) ?></span>
    </nav>
    <h1><i class="fas fa-envelope" aria-hidden="true"></i> <?= fk_h($cms_t['h1']) ?></h1>
    <p class="fk-text-muted"><?= fk_h($cms_t['subtitle']) ?></p>
</div>

<div class="fk-contact-wrap">
    <div class="fk-contact-layout">
        <?php require __DIR__ . '/includes/contact-channels.php'; ?>
        <div class="fk-contact-form-col">
            <?php require dirname(__DIR__) . '/includes/cms-contact-form.php'; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>