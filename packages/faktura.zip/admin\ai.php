<?php
require_once __DIR__ . '/init.php';

$ta = $t['admin'] ?? [];
$adm_title = $ta['ai_title'] ?? 'AI assistant';
$adm_nav_active = 'ai';
$settings = fk_load_settings();
$adm_saved = false;
$providers = fk_ai_providers();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $provider = trim($_POST['ai_provider'] ?? 'openai');
    if (!isset($providers[$provider])) {
        $provider = 'openai';
    }
    $model = trim($_POST['ai_model'] ?? '');
    if ($model === '' && !empty($_POST['ai_model_select'])) {
        $model = trim($_POST['ai_model_select']);
    }
    $settings['ai'] = array_merge($settings['ai'] ?? [], [
        'enabled'              => !empty($_POST['ai_enabled']),
        'provider'             => $provider,
        'api_base'             => rtrim(trim($_POST['ai_api_base'] ?? $providers[$provider]['api_base']), '/'),
        'model'                => $model !== '' ? $model : ($providers[$provider]['models'][0] ?? 'gpt-4o-mini'),
        'prompt_email_note'    => trim($_POST['ai_prompt_email_note'] ?? ''),
        'prompt_email_subject' => trim($_POST['ai_prompt_email_subject'] ?? ''),
        'prompt_invoice_notes' => trim($_POST['ai_prompt_invoice_notes'] ?? ''),
    ]);
    if (trim($_POST['ai_api_key'] ?? '') !== '') {
        $settings['ai']['api_key'] = $_POST['ai_api_key'];
    }
    fk_save_settings($settings);
    $adm_saved = true;
}

$ai = $settings['ai'] ?? [];
$resolved = fk_ai_resolve_config($ai);
$adm_extra_js = [
    fk_asset('js/admin-ai.js') . '?v=1',
];

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card">
    <h2><i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i> <?= fk_h($ta['ai_title'] ?? 'AI assistant') ?></h2>
    <p class="adm-card-lead"><?= fk_h($ta['ai_hint'] ?? 'Generate email notes, subjects and invoice payment text via OpenAI or xAI Grok. Without API key — smart templates per language.') ?></p>
    <form method="post" id="ai-settings-form">
        <div class="adm-field">
            <label><input type="checkbox" name="ai_enabled" value="1" <?= !empty($ai['enabled']) ? 'checked' : '' ?>> <?= fk_h($ta['ai_enabled'] ?? 'Enable AI generation') ?></label>
        </div>
        <div class="adm-grid-2">
            <div class="adm-field">
                <label for="ai-provider"><?= fk_h($ta['ai_provider'] ?? 'Provider') ?></label>
                <select name="ai_provider" id="ai-provider">
                    <?php foreach ($providers as $key => $preset): ?>
                    <option value="<?= fk_h($key) ?>" <?= ($ai['provider'] ?? 'openai') === $key ? 'selected' : '' ?>><?= fk_h($preset['label']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label for="ai-model-select"><?= fk_h($ta['ai_model'] ?? 'Model') ?></label>
                <select name="ai_model_select" id="ai-model-select"></select>
                <input type="text" name="ai_model" id="ai-model-custom" class="adm-model-custom" value="<?= fk_h($resolved['model']) ?>" placeholder="<?= fk_h($ta['ai_model_custom'] ?? 'Custom model name') ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['ai_api_base'] ?? 'API base URL') ?></label>
                <input type="url" name="ai_api_base" value="<?= fk_h($resolved['api_base']) ?>" placeholder="https://api.openai.com/v1">
                <p class="adm-field-hint"><?= fk_h($ta['ai_api_base_hint'] ?? 'OpenAI: api.openai.com/v1 · Grok: api.x.ai/v1') ?></p>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['ai_api_key'] ?? 'API key') ?></label>
                <input type="password" name="ai_api_key" value="" placeholder="<?= !empty($ai['api_key']) ? '••••••••' : '' ?>" autocomplete="new-password">
                <p class="adm-field-hint"><?= fk_h($ta['ai_api_key_hint'] ?? 'Leave blank to keep current key. Stored in settings.json.') ?></p>
            </div>
        </div>
        <div class="adm-field">
            <label><?= fk_h($ta['ai_prompt_email_note'] ?? 'Prompt: email personal note') ?></label>
            <textarea name="ai_prompt_email_note" rows="3"><?= fk_h($ai['prompt_email_note'] ?? '') ?></textarea>
            <p class="adm-field-hint"><?= fk_h($ta['ai_placeholders'] ?? 'Placeholders: {client_name}, {invoice_no}, {total}, {currency}, {due_date}, {company}, {lang}') ?></p>
        </div>
        <div class="adm-field">
            <label><?= fk_h($ta['ai_prompt_email_subject'] ?? 'Prompt: email subject') ?></label>
            <textarea name="ai_prompt_email_subject" rows="2"><?= fk_h($ai['prompt_email_subject'] ?? '') ?></textarea>
        </div>
        <div class="adm-field">
            <label><?= fk_h($ta['ai_prompt_invoice_notes'] ?? 'Prompt: invoice notes / payment terms') ?></label>
            <textarea name="ai_prompt_invoice_notes" rows="2"><?= fk_h($ai['prompt_invoice_notes'] ?? '') ?></textarea>
            <p class="adm-field-hint"><?= fk_h($ta['ai_placeholders_iban'] ?? 'Also: {iban}') ?></p>
        </div>
        <button type="submit" class="adm-btn adm-btn-primary" style="width:auto"><i class="fas fa-save"></i> <?= fk_h($ta['save'] ?? 'Save') ?></button>
        <a href="<?= fk_url('help.php#ai') ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank"><i class="fas fa-book"></i> <?= fk_h($ta['ai_help_link'] ?? 'Setup instructions') ?></a>
    </form>
</div>

<div class="adm-card">
    <h2><?= fk_h($ta['ai_usage_title'] ?? 'Where to use AI') ?></h2>
    <ul class="adm-muted-list">
        <li><?= fk_h($ta['ai_usage_send'] ?? 'Admin → Send email — “Generate with AI” for personal note') ?></li>
        <li><?= fk_h($ta['ai_usage_create'] ?? 'Create invoice — “AI notes” button for payment terms') ?></li>
        <li><?= fk_h($ta['ai_usage_demo'] ?? 'Without API key: multilingual template text (demo mode)') ?></li>
        <li><?= fk_h($ta['ai_usage_grok'] ?? 'Grok: use xAI API key and pick grok-3-mini or grok-3 in model list.') ?></li>
    </ul>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>