<?php

/**
 * Shared invoice HTML for preview, saved view & print.
 *
 * @param array<string, mixed> $inv
 * @param array<string, string> $ti
 */
function fk_render_invoice_article(array $inv, array $ti, string $currency, string $design, string $format, bool $wrap = true, ?array $settings = null): void
{
    $seller = $inv['seller'] ?? [];
    $buyer = $inv['buyer'] ?? [];
    $lines = $inv['lines'] ?? [];
    $totals = $inv['totals'] ?? [];
    $classes = fk_print_classes($design, $format);
    $tagOpen = $wrap ? '<article class="fk-preview ' . fk_h($classes) . '"' : '<div class="fk-preview-inner"';
    echo $wrap ? $tagOpen . ' id="fk-preview">' : $tagOpen . '>';
    ?>
    <div class="fk-preview-header">
        <div class="fk-preview-brand">
            <strong class="fk-preview-title"><?= fk_h($seller['name'] ?? ($ti['preview'] ?? 'Invoice')) ?></strong>
            <div class="fk-tax-badge fk-print-design-badge" aria-hidden="true"></div>
        </div>
        <div class="fk-preview-meta">
            <div><strong><?= fk_h($ti['invoice_no'] ?? 'No.') ?>:</strong> <span class="fk-meta-inv-no"><?= fk_h($inv['invoice_no'] ?? '') ?></span></div>
            <div><strong><?= fk_h($ti['invoice_date'] ?? 'Date') ?>:</strong> <span class="fk-meta-inv-date"><?= fk_h($inv['invoice_date'] ?? '') ?></span></div>
            <div><strong><?= fk_h($ti['due_date'] ?? 'Due') ?>:</strong> <span class="fk-meta-due-date"><?= fk_h($inv['due_date'] ?? '') ?></span></div>
        </div>
    </div>
    <div class="fk-grid fk-grid--2 fk-preview-parties">
        <div class="fk-preview-party fk-preview-seller">
            <strong><?= fk_h($ti['seller'] ?? 'Seller') ?></strong>
            <?php foreach (['name','org_nr','vat_nr','address','city','postal','country','email','phone','bank','iban','bic'] as $f): ?>
                <?php if (!empty($seller[$f])): ?><div><?= fk_h($seller[$f]) ?></div><?php endif; ?>
            <?php endforeach; ?>
        </div>
        <div class="fk-preview-party fk-preview-buyer">
            <strong><?= fk_h($ti['buyer'] ?? 'Buyer') ?></strong>
            <?php foreach (['name','org_nr','vat_nr','address','city','postal','country','email','phone'] as $f): ?>
                <?php if (!empty($buyer[$f])): ?><div><?= fk_h($buyer[$f]) ?></div><?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
    <table class="fk-preview-table">
        <thead>
            <tr>
                <th><?= fk_h($ti['line_desc'] ?? 'Description') ?></th>
                <th><?= fk_h($ti['line_qty'] ?? 'Qty') ?></th>
                <th><?= fk_h($ti['line_price'] ?? 'Price') ?></th>
                <th><?= fk_h($ti['line_total'] ?? 'Total') ?></th>
                <?php if (!empty(array_filter($lines, static fn($l) => trim((string) ($l['pay_url'] ?? '')) !== ''))): ?>
                <th><?= fk_h($ti['pay_btn'] ?? 'Pay') ?></th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody class="fk-preview-lines-body">
            <?php
            $hasLinePay = !empty(array_filter($lines, static fn($l) => trim((string) ($l['pay_url'] ?? '')) !== ''));
            $payBtnLabel = $ti['pay_btn'] ?? 'Pay';
            foreach ($lines as $line):
                $sum = (float) ($line['qty'] ?? 0) * (float) ($line['price'] ?? 0);
                $linePay = trim((string) ($line['pay_url'] ?? ''));
            ?>
            <tr>
                <td><?= fk_h($line['desc'] ?? '') ?></td>
                <td><?= fk_h((string) ($line['qty'] ?? '')) ?> <?= fk_h($line['unit'] ?? '') ?></td>
                <td><?= fk_h(fk_money((float) ($line['price'] ?? 0), $currency)) ?></td>
                <td><?= fk_h(fk_money($sum, $currency)) ?></td>
                <?php if ($hasLinePay): ?>
                <td class="fk-line-pay-cell">
                    <?php if ($linePay !== ''): ?>
                    <a href="<?= fk_h($linePay) ?>" class="fk-pay-btn fk-pay-btn--sm" target="_blank" rel="noopener noreferrer"><?= fk_h($payBtnLabel) ?></a>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="fk-totals">
        <div><span><?= fk_h($ti['subtotal'] ?? 'Subtotal') ?></span><span class="fk-sum-subtotal"><?= fk_h(fk_money((float) ($totals['subtotal'] ?? 0), $currency)) ?></span></div>
        <?php if (!empty($totals['tax_amount']) && (float) ($totals['tax_rate'] ?? 0) > 0): ?>
        <div class="fk-sum-tax-row">
            <span class="fk-sum-tax-label"><?= fk_h($totals['tax_label'] ?? ($ti['tax'] ?? 'Tax')) ?> (<?= fk_h((string) ($totals['tax_rate'] ?? 0)) ?>%)</span>
            <span class="fk-sum-tax"><?= fk_h(fk_money((float) ($totals['tax_amount'] ?? 0), $currency)) ?></span>
        </div>
        <?php endif; ?>
        <div class="fk-total-final"><span><?= fk_h($ti['total'] ?? 'Total') ?></span><span class="fk-sum-total"><?= fk_h(fk_money((float) ($totals['total'] ?? 0), $currency)) ?></span></div>
    </div>
    <div class="fk-preview-payment"><?php
        $payParts = [];
        if (!empty($seller['iban']) || !empty($seller['bank'])) {
            $pay = ($ti['payment'] ?? 'Payment') . ': ';
            if (!empty($seller['bank'])) $pay .= $seller['bank'] . ' ';
            if (!empty($seller['iban'])) $pay .= 'IBAN ' . $seller['iban'];
            $payParts[] = $pay;
        }
        if (!empty($inv['payment_purpose'])) {
            $payParts[] = '<strong>' . fk_h($ti['payment_purpose'] ?? 'Reference') . ':</strong> ' . fk_h($inv['payment_purpose']);
        }
        echo implode('<br>', $payParts);
        if ($settings !== null) {
            $payUrl = fk_resolve_payment_url($inv, $settings);
            if ($payUrl !== '') {
                echo '<div style="margin-top:.65rem"><a href="' . fk_h($payUrl) . '" class="fk-pay-btn fk-pay-btn--invoice" target="_blank" rel="noopener noreferrer">'
                    . fk_h($ti['pay_now'] ?? 'Pay now') . '</a></div>';
            }
        }
    ?></div>
    <div class="fk-preview-footer">
        <?php if (!empty($inv['notes'])): ?>
        <p class="fk-preview-notes"><?= fk_h($inv['notes']) ?></p>
        <?php else: ?>
        <p class="fk-preview-notes"></p>
        <?php endif; ?>
        <?php
        if ($settings !== null) {
            $qrLabel = $ti['qr_scan'] ?? 'Scan to pay or view';
            fk_render_invoice_qr($inv, $settings, (string) ($inv['id'] ?? ''), $qrLabel);
        }
        ?>
    </div>
    <?php
    fk_render_print_demo_mark();
    echo $wrap ? '</article>' : '</div>';
}