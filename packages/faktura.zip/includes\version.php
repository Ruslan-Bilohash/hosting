<?php
/**
 * Faktura Creator — single source of truth for script version.
 */
define('FK_VERSION', '1.0.1');
define('FK_VERSION_DATE', '2026-07-10');

function fk_version(): string
{
    return FK_VERSION;
}

function fk_version_label(): string
{
    return 'v' . FK_VERSION;
}