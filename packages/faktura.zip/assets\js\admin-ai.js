(function () {
    'use strict';

    var providers = {
        openai: { api_base: 'https://api.openai.com/v1', models: ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1'] },
        grok: { api_base: 'https://api.x.ai/v1', models: ['grok-3-mini', 'grok-3', 'grok-2-latest', 'grok-beta'] },
        compatible: { api_base: 'https://api.openai.com/v1', models: [] }
    };

    var providerSel = document.getElementById('ai-provider');
    var modelSel = document.getElementById('ai-model-select');
    var modelCustom = document.getElementById('ai-model-custom');
    var baseInput = document.querySelector('input[name="ai_api_base"]');
    if (!providerSel || !modelSel) return;

    function fillModels(provider, keepValue) {
        var preset = providers[provider] || providers.openai;
        modelSel.innerHTML = '';
        var models = preset.models.slice();
        if (keepValue && models.indexOf(keepValue) === -1) {
            models.unshift(keepValue);
        }
        if (!models.length) {
            var opt = document.createElement('option');
            opt.value = '';
            opt.textContent = '— Custom —';
            modelSel.appendChild(opt);
            if (modelCustom) modelCustom.style.display = '';
            return;
        }
        models.forEach(function (m) {
            var o = document.createElement('option');
            o.value = m;
            o.textContent = m;
            modelSel.appendChild(o);
        });
        if (keepValue && models.indexOf(keepValue) !== -1) {
            modelSel.value = keepValue;
        }
        if (modelCustom) modelCustom.style.display = 'none';
    }

    function syncFromProvider() {
        var p = providerSel.value || 'openai';
        var preset = providers[p] || providers.openai;
        if (baseInput && (!baseInput.dataset.userEdited || baseInput.value === '')) {
            baseInput.value = preset.api_base;
        }
        var current = modelCustom && modelCustom.style.display !== 'none' ? modelCustom.value : modelSel.value;
        fillModels(p, current);
        if (modelCustom) modelCustom.value = modelSel.value || current;
    }

    providerSel.addEventListener('change', function () {
        if (baseInput) delete baseInput.dataset.userEdited;
        syncFromProvider();
    });

    modelSel.addEventListener('change', function () {
        if (modelCustom) modelCustom.value = modelSel.value;
    });

    if (baseInput) {
        baseInput.addEventListener('input', function () {
            baseInput.dataset.userEdited = '1';
        });
    }

    syncFromProvider();
})();