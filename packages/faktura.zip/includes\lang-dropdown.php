<?php
/**
 * Language dropdown — site & admin. Expects $lang, $FK_LANGS, $t.
 */
$fk_dd_id = $fk_dd_id ?? 'fkLang';
$fk_dd_variant = $fk_dd_variant ?? '';
$fk_dd_url_fn = $fk_dd_url_fn ?? 'fk_lang_url';
$current = $FK_LANGS[$lang] ?? $FK_LANGS['en'];
$menuLabel = $t['nav']['lang_menu'] ?? 'Language';
$ddClass = 'fk-lang-dropdown';
if ($fk_dd_variant === 'admin') {
    $ddClass .= ' fk-lang-dropdown--admin';
}
if ($fk_dd_variant === 'mobile') {
    $ddClass .= ' fk-lang-dropdown--mobile';
}
$btnId = $fk_dd_id . 'Btn';
$menuId = $fk_dd_id . 'Menu';
?>
<div class="<?= fk_h($ddClass) ?>" id="<?= fk_h($fk_dd_id) ?>Dropdown">
    <button type="button"
            class="fk-lang-dropdown-btn"
            id="<?= fk_h($btnId) ?>"
            aria-expanded="false"
            aria-haspopup="listbox"
            aria-controls="<?= fk_h($menuId) ?>"
            aria-label="<?= fk_h($menuLabel) ?>">
        <span class="fk-lang-dropdown-current" aria-hidden="true"><?= $current['flag'] ?></span>
        <span class="fk-lang-dropdown-label"><?= fk_h($current['label']) ?></span>
        <i class="fas fa-chevron-down" aria-hidden="true"></i>
    </button>
    <ul class="fk-lang-dropdown-menu" id="<?= fk_h($menuId) ?>" role="listbox" hidden>
        <?php foreach (fk_langs() as $code => $info):
            $urlFn = $fk_dd_url_fn;
            $href = $urlFn($code);
        ?>
        <li role="option">
            <a href="<?= fk_h($href) ?>"
               class="<?= $lang === $code ? 'active' : '' ?>"
               <?= $lang === $code ? 'aria-current="true"' : '' ?>>
                <span class="fk-lang-flag" aria-hidden="true"><?= $info['flag'] ?></span>
                <span class="fk-lang-name"><?= fk_h($info['name']) ?></span>
                <span class="fk-lang-code"><?= fk_h($info['label']) ?></span>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
</div>