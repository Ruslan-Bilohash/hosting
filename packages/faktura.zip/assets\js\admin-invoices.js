(function () {
    'use strict';

    var search = document.getElementById('adm-doc-search');
    var grid = document.getElementById('adm-doc-grid');
    var tableWrap = document.getElementById('adm-doc-table');
    var resultEl = document.getElementById('adm-doc-result');
    if (!search || !grid) return;

    var cards = Array.prototype.slice.call(grid.querySelectorAll('.adm-doc-card'));
    var rows = tableWrap ? Array.prototype.slice.call(tableWrap.querySelectorAll('.adm-doc-row')) : [];
    var filter = 'all';
    var view = window.localStorage.getItem('fk_adm_inv_view');
    if (!view) {
        view = window.matchMedia('(min-width: 900px)').matches ? 'cards' : 'table';
    }

    function setView(mode) {
        view = mode;
        window.localStorage.setItem('fk_adm_inv_view', mode);
        var isTable = mode === 'table';
        grid.hidden = isTable;
        if (tableWrap) tableWrap.hidden = !isTable;
        document.querySelectorAll('.adm-view-btn').forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-view') === mode);
        });
    }

    function matchItem(el) {
        var demo = el.getAttribute('data-demo') === '1';
        if (filter === 'demo' && !demo) return false;
        var q = search.value.trim().toLowerCase();
        if (q === '') return true;
        return (el.getAttribute('data-search') || '').indexOf(q) !== -1;
    }

    function applyFilters() {
        var visible = 0;
        cards.forEach(function (card) {
            var show = matchItem(card);
            card.hidden = !show;
            if (show) visible++;
        });
        rows.forEach(function (row) {
            var show = matchItem(row);
            row.hidden = !show;
        });
        if (resultEl) {
            resultEl.textContent = visible + ' / ' + cards.length;
        }
    }

    document.querySelectorAll('.adm-filter-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            filter = btn.getAttribute('data-filter') || 'all';
            document.querySelectorAll('.adm-filter-btn').forEach(function (b) {
                b.classList.toggle('active', b === btn);
            });
            applyFilters();
        });
    });

    document.querySelectorAll('.adm-view-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            setView(btn.getAttribute('data-view') || 'cards');
        });
    });

    search.addEventListener('input', applyFilters);

    setView(view);
    applyFilters();
})();