<?php
require_once __DIR__ . '/init.php';

$settings = fk_load_settings();
$templates = fk_load_templates();
$countries = fk_active_countries($settings);
$countryIds = array_column($countries, 'id');
$requestedCountry = trim((string) ($_GET['country'] ?? ''));
$defaultCountry = $settings['default_country'] ?? 'en';
if ($requestedCountry !== '' && in_array($requestedCountry, $countryIds, true)) {
    $defaultCountry = $requestedCountry;
}
$company = fk_company_for_country($settings, $defaultCountry);
$inv = $t['invoice'];

$invoiceNo = ($settings['invoice_prefix'] ?? 'INV') . '-' . ($settings['next_number'] ?? 1001);
$invoiceDate = date('Y-m-d');
$dueDate = date('Y-m-d', strtotime('+14 days'));

$clientsList = fk_load_clients();
$clientsJson = array_map(static function (array $c) {
    return ['id' => $c['id'] ?? '', 'name' => $c['name'] ?? '', 'buyer' => fk_client_to_buyer($c)];
}, $clientsList);

$countriesJson = array_map(static function (array $c) use ($settings, $lang) {
    $row = $c;
    $row['company_override'] = fk_company_for_country($settings, $c['id'] ?? '');
    return $row;
}, $countries);

$aiProvider = fk_ai_referral_provider();
$aiProviders = fk_ai_providers();

$current_page = 'create';
$page_title = ($t['create']['title'] ?? $inv['title']) . ' — Faktura Creator';
$page_desc = $t['create']['meta_desc'] ?? $inv['subtitle'];
$canonicalQs = [];
if ($lang !== 'en') {
    $canonicalQs['lang'] = $lang;
}
if ($requestedCountry !== '' && in_array($requestedCountry, $countryIds, true)) {
    $canonicalQs['country'] = $requestedCountry;
}
$canonical = $site_url . '/create.php' . ($canonicalQs ? '?' . http_build_query($canonicalQs) : '');
$printDesign = fk_normalize_print_design($settings['print_design'] ?? 'classic-blue');
$printFormat = fk_normalize_print_format($settings['print_format'] ?? 'a4');
$qrSettings = $settings['qr'] ?? [];
$previewClasses = fk_print_classes($printDesign, $printFormat);
$extra_css = [
    fk_asset('css/print.css') . '?v=4',
    fk_asset('css/print-demo.css') . '?v=1',
];
$extra_js = [fk_asset('js/invoice.js') . '?v=6'];

require __DIR__ . '/includes/header.php';
?>

<?php if ($aiProvider !== ''): ?>
<div class="fk-ai-referral-banner" role="status">
    <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
    <span><?= fk_h(str_replace('{provider}', $aiProviders[$aiProvider]['label'] ?? $aiProvider, $inv['ai_referral_banner'] ?? 'Create invoice with {provider} AI — use “AI notes” below.')) ?></span>
</div>
<?php endif; ?>

<div class="fk-hero">
    <h1><?= fk_h($inv['title']) ?></h1>
    <p><?= fk_h($inv['subtitle']) ?></p>
    <div class="fk-features">
        <div class="fk-feature"><i class="fas fa-globe-europe" aria-hidden="true"></i><span><?= fk_h($t['features']['countries'] ?? '7 countries — VAT / MVA rates') ?></span></div>
        <div class="fk-feature"><i class="fas fa-save" aria-hidden="true"></i><span><?= fk_h($t['features']['save'] ?? 'Save invoices — view & print later') ?></span></div>
        <div class="fk-feature"><i class="fas fa-mobile-alt" aria-hidden="true"></i><span><?= fk_h($t['features']['responsive'] ?? 'Phone, tablet & desktop layout') ?></span></div>
        <div class="fk-feature"><i class="fas fa-book" aria-hidden="true"></i><span><a href="<?= fk_url('help.php') ?>"><?= fk_h($t['nav']['help'] ?? 'Help') ?></a> — <?= fk_h($t['features']['help_langs'] ?? 'instructions in 7 languages') ?></span></div>
    </div>
</div>

<div class="fk-grid fk-grid--main">
    <div class="fk-form-panel">
        <div class="fk-card">
            <h2><?= fk_h($inv['country']) ?></h2>
            <div class="fk-field-row">
                <div class="fk-field">
                    <label for="fk-country"><?= fk_h($inv['country']) ?></label>
                    <select id="fk-country" name="country">
                        <?php foreach ($countries as $c): ?>
                        <option value="<?= fk_h($c['id']) ?>" <?= ($c['id'] === $defaultCountry) ? 'selected' : '' ?>>
                            <?= fk_h(fk_localized($c, 'name', $lang)) ?>
                            (<?= (float)($c['tax_mode'] === 'single' ? $c['single_tax_rate'] : $c['vat_rate']) ?>%)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="fk-field">
                    <label for="fk-template"><?= fk_h($inv['template']) ?></label>
                    <select id="fk-template" name="template">
                        <option value=""><?= fk_h($inv['template_none']) ?></option>
                    </select>
                </div>
            </div>
            <div class="fk-field-row fk-field-row--3">
                <div class="fk-field">
                    <label for="invoice_no"><?= fk_h($inv['invoice_no']) ?></label>
                    <input type="text" id="invoice_no" value="<?= fk_h($invoiceNo) ?>">
                </div>
                <div class="fk-field">
                    <label for="invoice_date"><?= fk_h($inv['invoice_date']) ?></label>
                    <input type="date" id="invoice_date" value="<?= fk_h($invoiceDate) ?>">
                </div>
                <div class="fk-field">
                    <label for="due_date"><?= fk_h($inv['due_date']) ?></label>
                    <input type="date" id="due_date" value="<?= fk_h($dueDate) ?>">
                </div>
            </div>
        </div>

        <div class="fk-grid fk-grid--2" style="margin-top:1.25rem">
            <div class="fk-card">
                <h2><?= fk_h($inv['seller']) ?></h2>
                <?php foreach (['name','org_nr','vat_nr','address','city','postal','country','email','phone','bank','iban','bic'] as $f): ?>
                <div class="fk-field">
                    <label for="seller_<?= $f ?>"><?= fk_h($inv[$f] ?? $f) ?></label>
                    <input type="text" id="seller_<?= $f ?>" class="fk-company-input" value="<?= fk_h($company[$f] ?? '') ?>">
                </div>
                <?php endforeach; ?>
            </div>
            <div class="fk-card">
                <h2><?= fk_h($inv['buyer']) ?></h2>
                <?php if (!empty($clientsList)): ?>
                <div class="fk-field">
                    <label for="fk-client"><?= fk_h($inv['pick_client'] ?? 'Select client') ?></label>
                    <select id="fk-client" class="fk-no-print">
                        <option value=""><?= fk_h($inv['pick_client_none'] ?? '— Manual —') ?></option>
                        <?php foreach ($clientsList as $cl): ?>
                        <option value="<?= fk_h($cl['id'] ?? '') ?>"><?= fk_h($cl['name'] ?? '') ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size:.72rem;color:var(--fk-muted);margin:.35rem 0 0"><?= fk_h($inv['mobile_hint'] ?? '') ?></p>
                </div>
                <?php endif; ?>
                <?php
                $buyerDemo = ['name' => '', 'org_nr' => '', 'vat_nr' => '', 'address' => '', 'city' => '', 'postal' => '', 'country' => '', 'email' => '', 'phone' => '', 'bank' => '', 'iban' => '', 'bic' => ''];
                foreach (['name','org_nr','vat_nr','address','city','postal','country','email','phone'] as $f): ?>
                <div class="fk-field">
                    <label for="buyer_<?= $f ?>"><?= fk_h($inv[$f] ?? $f) ?></label>
                    <input type="text" id="buyer_<?= $f ?>" class="fk-company-input" value="<?= fk_h($buyerDemo[$f] ?? '') ?>">
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="fk-card" style="margin-top:1.25rem">
            <h2><?= fk_h($inv['lines_title']) ?></h2>
            <div id="fk-quick-add" class="fk-quick-add fk-no-print" hidden>
                <span class="fk-quick-label"><?= fk_h($inv['quick_add'] ?? 'Quick add') ?>:</span>
                <div id="fk-quick-buttons" class="fk-quick-buttons"></div>
                <p class="fk-wireframe-link" style="margin:.65rem 0 0;font-size:.78rem;color:var(--fk-muted)">
                    <a href="<?= fk_h(fk_url('calc.php')) ?>"><i class="fas fa-calculator" aria-hidden="true"></i> <?= fk_h($t['nav']['calc'] ?? 'Service calculator') ?></a>
                    — <?= fk_h($t['calc']['subtitle'] ?? 'Quick service quote with save & print.') ?>
                </p>
            </div>
            <div class="fk-lines-wrap">
                <table class="fk-lines-table">
                    <thead>
                        <tr>
                            <th><?= fk_h($inv['line_desc']) ?></th>
                            <th><?= fk_h($inv['line_qty']) ?></th>
                            <th><?= fk_h($inv['line_unit']) ?></th>
                            <th><?= fk_h($inv['line_price']) ?></th>
                            <th><?= fk_h($inv['line_total']) ?></th>
                            <th><?= fk_h($inv['line_pay_url'] ?? 'Payment link') ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="fk-lines-body"></tbody>
                </table>
            </div>
            <div class="fk-actions fk-no-print">
                <button type="button" class="fk-btn fk-btn-ghost" id="fk-add-line"><i class="fas fa-plus"></i> <?= fk_h($inv['add_line']) ?></button>
            </div>
            <div class="fk-field" style="margin-top:1rem">
                <label for="payment_purpose"><?= fk_h($inv['payment_purpose'] ?? 'Payment reference') ?></label>
                <input type="text" id="payment_purpose" class="fk-company-input" value="">
            </div>
            <div class="fk-field fk-no-print">
                <label for="payment_url"><?= fk_h($inv['payment_url'] ?? 'Payment link (invoice)') ?></label>
                <input type="url" id="payment_url" class="fk-company-input" placeholder="<?= fk_h($inv['payment_url_ph'] ?? 'https://… payment link') ?>">
                <p style="font-size:.72rem;color:var(--fk-muted);margin:.35rem 0 0"><?= fk_h($inv['payment_url_hint'] ?? 'Pay now button on invoice preview and print.') ?></p>
            </div>
            <div class="fk-field">
                <label for="notes"><?= fk_h($inv['notes']) ?></label>
                <textarea id="notes" rows="2" placeholder="<?= fk_h($inv['notes_placeholder']) ?>"><?= fk_h($inv['notes_placeholder']) ?></textarea>
                <button type="button" class="fk-btn fk-btn-ghost fk-btn-sm fk-no-print" id="fk-ai-notes" style="margin-top:.5rem"><i class="fas fa-wand-magic-sparkles"></i> <?= fk_h($inv['ai_notes_btn'] ?? 'AI notes') ?></button>
                <span id="fk-ai-notes-status" class="fk-no-print" style="font-size:.72rem;color:var(--fk-muted);margin-left:.5rem"></span>
            </div>
        </div>
    </div>

    <div class="fk-preview-col">
        <div class="fk-card fk-no-print" style="margin-bottom:1rem">
            <div id="fk-save-alert" class="fk-alert fk-alert-ok" hidden role="status"></div>
            <div class="fk-actions">
                <button type="button" class="fk-btn fk-btn-success" id="fk-save"><i class="fas fa-save"></i> <?= fk_h($inv['save'] ?? 'Save invoice') ?></button>
                <button type="button" class="fk-btn fk-btn-primary" id="fk-print"><i class="fas fa-print"></i> <?= fk_h($inv['print']) ?></button>
            </div>
            <span class="fk-tax-badge" id="fk-tax-badge"></span>
            <div class="fk-print-options">
                <h3><?= fk_h($inv['print_design'] ?? 'Print design') ?></h3>
                <?php fk_render_design_picker('print_design_ui', $printDesign, $lang); ?>
                <h3 style="margin-top:.75rem"><?= fk_h($inv['print_format'] ?? 'Paper format') ?></h3>
                <?php fk_render_format_select('print_format_ui', $printFormat, $lang, 'fk-print-format'); ?>
            </div>
        </div>
        <div class="fk-preview fk-preview-sticky <?= fk_h($previewClasses) ?>" id="fk-preview">
            <div class="fk-preview-header">
                <div>
                    <strong style="font-size:1.25rem"><?= fk_h($t['meta']['site_name']) ?></strong>
                    <div class="fk-tax-badge" id="fk-tax-badge-preview" aria-hidden="true"></div>
                </div>
                <div class="fk-preview-meta">
                    <div><strong><?= fk_h($inv['invoice_no']) ?>:</strong> <span id="fk-preview-inv-no"></span></div>
                    <div><strong><?= fk_h($inv['invoice_date']) ?>:</strong> <span id="fk-preview-inv-date"></span></div>
                    <div><strong><?= fk_h($inv['due_date']) ?>:</strong> <span id="fk-preview-due-date"></span></div>
                </div>
            </div>
            <div class="fk-grid fk-grid--2">
                <div class="fk-preview-party" id="fk-preview-seller"></div>
                <div class="fk-preview-party" id="fk-preview-buyer"></div>
            </div>
            <table class="fk-preview-table">
                <thead>
                    <tr>
                        <th><?= fk_h($inv['line_desc']) ?></th>
                        <th><?= fk_h($inv['line_qty']) ?></th>
                        <th><?= fk_h($inv['line_price']) ?></th>
                        <th><?= fk_h($inv['line_total']) ?></th>
                        <th id="fk-preview-pay-col" hidden><?= fk_h($inv['pay_btn'] ?? 'Pay') ?></th>
                    </tr>
                </thead>
                <tbody id="fk-preview-lines"></tbody>
            </table>
            <div class="fk-totals">
                <div><span><?= fk_h($inv['subtotal']) ?></span><span id="fk-sum-subtotal">0</span></div>
                <div id="fk-sum-tax-row"><span id="fk-sum-tax-label"><?= fk_h($inv['tax']) ?></span><span id="fk-sum-tax">0</span></div>
                <div class="fk-total-final"><span><?= fk_h($inv['total']) ?></span><span id="fk-sum-total">0</span></div>
            </div>
            <div id="fk-preview-payment" style="font-size:.85rem;margin-top:1.25rem;color:var(--fk-text)"></div>
            <div class="fk-preview-footer">
                <p id="fk-preview-notes" style="font-size:.82rem;margin-top:.75rem"></p>
                <div id="fk-preview-qr" class="fk-preview-qr" hidden></div>
            </div>
            <?php fk_render_print_demo_mark(); ?>
        </div>
    </div>
</div>

<script>
window.FK_INVOICE = <?= json_encode([
    'lang' => $lang,
    'ai_provider' => $aiProvider,
    'save_url' => fk_url('api/save-invoice.php'),
    'ai_url' => fk_url('api/ai-notes.php'),
    'site_url' => $site_url,
    'qr' => $qrSettings,
    'print_design' => $printDesign,
    'print_format' => $printFormat,
    'print_formats' => array_map(static fn($f) => $f['css'], fk_print_formats()),
    'countries' => $countriesJson,
    'clients' => $clientsJson,
    'templates' => $templates,
    'i18n' => [
        'template_none' => $inv['template_none'],
        'remove_line'   => $inv['remove_line'],
        'tax'           => $inv['tax'],
        'single_tax'    => $inv['single_tax'],
        'tax_mode_vat'  => $inv['tax_mode_vat'],
        'tax_mode_single' => $inv['tax_mode_single'],
        'payment' => $inv['payment'] ?? 'Payment',
        'payment_purpose' => $inv['payment_purpose'] ?? 'Payment reference',
        'payment_purpose_prefix' => ($lang === 'uk' ? 'Оплата за рахунок' : ($lang === 'lt' ? 'Apmokėjimas už sąskaitą' : ($lang === 'no' ? 'Betaling for faktura' : 'Payment for invoice'))),
        'line_pay_url' => $inv['line_pay_url'] ?? 'Payment link',
        'line_pay_url_ph' => $inv['line_pay_url_ph'] ?? 'https://…',
        'pay_btn' => $inv['pay_btn'] ?? 'Pay',
        'pay_now' => $inv['pay_now'] ?? 'Pay now',
        'qr_payment_template' => $qrSettings['payment_url_template'] ?? '',
        'save' => $inv['save'] ?? 'Save invoice',
        'saving' => $inv['saving'] ?? 'Saving…',
        'saved' => $inv['saved'] ?? 'Invoice saved.',
        'saved_link' => $inv['saved_link'] ?? 'Open saved invoice',
        'save_error' => $inv['save_error'] ?? 'Could not save invoice.',
        'qr_scan' => $inv['qr_scan'] ?? 'Scan to pay or view',
        'ai_notes_btn' => $inv['ai_notes_btn'] ?? 'AI notes',
        'ai_generating' => $inv['ai_generating'] ?? 'Generating…',
        'ai_ok' => $inv['ai_ok'] ?? 'Generated.',
        'ai_demo_ok' => $inv['ai_demo_ok'] ?? 'Template text (enable AI in admin).',
        'ai_failed' => $inv['ai_failed'] ?? 'Could not generate.',
        'ai_login_hint' => $inv['ai_login_hint'] ?? 'Log in to admin to use AI on this page.',
    ],
], JSON_UNESCAPED_UNICODE) ?>;
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>