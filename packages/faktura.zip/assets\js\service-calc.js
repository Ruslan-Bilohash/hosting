(function () {
    'use strict';

    const cfg = window.FK_CALC || {};
    const i18n = cfg.i18n || {};
    const presets = cfg.presets || [];
    const savedList = cfg.saved || [];
    const qrSize = cfg.qr_size || 140;

    let currentId = cfg.loaded?.id || '';
    let rowCount = 0;
    let paymentUrlTouched = false;

    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);

    function presetById(id) {
        return presets.find((p) => p.id === id) || presets[0] || null;
    }

    function fmt(n) {
        return (Math.round(n * 100) / 100).toFixed(2);
    }

    function getPresetId() {
        return $('#fk-calc-preset')?.value || presets[0]?.id || '';
    }

    function currencySymbol() {
        return presetById(getPresetId())?.currency_symbol || '€';
    }

    function updateCurrencyLabels() {
        const sym = currencySymbol();
        ['fk-calc-currency-live', 'fk-calc-currency-total', 'fk-calc-currency-sticky'].forEach((id) => {
            const el = document.getElementById(id);
            if (el) el.textContent = sym;
        });
        $$('.fk-calc-quick-price').forEach((el) => {
            const price = el.textContent.replace(/[^\d.,]/g, '').trim();
            if (price) el.textContent = `${price} ${sym}`;
        });
    }

    function paymentTemplate(preset) {
        const tpl = (preset?.payment_url_template || '').trim();
        if (tpl) return tpl;
        return (cfg.global_payment_template || '').trim();
    }

    function buildPaymentUrl(preset, manualOnly = false) {
        const input = $('#fk-calc-payment-url');
        if (manualOnly && input?.dataset.touched === '1') {
            return (input.value || '').trim();
        }
        const tpl = paymentTemplate(preset);
        if (!tpl) {
            return (input?.value || '').trim();
        }
        const total = $('#fk-calc-total')?.textContent || '0';
        const invNo = $('#fk-calc-invoice-no')?.value || '';
        const purpose = $('#fk-calc-payment-purpose-input')?.value
            || $('#fk-calc-payment-purpose')?.textContent
            || invNo;
        return tpl
            .replace(/\{amount\}/g, total)
            .replace(/\{invoice_no\}/g, invNo)
            .replace(/\{currency\}/g, preset?.currency || 'EUR')
            .replace(/\{id\}/g, currentId || '')
            .replace(/\{reference\}/g, purpose);
    }

    function qrImageUrl(url) {
        if (!url) return '';
        const size = Math.max(80, Math.min(400, qrSize));
        return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=8&data=${encodeURIComponent(url)}`;
    }

    function updatePaymentQr() {
        const preset = presetById(getPresetId());
        const urlInput = $('#fk-calc-payment-url');
        let url = (urlInput?.value || '').trim();
        if (!paymentUrlTouched && urlInput && urlInput.dataset.touched !== '1') {
            const generated = buildPaymentUrl(preset);
            if (generated) {
                url = generated;
                urlInput.value = generated;
            }
        }
        const qrEnabled = preset?.qr_enabled !== false;
        const wrap = $('#fk-calc-qr-wrap');
        const printBox = $('#fk-calc-qr-print');
        const img = $('#fk-calc-qr-img');
        const printImg = $('#fk-calc-qr-print-img');
        const payBtn = $('#fk-calc-pay-btn');
        const printUrl = $('#fk-calc-qr-print-url');

        if (!url || !qrEnabled) {
            wrap?.setAttribute('hidden', '');
            printBox?.setAttribute('hidden', '');
            if (payBtn) payBtn.href = '#';
            return;
        }

        const qrSrc = qrImageUrl(url);
        if (img) img.src = qrSrc;
        if (printImg) printImg.src = qrSrc;
        if (payBtn) {
            payBtn.href = url;
            payBtn.removeAttribute('hidden');
        }
        if (printUrl) printUrl.textContent = url;
        wrap?.removeAttribute('hidden');
        printBox?.removeAttribute('hidden');
    }

    function applyDocLabels(preset) {
        const doc = preset?.doc || {};
        const map = {
            'fk-doc-invoice-data': 'invoice_data',
            'fk-doc-invoice-no': 'invoice_no',
            'fk-doc-invoice-date': 'invoice_date',
            'fk-doc-due-date': 'due_date',
            'fk-doc-seller': 'seller',
            'fk-doc-buyer': 'buyer',
            'fk-doc-services': 'services',
            'fk-doc-col-nr': 'col_nr',
            'fk-doc-col-name': 'col_name',
            'fk-doc-col-qty': 'col_qty',
            'fk-doc-col-price': 'col_price',
            'fk-doc-col-sum': 'col_sum',
            'fk-doc-total': 'total',
            'fk-doc-payment': 'payment',
            'fk-doc-payment-purpose': 'payment_purpose',
        };
        Object.entries(map).forEach(([elId, key]) => {
            const el = document.getElementById(elId);
            if (el && doc[key]) {
                el.textContent = doc[key];
            }
        });
        const payText = $('#fk-calc-payment-text');
        if (payText && doc.payment_text) {
            const seller = preset.seller || {};
            payText.textContent = doc.payment_text
                .replace('{iban}', seller.iban || '')
                .replace('{bank}', seller.bank || '');
        }
        const ph = {
            buyer_name: doc.buyer_name_ph,
            buyer_code: doc.buyer_code_ph,
            buyer_address: doc.buyer_address_ph,
            buyer_phone: doc.buyer_phone_ph,
            buyer_email: doc.buyer_email_ph,
        };
        Object.entries(ph).forEach(([field, text]) => {
            const el = document.getElementById(field);
            if (el && text) {
                el.placeholder = text;
            }
        });
    }

    function renderSeller(preset) {
        const box = $('#fk-calc-seller');
        if (!box) return;
        const s = preset?.seller || {};
        const orgLabel = preset?.doc?.org_label || '';
        box.innerHTML = [
            s.name ? `<strong>${escapeHtml(s.name)}</strong>` : '',
            s.org_nr ? `${escapeHtml(orgLabel)} ${escapeHtml(s.org_nr)}<br>` : '',
            s.license ? `${escapeHtml(s.license)}<br><br>` : '',
            s.address ? `${escapeHtml(s.address)}<br>` : '',
            s.bank ? `${escapeHtml(s.bank)}<br>` : '',
            s.iban ? escapeHtml(s.iban) : '',
        ].filter(Boolean).join('');
    }

    function escapeHtml(str) {
        const d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    function renderQuickButtons(preset) {
        const wrap = $('#fk-calc-quick');
        if (!wrap) return;
        const sym = preset?.currency_symbol || '€';
        wrap.innerHTML = '';
        (preset?.services || []).forEach((svc) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'fk-calc-quick-btn fk-no-print';
            btn.innerHTML = `<span class="fk-calc-quick-label">${escapeHtml(svc.label || svc.desc)}</span>`
                + `<span class="fk-calc-quick-price">${fmt(svc.price || 0)} ${sym}</span>`;
            btn.addEventListener('click', () => addRow(svc.desc, svc.qty, svc.price));
            wrap.appendChild(btn);
        });
    }

    function addRow(desc = '', qty = 1, price = 0) {
        rowCount += 1;
        const tbody = $('#fk-calc-lines');
        if (!tbody) return;
        const tr = document.createElement('tr');
        const linePh = presetById(getPresetId())?.doc?.line_name_ph || '';
        tr.innerHTML = `
            <td class="fk-calc-col-nr" data-label="${escapeAttr(i18n.col_nr || 'No.')}">${rowCount}</td>
            <td data-label="${escapeAttr(i18n.col_name || 'Name')}"><input type="text" class="fk-line-desc" value="${escapeAttr(desc)}" placeholder="${escapeAttr(linePh)}"></td>
            <td class="fk-calc-col-qty" data-label="${escapeAttr(i18n.col_qty || 'Qty')}"><input type="number" class="fk-line-qty" value="${qty}" min="0" step="0.01" inputmode="decimal"></td>
            <td class="fk-calc-col-price" data-label="${escapeAttr(i18n.col_price || 'Price')}"><input type="number" class="fk-line-price" value="${price}" min="0" step="0.01" inputmode="decimal"></td>
            <td class="fk-calc-col-sum fk-line-total" data-label="${escapeAttr(i18n.col_sum || 'Sum')}">0.00</td>
            <td class="fk-calc-col-remove fk-no-print"><button type="button" class="fk-calc-remove-btn" aria-label="${escapeAttr(i18n.remove_line || 'Remove')}">×</button></td>
        `;
        tbody.appendChild(tr);
        tr.querySelector('.fk-calc-remove-btn')?.addEventListener('click', () => {
            tr.remove();
            renumber();
            calculate();
        });
        tr.querySelectorAll('input').forEach((inp) => inp.addEventListener('input', calculate));
        calculate();
    }

    function escapeAttr(str) {
        return String(str).replace(/"/g, '&quot;');
    }

    function renumber() {
        $$('#fk-calc-lines tr').forEach((row, i) => {
            const cell = row.cells[0];
            if (cell) cell.textContent = String(i + 1);
        });
        rowCount = document.querySelectorAll('#fk-calc-lines tr').length;
    }

    function parseLines() {
        const lines = [];
        $$('#fk-calc-lines tr').forEach((row) => {
            lines.push({
                desc: row.querySelector('.fk-line-desc')?.value || '',
                qty: parseFloat(row.querySelector('.fk-line-qty')?.value) || 0,
                price: parseFloat(row.querySelector('.fk-line-price')?.value) || 0,
            });
        });
        return lines;
    }

    function calculate() {
        let total = 0;
        $$('#fk-calc-lines tr').forEach((row) => {
            const qty = parseFloat(row.querySelector('.fk-line-qty')?.value) || 0;
            const price = parseFloat(row.querySelector('.fk-line-price')?.value) || 0;
            const line = qty * price;
            const cell = row.querySelector('.fk-line-total');
            if (cell) cell.textContent = fmt(line);
            total += line;
        });
        const totalStr = fmt(total);
        const totalEl = $('#fk-calc-total');
        if (totalEl) totalEl.textContent = totalStr;
        ['fk-calc-live-amount', 'fk-calc-sticky-amount'].forEach((id) => {
            const el = document.getElementById(id);
            if (el) el.textContent = totalStr;
        });
        const live = $('#fk-calc-live-total');
        if (live) {
            live.classList.remove('is-updated');
            void live.offsetWidth;
            live.classList.add('is-updated');
        }
        const invNo = $('#fk-calc-invoice-no')?.value || '';
        const preset = presetById(getPresetId());
        const tpl = preset?.doc?.payment_purpose_tpl || i18n.payment_purpose_tpl || 'Payment for invoice {no}';
        const purpose = tpl.replace('{no}', invNo);
        const purposeEl = $('#fk-calc-payment-purpose');
        if (purposeEl) purposeEl.textContent = purpose;
        const purposeInput = $('#fk-calc-payment-purpose-input');
        if (purposeInput && !purposeInput.dataset.touched) {
            purposeInput.value = purpose;
        }
        updatePaymentQr();
    }

    function collectPayload() {
        const preset = presetById(getPresetId());
        return {
            id: currentId || undefined,
            preset_id: preset?.id || '',
            country_id: preset?.country_id || '',
            invoice_no: $('#fk-calc-invoice-no')?.value || '',
            invoice_date: $('#fk-calc-invoice-date')?.value || '',
            due_date: $('#fk-calc-due-date')?.value || '',
            title: $('#fk-calc-title')?.value || '',
            buyer: {
                name: $('#buyer_name')?.value || '',
                code: $('#buyer_code')?.value || '',
                address: $('#buyer_address')?.value || '',
                phone: $('#buyer_phone')?.value || '',
                email: $('#buyer_email')?.value || '',
            },
            lines: parseLines(),
            payment_purpose: $('#fk-calc-payment-purpose-input')?.value || $('#fk-calc-payment-purpose')?.textContent || '',
            payment_url: $('#fk-calc-payment-url')?.value || '',
        };
    }

    function showAlert(msg, ok = true, asHtml = false) {
        const el = $('#fk-calc-alert');
        if (!el) return;
        if (asHtml) {
            el.innerHTML = msg;
        } else {
            el.textContent = msg;
        }
        el.className = ok ? 'fk-alert fk-alert-ok fk-calc-alert' : 'fk-alert fk-alert-err fk-calc-alert';
        el.hidden = false;
    }

    async function saveCalc() {
        const btn = $('#fk-calc-save');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${i18n.saving || 'Saving…'}`;
        }
        try {
            const res = await fetch(cfg.save_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(collectPayload()),
            });
            const data = await res.json();
            if (!data.ok) {
                throw new Error(data.error || 'save failed');
            }
            currentId = data.id;
            const payload = collectPayload();
            const total = parseFloat($('#fk-calc-total')?.textContent) || 0;
            const sym = currencySymbol();
            const title = payload.title || payload.buyer.name || payload.invoice_no || data.id;
            const existingIdx = savedList.findIndex((s) => s.id === data.id);
            const entry = {
                id: data.id,
                title: `${title} — ${fmt(total)} ${sym}`,
                full: { ...payload, id: data.id, total },
            };
            if (existingIdx >= 0) {
                savedList[existingIdx] = entry;
            } else {
                savedList.unshift(entry);
            }
            const link = data.view
                ? ` <a href="${data.view}">${i18n.saved_link || 'Open'}</a>`
                : '';
            showAlert((i18n.saved || 'Saved.') + link, true, !!link);
            if (data.view && history.replaceState) {
                history.replaceState(null, '', data.view);
            }
            refreshSavedSelect(data.id);
            updatePaymentQr();
        } catch (e) {
            showAlert(i18n.save_error || 'Could not save.', false);
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = `<i class="fas fa-save"></i> ${i18n.save || 'Save'}`;
            }
        }
    }

    function refreshSavedSelect(selectId) {
        const sel = $('#fk-calc-saved');
        if (!sel) return;
        const current = selectId || sel.value;
        sel.innerHTML = `<option value="">${i18n.load_none || '— New calculation —'}</option>`;
        savedList.forEach((item) => {
            const opt = document.createElement('option');
            opt.value = item.id;
            opt.textContent = item.title;
            if (item.id === current) opt.selected = true;
            sel.appendChild(opt);
        });
    }

    function loadPreset(presetId, keepBuyer = false) {
        const preset = presetById(presetId);
        if (!preset) return;
        applyDocLabels(preset);
        renderSeller(preset);
        renderQuickButtons(preset);
        updateCurrencyLabels();
        const tbody = $('#fk-calc-lines');
        if (tbody) tbody.innerHTML = '';
        rowCount = 0;
        const def = preset.default_line || {};
        addRow(def.desc || '', def.qty || 1, def.price || 0);
        if (!keepBuyer) {
            ['buyer_name', 'buyer_code', 'buyer_address', 'buyer_phone', 'buyer_email'].forEach((id) => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            const urlInput = $('#fk-calc-payment-url');
            if (urlInput) {
                urlInput.value = '';
                urlInput.dataset.touched = '';
            }
            paymentUrlTouched = false;
        }
        calculate();
    }

    function loadSaved(data) {
        if (!data) return;
        currentId = data.id || '';
        if (data.preset_id) {
            const sel = $('#fk-calc-preset');
            if (sel) sel.value = data.preset_id;
            loadPreset(data.preset_id, true);
        }
        const set = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.value = val ?? '';
        };
        set('fk-calc-invoice-no', data.invoice_no);
        set('fk-calc-invoice-date', data.invoice_date);
        set('fk-calc-due-date', data.due_date);
        set('fk-calc-title', data.title);
        const buyer = data.buyer || {};
        set('buyer_name', buyer.name);
        set('buyer_code', buyer.code);
        set('buyer_address', buyer.address);
        set('buyer_phone', buyer.phone);
        set('buyer_email', buyer.email);
        const tbody = $('#fk-calc-lines');
        if (tbody) tbody.innerHTML = '';
        rowCount = 0;
        (data.lines || []).forEach((line) => addRow(line.desc, line.qty, line.price));
        if (!(data.lines || []).length) {
            const preset = presetById(getPresetId());
            const def = preset?.default_line || {};
            addRow(def.desc || '', def.qty || 1, def.price || 0);
        }
        const purposeInput = $('#fk-calc-payment-purpose-input');
        if (purposeInput) {
            purposeInput.value = data.payment_purpose || '';
            purposeInput.dataset.touched = data.payment_purpose ? '1' : '';
        }
        const urlInput = $('#fk-calc-payment-url');
        if (urlInput) {
            urlInput.value = data.payment_url || '';
            urlInput.dataset.touched = data.payment_url ? '1' : '';
            paymentUrlTouched = !!data.payment_url;
        }
        calculate();
        const savedSel = $('#fk-calc-saved');
        if (savedSel && currentId) savedSel.value = currentId;
    }

    function setupStickyBar() {
        const sticky = $('#fk-calc-sticky');
        const sheet = $('#fk-calc-sheet');
        if (!sticky || !sheet) return;

        const mqNarrow = window.matchMedia('(max-width: 768px)');
        const mqWide = window.matchMedia('(min-width: 1024px)');
        const toggle = () => {
            const rect = sheet.getBoundingClientRect();
            const inView = rect.top < window.innerHeight * 0.85 && rect.bottom > 120;
            const showMobile = mqNarrow.matches && rect.top < window.innerHeight * 0.35;
            const showDesktop = mqWide.matches && inView;
            const show = showMobile || showDesktop;
            sticky.classList.toggle('is-visible', show);
            sticky.classList.toggle('is-desktop', showDesktop);
            sticky.setAttribute('aria-hidden', show ? 'false' : 'true');
            document.body.classList.toggle('fk-calc-has-sticky', show);
        };
        toggle();
        window.addEventListener('scroll', toggle, { passive: true });
        window.addEventListener('resize', toggle);
        if (mqNarrow.addEventListener) mqNarrow.addEventListener('change', toggle);
        if (mqWide.addEventListener) mqWide.addEventListener('change', toggle);
    }

    function bindEvents() {
        $('#fk-calc-preset')?.addEventListener('change', () => {
            currentId = '';
            loadPreset(getPresetId());
        });
        $('#fk-calc-add-line')?.addEventListener('click', () => addRow());
        $('#fk-calc-save')?.addEventListener('click', saveCalc);
        $('#fk-calc-print')?.addEventListener('click', () => window.print());
        $('#fk-calc-sticky-print')?.addEventListener('click', () => window.print());
        $('#fk-calc-sticky-save')?.addEventListener('click', saveCalc);
        $('#fk-calc-new')?.addEventListener('click', () => {
            currentId = '';
            const savedSel = $('#fk-calc-saved');
            if (savedSel) savedSel.value = '';
            loadPreset(getPresetId());
            const alert = $('#fk-calc-alert');
            if (alert) alert.hidden = true;
        });
        $('#fk-calc-saved')?.addEventListener('change', (e) => {
            const id = e.target.value;
            if (!id) return;
            const item = savedList.find((s) => s.id === id);
            if (item?.full) {
                loadSaved(item.full);
            } else {
                window.location.href = cfg.base_url + '?id=' + encodeURIComponent(id);
            }
        });
        ['fk-calc-invoice-no', 'fk-calc-invoice-date', 'fk-calc-due-date'].forEach((id) => {
            document.getElementById(id)?.addEventListener('input', calculate);
        });
        $('#fk-calc-payment-purpose-input')?.addEventListener('input', (e) => {
            e.target.dataset.touched = '1';
            const el = $('#fk-calc-payment-purpose');
            if (el) el.textContent = e.target.value;
            updatePaymentQr();
        });
        $('#fk-calc-payment-url')?.addEventListener('input', (e) => {
            e.target.dataset.touched = '1';
            paymentUrlTouched = true;
            updatePaymentQr();
        });
        $('#fk-calc-gen-payment-url')?.addEventListener('click', () => {
            const preset = presetById(getPresetId());
            const url = buildPaymentUrl(preset);
            const input = $('#fk-calc-payment-url');
            if (input) {
                input.value = url;
                input.dataset.touched = url ? '1' : '';
            }
            paymentUrlTouched = !!url;
            updatePaymentQr();
        });
    }

    function init() {
        refreshSavedSelect(currentId);
        if (cfg.loaded) {
            loadSaved(cfg.loaded);
        } else {
            loadPreset(getPresetId());
        }
        bindEvents();
        setupStickyBar();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();