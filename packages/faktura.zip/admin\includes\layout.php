<?php
$ta = $t['admin'] ?? [];
$adm_title = $adm_title ?? ($ta['dashboard'] ?? 'Admin');
$adm_nav_active = $adm_nav_active ?? '';
fk_admin_require();

$adm_nav_groups = [
    ['label' => $ta['nav_group_main'] ?? 'Main', 'items' => [
        ['slug' => 'dashboard', 'url' => 'index.php', 'label' => $ta['dashboard'] ?? 'Dashboard', 'icon' => 'fa-gauge-high'],
        ['slug' => 'invoices', 'url' => 'invoices.php', 'label' => $ta['invoices'] ?? 'Invoices', 'icon' => 'fa-file-invoice'],
        ['slug' => 'calcs', 'url' => 'calcs.php', 'label' => $ta['calcs'] ?? 'Calculations', 'icon' => 'fa-calculator'],
        ['slug' => 'service_presets', 'url' => 'service-presets.php', 'label' => $ta['service_presets'] ?? 'Service calculator', 'icon' => 'fa-bolt'],
        ['slug' => 'clients', 'url' => 'clients.php', 'label' => $ta['clients'] ?? 'Clients', 'icon' => 'fa-users'],
        ['slug' => 'send', 'url' => 'send-mail.php', 'label' => $ta['send_email'] ?? 'Send email', 'icon' => 'fa-paper-plane'],
        ['slug' => 'support', 'url' => 'support.php', 'label' => $ta['support'] ?? 'Support', 'icon' => 'fa-headset'],
    ]],
    ['label' => $ta['nav_group_setup'] ?? 'Setup', 'items' => [
        ['slug' => 'settings', 'url' => 'settings.php', 'label' => $ta['settings'] ?? 'Settings', 'icon' => 'fa-building'],
        ['slug' => 'countries', 'url' => 'countries.php', 'label' => $ta['countries'] ?? 'Countries', 'icon' => 'fa-globe-europe'],
        ['slug' => 'templates', 'url' => 'templates.php', 'label' => $ta['templates'] ?? 'Templates', 'icon' => 'fa-copy'],
        ['slug' => 'smtp', 'url' => 'smtp.php', 'label' => $ta['smtp_sub'] ?? 'SMTP', 'icon' => 'fa-envelope'],
        ['slug' => 'ai', 'url' => 'ai.php', 'label' => $ta['ai_nav'] ?? 'AI', 'icon' => 'fa-wand-magic-sparkles'],
    ]],
];

$adm_sidebar_site = [
    ['url' => fk_url('help.php'), 'label' => $ta['help'] ?? 'Help', 'icon' => 'fa-book-open', 'target' => '_blank'],
    ['url' => fk_url('index.php'), 'label' => $ta['view_site'] ?? 'View site', 'icon' => 'fa-arrow-up-right-from-square', 'target' => '_blank'],
    ['url' => fk_admin_url('logout.php'), 'label' => $ta['logout'] ?? 'Log out', 'icon' => 'fa-right-from-bracket', 'target' => ''],
];
?>
<!DOCTYPE html>
<html lang="<?= fk_h($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= fk_h($adm_title) ?> — Faktura Creator</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= fk_h(fk_asset('css/admin.css')) ?>?v=9">
    <?php if (!empty($extra_css)): foreach ((array) $extra_css as $css): ?>
    <link rel="stylesheet" href="<?= fk_h($css) ?>">
    <?php endforeach; endif; ?>
</head>
<body class="adm-body adm-body-pc<?= !empty($adm_body_class) ? ' ' . fk_h($adm_body_class) : '' ?>">
<div class="adm-shell">
<aside class="adm-sidebar" aria-label="<?= fk_h($ta['nav_menu'] ?? 'Admin') ?>">
    <a href="<?= fk_admin_url('index.php') ?>" class="adm-sidebar-brand">
        <span class="adm-sidebar-brand-icon"><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i></span>
        <span class="adm-sidebar-brand-text">Faktura Creator</span>
    </a>
    <?php foreach ($adm_nav_groups as $group): ?>
    <p class="adm-sidebar-label"><?= fk_h($group['label']) ?></p>
    <nav class="adm-sidebar-nav">
        <?php foreach ($group['items'] as $item): ?>
        <a href="<?= fk_admin_url($item['url']) ?>" class="adm-sidebar-link<?= $adm_nav_active === $item['slug'] ? ' active' : '' ?>">
            <i class="fas <?= fk_h($item['icon']) ?>" aria-hidden="true"></i>
            <span><?= fk_h($item['label']) ?></span>
        </a>
        <?php endforeach; ?>
    </nav>
    <?php endforeach; ?>
    <div class="adm-sidebar-foot">
        <?php foreach ($adm_sidebar_site as $link): ?>
        <a href="<?= fk_h($link['url']) ?>" class="adm-sidebar-link"<?= $link['target'] !== '' ? ' target="' . fk_h($link['target']) . '" rel="noopener"' : '' ?>>
            <i class="fas <?= fk_h($link['icon']) ?>" aria-hidden="true"></i>
            <span><?= fk_h($link['label']) ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</aside>
<div class="adm-shell-main">
<header class="adm-top">
    <p class="adm-top-crumb" aria-current="page"><i class="fas fa-desktop" aria-hidden="true"></i> <?= fk_h($adm_title) ?></p>
    <a href="<?= fk_admin_url('index.php') ?>" class="adm-brand"><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i> Faktura Creator</a>
    <button type="button" class="adm-menu-btn" id="adm-menu-btn" aria-expanded="false" aria-controls="adm-mobile-nav" aria-label="<?= fk_h($ta['nav_menu'] ?? 'Menu') ?>">
        <i class="fas fa-bars" aria-hidden="true"></i>
    </button>
    <label class="adm-nav-jump">
        <span class="sr-only"><?= fk_h($ta['nav_jump'] ?? 'Go to section') ?></span>
        <select id="adm-nav-jump" class="adm-select">
            <option value=""><?= fk_h($ta['nav_jump'] ?? 'Admin menu…') ?></option>
            <?php foreach ($adm_nav_groups as $group): ?>
            <optgroup label="<?= fk_h($group['label']) ?>">
                <?php foreach ($group['items'] as $item): ?>
                <option value="<?= fk_h(fk_admin_url($item['url'])) ?>"<?= $adm_nav_active === $item['slug'] ? ' selected' : '' ?>><?= fk_h($item['label']) ?></option>
                <?php endforeach; ?>
            </optgroup>
            <?php endforeach; ?>
            <optgroup label="<?= fk_h($ta['nav_group_site'] ?? 'Site') ?>">
                <option value="<?= fk_h(fk_url('help.php')) ?>"><?= fk_h($ta['help'] ?? 'Help') ?></option>
                <option value="<?= fk_h(fk_url('index.php')) ?>"><?= fk_h($ta['view_site'] ?? 'View site') ?></option>
                <option value="<?= fk_h(fk_admin_url('logout.php')) ?>"><?= fk_h($ta['logout'] ?? 'Log out') ?></option>
            </optgroup>
        </select>
    </label>
    <nav class="adm-nav" aria-label="<?= fk_h($ta['nav_menu'] ?? 'Admin') ?>">
        <?php foreach ($adm_nav_groups as $group): ?>
        <?php foreach ($group['items'] as $item): ?>
        <a href="<?= fk_admin_url($item['url']) ?>" class="<?= $adm_nav_active === $item['slug'] ? 'active' : '' ?>" title="<?= fk_h($item['label']) ?>"><i class="fas <?= fk_h($item['icon']) ?>" aria-hidden="true"></i><span><?= fk_h($item['label']) ?></span></a>
        <?php endforeach; ?>
        <?php endforeach; ?>
        <a href="<?= fk_url('help.php') ?>" target="_blank" rel="noopener" title="<?= fk_h($ta['help'] ?? 'Help') ?>"><i class="fas fa-book-open" aria-hidden="true"></i><span><?= fk_h($ta['help'] ?? 'Help') ?></span></a>
        <a href="<?= fk_url('index.php') ?>" target="_blank" rel="noopener" title="<?= fk_h($ta['view_site'] ?? 'View site') ?>"><i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i><span><?= fk_h($ta['view_site'] ?? 'View site') ?></span></a>
        <a href="<?= fk_admin_url('logout.php') ?>" title="<?= fk_h($ta['logout'] ?? 'Log out') ?>"><i class="fas fa-right-from-bracket" aria-hidden="true"></i><span><?= fk_h($ta['logout'] ?? 'Log out') ?></span></a>
    </nav>
    <div class="adm-top-tools">
        <a href="<?= fk_url('create.php') ?>" class="adm-top-icon" target="_blank" rel="noopener" title="<?= fk_h($t['nav']['create'] ?? 'Create invoice') ?>"><i class="fas fa-plus" aria-hidden="true"></i></a>
        <a href="<?= fk_url('help.php') ?>" class="adm-top-icon adm-top-icon--desk" target="_blank" rel="noopener" title="<?= fk_h($ta['help'] ?? 'Help') ?>"><i class="fas fa-book-open" aria-hidden="true"></i></a>
        <?php
        $fk_dd_id = 'fkLangAdm';
        $fk_dd_variant = 'admin';
        $fk_dd_url_fn = 'fk_admin_lang_url';
        require dirname(__DIR__, 2) . '/includes/lang-dropdown.php';
        ?>
    </div>
</header>
<nav class="adm-mobile-nav" id="adm-mobile-nav" hidden aria-label="<?= fk_h($ta['nav_menu'] ?? 'Admin') ?>">
    <?php foreach ($adm_nav_groups as $group): ?>
    <p class="adm-mobile-nav-label"><?= fk_h($group['label']) ?></p>
    <?php foreach ($group['items'] as $item): ?>
    <a href="<?= fk_admin_url($item['url']) ?>" class="<?= $adm_nav_active === $item['slug'] ? 'active' : '' ?>"><i class="fas <?= fk_h($item['icon']) ?>" aria-hidden="true"></i> <?= fk_h($item['label']) ?></a>
    <?php endforeach; ?>
    <?php endforeach; ?>
    <a href="<?= fk_url('help.php') ?>" target="_blank" rel="noopener"><i class="fas fa-book-open"></i> <?= fk_h($ta['help'] ?? 'Help') ?></a>
    <a href="<?= fk_url('index.php') ?>" target="_blank" rel="noopener"><i class="fas fa-arrow-up-right-from-square"></i> <?= fk_h($ta['view_site'] ?? 'View site') ?></a>
    <a href="<?= fk_admin_url('logout.php') ?>"><i class="fas fa-right-from-bracket"></i> <?= fk_h($ta['logout'] ?? 'Log out') ?></a>
    <div class="adm-mobile-lang">
        <?php
        $fk_dd_id = 'fkLangAdmMobile';
        $fk_dd_variant = 'mobile';
        $fk_dd_url_fn = 'fk_admin_lang_url';
        require dirname(__DIR__, 2) . '/includes/lang-dropdown.php';
        ?>
    </div>
</nav>
<main class="adm-main">
    <h1 class="adm-page-title"><?= fk_h($adm_title) ?></h1>
    <?php if (!empty($adm_saved)): ?><div class="adm-success"><i class="fas fa-circle-check" aria-hidden="true"></i> <?= fk_h($adm_demo_saved ?? false ? ($ta['demo_saved'] ?? 'Updated.') : ($ta['saved'] ?? 'Saved.')) ?></div><?php endif; ?>