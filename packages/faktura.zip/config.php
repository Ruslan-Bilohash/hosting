<?php
/**
 * Faktura Creator — admin panel for accountants & business
 * /faktura
 */
define('FK_BASE_PATH', '/faktura');
define('FK_DOMAIN', 'bilohash.com');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
define('FK_DEMO_URL', 'https://bilohash.com/faktura/');

$detected = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = (strpos($host, FK_DOMAIN) !== false) ? FK_BASE_PATH : ($detected ?: FK_BASE_PATH);

$protocol = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
) ? 'https' : 'http';

$site_url   = rtrim($protocol . '://' . $host . $base_path, '/');
$assets_url = $base_path . '/assets';

function fk_url(string $path = ''): string
{
    global $base_path;
    return rtrim($base_path, '/') . '/' . ltrim($path, '/');
}

function fk_asset(string $file): string
{
    global $assets_url;
    return $assets_url . '/' . ltrim($file, '/');
}

function fk_demo_url(string $path = ''): string
{
    $base = defined('FK_DEMO_URL') ? rtrim(FK_DEMO_URL, '/') : 'https://bilohash.com/faktura';
    if ($path === '') {
        return $base . '/';
    }
    return $base . '/' . ltrim($path, '/');
}

function fk_money(float $amount, string $currency): string
{
    $decimals = in_array($currency, ['NOK', 'SEK', 'UAH', 'PLN'], true) ? 2 : 2;
    $formatted = number_format($amount, $decimals, '.', ' ');
    return $formatted . ' ' . $currency;
}

if (!function_exists('bh_str_lower')) {
    function bh_str_lower(string $str): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($str) : strtolower($str);
    }
}