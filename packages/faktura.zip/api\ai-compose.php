<?php
require_once dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/admin-auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fk_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

if (!fk_admin_logged()) {
    fk_json_response(['ok' => false, 'error' => 'Unauthorized'], 401);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$type = trim((string) ($payload['type'] ?? 'email_note'));
$allowed = ['email_note', 'email_subject', 'invoice_notes'];
if (!in_array($type, $allowed, true)) {
    fk_json_response(['ok' => false, 'error' => 'Invalid type'], 400);
}

$settings = fk_load_settings();
$context = [];

$invoiceId = trim((string) ($payload['invoice_id'] ?? ''));
$clientId = trim((string) ($payload['client_id'] ?? ''));

if ($invoiceId !== '') {
    $invoice = fk_get_invoice($invoiceId);
    if ($invoice === null) {
        fk_json_response(['ok' => false, 'error' => 'Invoice not found'], 404);
    }
    $client = $clientId !== '' ? (fk_get_client($clientId) ?? []) : [];
    $context = fk_ai_context_from_invoice($invoice, $settings, $client);
} else {
    $context = [
        'client_name' => trim((string) ($payload['client_name'] ?? '')),
        'invoice_no'  => trim((string) ($payload['invoice_no'] ?? '')),
        'total'       => trim((string) ($payload['total'] ?? '')),
        'currency'    => trim((string) ($payload['currency'] ?? '')),
        'due_date'    => trim((string) ($payload['due_date'] ?? '')),
        'company'     => (string) ($settings['company']['name'] ?? 'Faktura Creator'),
        'iban'        => trim((string) ($payload['iban'] ?? $settings['company']['iban'] ?? '')),
    ];
}

$composeLang = trim((string) ($payload['lang'] ?? $lang));
if (!in_array($composeLang, array_keys(fk_langs()), true)) {
    $composeLang = $lang;
}

$result = fk_ai_compose($settings, $type, $context, $composeLang);
fk_json_response([
    'ok'    => $result['ok'],
    'text'  => $result['text'],
    'demo'  => $result['demo'],
    'error' => $result['error'],
], $result['ok'] ? 200 : 500);