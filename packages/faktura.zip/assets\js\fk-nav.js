(function () {
    'use strict';

    function closeDropdown(dropdown) {
        if (!dropdown) return;
        dropdown.classList.remove('is-open');
        var btn = dropdown.querySelector('.fk-lang-dropdown-btn');
        var menu = dropdown.querySelector('.fk-lang-dropdown-menu');
        if (btn) btn.setAttribute('aria-expanded', 'false');
        if (menu) menu.hidden = true;
    }

    function closeAllLang(except) {
        document.querySelectorAll('.fk-lang-dropdown.is-open').forEach(function (dd) {
            if (dd !== except) closeDropdown(dd);
        });
    }

    function bindLangDropdown(dropdown) {
        var btn = dropdown.querySelector('.fk-lang-dropdown-btn');
        var menu = dropdown.querySelector('.fk-lang-dropdown-menu');
        if (!btn || !menu || btn.dataset.fkLangBound === '1') return;
        btn.dataset.fkLangBound = '1';

        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var willOpen = !dropdown.classList.contains('is-open');
            closeAllLang(dropdown);
            if (willOpen) {
                dropdown.classList.add('is-open');
                menu.hidden = false;
                btn.setAttribute('aria-expanded', 'true');
            } else {
                closeDropdown(dropdown);
            }
        });
        menu.addEventListener('click', function (e) {
            e.stopPropagation();
        });
    }

    document.querySelectorAll('.fk-lang-dropdown').forEach(bindLangDropdown);

    var menuBtn = document.getElementById('fk-menu-btn');
    var panel = document.getElementById('fk-mobile-panel');
    var overlay = document.getElementById('fk-mobile-overlay');
    var topBar = menuBtn ? menuBtn.closest('.fk-top-bar') : null;
    var setMenuOpen = null;

    if (menuBtn && panel) {
        var icon = menuBtn.querySelector('i');
        var closeLabel = menuBtn.getAttribute('data-close-label') || 'Close menu';
        var openLabel = menuBtn.getAttribute('aria-label') || 'Menu';

        setMenuOpen = function (open) {
            panel.classList.toggle('open', open);
            panel.setAttribute('aria-hidden', open ? 'false' : 'true');
            menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
            menuBtn.setAttribute('aria-label', open ? closeLabel : openLabel);
            document.body.classList.toggle('fk-nav-open', open);
            if (topBar) topBar.classList.toggle('nav-open', open);
            if (overlay) {
                overlay.classList.toggle('is-open', open);
                overlay.setAttribute('aria-hidden', open ? 'false' : 'true');
            }
            if (icon) icon.className = open ? 'fas fa-times' : 'fas fa-bars';
            if (open) closeAllLang(null);
        };

        menuBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            setMenuOpen(!panel.classList.contains('open'));
        });

        panel.querySelectorAll('.fk-mobile-nav a').forEach(function (link) {
            link.addEventListener('click', function () { setMenuOpen(false); });
        });

        if (overlay) {
            overlay.addEventListener('click', function () { setMenuOpen(false); });
        }

        window.addEventListener('resize', function () {
            if (window.innerWidth >= 900) setMenuOpen(false);
        });
    }

    if (!document.body.dataset.fkLangDocBound) {
        document.body.dataset.fkLangDocBound = '1';
        document.addEventListener('click', function () { closeAllLang(null); });
        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') return;
            closeAllLang(null);
            if (setMenuOpen && panel && panel.classList.contains('open')) setMenuOpen(false);
        });
    }
})();