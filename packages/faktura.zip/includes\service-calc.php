<?php

function fk_service_presets_seed(): array
{
    $f = __DIR__ . '/../data/service-presets.php';
    $data = is_readable($f) ? (require $f) : [];
    return is_array($data) ? $data : [];
}

function fk_ensure_service_presets_json(): void
{
    $path = fk_data_path('service-presets.json');
    $seed = fk_service_presets_seed();
    if (!is_file($path)) {
        fk_save_json('service-presets.json', $seed);
        return;
    }
    $existing = json_decode(file_get_contents($path) ?: '[]', true);
    if (!is_array($existing)) {
        fk_save_json('service-presets.json', $seed);
        return;
    }
    $ids = array_column($existing, 'id');
    $merged = $existing;
    $changed = false;
    foreach ($seed as $preset) {
        if (!in_array($preset['id'] ?? '', $ids, true)) {
            $merged[] = $preset;
            $changed = true;
        }
    }
    if ($changed) {
        fk_save_json('service-presets.json', $merged);
    }
}

function fk_load_service_presets(): array
{
    fk_ensure_service_presets_json();
    $all = fk_load_json('service-presets.json', fk_service_presets_seed());
    if (!is_array($all)) {
        return [];
    }
    return array_values(array_filter($all, static fn(array $p) => !empty($p['active'])));
}

function fk_get_service_preset(string $id): ?array
{
    foreach (fk_load_service_presets() as $preset) {
        if (($preset['id'] ?? '') === $id) {
            return $preset;
        }
    }
    return null;
}

function fk_save_service_presets(array $presets): bool
{
    fk_ensure_service_presets_json();
    return fk_save_json('service-presets.json', array_values($presets));
}

function fk_currency_symbol(string $code): string
{
    $code = strtoupper(trim($code));
    return match ($code) {
        'EUR' => '€',
        'GBP' => '£',
        'USD' => '$',
        'PLN' => 'zł',
        'NOK', 'SEK' => 'kr',
        'UAH' => '₴',
        default => $code,
    };
}

function fk_preset_payment_template(array $preset, array $settings): string
{
    $tpl = trim((string) ($preset['payment_url_template'] ?? ''));
    if ($tpl !== '') {
        return $tpl;
    }
    return trim((string) (($settings['qr'] ?? [])['payment_url_template'] ?? ''));
}

/**
 * @param array<string, mixed> $calc
 * @param array<string, mixed> $preset
 * @param array<string, mixed> $settings
 */
function fk_calc_payment_url(array $calc, array $preset, array $settings): string
{
    $direct = trim((string) ($calc['payment_url'] ?? ''));
    if ($direct !== '') {
        return $direct;
    }
    $tpl = fk_preset_payment_template($preset, $settings);
    if ($tpl === '') {
        return '';
    }
    $total = fk_calc_total($calc);
    return str_replace(
        ['{amount}', '{invoice_no}', '{currency}', '{id}', '{reference}'],
        [
            (string) $total,
            (string) ($calc['invoice_no'] ?? ''),
            (string) ($preset['currency'] ?? 'EUR'),
            (string) ($calc['id'] ?? ''),
            (string) ($calc['payment_purpose'] ?? $calc['invoice_no'] ?? ''),
        ],
        $tpl
    );
}

function fk_default_service_preset_id(array $settings): string
{
    $id = trim((string) ($settings['default_service_preset'] ?? ''));
    if ($id !== '' && fk_get_service_preset($id) !== null) {
        return $id;
    }
    $presets = fk_load_service_presets();
    return (string) ($presets[0]['id'] ?? 'cleaning-lt');
}

/**
 * Copy seller block from a service preset into settings (company + country override).
 */
function fk_apply_service_preset_to_settings(string $presetId): bool
{
    $preset = fk_get_service_preset($presetId);
    if ($preset === null) {
        return false;
    }
    $settings = fk_load_settings();
    $seller = $preset['seller'] ?? [];
    $countryId = (string) ($preset['country_id'] ?? 'lt');

    $company = [
        'name'    => trim((string) ($seller['name'] ?? '')),
        'org_nr'  => trim((string) ($seller['org_nr'] ?? '')),
        'vat_nr'  => trim((string) ($seller['license'] ?? '')),
        'address' => trim((string) ($seller['address'] ?? '')),
        'city'    => '',
        'postal'  => '',
        'country' => $countryId === 'lt' ? 'Lithuania' : ($settings['company']['country'] ?? ''),
        'email'   => $settings['company']['email'] ?? '',
        'phone'   => $settings['company']['phone'] ?? '',
        'bank'    => trim((string) ($seller['bank'] ?? '')),
        'iban'    => trim((string) ($seller['iban'] ?? '')),
        'bic'     => $settings['company']['bic'] ?? '',
    ];

    $settings['company'] = array_merge($settings['company'] ?? [], array_filter($company, static fn($v) => $v !== ''));
    $settings['default_service_preset'] = $presetId;
    if (($preset['country_id'] ?? '') !== '') {
        $settings['default_country'] = $countryId;
    }

    foreach ($settings['countries'] ?? [] as $i => $country) {
        if (($country['id'] ?? '') === $countryId) {
            $settings['countries'][$i]['company_override'] = array_merge(
                $country['company_override'] ?? [],
                array_filter($company, static fn($v) => $v !== '')
            );
            if (!empty($preset['currency'])) {
                $settings['countries'][$i]['currency'] = $preset['currency'];
            }
            break;
        }
    }

    return fk_save_settings($settings);
}

function fk_calc_qr_enabled(array $preset, array $settings): bool
{
    if (array_key_exists('qr_enabled', $preset)) {
        return !empty($preset['qr_enabled']);
    }
    return !empty(($settings['qr'] ?? [])['enabled']);
}

function fk_service_desc(array $service, string $lang, ?array $preset = null): string
{
    $desc = $service['desc'] ?? '';
    if (is_array($desc)) {
        $docLang = $preset['document_lang'] ?? null;
        if ($docLang && isset($desc[$docLang])) {
            return (string) $desc[$docLang];
        }
        return (string) ($desc[$lang] ?? $desc['en'] ?? reset($desc) ?: '');
    }
    return (string) $desc;
}

function fk_service_quick_label(array $service, string $lang): string
{
    $desc = $service['desc'] ?? '';
    if (is_array($desc)) {
        return (string) ($desc[$lang] ?? $desc['en'] ?? reset($desc) ?: '');
    }
    return (string) $desc;
}

function fk_preset_doc_label(array $preset, string $key, string $fallback = ''): string
{
    $doc = $preset['doc'] ?? [];
    return (string) ($doc[$key] ?? $fallback);
}

function fk_calcs_file(): string
{
    return 'calcs.json';
}

function fk_ensure_calcs_json(): void
{
    if (!is_file(fk_data_path(fk_calcs_file()))) {
        fk_save_json(fk_calcs_file(), []);
    }
}

function fk_load_calcs(): array
{
    fk_ensure_calcs_json();
    $all = fk_load_json(fk_calcs_file(), []);
    return is_array($all) ? array_values($all) : [];
}

function fk_save_calcs(array $list): bool
{
    return fk_save_json(fk_calcs_file(), array_values($list));
}

function fk_get_calc(string $id): ?array
{
    foreach (fk_load_calcs() as $calc) {
        if (($calc['id'] ?? '') === $id) {
            return $calc;
        }
    }
    return null;
}

function fk_add_calc(array $calc): array
{
    $list = fk_load_calcs();
    $calc['id'] = $calc['id'] ?? ('calc-' . date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6));
    $calc['created_at'] = $calc['created_at'] ?? gmdate('c');
    $calc['updated_at'] = $calc['updated_at'] ?? $calc['created_at'];
    array_unshift($list, $calc);
    fk_save_calcs($list);
    return $calc;
}

function fk_update_calc(string $id, array $patch): ?array
{
    $list = fk_load_calcs();
    $found = null;
    foreach ($list as $i => $row) {
        if (($row['id'] ?? '') === $id) {
            $patch['updated_at'] = gmdate('c');
            $list[$i] = array_merge($row, $patch);
            $found = $list[$i];
            break;
        }
    }
    if ($found === null) {
        return null;
    }
    fk_save_calcs($list);
    return $found;
}

function fk_delete_calc(string $id): bool
{
    $list = array_values(array_filter(
        fk_load_calcs(),
        static fn(array $c) => ($c['id'] ?? '') !== $id
    ));
    return fk_save_calcs($list);
}

function fk_calc_title(array $calc): string
{
    $title = trim((string) ($calc['title'] ?? ''));
    if ($title !== '') {
        return $title;
    }
    $buyer = trim((string) ($calc['buyer']['name'] ?? ''));
    if ($buyer !== '') {
        return $buyer;
    }
    return (string) ($calc['invoice_no'] ?? $calc['id'] ?? 'Calculation');
}

function fk_calc_total(array $calc): float
{
    if (isset($calc['total'])) {
        return (float) $calc['total'];
    }
    $sum = 0.0;
    foreach ($calc['lines'] ?? [] as $line) {
        $sum += (float) ($line['qty'] ?? 0) * (float) ($line['price'] ?? 0);
    }
    return round($sum, 2);
}

function fk_presets_for_js(array $presets, string $lang): array
{
    return array_map(static function (array $p) use ($lang) {
        $services = [];
        foreach ($p['services'] ?? [] as $svc) {
            $services[] = [
                'desc'  => fk_service_desc($svc, $lang, $p),
                'label' => fk_service_quick_label($svc, $lang),
                'qty'   => (float) ($svc['qty'] ?? 1),
                'price' => (float) ($svc['price'] ?? 0),
            ];
        }
        $default = $p['default_line'] ?? [];
        $defaultDesc = is_array($default['desc'] ?? null)
            ? fk_localized(['desc' => $default['desc']], 'desc', $lang)
            : (string) ($default['desc'] ?? '');
        if ($defaultDesc === '' && !empty($services)) {
            $defaultDesc = $services[0]['desc'];
        }
        $currency = (string) ($p['currency'] ?? 'EUR');
        return [
            'id'          => $p['id'] ?? '',
            'country_id'  => $p['country_id'] ?? '',
            'currency'    => $currency,
            'currency_symbol' => fk_currency_symbol($currency),
            'name'        => fk_localized($p, 'name', $lang),
            'seller'      => $p['seller'] ?? [],
            'doc'         => $p['doc'] ?? [],
            'services'    => $services,
            'payment_url_template' => (string) ($p['payment_url_template'] ?? ''),
            'qr_enabled'  => !array_key_exists('qr_enabled', $p) || !empty($p['qr_enabled']),
            'default_line'=> [
                'desc'  => $defaultDesc,
                'qty'   => (float) ($default['qty'] ?? 1),
                'price' => (float) ($default['price'] ?? 0),
            ],
        ];
    }, $presets);
}