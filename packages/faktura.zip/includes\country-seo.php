<?php

/** @return array<string, array<string, mixed>> */
function fk_country_seo_registry(): array
{
    static $registry = null;
    if ($registry === null) {
        $file = __DIR__ . '/../data/country-seo-registry.php';
        $registry = is_readable($file) ? (require $file) : [];
        if (!is_array($registry)) {
            $registry = [];
        }
    }
    return $registry;
}

/** @return array<string, array{title: string, text: string, buyer: string, seller: string}> */
function fk_country_seo_business_native(): array
{
    static $business = null;
    if ($business === null) {
        $file = __DIR__ . '/../data/country-seo-business.php';
        $business = is_readable($file) ? (require $file) : [];
        if (!is_array($business)) {
            $business = [];
        }
    }
    return $business;
}

function fk_country_id_from_slug(string $slug): ?string
{
    $slug = strtolower(trim($slug));
    if ($slug === '') {
        return null;
    }
    foreach (fk_country_seo_registry() as $countryId => $meta) {
        $slugs = array_map('strtolower', $meta['slugs'] ?? []);
        if (in_array($slug, $slugs, true)) {
            return $countryId;
        }
    }
    return null;
}

function fk_country_canonical_slug(string $countryId): string
{
    $meta = fk_country_seo_registry()[$countryId] ?? null;
    return is_array($meta) ? (string) ($meta['canonical_slug'] ?? $countryId) : $countryId;
}

function fk_country_page_path(string $countryId): string
{
    return fk_url(fk_country_canonical_slug($countryId) . '/');
}

function fk_country_page_url(string $countryId, ?string $uiLang = null, bool $absolute = false): string
{
    global $site_url;
    $slug = fk_country_canonical_slug($countryId);
    $relative = fk_url($slug . '/');
    $qs = [];
    if ($uiLang !== null && $uiLang !== '' && $uiLang !== FK_LANG_DEFAULT) {
        $qs['lang'] = $uiLang;
    }
    $query = $qs ? '?' . http_build_query($qs) : '';
    if ($absolute) {
        return rtrim($site_url ?? '', '/') . '/' . $slug . '/' . $query;
    }
    return $relative . $query;
}

/** @return list<array{hreflang: string, url: string}> */
function fk_country_hreflang_alternates(string $countryId): array
{
    global $site_url, $FK_LANGS;
    $base = rtrim($site_url ?? '', '/') . '/' . fk_country_canonical_slug($countryId) . '/';
    $alts = [];
    foreach (array_keys($FK_LANGS ?? []) as $code) {
        $meta = $FK_LANGS[$code] ?? [];
        $alts[] = [
            'hreflang' => (string) ($meta['html'] ?? $code),
            'url'      => $base . ($code === FK_LANG_DEFAULT ? '' : '?lang=' . urlencode($code)),
        ];
    }
    return $alts;
}

/**
 * @return array{
 *   meta_title: string,
 *   meta_desc: string,
 *   badge: string,
 *   h1: string,
 *   lead: string,
 *   business_heading: string,
 *   tax_line: string,
 *   sector_label: string
 * }
 */
function fk_country_seo_copy(string $countryId, string $uiLang, array $country, array $registryMeta): array
{
    $uiLang = in_array($uiLang, array_keys(fk_langs()), true) ? $uiLang : FK_LANG_DEFAULT;
    $countryName = fk_localized($country, 'name', $uiLang);
    $taxLabel = fk_localized($country, 'tax_label', $uiLang);
    $rate = ($country['tax_mode'] ?? 'vat') === 'single'
        ? (float) ($country['single_tax_rate'] ?? 0)
        : (float) ($country['vat_rate'] ?? 0);
    $currency = (string) ($country['currency'] ?? '');
    $sector = (string) (($registryMeta['sector_native'][$uiLang] ?? $registryMeta['sector_native']['en'] ?? ''));

    $vars = [
        '{country}'    => $countryName,
        '{tax}'        => $taxLabel,
        '{rate}'       => rtrim(rtrim(number_format($rate, 2, '.', ''), '0'), '.'),
        '{currency}'   => $currency,
        '{sector}'     => $sector,
    ];
    $fill = static function (string $tpl) use ($vars): string {
        return str_replace(array_keys($vars), array_values($vars), $tpl);
    };

    $packs = [
        'en' => [
            'meta_title'       => 'Faktura Creator for {country} — {tax} invoicing for accountants & SMEs',
            'meta_desc'        => 'Admin panel for {country}: {tax} {rate}%, {currency}, local company fields and a {sector} demo invoice in the market language. 30-day demo, BILOHASH support.',
            'badge'            => '{country} · {tax} {rate}% · {currency}',
            'h1'               => 'Invoicing admin panel for {country}',
            'lead'             => 'Faktura Creator helps accountants and SMEs in {country} issue compliant invoices with {tax}, {currency} and local company defaults. A few clicks of setup — and you get automation.',
            'business_heading' => 'Business example',
            'tax_line'         => '{tax} {rate}% · {currency} · {sector}',
            'sector_label'     => 'Sector',
        ],
        'uk' => [
            'meta_title'       => 'Faktura Creator для {country} — рахунки з {tax} для бухгалтерів і МСП',
            'meta_desc'        => 'Адмін-панель для {country}: {tax} {rate}%, {currency}, локальні реквізити та демо-рахунок ({sector}) мовою ринку. 30-денне демо, підтримка BILOHASH.',
            'badge'            => '{country} · {tax} {rate}% · {currency}',
            'h1'               => 'Адмін-панель для рахунків у {country}',
            'lead'             => 'Faktura Creator допомагає бухгалтерам і МСП у {country} виставляти коректні рахунки з {tax}, {currency} та локальними полями компанії. Налаштування в декілька кліків — і ви отримуєте автоматизацію.',
            'business_heading' => 'Приклад бізнесу',
            'tax_line'         => '{tax} {rate}% · {currency} · {sector}',
            'sector_label'     => 'Сфера',
        ],
        'no' => [
            'meta_title'       => 'Faktura Creator for {country} — MVA-fakturering for regnskapsførere og SMB',
            'meta_desc'        => 'Adminpanel for {country}: {tax} {rate} %, {currency}, lokale firmafelt og demofaktura ({sector}) på markedspråk. 30-dagers demo, BILOHASH-støtte.',
            'badge'            => '{country} · {tax} {rate} % · {currency}',
            'h1'               => 'Faktureringspanel for {country}',
            'lead'             => 'Faktura Creator hjelper regnskapsførere og SMB i {country} med korrekte fakturaer med {tax}, {currency} og lokale firmainnstillinger. Noen få klikk — full automatisering.',
            'business_heading' => 'Eksempel på virksomhet',
            'tax_line'         => '{tax} {rate} % · {currency} · {sector}',
            'sector_label'     => 'Bransje',
        ],
        'lt' => [
            'meta_title'       => 'Faktura Creator {country} — PVM sąskaitos buhalteriams ir MVĮ',
            'meta_desc'        => 'Admin skydelis {country}: {tax} {rate} %, {currency}, vietiniai laukai ir demo sąskaita ({sector}) rinkos kalba. 30 dienų demo, BILOHASH palaikymas.',
            'badge'            => '{country} · {tax} {rate} % · {currency}',
            'h1'               => 'Sąskaitų admin skydelis {country}',
            'lead'             => 'Faktura Creator padeda buhalteriams ir MVĮ {country} išrašyti teisingas sąskaitas su {tax}, {currency} ir vietiniais įmonės laukais. Keli paspaudimai — automatizavimas.',
            'business_heading' => 'Verslo pavyzdys',
            'tax_line'         => '{tax} {rate} % · {currency} · {sector}',
            'sector_label'     => 'Sritis',
        ],
        'pl' => [
            'meta_title'       => 'Faktura Creator — {country}: faktury VAT dla księgowych i MŚP',
            'meta_desc'        => 'Panel dla {country}: {tax} {rate}%, {currency}, lokalne pola firmy i demo faktura ({sector}) w języku rynku. 30-dniowe demo, wsparcie BILOHASH.',
            'badge'            => '{country} · {tax} {rate}% · {currency}',
            'h1'               => 'Panel faktur dla {country}',
            'lead'             => 'Faktura Creator pomaga księgowym i MŚP w {country} wystawiać poprawne faktury z {tax}, {currency} i lokalnymi danymi firmy. Kilka kliknięć — pełna automatyzacja.',
            'business_heading' => 'Przykład biznesu',
            'tax_line'         => '{tax} {rate}% · {currency} · {sector}',
            'sector_label'     => 'Branża',
        ],
        'de' => [
            'meta_title'       => 'Faktura Creator für {country} — Rechnungen mit {tax} für Buchhalter & KMU',
            'meta_desc'        => 'Admin-Panel für {country}: {tax} {rate} %, {currency}, lokale Firmenfelder und Demo-Rechnung ({sector}) in Marktsprache. 30-Tage-Demo, BILOHASH-Support.',
            'badge'            => '{country} · {tax} {rate} % · {currency}',
            'h1'               => 'Rechnungs-Admin-Panel für {country}',
            'lead'             => 'Faktura Creator unterstützt Buchhalter und KMU in {country} bei konformen Rechnungen mit {tax}, {currency} und lokalen Firmendaten. Ein paar Klicks — volle Automatisierung.',
            'business_heading' => 'Unternehmensbeispiel',
            'tax_line'         => '{tax} {rate} % · {currency} · {sector}',
            'sector_label'     => 'Branche',
        ],
        'sv' => [
            'meta_title'       => 'Faktura Creator för {country} — fakturering med {tax} för revisorer och småföretag',
            'meta_desc'        => 'Adminpanel för {country}: {tax} {rate} %, {currency}, lokala fält och demofaktura ({sector}) på marknadsspråk. 30-dagars demo, BILOHASH-support.',
            'badge'            => '{country} · {tax} {rate} % · {currency}',
            'h1'               => 'Faktureringspanel för {country}',
            'lead'             => 'Faktura Creator hjälper revisorer och småföretag i {country} med korrekta fakturor med {tax}, {currency} och lokala företagsfält. Några klick — full automatisering.',
            'business_heading' => 'Företagsexempel',
            'tax_line'         => '{tax} {rate} % · {currency} · {sector}',
            'sector_label'     => 'Bransch',
        ],
    ];

    $pack = $packs[$uiLang] ?? $packs['en'];
    $out = [];
    foreach ($pack as $key => $tpl) {
        $out[$key] = $fill($tpl);
    }
    return $out;
}

function fk_country_native_lang_label(string $nativeLang): string
{
    $labels = [
        'en' => 'English',
        'uk' => 'Українська',
        'no' => 'Norsk',
        'lt' => 'Lietuvių',
        'pl' => 'Polski',
        'de' => 'Deutsch',
        'sv' => 'Svenska',
    ];
    return $labels[$nativeLang] ?? strtoupper($nativeLang);
}

/** @return array<string, array<string, mixed>> */
function fk_country_seo_active_list(array $settings): array
{
    $registry = fk_country_seo_registry();
    $list = [];
    foreach (fk_active_countries($settings) as $country) {
        $id = $country['id'] ?? '';
        if ($id === '' || !isset($registry[$id])) {
            continue;
        }
        $list[$id] = array_merge($registry[$id], ['country' => $country]);
    }
    return $list;
}