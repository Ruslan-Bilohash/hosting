# Faktura Creator

**PHP-adminpanel for regnskapsførere og bedriftseiere** — klienter, MVA for 7 land, fakturamaler, SMTP, AI-betalingsnotater, QR-betaling og BILOHASH-økosystem-støtte. Porteføljeprosjekt av [Ruslan Bilohash](https://bilohash.com/).

**Versjon (dette repo):** 1.0.0 · **Readme-språk:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-innebygd-purple)

---

## Viktig — kun demo-repositorium

> **Dette GitHub-repositoriet inneholder et demo / porteføljeeksempel av Faktura Creator.**
> Det er **ikke** det komplette kommersielle produktet og **ikke** nødvendigvis den nyeste versjonen.
>
> **Nyeste fullversjon**, oppdateringer og kommersiell støtte er tilgjengelig **kun fra forfatteren**:
> - Live demo: https://bilohash.com/faktura/
> - 30-dagers selvinstallasjon: https://bilohash.com/faktura/demo-install.php
> - Abonnement: https://bilohash.com/ecosystem/join.php
> - Kontakt: **rbilohash@gmail.com**

**Kommersiell bruk uten skriftlig samtykke fra forfatteren er forbudt.** Se [LICENSE](LICENSE).

---

## Live demo

| Ressurs | URL |
|---------|-----|
| **Forside** | https://bilohash.com/faktura/ |
| **Opprett faktura** | https://bilohash.com/faktura/create.php |
| **Tjenestekalkulator** | https://bilohash.com/faktura/calc.php |
| **Adminpanel** | https://bilohash.com/faktura/admin/ |
| **Hjelp og video** | https://bilohash.com/faktura/help.php |
| **30-dagers demo-nedlasting** | https://bilohash.com/faktura/demo-install.php |
| **BILOHASH-kundeportal** | https://bilohash.com/ecosystem/cabinet.php |

**Admin-innlogging (demo):** `demo` / `bilofaktura2026`

---

## AI innebygd fra start

Faktura Creator har **innebygd AI-hjelp** (OpenAI / xAI Grok — API-nøkkel i admin):

| Område | Hva AI gjør |
|--------|-------------|
| **E-postnotater** | Personlig notat ved sending av fakturaer |
| **E-postemne** | Korte emnelinjer for faktura-e-post |
| **Fakturanotater** | Betalingsvilkår og bankoverføringstekst |
| **Support** | Utkast til økosystem-støtte og kunde-e-post |

Demomodus fungerer **uten API-nøkkel** — flerspråklige maler for evaluering.

---

## Funksjoner

### Offentlig frontend
- Mobil-først fakturaoppretting med MVA-presets per land
- **7 markeder:** UK, Norge, Litauen, Polen, Tyskland, Sverige, Ukraina
- **12 utskriftsdesign** — A4, Letter, Legal; forhåndsvisning og utskrift/PDF
- Tjenestekalkulator med forhåndsinnstillinger
- Lagre fakturaer og kalkulasjoner; delbare lenker
- QR på fakturaer — betalings-URL-mal eller egen lenke
- Demofakturaer på forsiden per land
- Hjelpeside med skjermbilder og video
- Språk: **EN, UA, LT, PL, DE, SV, NO** (`?lang=` + informasjonskapsel)
- Kontakt og BILOHASH-økosystem

### Adminpanel
- **Dashboard** — klienter, fakturaer, demo på forsiden, MVA-tabell
- **Klienter** — database for faktura på 2 klikk
- **Fakturaer** — søk, utskrift, e-post, demo på forsiden
- **Kalkulasjoner** — lagrede tjenestetilbud
- **Tjenestepresets** — kalkulatormaler og betalings-URL
- **Send e-post** — SMTP med AI-notater
- **Innstillinger** — firma, nummerering, QR
- **Land og skatt** — MVA / enkelt sats
- **Maler** — standard linjer
- **SMTP** — vert, port, TLS (demo logger til `email-log.json`)
- **AI** — leverandør, modell, prompts, henvisningslenker
- **Support og e-post** — BILOHASH-innboks, eier-chat, kundeutkast
- Flerspråklig admin

### BILOHASH-økosystem
- **30-dagers ZIP** — nedlasting fra kundeportal etter abonnement
- **Supportmeldinger** — tråder med BILOHASH fra admin
- **Abonnement** — 49 kr/mnd (1 CMS) eller 249 kr/mnd (alle skript på 1 domene)

---

## Teknisk stack

- PHP 8+ (uten rammeverk)
- JSON-lagring (`data/*.json`)
- Modulær i18n (`lang/*.php`)
- Apache `.htaccess`, kanoniske URL-er, hreflang
- Font Awesome 6, vanlig CSS og JS
- OpenAI-kompatibel API (OpenAI, xAI Grok)

---

## Krav

- PHP 8.0 eller nyere
- Apache med `mod_rewrite`
- Skrivbar `data/`-mappe
- SMTP (valgfritt — demo logger e-post lokalt)

---

## Installasjon

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Kopier `faktura/` til webroten (f.eks. `/faktura/`).
2. Skriverettigheter på `data/`:
   ```bash
   chmod 755 data
   ```
3. Åpne `https://ditt-domene.no/faktura/`.
4. Admin: `https://ditt-domene.no/faktura/admin/` — endre påloggingsdata før produksjon.

### Selvinstallasjon (30 dager)

1. Abonner på https://bilohash.com/ecosystem/join.php
2. Logg inn i [kundeportalen](https://bilohash.com/ecosystem/cabinet.php) og last ned demo-ZIP
3. Last opp til hosting (f.eks. `/public_html/faktura/`)
4. Guide: https://bilohash.com/faktura/demo-install.php

### Lokal PHP-server

```bash
cd faktura
php -S localhost:8080
```

### Konfigurasjon (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
```

---

## Prosjektstruktur

```
faktura/
├── index.php              # Forside — landdemoer
├── create.php             # Opprett faktura
├── calc.php               # Tjenestekalkulator
├── invoice.php            # Vis / skriv ut
├── help.php / contact.php
├── demo-install.php       # 30-dagers pakke
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Admin + support API
├── api/                   # lagre faktura, AI (offentlig)
└── LICENSE
```

---

## Demo-modus

- Demopålogging vist på innloggingssiden
- SMTP av — e-post logges til `data/email-log.json`
- AI uten nøkkel — lokale maler
- Eksempelfakturaer på forsiden

### Bygg demo-pakke

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

### Språkkontroll

```bash
node scripts/check-lang-keys.mjs
```

---

## Forfatter og kommersiell lisens

**Ruslan Bilohash**
- Nettsted: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- E-post: rbilohash@gmail.com

For **kommersiell lisens**, full kildekode eller **nyeste produksjonsversjon**, kontakt forfatteren. Se [LICENSE](LICENSE).