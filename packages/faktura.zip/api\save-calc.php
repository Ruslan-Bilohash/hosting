<?php
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__) . '/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fk_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$invoiceNo = trim((string) ($payload['invoice_no'] ?? ''));
if ($invoiceNo === '') {
    fk_json_response(['ok' => false, 'error' => 'invoice_no required'], 400);
}

$presetId = trim((string) ($payload['preset_id'] ?? ''));
if ($presetId !== '' && fk_get_service_preset($presetId) === null) {
    fk_json_response(['ok' => false, 'error' => 'invalid preset'], 400);
}

$lines = [];
foreach ($payload['lines'] ?? [] as $line) {
    if (!is_array($line)) {
        continue;
    }
    $lines[] = [
        'desc'  => trim((string) ($line['desc'] ?? '')),
        'qty'   => (float) ($line['qty'] ?? 0),
        'price' => (float) ($line['price'] ?? 0),
    ];
}

$total = 0.0;
foreach ($lines as $line) {
    $total += $line['qty'] * $line['price'];
}
$total = round($total, 2);

$buyer = is_array($payload['buyer'] ?? null) ? $payload['buyer'] : [];
$title = trim((string) ($payload['title'] ?? ''));
if ($title === '') {
    $title = trim((string) ($buyer['name'] ?? ''));
    if ($title === '') {
        $title = $invoiceNo;
    }
}

$record = [
    'title'            => $title,
    'preset_id'        => $presetId,
    'invoice_no'       => $invoiceNo,
    'invoice_date'     => (string) ($payload['invoice_date'] ?? ''),
    'due_date'         => (string) ($payload['due_date'] ?? ''),
    'buyer'            => [
        'name'    => trim((string) ($buyer['name'] ?? '')),
        'code'    => trim((string) ($buyer['code'] ?? '')),
        'address' => trim((string) ($buyer['address'] ?? '')),
        'phone'   => trim((string) ($buyer['phone'] ?? '')),
        'email'   => trim((string) ($buyer['email'] ?? '')),
    ],
    'lines'            => $lines,
    'total'            => $total,
    'payment_purpose'  => trim((string) ($payload['payment_purpose'] ?? '')),
    'payment_url'      => trim((string) ($payload['payment_url'] ?? '')),
    'lang'             => $lang,
    'country_id'       => (string) ($payload['country_id'] ?? ''),
];

$existingId = trim((string) ($payload['id'] ?? ''));
if ($existingId !== '' && fk_get_calc($existingId) !== null) {
    $saved = fk_update_calc($existingId, $record);
    if ($saved === null) {
        fk_json_response(['ok' => false, 'error' => 'update failed'], 500);
    }
} else {
    $saved = fk_add_calc($record);
}

fk_json_response([
    'ok'   => true,
    'id'   => $saved['id'],
    'view' => fk_url('calc.php?id=' . urlencode($saved['id'])),
]);