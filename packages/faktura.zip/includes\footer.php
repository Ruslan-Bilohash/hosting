</main>
<?php
if (empty($fk_skip_ecosystem) && is_file(__DIR__ . '/ecosystem-strip.php')) {
    require __DIR__ . '/ecosystem-strip.php';
}
?>
<footer class="fk-footer">
    <p><?= fk_h($t['footer_copy'] ?? '© BILOHASH Faktura Creator') ?></p>
    <p class="fk-footer-links">
        <a href="https://bilohash.com/">BILOHASH</a> ·
        <a href="<?= fk_h(fk_demo_url()) ?>" rel="related"><?= fk_h($t['footer']['demo_link'] ?? 'Live demo') ?></a> ·
        <a href="<?= fk_h(fk_url('demo-install.php')) ?>"><?= fk_h($t['nav']['demo_install'] ?? '30-day demo') ?></a> ·
        <a href="https://bilohash.com/ecosystem/join.php"><?= fk_h($t['footer']['ecosystem'] ?? 'BILOHASH ecosystem') ?></a> ·
        <a href="<?= fk_h(fk_url('help.php')) ?>"><?= fk_h($t['nav']['help'] ?? 'Help') ?></a> ·
        <a href="<?= fk_h(fk_url('contact.php')) ?>"><?= fk_h($t['nav']['contact'] ?? 'Contact') ?></a> ·
        <a href="<?= fk_h(fk_admin_url('login.php')) ?>"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?></a>
    </p>
</footer>
<script src="<?= fk_h(fk_asset('js/fk-nav.js')) ?>?v=3" defer></script>
<?php if (!empty($extra_js)): foreach ((array)$extra_js as $js): ?>
<script src="<?= fk_h($js) ?>" defer></script>
<?php endforeach; endif; ?>
</body>
</html>