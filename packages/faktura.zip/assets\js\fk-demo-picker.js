(function () {
    var select = document.getElementById('fk-demo-select');
    if (!select) return;

    var shot = document.getElementById('fk-demo-shot');
    var meta = document.getElementById('fk-demo-meta');
    var view = document.getElementById('fk-demo-view');
    var thumbs = document.querySelectorAll('.fk-demo-thumb');

    function applyOption(opt) {
        if (!opt) return;
        if (shot && opt.dataset.shot) {
            shot.src = opt.dataset.shot;
            shot.alt = opt.dataset.label || '';
        }
        if (meta) meta.textContent = opt.dataset.meta || '';
        if (view && opt.dataset.view) view.href = opt.dataset.view;
        thumbs.forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-demo-id') === opt.value);
        });
    }

    select.addEventListener('change', function () {
        applyOption(select.options[select.selectedIndex]);
    });

    thumbs.forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = btn.getAttribute('data-demo-id');
            if (!id) return;
            for (var i = 0; i < select.options.length; i++) {
                if (select.options[i].value === id) {
                    select.selectedIndex = i;
                    applyOption(select.options[i]);
                    break;
                }
            }
        });
    });

    applyOption(select.options[select.selectedIndex]);
})();