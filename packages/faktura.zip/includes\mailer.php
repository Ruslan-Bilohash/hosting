<?php

/**
 * SMTP mail + invoice emails.
 */

function fk_email_log_path(): string
{
    return 'email-log.json';
}

function fk_log_email(array $entry): void
{
    $list = fk_load_json(fk_email_log_path(), []);
    if (!is_array($list)) {
        $list = [];
    }
    $entry['at'] = $entry['at'] ?? gmdate('c');
    array_unshift($list, $entry);
    fk_save_json(fk_email_log_path(), array_slice($list, 0, 200));
}

function fk_smtp_read_line($fp): string
{
    $data = '';
    while (!feof($fp)) {
        $line = fgets($fp, 515);
        if ($line === false) {
            break;
        }
        $data .= $line;
        if (strlen($line) < 4 || $line[3] === ' ') {
            break;
        }
    }
    return $data;
}

function fk_smtp_expect($fp, array $codes): bool
{
    $resp = fk_smtp_read_line($fp);
    $code = (int) substr($resp, 0, 3);
    return in_array($code, $codes, true);
}

function fk_smtp_cmd($fp, string $cmd, array $ok): bool
{
    fwrite($fp, $cmd . "\r\n");
    return fk_smtp_expect($fp, $ok);
}

/**
 * @return array{ok: bool, error: string, demo: bool}
 */
function fk_send_email(array $settings, string $to, string $subject, string $htmlBody, string $textBody = ''): array
{
    $to = trim($to);
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => 'Invalid recipient email', 'demo' => false];
    }

    $smtp = $settings['smtp'] ?? [];
    $fromEmail = trim($smtp['from_email'] ?? '');
    $fromName = trim($smtp['from_name'] ?? 'Faktura Creator');
    if ($fromEmail === '' || !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
        $fromEmail = 'invoice@bilohash.com';
    }

    if (empty($smtp['enabled']) || empty($smtp['host'])) {
        fk_log_email([
            'to' => $to, 'subject' => $subject, 'status' => 'demo_logged',
            'note' => 'SMTP disabled — email stored in log only',
        ]);
        return ['ok' => true, 'error' => '', 'demo' => true];
    }

    $host = $smtp['host'];
    $port = (int) ($smtp['port'] ?? 587);
    $enc = $smtp['encryption'] ?? 'tls';
    $user = $smtp['username'] ?? '';
    $pass = $smtp['password'] ?? '';

    $remote = ($enc === 'ssl' ? 'ssl://' : '') . $host . ':' . $port;
    $errno = 0;
    $errstr = '';
    $fp = @stream_socket_client($remote, $errno, $errstr, 20, STREAM_CLIENT_CONNECT);
    if (!$fp) {
        return ['ok' => false, 'error' => "SMTP connect failed: $errstr", 'demo' => false];
    }
    stream_set_timeout($fp, 20);

    if (!fk_smtp_expect($fp, [220])) {
        fclose($fp);
        return ['ok' => false, 'error' => 'SMTP greeting failed', 'demo' => false];
    }

    $ehloHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
    if (!fk_smtp_cmd($fp, 'EHLO ' . $ehloHost, [250])) {
        fclose($fp);
        return ['ok' => false, 'error' => 'SMTP EHLO failed', 'demo' => false];
    }

    if ($enc === 'tls') {
        if (!fk_smtp_cmd($fp, 'STARTTLS', [220])) {
            fclose($fp);
            return ['ok' => false, 'error' => 'STARTTLS failed', 'demo' => false];
        }
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($fp);
            return ['ok' => false, 'error' => 'TLS handshake failed', 'demo' => false];
        }
        if (!fk_smtp_cmd($fp, 'EHLO ' . $ehloHost, [250])) {
            fclose($fp);
            return ['ok' => false, 'error' => 'SMTP EHLO after TLS failed', 'demo' => false];
        }
    }

    if ($user !== '') {
        if (!fk_smtp_cmd($fp, 'AUTH LOGIN', [334])
            || !fk_smtp_cmd($fp, base64_encode($user), [334])
            || !fk_smtp_cmd($fp, base64_encode($pass), [235])) {
            fclose($fp);
            return ['ok' => false, 'error' => 'SMTP authentication failed', 'demo' => false];
        }
    }

    if (!fk_smtp_cmd($fp, 'MAIL FROM:<' . $fromEmail . '>', [250])
        || !fk_smtp_cmd($fp, 'RCPT TO:<' . $to . '>', [250, 251])
        || !fk_smtp_cmd($fp, 'DATA', [354])) {
        fclose($fp);
        return ['ok' => false, 'error' => 'SMTP envelope failed', 'demo' => false];
    }

    $textBody = $textBody !== '' ? $textBody : strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $htmlBody));
    $boundary = 'fk_' . bin2hex(random_bytes(8));
    $subjectEnc = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $fromHeader = $fromName !== '' ? '=?UTF-8?B?' . base64_encode($fromName) . '?= <' . $fromEmail . '>' : $fromEmail;

    $msg = "From: {$fromHeader}\r\n";
    $msg .= "To: <{$to}>\r\n";
    $msg .= "Subject: {$subjectEnc}\r\n";
    $msg .= "MIME-Version: 1.0\r\n";
    $msg .= "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n\r\n";
    $msg .= "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $msg .= chunk_split(base64_encode($textBody)) . "\r\n";
    $msg .= "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $msg .= chunk_split(base64_encode($htmlBody)) . "\r\n";
    $msg .= "--{$boundary}--\r\n";
    $msg = str_replace("\n.", "\n..", $msg);

    fwrite($fp, $msg . "\r\n.\r\n");
    if (!fk_smtp_expect($fp, [250])) {
        fclose($fp);
        return ['ok' => false, 'error' => 'SMTP DATA failed', 'demo' => false];
    }

    fk_smtp_cmd($fp, 'QUIT', [221]);
    fclose($fp);

    fk_log_email(['to' => $to, 'subject' => $subject, 'status' => 'sent']);
    return ['ok' => true, 'error' => '', 'demo' => false];
}

function fk_invoice_email_content(array $invoice, array $settings, string $lang, string $customNote = ''): array
{
    global $site_url;
    $ti = [];
    $langFile = __DIR__ . '/../lang/' . $lang . '.php';
    if (is_file($langFile)) {
        $ti = (require $langFile)['invoice'] ?? [];
    }
    if ($ti === []) {
        $ti = (require __DIR__ . '/../lang/en.php')['invoice'] ?? [];
    }
    $mail = (require __DIR__ . '/../lang/en.php');
    if (is_file($langFile)) {
        $mail = array_replace_recursive($mail, require $langFile);
    }
    $em = $mail['email'] ?? [];

    $company = $settings['company']['name'] ?? 'Faktura Creator';
    $invNo = $invoice['invoice_no'] ?? '';
    $total = fk_money((float) ($invoice['totals']['total'] ?? 0), $invoice['currency'] ?? '');
    $viewUrl = rtrim($site_url ?? '', '/') . '/invoice.php?id=' . urlencode($invoice['id'] ?? '');
    $due = $invoice['due_date'] ?? '';

    $subject = str_replace(['{no}', '{company}'], [$invNo, $company], $em['subject'] ?? 'Invoice {no} from {company}');

    $html = '<div style="font-family:Inter,Arial,sans-serif;max-width:520px;color:#1e293b">';
    $html .= '<h2 style="color:#1e40af;margin:0 0 12px">' . htmlspecialchars($em['heading'] ?? 'Your invoice') . '</h2>';
    $html .= '<p>' . htmlspecialchars(str_replace('{name}', $invoice['buyer']['name'] ?? ($em['default_name'] ?? 'Customer'), $em['greeting'] ?? 'Hello,')) . '</p>';
    $html .= '<p><strong>' . htmlspecialchars($ti['invoice_no'] ?? 'Invoice') . ':</strong> ' . htmlspecialchars($invNo) . '<br>';
    $html .= '<strong>' . htmlspecialchars($ti['total'] ?? 'Total') . ':</strong> ' . htmlspecialchars($total) . '<br>';
    if ($due) {
        $html .= '<strong>' . htmlspecialchars($ti['due_date'] ?? 'Due') . ':</strong> ' . htmlspecialchars($due) . '<br>';
    }
    $html .= '</p>';
    if ($customNote !== '') {
        $html .= '<p style="color:#64748b">' . nl2br(htmlspecialchars($customNote)) . '</p>';
    }
    $html .= '<p><a href="' . htmlspecialchars($viewUrl) . '" style="display:inline-block;background:#1e40af;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:600">'
        . htmlspecialchars($em['btn'] ?? 'View & print invoice') . '</a></p>';
    $html .= '<p style="font-size:12px;color:#94a3b8">' . htmlspecialchars($em['footer'] ?? 'Sent via Faktura Creator') . '</p></div>';

    $text = ($em['heading'] ?? 'Invoice') . "\n{$invNo}\n{$total}\n{$viewUrl}";

    return ['subject' => $subject, 'html' => $html, 'text' => $text];
}

/**
 * @return array{ok: bool, error: string, demo: bool}
 */
function fk_send_invoice_to_client(array $settings, array $invoice, array $client, string $lang, string $customNote = ''): array
{
    $email = trim($client['email'] ?? '');
    if ($email === '') {
        return ['ok' => false, 'error' => 'Client has no email', 'demo' => false];
    }
    $content = fk_invoice_email_content($invoice, $settings, $lang, $customNote);
    $result = fk_send_email($settings, $email, $content['subject'], $content['html'], $content['text']);
    if ($result['ok']) {
        fk_update_invoice($invoice['id'] ?? '', [
            'client_id' => $client['id'] ?? '',
            'last_sent_at' => gmdate('c'),
            'last_sent_to' => $email,
        ]);
    }
    return $result;
}

function fk_client_to_buyer(array $client): array
{
    return [
        'name' => $client['name'] ?? '',
        'org_nr' => $client['org_nr'] ?? '',
        'vat_nr' => $client['vat_nr'] ?? '',
        'address' => $client['address'] ?? '',
        'city' => $client['city'] ?? '',
        'postal' => $client['postal'] ?? '',
        'country' => $client['country'] ?? '',
        'email' => $client['email'] ?? '',
        'phone' => $client['phone'] ?? '',
    ];
}