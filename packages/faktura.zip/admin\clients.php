<?php
require_once __DIR__ . '/init.php';

$ta = $t['admin'] ?? [];
$adm_title = $ta['clients'] ?? 'Clients';
$adm_nav_active = 'clients';
$adm_body_class = 'adm-page-clients';
$adm_saved = false;
$adm_error = '';
$editId = trim($_GET['edit'] ?? '');
$editing = $editId !== '' ? fk_get_client($editId) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $action = $_POST['action'] ?? 'save';

    if ($action === 'delete') {
        $id = trim($_POST['client_id'] ?? '');
        if ($id !== '' && fk_delete_client($id)) {
            $adm_saved = true;
            $editing = null;
            $editId = '';
        }
    } else {
        $fields = [
            'name' => trim($_POST['name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'org_nr' => trim($_POST['org_nr'] ?? ''),
            'vat_nr' => trim($_POST['vat_nr'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'city' => trim($_POST['city'] ?? ''),
            'postal' => trim($_POST['postal'] ?? ''),
            'country' => trim($_POST['country'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'notes' => trim($_POST['notes'] ?? ''),
        ];
        if ($fields['name'] === '' || $fields['email'] === '') {
            $adm_error = $ta['client_required'] ?? 'Name and email required.';
        } else {
            $id = trim($_POST['client_id'] ?? '');
            if ($id !== '' && fk_get_client($id)) {
                fk_update_client($id, $fields);
            } else {
                fk_add_client($fields);
            }
            $adm_saved = true;
            $editId = '';
            $editing = null;
        }
    }
}

$clients = fk_load_clients();
$invoices = fk_load_invoices();
$settings = fk_load_settings();
$clientCount = count($clients);
$adm_extra_js = [fk_asset('js/admin-clients.js') . '?v=1'];

require __DIR__ . '/includes/layout.php';
?>

<?php if ($adm_error): ?><div class="adm-error"><?= fk_h($adm_error) ?></div><?php endif; ?>

<div class="adm-card adm-card--flush">
    <div class="adm-doc-head">
        <div class="adm-doc-head-text">
            <h2><i class="fas fa-users" aria-hidden="true"></i> <?= fk_h($ta['clients_list'] ?? 'All clients') ?> (<?= $clientCount ?>)</h2>
            <p><?= fk_h($ta['clients_hint'] ?? 'Search by name, email, phone or city. Reuse clients when creating invoices.') ?></p>
        </div>
        <a href="#adm-client-form" class="adm-btn adm-btn-primary adm-btn-sm">
            <i class="fas fa-user-plus" aria-hidden="true"></i> <?= fk_h($ta['client_add'] ?? 'Add client') ?>
        </a>
    </div>

    <?php if (empty($clients)): ?>
    <p class="adm-empty"><i class="fas fa-inbox" aria-hidden="true"></i> <?= fk_h($ta['clients_empty'] ?? 'No clients yet. Add your first client below.') ?></p>
    <?php else: ?>
    <div class="adm-doc-toolbar adm-clients-toolbar">
        <label class="adm-doc-search adm-clients-search">
            <i class="fas fa-magnifying-glass" aria-hidden="true"></i>
            <input type="search" id="adm-clients-search" placeholder="<?= fk_h($ta['client_search'] ?? 'Search by name, email, phone, city…') ?>" autocomplete="off" aria-label="<?= fk_h($ta['client_search'] ?? 'Search clients') ?>">
        </label>
    </div>
    <p class="adm-doc-result" id="adm-clients-result" aria-live="polite"></p>

    <div class="adm-clients-table-wrap adm-table-wrap">
        <table class="adm-table adm-table--icons">
            <thead>
                <tr>
                    <th><i class="fas fa-user" aria-hidden="true"></i><?= fk_h($ta['client_name'] ?? 'Name') ?></th>
                    <th><i class="fas fa-envelope" aria-hidden="true"></i><?= fk_h($ta['client_email'] ?? 'Email') ?></th>
                    <th><i class="fas fa-phone" aria-hidden="true"></i><?= fk_h($t['invoice']['phone'] ?? 'Phone') ?></th>
                    <th><span class="adm-sr-only"><?= fk_h($ta['inv_actions'] ?? 'Actions') ?></span></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($clients as $c):
                    $searchBlob = strtolower(implode(' ', [
                        $c['name'] ?? '',
                        $c['email'] ?? '',
                        $c['phone'] ?? '',
                        $c['city'] ?? '',
                        $c['country'] ?? '',
                        $c['org_nr'] ?? '',
                        $c['vat_nr'] ?? '',
                    ]));
                ?>
                <tr class="adm-client-row" data-search="<?= fk_h($searchBlob) ?>">
                    <td><strong><?= fk_h($c['name'] ?? '') ?></strong><br><span class="adm-client-meta"><?= fk_h(trim(($c['city'] ?? '') . ' ' . ($c['country'] ?? ''))) ?></span></td>
                    <td><a href="mailto:<?= fk_h($c['email'] ?? '') ?>"><?= fk_h($c['email'] ?? '') ?></a></td>
                    <td><?= fk_h($c['phone'] ?? '—') ?></td>
                    <td>
                        <div class="adm-actions-row adm-actions-row--tight">
                            <a href="<?= fk_h(fk_admin_url('clients.php?edit=' . urlencode($c['id'] ?? ''))) ?>" class="adm-btn adm-btn-ghost adm-btn-sm" title="<?= fk_h($ta['client_edit'] ?? 'Edit') ?>"><i class="fas fa-edit" aria-hidden="true"></i></a>
                            <a href="<?= fk_h(fk_admin_url('send-mail.php?client_id=' . urlencode($c['id'] ?? ''))) ?>" class="adm-btn adm-btn-ghost adm-btn-sm" title="<?= fk_h($ta['send_email'] ?? 'Send') ?>"><i class="fas fa-paper-plane" aria-hidden="true"></i></a>
                            <form method="post" class="adm-inline-form" onsubmit="return confirm('<?= fk_h($ta['client_delete_confirm'] ?? 'Delete client?') ?>');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="client_id" value="<?= fk_h($c['id'] ?? '') ?>">
                                <button type="submit" class="adm-btn adm-btn-danger adm-btn-sm" title="<?= fk_h($ta['delete'] ?? 'Delete') ?>"><i class="fas fa-trash" aria-hidden="true"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="adm-clients-cards" id="adm-clients-cards">
        <?php foreach ($clients as $c):
            $searchBlob = strtolower(implode(' ', [
                $c['name'] ?? '',
                $c['email'] ?? '',
                $c['phone'] ?? '',
                $c['city'] ?? '',
                $c['country'] ?? '',
                $c['org_nr'] ?? '',
                $c['vat_nr'] ?? '',
            ]));
        ?>
        <article class="adm-client-card" data-search="<?= fk_h($searchBlob) ?>">
            <div class="adm-client-card-head">
                <span class="adm-client-card-avatar"><i class="fas fa-user" aria-hidden="true"></i></span>
                <div>
                    <strong><?= fk_h($c['name'] ?? '') ?></strong>
                    <?php if (!empty($c['city']) || !empty($c['country'])): ?>
                    <span class="adm-client-meta"><?= fk_h(trim(($c['city'] ?? '') . ' ' . ($c['country'] ?? ''))) ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <p class="adm-client-card-line"><i class="fas fa-envelope" aria-hidden="true"></i> <a href="mailto:<?= fk_h($c['email'] ?? '') ?>"><?= fk_h($c['email'] ?? '') ?></a></p>
            <?php if (!empty($c['phone'])): ?>
            <p class="adm-client-card-line"><i class="fas fa-phone" aria-hidden="true"></i> <?= fk_h($c['phone']) ?></p>
            <?php endif; ?>
            <div class="adm-client-card-actions">
                <a href="<?= fk_h(fk_admin_url('clients.php?edit=' . urlencode($c['id'] ?? ''))) ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><i class="fas fa-edit" aria-hidden="true"></i> <?= fk_h($ta['client_edit'] ?? 'Edit') ?></a>
                <a href="<?= fk_h(fk_admin_url('send-mail.php?client_id=' . urlencode($c['id'] ?? ''))) ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><i class="fas fa-paper-plane" aria-hidden="true"></i></a>
                <form method="post" class="adm-inline-form" onsubmit="return confirm('<?= fk_h($ta['client_delete_confirm'] ?? 'Delete client?') ?>');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="client_id" value="<?= fk_h($c['id'] ?? '') ?>">
                    <button type="submit" class="adm-btn adm-btn-danger adm-btn-sm"><i class="fas fa-trash" aria-hidden="true"></i></button>
                </form>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<div class="adm-grid-2" style="align-items:start" id="adm-client-form">
    <div class="adm-card">
        <h2><?= fk_h($editing ? ($ta['client_edit'] ?? 'Edit client') : ($ta['client_add'] ?? 'Add client')) ?></h2>
        <form method="post">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="client_id" value="<?= fk_h($editing['id'] ?? '') ?>">
            <?php foreach (['name','email','org_nr','vat_nr','phone','address','city','postal','country'] as $f): ?>
            <div class="adm-field">
                <label><?= fk_h($ta['client_' . $f] ?? ($t['invoice'][$f] ?? $f)) ?><?= in_array($f, ['name','email'], true) ? ' *' : '' ?></label>
                <input type="<?= $f === 'email' ? 'email' : 'text' ?>" name="<?= $f ?>" value="<?= fk_h($editing[$f] ?? '') ?>" <?= in_array($f, ['name','email'], true) ? 'required' : '' ?>>
            </div>
            <?php endforeach; ?>
            <div class="adm-field">
                <label><?= fk_h($ta['client_notes'] ?? 'Notes') ?></label>
                <textarea name="notes" rows="2"><?= fk_h($editing['notes'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="adm-btn adm-btn-primary" style="width:auto"><?= fk_h($ta['save'] ?? 'Save') ?></button>
            <?php if ($editing): ?>
            <a href="<?= fk_h(fk_admin_url('clients.php')) ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><?= fk_h($ta['cancel'] ?? 'Cancel') ?></a>
            <?php endif; ?>
        </form>
    </div>

    <div class="adm-card">
        <h2><?= fk_h($ta['client_send_title'] ?? 'Send invoice by email') ?></h2>
        <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 1rem"><?= fk_h($ta['client_send_hint'] ?? 'Configure SMTP in SMTP & subscription. Select client and saved invoice.') ?></p>
        <form method="post" action="<?= fk_h(fk_admin_url('send-mail.php')) ?>">
            <div class="adm-field">
                <label><?= fk_h($ta['client_pick'] ?? 'Client') ?></label>
                <select name="client_id" required>
                    <option value="">—</option>
                    <?php foreach ($clients as $c): ?>
                    <option value="<?= fk_h($c['id']) ?>"><?= fk_h($c['name'] ?? '') ?> &lt;<?= fk_h($c['email'] ?? '') ?>&gt;</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['invoice_pick'] ?? 'Invoice') ?></label>
                <select name="invoice_id" required>
                    <option value="">—</option>
                    <?php foreach ($invoices as $inv): ?>
                    <option value="<?= fk_h($inv['id'] ?? '') ?>"><?= fk_h($inv['invoice_no'] ?? '') ?> — <?= fk_h(fk_money((float)($inv['totals']['total'] ?? 0), $inv['currency'] ?? '')) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['email_note'] ?? 'Personal note (optional)') ?></label>
                <textarea name="custom_note" rows="2" placeholder="<?= fk_h($ta['email_note_ph'] ?? 'Thank you for your business.') ?>"></textarea>
            </div>
            <button type="submit" class="adm-btn adm-btn-primary" style="width:auto"><i class="fas fa-paper-plane"></i> <?= fk_h($ta['send_email'] ?? 'Send email') ?></button>
        </form>
        <?php if (empty($settings['smtp']['enabled'])): ?>
        <p class="adm-field-hint" style="margin-top:.75rem"><i class="fas fa-info-circle"></i> <?= fk_h($ta['smtp_demo_note'] ?? 'SMTP off: emails are logged to email-log.json (demo).') ?></p>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>