# Faktura Creator

**PHP administravimo panelė buhalteriams ir verslo savininkams** — klientai, PVM 7 šalims, sąskaitų šablonai, SMTP, AI mokėjimo pastabos, QR mokėjimai ir BILOHASH ekosistemos palaikymas. Portfelio projektas — [Ruslan Bilohash](https://bilohash.com/).

**Versija (šis repo):** 1.0.0 · **Readme kalbos:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-įmontuota-purple)

---

## Svarbu — tik demo saugykla

> **Šiame GitHub saugykloje pateiktas Faktura Creator demo / portfelio pavyzdys.**
> Tai **ne** pilnas komercinis produktas ir **ne** būtinai naujausia versija.
>
> **Naujausia pilna versija**, atnaujinimai ir komercinė pagalba prieinami **tik pas autorių**:
> - Gyva demonstracija: https://bilohash.com/faktura/
> - 30 dienų savarankiškas diegimas: https://bilohash.com/faktura/demo-install.php
> - Prenumerata: https://bilohash.com/ecosystem/join.php
> - Kontaktas: **rbilohash@gmail.com**

**Komercinis naudojimas be raštiško autoriaus sutikimo draudžiamas.** Žr. [LICENSE](LICENSE).

---

## Gyva demonstracija

| Išteklius | URL |
|-----------|-----|
| **Pagrindinis** | https://bilohash.com/faktura/ |
| **Sukurti sąskaitą** | https://bilohash.com/faktura/create.php |
| **Paslaugų skaičiuoklė** | https://bilohash.com/faktura/calc.php |
| **Administravimas** | https://bilohash.com/faktura/admin/ |
| **Pagalba ir video** | https://bilohash.com/faktura/help.php |
| **30 dienų demo atsisiuntimas** | https://bilohash.com/faktura/demo-install.php |
| **BILOHASH klientų kabinetas** | https://bilohash.com/ecosystem/cabinet.php |

**Admin prisijungimas (demo):** `demo` / `bilofaktura2026`

---

## AI įmontuota iš karto

Faktura Creator turi **įmontuotą AI pagalbą** (OpenAI / xAI Grok — API raktas admin panelėje):

| Sritis | Ką daro AI |
|--------|------------|
| **El. pašto pastabos** | Asmeninė pastaba siunčiant sąskaitas klientams |
| **El. pašto tema** | Trumpos temos sąskaitų laiškams |
| **Sąskaitos pastabos** | Mokėjimo sąlygos ir banko pavedimo tekstas |
| **Palaikymas** | Ekonominės ekosistemos ir klientų laiškų juodraščiai |

Demo režimas veikia **be API rakto** — daugiakalbiai šablonai.

---

## Funkcijos

### Viešas frontendas
- Mobilus sąskaitų kūrimas su PVM nustatymais pagal šalį
- **7 rinkos:** UK, Norvegija, Lietuva, Lenkija, Vokietija, Švedija, Ukraina
- **12 spausdinimo maketų** — A4, Letter, Legal; peržiūra ir spausdinimas/PDF
- Paslaugų skaičiuoklė su šablonais
- Išsaugotos sąskaitos ir skaičiavimai; bendrinamos nuorodos
- QR ant sąskaitų — mokėjimo URL šablonas arba nuosava nuoroda
- Demo sąskaitos pagrindiniame puslapyje kiekvienai šaliai
- Pagalbos puslapis su ekrano nuotraukomis ir video
- Kalbos: **EN, UA, LT, PL, DE, SV, NO** (`?lang=` + slapukas)
- Kontaktas ir BILOHASH ekosistemos juosta

### Administravimo panelė
- **Dashboard** — klientai, sąskaitos, demo pagrindiniame, PVM lentelė
- **Klientai** — duomenų bazė sąskaitoms dviem paspaudimais
- **Sąskaitos** — paieška, spausdinimas, el. paštas, demo pagrindiniame
- **Skaičiavimai** — išsaugoti paslaugų pasiūlymai
- **Paslaugų šablonai** — skaičiuoklės ir mokėjimo URL
- **Siųsti el. paštą** — SMTP su AI pastabomis
- **Nustatymai** — įmonė, numeracija, QR
- **Šalys ir mokesčiai** — PVM / viena norma
- **Šablonai** — numatytos eilutės
- **SMTP** — serveris, portas, TLS (demo į `email-log.json`)
- **AI** — tiekėjas, modelis, promptai, referral nuorodos
- **Palaikymas ir paštas** — BILOHASH inbox, ekosistemos pokalbis, klientų juodraščiai
- Daugiakalbis admin

### BILOHASH ekosistema
- **30 dienų ZIP** — atsisiuntimas iš kabineto po prenumeratos
- **Palaikymo žinutės** — pokalbiai su BILOHASH iš admin
- **Prenumerata** — 49 kr/mėn. (1 CMS) arba 249 kr/mėn. (visi skriptai 1 domene)

---

## Technologijos

- PHP 8+ (be framework)
- JSON saugykla (`data/*.json`)
- Modulinis i18n (`lang/*.php`)
- Apache `.htaccess`, kanoniniai URL, hreflang
- Font Awesome 6, paprastas CSS ir JS
- OpenAI suderinamas API (OpenAI, xAI Grok)

---

## Reikalavimai

- PHP 8.0 ar naujesnė
- Apache su `mod_rewrite`
- Rašomas `data/` katalogas
- SMTP (neprivaloma — demo logina el. paštą lokaliai)

---

## Diegimas

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Nukopijuokite `faktura/` į web root (pvz. `/faktura/`).
2. Rašymo teisės `data/`:
   ```bash
   chmod 755 data
   ```
3. Atidarykite `https://jusu-domenas.lt/faktura/`.
4. Admin: `https://jusu-domenas.lt/faktura/admin/` — pakeiskite prisijungimo duomenis.

### Savarankiškas diegimas (30 dienų)

1. Prenumeruokite https://bilohash.com/ecosystem/join.php
2. Prisijunkite prie [klientų kabineto](https://bilohash.com/ecosystem/cabinet.php) ir atsisiųskite demo ZIP
3. Įkelkite į hostingą
4. Vadovas: https://bilohash.com/faktura/demo-install.php

### Vietinis PHP serveris

```bash
cd faktura
php -S localhost:8080
```

### Konfigūracija (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
```

---

## Projekto struktūra

```
faktura/
├── index.php              # Pagrindinis — demo pagal šalis
├── create.php             # Sąskaitos kūrimas
├── calc.php               # Paslaugų skaičiuoklė
├── invoice.php            # Peržiūra / spausdinimas
├── help.php / contact.php
├── demo-install.php       # 30 dienų paketas
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Admin + support API
├── api/                   # išsaugoti sąskaitą, AI (vieša)
└── LICENSE
```

---

## Demo režimas

- Demo prisijungimas rodomas prisijungimo puslapyje
- SMTP išjungtas — laiškai į `data/email-log.json`
- AI be rakto — vietiniai šablonai
- Pavyzdinės sąskaitos pagrindiniame puslapyje

### Demo paketo surinkimas

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

### Vertimų tikrinimas

```bash
node scripts/check-lang-keys.mjs
```

---

## Autorius ir komercinė licencija

**Ruslan Bilohash**
- Svetainė: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- El. paštas: rbilohash@gmail.com

**Komercinei licencijai**, pilnam kodui ar **naujausiai versijai** kreipkitės į autorių. Žr. [LICENSE](LICENSE).