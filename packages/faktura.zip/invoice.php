<?php
require_once __DIR__ . '/init.php';

$id = trim($_GET['id'] ?? '');
$inv = fk_get_invoice($id);
if ($inv === null) {
    http_response_code(404);
    $current_page = 'invoice';
    require __DIR__ . '/includes/header.php';
    echo '<div class="fk-card"><h1>404</h1><p><a href="' . fk_h(fk_url('index.php')) . '">' . fk_h($t['breadcrumb_home'] ?? 'Home') . '</a></p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$settings = fk_load_settings();
$ti = $t['invoice'] ?? [];
$embed = !empty($_GET['embed']);
$current_page = 'invoice';
$page_title = ($inv['invoice_no'] ?? 'Invoice') . ' — Faktura Creator';
$printDesign = fk_normalize_print_design($inv['print_design'] ?? ($settings['print_design'] ?? 'classic-blue'));
$printFormat = fk_normalize_print_format($inv['print_format'] ?? ($settings['print_format'] ?? 'a4'));
$currency = $inv['currency'] ?? '';
$extra_css = [
    fk_asset('css/print.css') . '?v=4',
    fk_asset('css/print-demo.css') . '?v=1',
];
$body_class = fk_print_classes($printDesign, $printFormat) . ($embed ? ' fk-embed' : '');
if ($embed) {
    $fk_skip_ecosystem = true;
}

require __DIR__ . '/includes/header.php';
?>

<?php if (!$embed): ?>
<div class="fk-actions fk-no-print" style="margin-bottom:1rem">
    <a href="<?= fk_url('index.php') ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-arrow-left"></i> <?= fk_h($t['breadcrumb_home'] ?? 'Home') ?></a>
    <button type="button" class="fk-btn fk-btn-primary" id="fk-print-saved"><i class="fas fa-print"></i> <?= fk_h($ti['print'] ?? 'Print') ?></button>
    <span class="fk-tax-badge"><?= fk_h(fk_print_design_name($printDesign, $lang)) ?> · <?= fk_h(fk_print_format_name($printFormat, $lang)) ?></span>
</div>
<?php endif; ?>

<?php fk_render_invoice_article($inv, $ti, $currency, $printDesign, $printFormat, true, $settings); ?>

<script>
(function(){
    var fmt = <?= json_encode($printFormat) ?>;
    var css = <?= json_encode(fk_print_formats()) ?>;
    var pageCss = (css[fmt] && css[fmt].css) ? css[fmt].css : 'A4';
    document.getElementById('fk-print-saved').addEventListener('click', function(){
        var s = document.getElementById('fk-dynamic-page');
        if (!s) { s = document.createElement('style'); s.id = 'fk-dynamic-page'; document.head.appendChild(s); }
        s.textContent = '@page { size: ' + pageCss + '; margin: 8mm; }';
        window.print();
    });
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>