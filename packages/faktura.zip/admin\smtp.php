<?php
require_once __DIR__ . '/init.php';

$adm_title = $t['admin']['smtp_sub'] ?? 'SMTP & subscription';
$adm_nav_active = 'smtp';
$settings = fk_load_settings();
$adm_saved = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $settings['smtp'] = array_merge($settings['smtp'] ?? [], [
        'enabled'    => !empty($_POST['smtp_enabled']),
        'host'       => trim($_POST['smtp_host'] ?? ''),
        'port'       => max(1, (int) ($_POST['smtp_port'] ?? 587)),
        'encryption' => in_array($_POST['smtp_encryption'] ?? '', ['tls', 'ssl', 'none'], true)
            ? $_POST['smtp_encryption'] : 'tls',
        'username'   => trim($_POST['smtp_username'] ?? ''),
        'from_email' => trim($_POST['smtp_from_email'] ?? ''),
        'from_name'  => trim($_POST['smtp_from_name'] ?? ''),
    ]);
    if (trim($_POST['smtp_password'] ?? '') !== '') {
        $settings['smtp']['password'] = $_POST['smtp_password'];
    }

    $settings['subscription'] = array_merge($settings['subscription'] ?? [], [
        'enabled'      => !empty($_POST['sub_enabled']),
        'script_price' => max(0, (float) ($_POST['sub_script_price'] ?? 49)),
        'full_price'   => max(0, (float) ($_POST['sub_full_price'] ?? 249)),
        'currency'     => trim($_POST['sub_currency'] ?? 'NOK'),
        'note_en'      => trim($_POST['sub_note_en'] ?? ''),
        'note_no'      => trim($_POST['sub_note_no'] ?? ''),
        'note_uk'      => trim($_POST['sub_note_uk'] ?? ''),
        'join_url'     => trim($_POST['sub_join_url'] ?? ''),
    ]);

    fk_save_settings($settings);
    $adm_saved = true;
}

$smtp = $settings['smtp'] ?? [];
$sub = $settings['subscription'] ?? [];

require __DIR__ . '/includes/layout.php';
?>

<form method="post">
    <div class="adm-card">
        <h2><?= fk_h($t['admin']['smtp_title'] ?? 'SMTP settings') ?></h2>
        <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 1rem"><?= fk_h($t['admin']['smtp_hint'] ?? 'Configure outgoing mail for future invoice delivery. Password is stored in settings.json (demo).') ?></p>
        <div class="adm-field">
            <label><input type="checkbox" name="smtp_enabled" value="1" <?= !empty($smtp['enabled']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['active'] ?? 'Enabled') ?></label>
        </div>
        <div class="adm-grid-2">
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_host'] ?? 'SMTP host') ?></label>
                <input type="text" name="smtp_host" value="<?= fk_h($smtp['host'] ?? '') ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_port'] ?? 'Port') ?></label>
                <input type="number" name="smtp_port" value="<?= (int) ($smtp['port'] ?? 587) ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_encryption'] ?? 'Encryption') ?></label>
                <select name="smtp_encryption">
                    <?php foreach (['tls' => 'TLS', 'ssl' => 'SSL', 'none' => 'None'] as $val => $lbl): ?>
                    <option value="<?= $val ?>" <?= ($smtp['encryption'] ?? 'tls') === $val ? 'selected' : '' ?>><?= $lbl ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_username'] ?? 'Username') ?></label>
                <input type="text" name="smtp_username" value="<?= fk_h($smtp['username'] ?? '') ?>" autocomplete="off">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_password'] ?? 'Password') ?></label>
                <input type="password" name="smtp_password" value="" placeholder="<?= !empty($smtp['password']) ? '••••••••' : '' ?>" autocomplete="new-password">
                <p class="adm-field-hint"><?= fk_h($t['admin']['smtp_password_hint'] ?? 'Leave blank to keep current password.') ?></p>
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_from_email'] ?? 'From email') ?></label>
                <input type="email" name="smtp_from_email" value="<?= fk_h($smtp['from_email'] ?? '') ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['smtp_from_name'] ?? 'From name') ?></label>
                <input type="text" name="smtp_from_name" value="<?= fk_h($smtp['from_name'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="adm-card">
        <h2><?= fk_h($t['admin']['subscription_title'] ?? 'BILOHASH subscription') ?></h2>
        <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 1rem"><?= fk_h($t['admin']['subscription_hint'] ?? 'Pricing text shown on Help page (EN / NO / UA).') ?></p>
        <div class="adm-field">
            <label><input type="checkbox" name="sub_enabled" value="1" <?= !empty($sub['enabled']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['active'] ?? 'Enabled') ?></label>
        </div>
        <div class="adm-grid-2">
            <div class="adm-field">
                <label><?= fk_h($t['admin']['sub_script_price'] ?? '1 CMS price') ?></label>
                <input type="number" step="0.01" name="sub_script_price" value="<?= fk_h((string) ($sub['script_price'] ?? 49)) ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['sub_full_price'] ?? 'All CMS price') ?></label>
                <input type="number" step="0.01" name="sub_full_price" value="<?= fk_h((string) ($sub['full_price'] ?? 249)) ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['invoice']['currency'] ?? 'Currency') ?></label>
                <input type="text" name="sub_currency" value="<?= fk_h($sub['currency'] ?? 'NOK') ?>">
            </div>
            <div class="adm-field">
                <label><?= fk_h($t['admin']['sub_join_url'] ?? 'Join URL') ?></label>
                <input type="url" name="sub_join_url" value="<?= fk_h($sub['join_url'] ?? '') ?>">
            </div>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['sub_note_en'] ?? 'Note (English)') ?></label>
            <textarea name="sub_note_en" rows="2"><?= fk_h($sub['note_en'] ?? '') ?></textarea>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['sub_note_no'] ?? 'Note (Norwegian)') ?></label>
            <textarea name="sub_note_no" rows="2"><?= fk_h($sub['note_no'] ?? '') ?></textarea>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['sub_note_uk'] ?? 'Note (Ukrainian)') ?></label>
            <textarea name="sub_note_uk" rows="2"><?= fk_h($sub['note_uk'] ?? '') ?></textarea>
        </div>
    </div>

    <button type="submit" class="adm-btn adm-btn-primary" style="width:auto"><?= fk_h($t['admin']['save'] ?? 'Save changes') ?></button>
</form>

<?php require __DIR__ . '/includes/layout-end.php'; ?>