<?php
require_once __DIR__ . '/init.php';

$adm_title = $t['admin']['calcs'] ?? 'Saved calculations';
$adm_nav_active = 'calcs';
$adm_body_class = 'adm-page-calcs';
$adm_saved = false;
$ta = $t['admin'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $deleteId = trim($_POST['delete_id'] ?? '');
    if ($deleteId !== '' && fk_delete_calc($deleteId)) {
        $adm_saved = true;
    }
}

$list = fk_load_calcs();
$presets = fk_load_service_presets();
$presetNames = [];
foreach ($presets as $p) {
    $presetNames[$p['id'] ?? ''] = fk_localized($p, 'name', $lang);
}

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card adm-card--flush">
    <div class="adm-doc-head">
        <div class="adm-doc-head-text">
            <h2><i class="fas fa-calculator" aria-hidden="true"></i> <?= fk_h($adm_title) ?></h2>
            <p><?= fk_h($ta['calcs_hint'] ?? 'Service calculator drafts — open, print or delete.') ?></p>
        </div>
        <a href="<?= fk_url('calc.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank" rel="noopener">
            <i class="fas fa-plus" aria-hidden="true"></i> <?= fk_h($ta['calcs_create'] ?? 'New calculation') ?>
        </a>
    </div>

    <?php if (empty($list)): ?>
    <p class="adm-empty"><i class="fas fa-inbox" aria-hidden="true"></i> <?= fk_h($ta['calcs_empty'] ?? 'No saved calculations yet.') ?></p>
    <?php else: ?>
    <div class="adm-doc-stats">
        <div class="adm-doc-stat"><i class="fas fa-calculator" aria-hidden="true"></i><strong><?= count($list) ?></strong><span><?= fk_h($ta['calcs_count'] ?? 'Calculations') ?></span></div>
    </div>

    <div class="adm-table-wrap">
        <table class="adm-table">
            <thead>
                <tr>
                    <th><?= fk_h($ta['calcs_col_title'] ?? 'Title') ?></th>
                    <th><?= fk_h($ta['calcs_col_preset'] ?? 'Preset') ?></th>
                    <th><?= fk_h($ta['calcs_col_total'] ?? 'Total') ?></th>
                    <th><?= fk_h($ta['calcs_col_date'] ?? 'Updated') ?></th>
                    <th><?= fk_h($ta['inv_actions'] ?? 'Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($list as $row):
                    $pid = $row['preset_id'] ?? '';
                    $cur = '€';
                    foreach ($presets as $p) {
                        if (($p['id'] ?? '') === $pid) {
                            $cur = ($p['currency'] ?? 'EUR') === 'EUR' ? '€' : ($p['currency'] ?? 'EUR');
                            break;
                        }
                    }
                    $total = fk_calc_total($row);
                    $updated = $row['updated_at'] ?? $row['created_at'] ?? '';
                    $updatedFmt = $updated !== '' ? date('Y-m-d H:i', strtotime($updated)) : '—';
                ?>
                <tr>
                    <td>
                        <strong><?= fk_h(fk_calc_title($row)) ?></strong><br>
                        <span style="font-size:.78rem;color:var(--adm-muted)"><?= fk_h($row['invoice_no'] ?? '') ?></span>
                    </td>
                    <td><?= fk_h($presetNames[$pid] ?? $pid ?: '—') ?></td>
                    <td><?= fk_h(number_format($total, 2, '.', ' ')) ?> <?= fk_h($cur) ?></td>
                    <td><?= fk_h($updatedFmt) ?></td>
                    <td class="adm-actions-cell">
                        <a href="<?= fk_h(fk_url('calc.php?id=' . urlencode($row['id'] ?? ''))) ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank" rel="noopener">
                            <i class="fas fa-eye" aria-hidden="true"></i> <?= fk_h($ta['view'] ?? 'View') ?>
                        </a>
                        <form method="post" style="display:inline" onsubmit="return confirm('<?= fk_h($ta['calcs_delete_confirm'] ?? 'Delete this calculation?') ?>')">
                            <input type="hidden" name="delete_id" value="<?= fk_h($row['id'] ?? '') ?>">
                            <button type="submit" class="adm-btn adm-btn-danger adm-btn-sm"><i class="fas fa-trash" aria-hidden="true"></i> <?= fk_h($ta['delete'] ?? 'Delete') ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>