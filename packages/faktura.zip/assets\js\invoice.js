(function () {
    'use strict';

    const cfg = window.FK_INVOICE || {};
    const i18n = cfg.i18n || {};
    const countries = cfg.countries || [];
    const clients = cfg.clients || [];
    const templates = cfg.templates || [];
    const lang = cfg.lang || 'en';

    const el = (id) => document.getElementById(id);

    function localized(obj, field) {
        if (!obj) return '';
        const v = obj[field];
        if (typeof v === 'string') return v;
        if (v && typeof v === 'object') return v[lang] || v.en || Object.values(v)[0] || '';
        return '';
    }

    function countryById(id) {
        return countries.find((c) => c.id === id) || countries[0];
    }

    function templatesForCountry(countryId) {
        return templates.filter((t) => t.country_id === countryId);
    }

    function parseLines() {
        const rows = document.querySelectorAll('#fk-lines-body tr');
        const lines = [];
        rows.forEach((row) => {
            const desc = row.querySelector('.fk-line-desc')?.value?.trim() || '';
            const qty = parseFloat(row.querySelector('.fk-line-qty')?.value) || 0;
            const price = parseFloat(row.querySelector('.fk-line-price')?.value) || 0;
            const payUrl = row.querySelector('.fk-line-pay-url')?.value?.trim() || '';
            if (desc || qty || price || payUrl) {
                lines.push({ desc, qty, price, unit: row.querySelector('.fk-line-unit')?.value || 'pcs', pay_url: payUrl });
            }
        });
        return lines;
    }

    function calcTotals(lines, country) {
        let subtotal = 0;
        lines.forEach((l) => { subtotal += l.qty * l.price; });
        subtotal = Math.round(subtotal * 100) / 100;
        const mode = country.tax_mode || 'vat';
        const rate = mode === 'single' ? (country.single_tax_rate || 0) : (country.vat_rate || 0);
        const taxAmount = Math.round(subtotal * rate) / 100;
        let total;
        if (mode === 'single') {
            total = Math.round((subtotal - taxAmount) * 100) / 100;
        } else {
            total = Math.round((subtotal + taxAmount) * 100) / 100;
        }
        const taxLabel = localized(country, 'tax_label') || 'VAT';
        return { subtotal, taxAmount, total, rate, mode, taxLabel };
    }

    function money(amount, currency) {
        return amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ' + (currency || '');
    }

    function addLineRow(data) {
        const tbody = el('fk-lines-body');
        if (!tbody) return;
        const tr = document.createElement('tr');
        const payPh = (i18n.line_pay_url_ph || 'https://…').replace(/"/g, '&quot;');
        tr.innerHTML = `
            <td><input type="text" class="fk-line-desc" value="${(data?.desc || '').replace(/"/g, '&quot;')}"></td>
            <td class="col-qty"><input type="number" class="fk-line-qty" min="0" step="any" value="${data?.qty ?? 1}"></td>
            <td class="col-unit"><input type="text" class="fk-line-unit" value="${data?.unit || 'pcs'}"></td>
            <td class="col-price"><input type="number" class="fk-line-price" min="0" step="any" value="${data?.price ?? 0}"></td>
            <td class="col-total fk-line-sum">0</td>
            <td class="col-pay"><input type="url" class="fk-line-pay-url" placeholder="${payPh}" value="${(data?.pay_url || '').replace(/"/g, '&quot;')}"></td>
            <td><button type="button" class="fk-btn fk-btn-ghost fk-btn-sm fk-remove-line">${i18n.remove_line || 'Remove'}</button></td>`;
        tbody.appendChild(tr);
        tr.querySelectorAll('input').forEach((inp) => inp.addEventListener('input', updateAll));
        tr.querySelector('.fk-remove-line')?.addEventListener('click', () => { tr.remove(); updateAll(); });
        updateAll();
    }

    function fillCompany(prefix, data) {
        ['name', 'org_nr', 'vat_nr', 'address', 'city', 'postal', 'country', 'email', 'phone', 'bank', 'iban', 'bic'].forEach((f) => {
            const input = el(prefix + '_' + f);
            if (input && data[f] !== undefined) input.value = data[f];
        });
    }

    function updateLineSums() {
        document.querySelectorAll('#fk-lines-body tr').forEach((row) => {
            const qty = parseFloat(row.querySelector('.fk-line-qty')?.value) || 0;
            const price = parseFloat(row.querySelector('.fk-line-price')?.value) || 0;
            const sum = row.querySelector('.fk-line-sum');
            if (sum) sum.textContent = (qty * price).toFixed(2);
        });
    }

    function updatePreview() {
        const countryId = el('fk-country')?.value;
        const country = countryById(countryId);
        const lines = parseLines();
        const totals = calcTotals(lines, country);
        const currency = country.currency || '';

        updateLineSums();

        const hasLinePay = lines.some((l) => l.pay_url);
        const payCol = el('fk-preview-pay-col');
        if (payCol) payCol.hidden = !hasLinePay;

        const previewLines = el('fk-preview-lines');
        const payLabel = i18n.pay_btn || 'Pay';
        if (previewLines) {
            previewLines.innerHTML = lines.map((l) => {
                const payCell = hasLinePay
                    ? `<td class="fk-line-pay-cell">${l.pay_url ? `<a href="${l.pay_url.replace(/"/g, '&quot;')}" class="fk-pay-btn fk-pay-btn--sm" target="_blank" rel="noopener noreferrer">${payLabel}</a>` : ''}</td>`
                    : '';
                return `<tr>
                    <td>${l.desc}</td>
                    <td>${l.qty} ${l.unit}</td>
                    <td>${money(l.price, currency)}</td>
                    <td>${money(l.qty * l.price, currency)}</td>
                    ${payCell}
                </tr>`;
            }).join('');
        }

        el('fk-sum-subtotal').textContent = money(totals.subtotal, currency);
        const taxRow = el('fk-sum-tax-row');
        const taxLabel = el('fk-sum-tax-label');
        const taxVal = el('fk-sum-tax');
        if (taxRow && taxLabel && taxVal) {
            const lbl = totals.mode === 'single' ? (i18n.single_tax || 'Single tax') : (i18n.tax || 'Tax');
            taxLabel.textContent = `${lbl} (${totals.taxLabel} ${totals.rate}%)`;
            taxVal.textContent = (totals.mode === 'single' ? '−' : '+') + money(totals.taxAmount, currency);
            taxRow.style.display = totals.rate > 0 ? 'flex' : 'none';
        }
        el('fk-sum-total').textContent = money(totals.total, currency);

        const badgeText = totals.mode === 'single'
            ? `${i18n.tax_mode_single || 'Single tax'}: ${totals.rate}%`
            : `${i18n.tax_mode_vat || 'VAT'}: ${totals.rate}% · ${currency}`;
        ['fk-tax-badge', 'fk-tax-badge-preview'].forEach((id) => {
            const badge = el(id);
            if (badge) badge.textContent = badgeText;
        });

        ['seller', 'buyer'].forEach((party) => {
            const box = el('fk-preview-' + party);
            if (!box) return;
            const fields = ['name', 'org_nr', 'vat_nr', 'address', 'city', 'postal', 'country', 'email', 'phone'];
            box.innerHTML = fields.map((f) => {
                const v = el(party + '_' + f)?.value?.trim();
                return v ? (f === 'name' ? `<strong>${v}</strong>` : `<div>${v}</div>`) : '';
            }).join('');
        });

        el('fk-preview-inv-no').textContent = el('invoice_no')?.value || '';
        el('fk-preview-inv-date').textContent = el('invoice_date')?.value || '';
        el('fk-preview-due-date').textContent = el('due_date')?.value || '';
        el('fk-preview-notes').textContent = el('notes')?.value || '';

        const payBox = el('fk-preview-payment');
        const purpose = el('payment_purpose')?.value?.trim();
        const iban = el('seller_iban')?.value?.trim();
        const bank = el('seller_bank')?.value?.trim();
        if (payBox) {
            let html = '';
            if (iban || bank) {
                html += `<strong>${i18n.payment || 'Payment'}:</strong> `;
                if (bank) html += `${bank} `;
                if (iban) html += `IBAN ${iban}<br>`;
            }
            if (purpose) html += `<strong>${i18n.payment_purpose || 'Reference'}:</strong> ${purpose}`;
            const invPayUrl = resolveInvoicePayUrl(country, totals, purpose);
            if (invPayUrl) {
                html += `<div><a href="${invPayUrl.replace(/"/g, '&quot;')}" class="fk-pay-btn fk-pay-btn--invoice" target="_blank" rel="noopener noreferrer">${i18n.pay_now || 'Pay now'}</a></div>`;
            }
            payBox.innerHTML = html;
        }
        updateQrPreview(country, totals);
        syncPaymentPurpose();
    }

    function resolveInvoicePayUrl(country, totals, purpose) {
        const custom = el('payment_url')?.value?.trim() || '';
        if (custom) return custom;
        const tpl = cfg.qr?.payment_url_template || i18n.qr_payment_template || '';
        if (!tpl) return '';
        const invNo = el('invoice_no')?.value?.trim() || '';
        return tpl
            .replace(/\{amount\}/g, String(totals.total))
            .replace(/\{invoice_no\}/g, invNo)
            .replace(/\{currency\}/g, country.currency || '')
            .replace(/\{id\}/g, '')
            .replace(/\{reference\}/g, purpose || invNo);
    }

    function buildQrTarget(country, totals) {
        const qr = cfg.qr || {};
        if (!qr.enabled) return '';
        const mode = qr.mode || 'invoice_link';
        const invNo = el('invoice_no')?.value?.trim() || '';
        const purpose = el('payment_purpose')?.value?.trim() || invNo;
        if (mode === 'payment_url') {
            const custom = el('payment_url')?.value?.trim() || '';
            if (custom) return custom;
            const tpl = qr.payment_url_template || '';
            if (tpl) {
                return tpl
                    .replace(/\{amount\}/g, String(totals.total))
                    .replace(/\{invoice_no\}/g, invNo)
                    .replace(/\{currency\}/g, country.currency || '')
                    .replace(/\{id\}/g, '')
                    .replace(/\{reference\}/g, purpose);
            }
        }
        if (mode === 'custom' && qr.custom_url) return qr.custom_url;
        const base = (cfg.site_url || '').replace(/\/$/, '');
        return invNo ? base + '/invoice.php?id=preview&no=' + encodeURIComponent(invNo) : '';
    }

    function updateQrPreview(country, totals) {
        const box = el('fk-preview-qr');
        if (!box) return;
        const target = buildQrTarget(country, totals);
        if (!target) {
            box.hidden = true;
            box.innerHTML = '';
            return;
        }
        const size = Math.max(80, Math.min(200, parseInt(cfg.qr?.size, 10) || 120));
        const img = 'https://api.qrserver.com/v1/create-qr-code/?size=' + size + 'x' + size + '&margin=8&data=' + encodeURIComponent(target);
        let html = '<img src="' + img + '" alt="' + (i18n.qr_scan || 'QR') + '" width="' + size + '" height="' + size + '">';
        if (cfg.qr?.show_url_text) {
            html += '<div class="fk-preview-qr-url">' + target + '</div>';
        }
        box.innerHTML = html;
        box.hidden = false;
    }

    function updateAll() { updatePreview(); }

    function onCountryChange() {
        const countryId = el('fk-country')?.value;
        const country = countryById(countryId);
        if (country.company_override) fillCompany('seller', country.company_override);
        const tplSelect = el('fk-template');
        if (tplSelect) {
            const prev = tplSelect.value;
            tplSelect.innerHTML = `<option value="">${i18n.template_none || '— Empty —'}</option>`;
            templatesForCountry(countryId).forEach((t) => {
                const opt = document.createElement('option');
                opt.value = t.id;
                opt.textContent = localized(t, 'name');
                tplSelect.appendChild(opt);
            });
            if ([...tplSelect.options].some((o) => o.value === prev)) tplSelect.value = prev;
            else tplSelect.value = '';
        }
        updateAll();
    }

    function renderQuickButtons(tpl) {
        const wrap = el('fk-quick-add');
        const box = el('fk-quick-buttons');
        if (!wrap || !box) return;
        if (!tpl || !tpl.lines?.length) {
            wrap.hidden = true;
            box.innerHTML = '';
            return;
        }
        wrap.hidden = false;
        box.innerHTML = '';
        tpl.lines.forEach((line) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'fk-btn fk-btn-ghost fk-btn-sm fk-quick-btn';
            btn.textContent = localized(line, 'desc');
            btn.addEventListener('click', () => addLineRow({
                desc: localized(line, 'desc'),
                qty: line.qty,
                price: line.price,
                unit: line.unit,
            }));
            box.appendChild(btn);
        });
    }

    function syncPaymentPurpose() {
        const invNo = el('invoice_no')?.value?.trim() || '';
        const field = el('payment_purpose');
        if (!field) return;
        const prefix = i18n.payment_purpose_prefix || 'Payment for invoice';
        if (!field.dataset.touched) {
            field.value = invNo ? `${prefix} ${invNo}` : '';
        }
    }

    function onTemplateChange() {
        const tplId = el('fk-template')?.value;
        const tpl = templates.find((t) => t.id === tplId);
        const tbody = el('fk-lines-body');
        if (!tbody) return;
        tbody.innerHTML = '';
        renderQuickButtons(tpl || null);
        if (tpl && tpl.lines) {
            tpl.lines.forEach((line) => addLineRow({
                desc: localized(line, 'desc'),
                qty: line.qty,
                price: line.price,
                unit: line.unit,
            }));
        } else {
            addLineRow({});
        }
    }

    function getSelectedDesign() {
        const checked = document.querySelector('input[name="print_design_ui"]:checked');
        return checked?.value || cfg.print_design || 'classic-blue';
    }

    function getSelectedFormat() {
        return el('fk-print-format')?.value || cfg.print_format || 'a4';
    }

    function applyPrintTheme() {
        const preview = el('fk-preview');
        if (!preview) return;
        const design = getSelectedDesign();
        const format = getSelectedFormat();
        preview.classList.forEach((cls) => {
            if (cls.startsWith('fk-design-') || cls.startsWith('fk-fmt-')) preview.classList.remove(cls);
        });
        preview.classList.add('fk-design-' + design, 'fk-fmt-' + format);
    }

    function injectPageSize() {
        const format = getSelectedFormat();
        const map = cfg.print_formats || { a4: 'A4', a5: 'A5', letter: 'letter', legal: 'legal' };
        let style = el('fk-dynamic-page');
        if (!style) {
            style = document.createElement('style');
            style.id = 'fk-dynamic-page';
            document.head.appendChild(style);
        }
        style.textContent = '@page { size: ' + (map[format] || 'A4') + '; margin: 8mm; }';
    }

    function printInvoice() {
        applyPrintTheme();
        injectPageSize();
        window.print();
    }

    function onClientChange() {
        const id = el('fk-client')?.value;
        const client = clients.find((c) => c.id === id);
        if (client && client.buyer) {
            fillCompany('buyer', client.buyer);
            updateAll();
        }
    }

    function initPrintPicker() {
        document.querySelectorAll('.fk-design-option input[name="print_design_ui"]').forEach((inp) => {
            inp.addEventListener('change', () => {
                document.querySelectorAll('.fk-design-option').forEach((l) => l.classList.remove('selected'));
                inp.closest('.fk-design-option')?.classList.add('selected');
                applyPrintTheme();
            });
        });
        el('fk-print-format')?.addEventListener('change', applyPrintTheme);
        applyPrintTheme();
    }

    function collectParty(prefix) {
        const data = {};
        ['name', 'org_nr', 'vat_nr', 'address', 'city', 'postal', 'country', 'email', 'phone', 'bank', 'iban', 'bic'].forEach((f) => {
            const v = el(prefix + '_' + f)?.value?.trim();
            if (v) data[f] = v;
        });
        return data;
    }

    function collectFormData() {
        return {
            invoice_no: el('invoice_no')?.value?.trim() || '',
            invoice_date: el('invoice_date')?.value || '',
            due_date: el('due_date')?.value || '',
            country_id: el('fk-country')?.value || '',
            client_id: el('fk-client')?.value || '',
            seller: collectParty('seller'),
            buyer: collectParty('buyer'),
            lines: parseLines(),
            notes: el('notes')?.value || '',
            payment_purpose: el('payment_purpose')?.value || '',
            payment_url: el('payment_url')?.value?.trim() || '',
            print_design: getSelectedDesign(),
            print_format: getSelectedFormat(),
        };
    }

    function showSaveAlert(ok, message, link) {
        const box = el('fk-save-alert');
        if (!box) return;
        box.hidden = false;
        box.className = 'fk-alert ' + (ok ? 'fk-alert-ok' : 'fk-alert-err');
        let html = message;
        if (ok && link) {
            html += ' <a href="' + link + '">' + (i18n.saved_link || 'Open') + ' →</a>';
        }
        box.innerHTML = html;
    }

    async function saveInvoice() {
        const btn = el('fk-save');
        const payload = collectFormData();
        if (!payload.invoice_no) {
            showSaveAlert(false, i18n.save_error || 'Invoice number required.');
            return;
        }
        if (btn) {
            btn.disabled = true;
            btn.dataset.prev = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + (i18n.saving || 'Saving…');
        }
        try {
            const res = await fetch(cfg.save_url || 'api/save-invoice.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (data.ok) {
                showSaveAlert(true, i18n.saved || 'Invoice saved.', data.view);
                if (data.view) {
                    const noField = el('invoice_no');
                    const prefix = (noField?.value || '').replace(/\d+$/, '') || 'INV-';
                    const nextNum = parseInt(String(noField?.value || '').replace(/\D/g, ''), 10) + 1;
                    if (noField && nextNum) noField.value = prefix + nextNum;
                    syncPaymentPurpose();
                    updateAll();
                }
            } else {
                showSaveAlert(false, data.error || i18n.save_error || 'Error');
            }
        } catch (e) {
            showSaveAlert(false, i18n.save_error || 'Network error');
        } finally {
            if (btn) {
                btn.disabled = false;
                if (btn.dataset.prev) btn.innerHTML = btn.dataset.prev;
            }
        }
    }

    async function generateAiNotes() {
        const btn = el('fk-ai-notes');
        const status = el('fk-ai-notes-status');
        const notes = el('notes');
        if (!btn || !notes) return;
        const country = countryById(el('fk-country')?.value);
        const totals = calcTotals(parseLines(), country);
        btn.disabled = true;
        if (status) status.textContent = i18n.ai_generating || 'Generating…';
        try {
            const res = await fetch(cfg.ai_url || 'api/ai-notes.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    lang: lang,
                    provider: cfg.ai_provider || '',
                    invoice_no: el('invoice_no')?.value?.trim() || '',
                    total: String(totals.total),
                    currency: country.currency || '',
                    due_date: el('due_date')?.value || '',
                    iban: el('seller_iban')?.value?.trim() || '',
                    client_name: el('buyer_name')?.value?.trim() || '',
                }),
            });
            const data = await res.json();
            if (data.ok && data.text) {
                notes.value = data.text;
                updateAll();
                if (status) status.textContent = data.demo ? (i18n.ai_demo_ok || 'Template.') : (i18n.ai_ok || 'OK');
            } else if (status) {
                status.textContent = data.error || i18n.ai_failed || 'Failed';
            }
        } catch (e) {
            if (status) status.textContent = i18n.ai_failed || 'Failed';
        } finally {
            btn.disabled = false;
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        el('fk-country')?.addEventListener('change', onCountryChange);
        el('fk-template')?.addEventListener('change', onTemplateChange);
        el('fk-add-line')?.addEventListener('click', () => addLineRow({}));
        el('fk-print')?.addEventListener('click', printInvoice);
        el('fk-save')?.addEventListener('click', saveInvoice);
        el('fk-ai-notes')?.addEventListener('click', generateAiNotes);

        document.querySelectorAll('.fk-company-input').forEach((inp) => inp.addEventListener('input', updateAll));
        el('payment_url')?.addEventListener('input', updateAll);
        document.getElementById('fk-lines-body')?.addEventListener('input', (e) => {
            if (e.target?.classList?.contains('fk-line-pay-url')) updateAll();
        });
        ['invoice_no', 'invoice_date', 'due_date', 'notes'].forEach((id) => {
            el(id)?.addEventListener('input', updateAll);
        });
        el('payment_purpose')?.addEventListener('input', () => {
            el('payment_purpose').dataset.touched = '1';
            updateAll();
        });
        el('invoice_no')?.addEventListener('input', () => {
            if (!el('payment_purpose')?.dataset.touched) syncPaymentPurpose();
            updateAll();
        });

        initPrintPicker();
        el('fk-client')?.addEventListener('change', onClientChange);

        if (!el('fk-lines-body')?.children.length) addLineRow({});
        onCountryChange();
        if (el('fk-template')?.value) onTemplateChange();
        updateAll();
    });
})();