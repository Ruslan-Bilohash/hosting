<?php
$page_title = $page_title ?? ($t['meta']['title'] ?? 'Faktura Creator');
$page_desc  = $page_desc ?? ($t['meta']['description'] ?? '');
$canonical  = $canonical ?? ($site_url ?? '') . '/';
$body_class = $body_class ?? '';
if (!empty($_GET['embed'])) {
    $body_class = trim($body_class . ' fk-embed');
}
$css_ver = '16';

$fk_nav_items = [
    ['page' => 'home',    'url' => 'index.php',  'icon' => 'fa-house',                    'label' => $t['nav']['home'] ?? 'Home'],
    ['page' => 'create',  'url' => 'create.php', 'icon' => 'fa-file-circle-plus',         'label' => $t['nav']['create'] ?? 'Create invoice'],
    ['page' => 'factura', 'url' => 'factura.html', 'icon' => 'fa-file-invoice',           'label' => $t['nav']['factura'] ?? ($t['home']['demo_title'] ?? 'Demo invoices')],
    ['page' => 'help',    'url' => 'help.php',   'icon' => 'fa-book-open',                'label' => $t['nav']['help'] ?? 'Help'],
    ['page' => 'contact', 'url' => 'contact.php','icon' => 'fa-envelope',                 'label' => $t['nav']['contact'] ?? 'Contact'],
    ['page' => 'demo_install', 'url' => 'demo-install.php', 'icon' => 'fa-download',    'label' => $t['nav']['demo_install'] ?? '30-day demo'],
    ['page' => 'admin',   'url' => fk_admin_url('login.php'), 'icon' => 'fa-lock',        'label' => $t['nav']['admin'] ?? 'Admin', 'external' => false],
];
?>
<!DOCTYPE html>
<html lang="<?= fk_h($lang_meta['html'] ?? 'en') ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= fk_h($page_title) ?></title>
    <meta name="description" content="<?= fk_h($page_desc) ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?= fk_h($canonical) ?>">
    <?php if (!empty($hreflang_alternates) && is_array($hreflang_alternates)): foreach ($hreflang_alternates as $alt): ?>
    <link rel="alternate" hreflang="<?= fk_h($alt['hreflang'] ?? '') ?>" href="<?= fk_h($alt['url'] ?? '') ?>">
    <?php endforeach; ?>
    <link rel="alternate" hreflang="x-default" href="<?= fk_h($hreflang_default ?? $canonical) ?>">
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= fk_h(fk_asset('css/style.css')) ?>?v=<?= $css_ver ?>">
    <?php
    require_once dirname(__DIR__, 2) . '/includes/ecosystem-subscription-strip.php';
    ecosystem_subscription_strip_head_link();
    ?>
    <?php if (!empty($extra_css)): foreach ((array)$extra_css as $css): ?>
    <link rel="stylesheet" href="<?= fk_h($css) ?>">
    <?php endforeach; endif; ?>
</head>
<body class="<?= fk_h($body_class) ?>">

<header class="fk-top-bar">
    <?php ecosystem_subscription_strip_render($lang); ?>
    <div class="fk-header-inner">
        <a href="<?= fk_h(fk_url('index.php')) ?>" class="fk-logo">
            <span class="fk-logo-icon"><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i></span>
            <span class="fk-logo-text"><?= fk_h($t['meta']['site_name'] ?? 'Faktura Creator') ?></span>
        </a>
        <div class="fk-header-actions">
            <nav class="fk-nav" aria-label="<?= fk_h($t['nav']['main_nav'] ?? 'Main') ?>">
                <?php foreach ($fk_nav_items as $item):
                    $href = str_starts_with($item['url'], '/') || str_contains($item['url'], '://') ? $item['url'] : fk_url($item['url']);
                    $active = ($current_page ?? '') === $item['page'];
                ?>
                <a href="<?= fk_h($href) ?>" class="<?= $active ? 'active' : '' ?>">
                    <i class="fas <?= fk_h($item['icon']) ?>" aria-hidden="true"></i>
                    <span><?= fk_h($item['label']) ?></span>
                </a>
                <?php endforeach; ?>
            </nav>
            <?php
            $fk_dd_id = 'fkLang';
            $fk_dd_variant = '';
            require __DIR__ . '/lang-dropdown.php';
            ?>
            <button type="button" class="fk-menu-btn" id="fk-menu-btn"
                    aria-label="<?= fk_h($t['nav']['menu'] ?? 'Menu') ?>"
                    data-close-label="<?= fk_h($t['nav']['menu_close'] ?? 'Close menu') ?>"
                    aria-expanded="false" aria-controls="fk-mobile-panel">
                <i class="fas fa-bars" aria-hidden="true"></i>
            </button>
        </div>
    </div>
    <div class="fk-mobile-overlay" id="fk-mobile-overlay" aria-hidden="true"></div>
    <div class="fk-mobile-panel" id="fk-mobile-panel" aria-hidden="true">
        <nav class="fk-mobile-nav" aria-label="<?= fk_h($t['nav']['main_nav'] ?? 'Main') ?>">
            <?php foreach ($fk_nav_items as $item):
                $href = str_starts_with($item['url'], '/') || str_contains($item['url'], '://') ? $item['url'] : fk_url($item['url']);
            ?>
            <a href="<?= fk_h($href) ?>">
                <i class="fas <?= fk_h($item['icon']) ?>" aria-hidden="true"></i>
                <span><?= fk_h($item['label']) ?></span>
            </a>
            <?php endforeach; ?>
        </nav>
        <div class="fk-mobile-lang">
            <?php
            $fk_dd_id = 'fkLangMobile';
            $fk_dd_variant = 'mobile';
            require __DIR__ . '/lang-dropdown.php';
            ?>
        </div>
    </div>
</header>

<main class="fk-main" id="main">