<?php
http_response_code(404);
require_once __DIR__ . '/init.php';
$page_title = '404 — Faktura Creator';
require __DIR__ . '/includes/header.php';
?>
<div class="fk-card"><h1>404</h1><p><a href="<?= fk_url('index.php') ?>"><?= fk_h($t['breadcrumb_home'] ?? 'Home') ?></a></p></div>
<?php require __DIR__ . '/includes/footer.php'; ?>