<?php
/**
 * Shared bootstrap for Faktura admin JSON API endpoints.
 */
require_once dirname(__DIR__, 2) . '/init.php';
require_once dirname(__DIR__, 2) . '/includes/admin-auth.php';
require_once dirname(__DIR__, 2) . '/includes/ai.php';

@ini_set('display_errors', '0');

fk_admin_require();