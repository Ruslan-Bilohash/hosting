<?php

/**
 * AI referral / share links — create.php with lang + OpenAI or Grok.
 */

/**
 * @return array<string, string>
 */
function fk_ai_lang_country_map(): array
{
    return [
        'en' => 'en',
        'uk' => 'uk',
        'lt' => 'lt',
        'pl' => 'pl',
        'de' => 'de',
        'sv' => 'sv',
        'no' => 'no',
    ];
}

function fk_ai_sanitize_provider(string $provider): string
{
    $provider = strtolower(preg_replace('/[^a-z0-9_-]/', '', $provider) ?? '');
    return in_array($provider, ['openai', 'grok'], true) ? $provider : 'openai';
}

/**
 * Active AI provider from ?ai= or cookie (create page).
 */
function fk_ai_referral_provider(): string
{
    if (!empty($_GET['ai'])) {
        return fk_ai_sanitize_provider((string) $_GET['ai']);
    }
    if (!empty($_COOKIE['fk_ai_provider'])) {
        return fk_ai_sanitize_provider((string) $_COOKIE['fk_ai_provider']);
    }
    return '';
}

/**
 * Persist ?ai= in cookie.
 */
function fk_ai_maybe_set_provider_cookie(): void
{
    if (empty($_GET['ai'])) {
        return;
    }
    $provider = fk_ai_sanitize_provider((string) $_GET['ai']);
    setcookie('fk_ai_provider', $provider, [
        'expires'  => time() + 365 * 86400,
        'path'     => fk_lang_cookie_path(),
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
    $_COOKIE['fk_ai_provider'] = $provider;
}

/**
 * Build create.php URL with lang, country and AI provider.
 */
function fk_ai_referral_url(string $lang, string $provider = 'openai', bool $withCountry = true): string
{
    $lang = in_array($lang, array_keys(fk_langs()), true) ? $lang : 'en';
    $provider = fk_ai_sanitize_provider($provider);
    $params = ['ai' => $provider];
    if ($lang !== 'en') {
        $params['lang'] = $lang;
    }
    if ($withCountry) {
        $map = fk_ai_lang_country_map();
        if (isset($map[$lang])) {
            $params['country'] = $map[$lang];
        }
    }
    return fk_url('create.php') . '?' . http_build_query($params);
}

/**
 * All referral links: 7 langs × openai + grok.
 *
 * @return array<int, array{lang: string, lang_label: string, provider: string, provider_label: string, url: string}>
 */
function fk_ai_referral_links_matrix(): array
{
    $providers = fk_ai_providers();
    $rows = [];
    foreach (array_keys(fk_langs()) as $code) {
        $meta = fk_langs()[$code] ?? [];
        $langLabel = is_array($meta) ? ($meta['name'] ?? strtoupper($code)) : (string) $meta;
        foreach (['openai', 'grok'] as $pid) {
            $rows[] = [
                'lang'            => $code,
                'lang_label'      => $langLabel,
                'provider'        => $pid,
                'provider_label'  => $providers[$pid]['label'] ?? ucfirst($pid),
                'url'             => fk_ai_referral_url($code, $pid),
            ];
        }
    }
    return $rows;
}

/**
 * Merge provider override into AI settings for one compose call.
 *
 * @param array<string, mixed> $ai
 * @return array<string, mixed>
 */
function fk_ai_with_provider(array $ai, string $provider): array
{
    $provider = fk_ai_sanitize_provider($provider);
    $presets = fk_ai_providers();
    if (!isset($presets[$provider])) {
        return $ai;
    }
    $preset = $presets[$provider];
    $ai['provider'] = $provider;
    $ai['api_base'] = rtrim($preset['api_base'], '/');
    $models = $preset['models'] ?? [];
    $current = trim((string) ($ai['model'] ?? ''));
    if ($current === '' || !in_array($current, $models, true)) {
        $ai['model'] = $models[0] ?? $current;
    }
    return $ai;
}