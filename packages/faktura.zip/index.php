<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/country-seo.php';

$settings = fk_load_settings();
$demoInvoices = fk_get_demo_invoices();
$h = $t['home'] ?? [];
$sub = $settings['subscription'] ?? [];

$cabinetLoggedIn = false;
$supportUrl = '/ecosystem/join.php';
$supportLinkLabel = $h['lead_support_link_join'] ?? 'Register a BILOHASH account for support';
$cabinetLang = $lang === 'uk' ? 'ua' : $lang;
$cabinetFile = dirname(__DIR__) . '/includes/license-cabinet-i18n.php';
$joinFile = dirname(__DIR__) . '/includes/ecosystem-join-i18n.php';
if (is_file($joinFile)) {
    require_once $joinFile;
    $supportUrl = ecosystem_join_url($lang);
}
$cabinetUrl = '/ecosystem/cabinet.php?product=faktura' . ($cabinetLang !== 'en' ? '&lang=' . urlencode($cabinetLang === 'ua' ? 'uk' : $cabinetLang) : '');
if (is_file($cabinetFile)) {
    require_once $cabinetFile;
    $cabinetUrl = license_cabinet_url($cabinetLang) . (str_contains(license_cabinet_url($cabinetLang), '?') ? '&' : '?') . 'product=faktura';
}
$cabinetRoot = dirname(__DIR__) . '/includes/license-cabinet.php';
if (is_file($cabinetRoot)) {
    require_once $cabinetRoot;
    license_cabinet_ensure_session();
    $cabinetLoggedIn = license_cabinet_is_logged_in();
    if ($cabinetLoggedIn) {
        $supportUrl = $cabinetUrl;
        $supportLinkLabel = $h['lead_support_link_cabinet'] ?? 'Open support in your cabinet';
    }
}

$current_page = 'home';
$page_title = $h['meta_title'] ?? ($t['meta']['title'] ?? 'Faktura Creator');
$page_desc = $h['meta_desc'] ?? ($t['meta']['description'] ?? '');
$canonical = $site_url . '/' . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');

require __DIR__ . '/includes/header.php';
?>

<section class="fk-home-hero">
    <div class="fk-home-hero-inner">
        <p class="fk-home-badge"><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i> <?= fk_h($h['badge'] ?? 'Faktura Creator · BILOHASH') ?></p>
        <h1><?= fk_h($h['title'] ?? 'Faktura Creator') ?></h1>
        <p class="fk-home-lead">
            <?= fk_h($h['lead'] ?? '') ?>
            <?php if (!empty($h['lead_support_before'])): ?>
            <?= fk_h($h['lead_support_before']) ?><a href="<?= fk_h($supportUrl) ?>"><?= fk_h($supportLinkLabel) ?></a><?= fk_h($h['lead_support_after'] ?? '.') ?>
            <?php endif; ?>
        </p>
        <div class="fk-home-cta">
            <a href="<?= fk_h(fk_url('create.php')) ?>" class="fk-btn fk-btn-primary fk-btn-lg"><i class="fas fa-mobile-alt"></i> <?= fk_h($h['cta_create'] ?? 'Create invoice') ?></a>
            <a href="<?= fk_h(fk_url('factura.html')) ?>" class="fk-btn fk-btn-ghost fk-btn-lg"><i class="fas fa-file-invoice"></i> <?= fk_h($h['cta_factura'] ?? 'Demo invoices') ?></a>
            <a href="<?= fk_h(fk_admin_url('clients.php')) ?>" class="fk-btn fk-btn-ghost fk-btn-lg"><i class="fas fa-users"></i> <?= fk_h($h['cta_admin'] ?? 'Admin') ?></a>
        </div>
    </div>
</section>

<?php if (!empty($h['mobile_steps'])): ?>
<section class="fk-home-section fk-home-mobile">
    <h2><i class="fas fa-bolt" style="color:var(--fk-primary)"></i> <?= fk_h($h['mobile_title'] ?? 'Two clicks') ?></h2>
    <div class="fk-home-steps">
        <?php foreach ($h['mobile_steps'] as $step): ?>
        <div class="fk-home-step">
            <span class="fk-home-step-n"><?= fk_h($step['n'] ?? '') ?></span>
            <div>
                <strong><?= fk_h($step['t'] ?? '') ?></strong>
                <p><?= fk_h($step['d'] ?? '') ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<section class="fk-home-section">
    <h2><?= fk_h($h['about_title'] ?? 'About the script') ?></h2>
    <p class="fk-home-text"><?= fk_h($h['about_text'] ?? '') ?></p>
    <div class="fk-home-benefits">
        <?php foreach (($h['benefits'] ?? []) as $b): ?>
        <div class="fk-home-benefit">
            <i class="fas <?= fk_h($b['icon'] ?? 'fa-check') ?>" aria-hidden="true"></i>
            <div>
                <strong><?= fk_h($b['title'] ?? '') ?></strong>
                <p><?= fk_h($b['text'] ?? '') ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<?php
$countryFlags = ['en' => '🇬🇧', 'no' => '🇳🇴', 'lt' => '🇱🇹', 'pl' => '🇵🇱', 'de' => '🇩🇪', 'sv' => '🇸🇪', 'uk' => '🇺🇦'];
$activeCountries = fk_active_countries($settings);
?>
<section class="fk-home-section" id="countries">
    <h2><i class="fas fa-globe-europe" aria-hidden="true"></i> <?= fk_h($h['countries_title'] ?? 'VAT for 7 countries') ?></h2>
    <p class="fk-home-text fk-text-muted"><?= fk_h($h['countries_text'] ?? 'United Kingdom, Norway, Lithuania, Poland, Germany, Sweden and Ukraine — correct VAT/MVA, currency and company defaults on the frontend.') ?></p>
    <div class="fk-country-grid">
        <?php foreach ($activeCountries as $c):
            $cid = $c['id'] ?? '';
            $rate = ($c['tax_mode'] ?? 'vat') === 'single' ? ($c['single_tax_rate'] ?? 0) : ($c['vat_rate'] ?? 0);
        ?>
        <a href="<?= fk_h(fk_country_page_url($cid, $lang)) ?>" class="fk-country-card">
            <span class="fk-country-flag" aria-hidden="true"><?= ($countryFlags[$cid] ?? (fk_country_seo_registry()[$cid]['flag'] ?? '🌐')) ?></span>
            <strong><?= fk_h(fk_localized($c, 'name', $lang)) ?></strong>
            <span class="fk-menu-desc"><?= fk_h(fk_localized($c, 'tax_label', $lang)) ?> <?= fk_h((string) $rate) ?>% · <?= fk_h($c['currency'] ?? '') ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/demo-invoices-section.php'; ?>

<section class="fk-home-section fk-home-section--cta">
    <div class="fk-card fk-home-cta-card">
        <h2><?= fk_h($h['start_title'] ?? 'Get started') ?></h2>
        <p><?= fk_h($h['start_text'] ?? '') ?></p>
        <div class="fk-home-cta">
            <a href="<?= fk_h(fk_url('create.php')) ?>" class="fk-btn fk-btn-primary"><?= fk_h($h['cta_create'] ?? 'Create invoice') ?></a>
            <a href="<?= fk_h(fk_url('demo-install.php')) ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-download"></i> <?= fk_h($h['cta_demo_install'] ?? '30-day demo download') ?></a>
            <a href="<?= fk_h(fk_admin_url('login.php')) ?>" class="fk-btn fk-btn-ghost"><?= fk_h($h['cta_admin'] ?? 'Admin panel') ?></a>
        </div>
        <?php if (!empty($sub['note_en'])): ?>
        <p class="fk-home-sub-note"><?= fk_h($sub['note_' . $lang] ?? $sub['note_en']) ?></p>
        <?php endif; ?>
    </div>
</section>

<?php
if (!empty($demoInvoices)) {
    $extra_js = array_merge((array)($extra_js ?? []), [fk_asset('js/fk-demo-picker.js') . '?v=1']);
}
require __DIR__ . '/includes/footer.php';
?>