<?php
header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__) . '/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fk_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$invoiceNo = trim((string) ($payload['invoice_no'] ?? ''));
if ($invoiceNo === '') {
    fk_json_response(['ok' => false, 'error' => 'invoice_no required'], 400);
}

$settings = fk_load_settings();
$countryId = (string) ($payload['country_id'] ?? '');
$country = $countryId !== '' ? fk_country_by_id($settings, $countryId) : null;

$lines = [];
foreach ($payload['lines'] ?? [] as $line) {
    if (!is_array($line)) continue;
    $lines[] = [
        'desc'    => trim((string) ($line['desc'] ?? '')),
        'qty'     => (float) ($line['qty'] ?? 0),
        'unit'    => trim((string) ($line['unit'] ?? 'pcs')),
        'price'   => (float) ($line['price'] ?? 0),
        'pay_url' => trim((string) ($line['pay_url'] ?? '')),
    ];
}

$totals = $country
    ? fk_calculate_totals($lines, $country, $lang)
    : ['subtotal' => 0, 'tax_amount' => 0, 'total' => 0, 'tax_label' => '', 'tax_rate' => 0, 'tax_mode' => 'vat'];

$record = [
    'invoice_no'       => $invoiceNo,
    'invoice_date'     => (string) ($payload['invoice_date'] ?? ''),
    'due_date'         => (string) ($payload['due_date'] ?? ''),
    'country_id'       => $countryId,
    'currency'         => $country['currency'] ?? '',
    'seller'           => $payload['seller'] ?? [],
    'buyer'            => $payload['buyer'] ?? [],
    'lines'            => $lines,
    'totals'           => $totals,
    'notes'            => (string) ($payload['notes'] ?? ''),
    'payment_purpose'  => (string) ($payload['payment_purpose'] ?? ''),
    'payment_url'      => trim((string) ($payload['payment_url'] ?? '')),
    'lang'             => $lang,
    'client_id'        => trim((string) ($payload['client_id'] ?? '')),
    'print_design'     => fk_normalize_print_design((string) ($payload['print_design'] ?? $settings['print_design'] ?? 'classic-blue')),
    'print_format'     => fk_normalize_print_format((string) ($payload['print_format'] ?? $settings['print_format'] ?? 'a4')),
];

$saved = fk_add_invoice($record);

$settings['next_number'] = max((int) ($settings['next_number'] ?? 1000), (int) preg_replace('/\D/', '', $invoiceNo)) + 1;
fk_save_settings($settings);

fk_json_response([
    'ok'   => true,
    'id'   => $saved['id'],
    'view' => fk_url('invoice.php?id=' . urlencode($saved['id'])),
]);