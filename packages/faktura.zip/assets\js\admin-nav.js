(function () {
    var menuBtn = document.getElementById('adm-menu-btn');
    var mobileNav = document.getElementById('adm-mobile-nav');

    if (!menuBtn || !mobileNav) return;

    function setAdmNavOpen(open) {
        mobileNav.hidden = !open;
        menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        document.body.classList.toggle('adm-nav-open', open);
        var icon = menuBtn.querySelector('i');
        if (icon) icon.className = open ? 'fas fa-times' : 'fas fa-bars';
    }

    menuBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        setAdmNavOpen(mobileNav.hidden);
    });

    mobileNav.querySelectorAll('a').forEach(function (link) {
        if (link.closest('.adm-mobile-lang')) return;
        link.addEventListener('click', function () { setAdmNavOpen(false); });
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth >= 900) setAdmNavOpen(false);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && !mobileNav.hidden) setAdmNavOpen(false);
    });

    var jump = document.getElementById('adm-nav-jump');
    if (jump) {
        jump.addEventListener('change', function () {
            if (jump.value) {
                window.location.href = jump.value;
            }
        });
    }
})();