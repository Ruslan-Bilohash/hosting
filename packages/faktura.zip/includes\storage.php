<?php

function fk_data_path(string $file): string
{
    return __DIR__ . '/../data/' . $file;
}

function fk_load_json(string $file, $seed = null)
{
    $path = fk_data_path($file);
    if (is_readable($path)) {
        $raw = file_get_contents($path);
        $data = json_decode($raw ?: '[]', true);
        if (is_array($data)) {
            return $data;
        }
    }
    return $seed ?? [];
}

function fk_save_json(string $file, array $data): bool
{
    $dir = dirname(fk_data_path($file));
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return file_put_contents(fk_data_path($file), $json, LOCK_EX) !== false;
}

function fk_settings_seed(): array
{
    $seedFile = __DIR__ . '/../data/settings.php';
    return is_readable($seedFile) ? (require $seedFile) : [];
}

function fk_templates_seed(): array
{
    $seedFile = __DIR__ . '/../data/templates.php';
    $data = is_readable($seedFile) ? (require $seedFile) : [];
    return is_array($data) ? $data : [];
}

function fk_merge_settings(array $stored, array $seed): array
{
    $merged = array_replace_recursive($seed, $stored);
    if (!empty($seed['countries']) && empty($merged['countries'])) {
        $merged['countries'] = $seed['countries'];
    }
    if (!empty($seed['countries']) && !empty($merged['countries'])) {
        $byId = [];
        foreach ($merged['countries'] as $c) {
            $byId[$c['id'] ?? ''] = $c;
        }
        foreach ($seed['countries'] as $sc) {
            $id = $sc['id'] ?? '';
            if ($id === '') continue;
            if (!isset($byId[$id])) {
                $byId[$id] = $sc;
            } else {
                $byId[$id] = array_replace_recursive($sc, $byId[$id]);
            }
        }
        $merged['countries'] = array_values($byId);
    }
    return $merged;
}

function fk_ensure_settings_json(): void
{
    $seed = fk_settings_seed();
    $path = fk_data_path('settings.json');
    if (!is_file($path)) {
        fk_save_json('settings.json', $seed);
        return;
    }
    $existing = json_decode(file_get_contents($path) ?: '[]', true);
    if (!is_array($existing) || $existing === []) {
        fk_save_json('settings.json', $seed);
        return;
    }
    fk_save_json('settings.json', fk_merge_settings($existing, $seed));
}

function fk_ensure_templates_json(): void
{
    $path = fk_data_path('templates.json');
    $seed = fk_templates_seed();
    if (!is_file($path)) {
        fk_save_json('templates.json', $seed);
        return;
    }
    $existing = json_decode(file_get_contents($path) ?: '[]', true);
    if (!is_array($existing)) {
        fk_save_json('templates.json', $seed);
        return;
    }
    $ids = array_column($existing, 'id');
    $merged = $existing;
    $changed = false;
    foreach ($seed as $tpl) {
        if (!in_array($tpl['id'] ?? '', $ids, true)) {
            $merged[] = $tpl;
            $changed = true;
        }
    }
    if ($changed) {
        fk_save_json('templates.json', $merged);
    }
}

function fk_load_settings(): array
{
    fk_ensure_settings_json();
    $seed = fk_settings_seed();
    $data = fk_load_json('settings.json', $seed);
    return is_array($data) ? fk_merge_settings($data, $seed) : $seed;
}

function fk_save_settings(array $settings): bool
{
    return fk_save_json('settings.json', $settings);
}

function fk_load_templates(): array
{
    fk_ensure_templates_json();
    $all = fk_load_json('templates.json', fk_templates_seed());
    if (!is_array($all)) return [];
    return array_values(array_filter($all, static fn(array $t) => !empty($t['active'])));
}

function fk_load_templates_all(): array
{
    fk_ensure_templates_json();
    $all = fk_load_json('templates.json', fk_templates_seed());
    return is_array($all) ? $all : [];
}

function fk_save_templates(array $templates): bool
{
    return fk_save_json('templates.json', array_values($templates));
}

function fk_invoices_file(): string
{
    return 'invoices.json';
}

function fk_load_invoices(): array
{
    $all = fk_load_json(fk_invoices_file(), []);
    return is_array($all) ? $all : [];
}

function fk_save_invoices(array $list): bool
{
    return fk_save_json(fk_invoices_file(), array_values($list));
}

function fk_add_invoice(array $invoice): array
{
    $list = fk_load_invoices();
    $invoice['id'] = $invoice['id'] ?? ('inv-' . date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6));
    $invoice['created_at'] = $invoice['created_at'] ?? gmdate('c');
    array_unshift($list, $invoice);
    fk_save_invoices($list);
    return $invoice;
}

function fk_get_invoice(string $id): ?array
{
    foreach (fk_load_invoices() as $inv) {
        if (($inv['id'] ?? '') === $id) {
            return $inv;
        }
    }
    return null;
}

function fk_delete_invoice(string $id): bool
{
    $list = array_values(array_filter(
        fk_load_invoices(),
        static fn(array $inv) => ($inv['id'] ?? '') !== $id
    ));
    return fk_save_invoices($list);
}

function fk_update_invoice(string $id, array $patch): bool
{
    $list = fk_load_invoices();
    $found = false;
    foreach ($list as $i => $inv) {
        if (($inv['id'] ?? '') === $id) {
            $list[$i] = array_merge($inv, $patch);
            $found = true;
            break;
        }
    }
    return $found && fk_save_invoices($list);
}

function fk_demo_invoices_seed(): array
{
    $seedFile = __DIR__ . '/../data/demo-invoices.php';
    $data = is_readable($seedFile) ? (require $seedFile) : [];
    return is_array($data) ? $data : [];
}

function fk_ensure_demo_invoices(): void
{
    $list = fk_load_invoices();
    $ids = array_column($list, 'id');
    $changed = false;
    foreach ($list as &$inv) {
        if (($inv['id'] ?? '') === 'demo-lt-services' && !in_array('demo-lt-cleaning', $ids, true)) {
            $inv['id'] = 'demo-lt-cleaning';
            $changed = true;
        }
    }
    unset($inv);
    if ($changed) {
        $ids = array_column($list, 'id');
    }
    foreach (fk_demo_invoices_seed() as $demo) {
        $id = $demo['id'] ?? '';
        if ($id === '' || in_array($id, $ids, true)) {
            continue;
        }
        $demo['created_at'] = $demo['created_at'] ?? gmdate('c');
        $list[] = $demo;
        $changed = true;
    }
    if ($changed) {
        fk_save_invoices($list);
    }
}

function fk_get_demo_invoices(): array
{
    $demos = array_values(array_filter(
        fk_load_invoices(),
        static fn(array $inv) => !empty($inv['is_demo'])
    ));
    usort($demos, static function (array $a, array $b) {
        return (int) ($a['demo_order'] ?? 99) <=> (int) ($b['demo_order'] ?? 99);
    });
    return $demos;
}

function fk_demo_invoice_label(array $inv, string $lang): string
{
    $label = $inv['demo_label'] ?? [];
    if (is_array($label)) {
        return (string) ($label[$lang] ?? $label['en'] ?? ($inv['invoice_no'] ?? ''));
    }
    return (string) ($inv['invoice_no'] ?? '');
}

function fk_company_for_country(array $settings, string $countryId): array
{
    $base = $settings['company'] ?? [];
    foreach ($settings['countries'] ?? [] as $country) {
        if (($country['id'] ?? '') === $countryId && !empty($country['company_override'])) {
            return array_merge($base, $country['company_override']);
        }
    }
    return $base;
}

function fk_clients_file(): string
{
    return 'clients.json';
}

function fk_clients_seed(): array
{
    $f = __DIR__ . '/../data/clients-seed.php';
    $data = is_readable($f) ? (require $f) : [];
    return is_array($data) ? $data : [];
}

function fk_ensure_clients_json(): void
{
    $path = fk_data_path(fk_clients_file());
    if (!is_file($path)) {
        fk_save_json(fk_clients_file(), fk_clients_seed());
        return;
    }
    $existing = fk_load_json(fk_clients_file(), []);
    $ids = array_column($existing, 'id');
    $merged = $existing;
    $changed = false;
    foreach (fk_clients_seed() as $c) {
        if (!in_array($c['id'] ?? '', $ids, true)) {
            $merged[] = $c;
            $changed = true;
        }
    }
    if ($changed) {
        fk_save_json(fk_clients_file(), array_values($merged));
    }
}

function fk_load_clients(): array
{
    fk_ensure_clients_json();
    $all = fk_load_json(fk_clients_file(), []);
    return is_array($all) ? array_values($all) : [];
}

function fk_save_clients(array $list): bool
{
    return fk_save_json(fk_clients_file(), array_values($list));
}

function fk_get_client(string $id): ?array
{
    foreach (fk_load_clients() as $c) {
        if (($c['id'] ?? '') === $id) {
            return $c;
        }
    }
    return null;
}

function fk_add_client(array $client): array
{
    $list = fk_load_clients();
    $client['id'] = $client['id'] ?? ('cli-' . substr(bin2hex(random_bytes(4)), 0, 8));
    $client['created_at'] = $client['created_at'] ?? gmdate('c');
    $list[] = $client;
    fk_save_clients($list);
    return $client;
}

function fk_update_client(string $id, array $patch): bool
{
    $list = fk_load_clients();
    $found = false;
    foreach ($list as $i => $c) {
        if (($c['id'] ?? '') === $id) {
            $list[$i] = array_merge($c, $patch);
            $found = true;
            break;
        }
    }
    return $found && fk_save_clients($list);
}

function fk_delete_client(string $id): bool
{
    $list = array_values(array_filter(
        fk_load_clients(),
        static fn(array $c) => ($c['id'] ?? '') !== $id
    ));
    return fk_save_clients($list);
}

function fk_bootstrap_data(): void
{
    fk_ensure_settings_json();
    fk_ensure_templates_json();
    fk_ensure_clients_json();
    if (!is_file(fk_data_path(fk_invoices_file()))) {
        fk_save_invoices([]);
    }
    fk_ensure_demo_invoices();
    if (!is_file(fk_data_path('email-log.json'))) {
        fk_save_json('email-log.json', []);
    }
    if (function_exists('fk_ensure_calcs_json')) {
        fk_ensure_calcs_json();
    }
    if (function_exists('fk_ensure_service_presets_json')) {
        fk_ensure_service_presets_json();
    }
}