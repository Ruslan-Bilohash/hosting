<?php
require_once __DIR__ . '/init.php';

$ta = $t['admin'] ?? [];
$settings = fk_load_settings();
$clients = fk_load_clients();
$invoices = fk_load_invoices();

$clientId = trim($_GET['client_id'] ?? $_POST['client_id'] ?? '');
$invoiceId = trim($_GET['invoice_id'] ?? $_POST['invoice_id'] ?? '');
$adm_title = $ta['send_email'] ?? 'Send invoice email';
$adm_nav_active = 'send';
$adm_saved = false;
$adm_error = '';
$sendDemo = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $client = fk_get_client(trim($_POST['client_id'] ?? ''));
    $invoice = fk_get_invoice(trim($_POST['invoice_id'] ?? ''));
    $note = trim($_POST['custom_note'] ?? '');

    if ($client === null || $invoice === null) {
        $adm_error = $ta['send_missing'] ?? 'Select client and invoice.';
    } else {
        $result = fk_send_invoice_to_client($settings, $invoice, $client, $lang, $note);
        if ($result['ok']) {
            $adm_saved = true;
            $sendDemo = !empty($result['demo']);
            $clientId = $client['id'];
            $invoiceId = $invoice['id'];
        } else {
            $adm_error = $result['error'] ?? ($ta['send_failed'] ?? 'Send failed.');
        }
    }
}

$client = $clientId !== '' ? fk_get_client($clientId) : null;
$invoice = $invoiceId !== '' ? fk_get_invoice($invoiceId) : null;
$preview = ($invoice && $client) ? fk_invoice_email_content($invoice, $settings, $lang) : null;

require __DIR__ . '/includes/layout.php';
?>

<?php if ($adm_error): ?><div class="adm-error"><?= fk_h($adm_error) ?></div><?php endif; ?>
<?php if ($adm_saved): ?>
<div class="adm-success">
    <?= fk_h($sendDemo ? ($ta['send_demo_ok'] ?? 'Demo mode: email logged (enable SMTP to send for real).') : ($ta['send_ok'] ?? 'Invoice email sent successfully.')) ?>
    <?php if ($client): ?> → <?= fk_h($client['email'] ?? '') ?><?php endif; ?>
</div>
<?php endif; ?>

<div class="adm-card">
    <form method="post">
        <div class="adm-grid-2">
            <div class="adm-field">
                <label><?= fk_h($ta['client_pick'] ?? 'Client') ?></label>
                <select name="client_id" required>
                    <option value="">—</option>
                    <?php foreach ($clients as $c): ?>
                    <option value="<?= fk_h($c['id']) ?>" <?= ($clientId === ($c['id'] ?? '')) ? 'selected' : '' ?>><?= fk_h($c['name'] ?? '') ?> &lt;<?= fk_h($c['email'] ?? '') ?>&gt;</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="adm-field">
                <label><?= fk_h($ta['invoice_pick'] ?? 'Invoice') ?></label>
                <select name="invoice_id" required>
                    <option value="">—</option>
                    <?php foreach ($invoices as $inv): ?>
                    <option value="<?= fk_h($inv['id'] ?? '') ?>" <?= ($invoiceId === ($inv['id'] ?? '')) ? 'selected' : '' ?>><?= fk_h($inv['invoice_no'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="adm-field">
            <label><?= fk_h($ta['email_note'] ?? 'Personal note') ?></label>
            <textarea name="custom_note" id="fk-email-note" rows="3"></textarea>
            <button type="button" class="adm-btn adm-btn-ghost adm-btn-sm" id="fk-ai-note" style="margin-top:.5rem"><i class="fas fa-wand-magic-sparkles"></i> <?= fk_h($ta['ai_generate'] ?? 'Generate with AI') ?></button>
            <span id="fk-ai-status" style="font-size:.78rem;color:var(--adm-muted);margin-left:.5rem"></span>
        </div>
        <?php if ($preview): ?>
        <div class="adm-field">
            <label><?= fk_h($ta['email_preview'] ?? 'Preview') ?></label>
            <div style="border:1px solid var(--adm-border);border-radius:8px;padding:1rem;background:#f8fafc;font-size:.88rem"><?= $preview['html'] ?></div>
        </div>
        <?php endif; ?>
        <button type="submit" class="adm-btn adm-btn-primary" style="width:auto"><i class="fas fa-paper-plane"></i> <?= fk_h($ta['send_email'] ?? 'Send email') ?></button>
        <a href="<?= fk_admin_url('clients.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm"><?= fk_h($ta['clients'] ?? 'Clients') ?></a>
    </form>
</div>

<script>
(function(){
    var btn = document.getElementById('fk-ai-note');
    var note = document.getElementById('fk-email-note');
    var status = document.getElementById('fk-ai-status');
    if (!btn || !note) return;
    btn.addEventListener('click', function(){
        var clientId = document.querySelector('[name="client_id"]')?.value || '';
        var invoiceId = document.querySelector('[name="invoice_id"]')?.value || '';
        if (!invoiceId) {
            status.textContent = <?= json_encode($ta['send_missing'] ?? 'Select invoice.') ?>;
            return;
        }
        btn.disabled = true;
        status.textContent = <?= json_encode($ta['ai_generating'] ?? 'Generating…') ?>;
        fetch(<?= json_encode(fk_url('api/ai-compose.php')) ?>, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({type: 'email_note', client_id: clientId, invoice_id: invoiceId, lang: <?= json_encode($lang) ?>})
        }).then(function(r){ return r.json(); }).then(function(data){
            if (data.ok && data.text) {
                note.value = data.text;
                status.textContent = data.demo ? <?= json_encode($ta['ai_demo_ok'] ?? 'Template text (no API key).') ?> : <?= json_encode($ta['ai_ok'] ?? 'Generated.') ?>;
            } else {
                status.textContent = data.error || <?= json_encode($ta['ai_failed'] ?? 'AI failed.') ?>;
            }
        }).catch(function(){
            status.textContent = <?= json_encode($ta['ai_failed'] ?? 'AI failed.') ?>;
        }).finally(function(){ btn.disabled = false; });
    });
})();
</script>
<?php require __DIR__ . '/includes/layout-end.php'; ?>