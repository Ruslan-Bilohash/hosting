# Faktura Creator

**PHP-Adminpanel für Buchhalter und Unternehmer** — Kunden, MwSt. für 7 Länder, Rechnungsvorlagen, SMTP, KI-Zahlungshinweise, QR-Zahlung und BILOHASH-Ökosystem-Support. Portfolio-Projekt von [Ruslan Bilohash](https://bilohash.com/).

**Version (dieses Repo):** 1.0.0 · **Readme-Sprachen:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-eingebaut-purple)

---

## Wichtig — nur Demo-Repository

> **Dieses GitHub-Repository enthält ein Demo- / Portfolio-Beispiel von Faktura Creator.**
> Es ist **nicht** das vollständige kommerzielle Produkt und **nicht** zwingend die neueste Version.
>
> Die **neueste Vollversion**, Updates und kommerzieller Support sind **nur beim Autor** erhältlich:
> - Live-Demo: https://bilohash.com/faktura/
> - 30-Tage-Selbstinstallation: https://bilohash.com/faktura/demo-install.php
> - Abonnement: https://bilohash.com/ecosystem/join.php
> - Kontakt: **rbilohash@gmail.com**

**Kommerzielle Nutzung ohne schriftliche Zustimmung des Autors ist untersagt.** Siehe [LICENSE](LICENSE).

---

## Live-Demo

| Ressource | URL |
|-----------|-----|
| **Startseite** | https://bilohash.com/faktura/ |
| **Rechnung erstellen** | https://bilohash.com/faktura/create.php |
| **Service-Kalkulator** | https://bilohash.com/faktura/calc.php |
| **Admin-Panel** | https://bilohash.com/faktura/admin/ |
| **Hilfe & Video** | https://bilohash.com/faktura/help.php |
| **30-Tage-Demo-Download** | https://bilohash.com/faktura/demo-install.php |
| **BILOHASH-Kundenportal** | https://bilohash.com/ecosystem/cabinet.php |

**Admin-Login (Demo):** `demo` / `bilofaktura2026`

---

## KI sofort einsatzbereit

Faktura Creator bietet **integrierte KI-Unterstützung** (OpenAI / xAI Grok — API-Schlüssel im Admin):

| Bereich | Was die KI tut |
|---------|----------------|
| **E-Mail-Notizen** | Persönliche Notiz beim Rechnungsversand |
| **E-Mail-Betreff** | Kurze Betreffzeilen für Rechnungs-E-Mails |
| **Rechnungsnotizen** | Zahlungsbedingungen und Überweisungstext |
| **Support** | Entwürfe für Ökosystem-Support und Kunden-E-Mails |

Der Demo-Modus funktioniert **ohne API-Schlüssel** — mehrsprachige Vorlagen.

---

## Funktionen

### Öffentliches Frontend
- Mobile-first Rechnungserstellung mit MwSt.-Presets pro Land
- **7 Märkte:** UK, Norwegen, Litauen, Polen, Deutschland, Schweden, Ukraine
- **12 Drucklayouts** — A4, Letter, Legal; Vorschau und Druck/PDF
- Service-Kalkulator mit Vorlagen
- Gespeicherte Rechnungen und Kalkulationen; teilbare Links
- QR auf Rechnungen — Zahlungs-URL-Vorlage oder eigener Link
- Demo-Rechnungen auf der Startseite pro Land
- Hilfeseite mit Screenshots und Video
- Sprachen: **EN, UA, LT, PL, DE, SV, NO** (`?lang=` + Cookie)
- Kontakt und BILOHASH-Ökosystem-Leiste

### Admin-Panel
- **Dashboard** — Kunden, Rechnungen, Demo auf Startseite, MwSt.-Tabelle
- **Kunden** — Datenbank für Rechnungen in 2 Klicks
- **Rechnungen** — Suche, Druck, E-Mail, Demo auf Startseite
- **Kalkulationen** — gespeicherte Service-Angebote
- **Service-Presets** — Kalkulator-Vorlagen und Zahlungs-URL
- **E-Mail senden** — SMTP mit KI-Notizen
- **Einstellungen** — Firma, Nummerierung, QR
- **Länder & Steuern** — MwSt. / Einzelsatz
- **Vorlagen** — Standard-Positionen
- **SMTP** — Host, Port, TLS (Demo schreibt in `email-log.json`)
- **KI** — Anbieter, Modell, Prompts, Referral-Links
- **Support & E-Mail** — BILOHASH-Posteingang, Eigentümer-Chat, Kundenentwürfe
- Mehrsprachiges Admin

### BILOHASH-Ökosystem
- **30-Tage-ZIP** — Download aus Kundenportal nach Abonnement
- **Support-Nachrichten** — Threads mit BILOHASH aus dem Admin
- **Abonnement** — 49 kr/Monat (1 CMS) oder 249 kr/Monat (alle Skripte auf 1 Domain)

---

## Technischer Stack

- PHP 8+ (ohne Framework)
- JSON-Speicher (`data/*.json`)
- Modulares i18n (`lang/*.php`)
- Apache `.htaccess`, kanonische URLs, hreflang
- Font Awesome 6, Vanilla CSS & JS
- OpenAI-kompatible API (OpenAI, xAI Grok)

---

## Anforderungen

- PHP 8.0 oder neuer
- Apache mit `mod_rewrite`
- Beschreibbares `data/`-Verzeichnis
- SMTP (optional — Demo protokolliert E-Mails lokal)

---

## Installation

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Kopieren Sie `faktura/` ins Web-Root (z. B. `/faktura/`).
2. Schreibrechte für `data/`:
   ```bash
   chmod 755 data
   ```
3. Öffnen Sie `https://ihre-domain.de/faktura/`.
4. Admin: `https://ihre-domain.de/faktura/admin/` — Zugangsdaten vor Produktion ändern.

### Selbstinstallation (30 Tage)

1. Abonnieren Sie https://bilohash.com/ecosystem/join.php
2. Melden Sie sich im [Kundenportal](https://bilohash.com/ecosystem/cabinet.php) an und laden Sie die Demo-ZIP herunter
3. Auf Hosting hochladen
4. Anleitung: https://bilohash.com/faktura/demo-install.php

### Lokaler PHP-Server

```bash
cd faktura
php -S localhost:8080
```

### Konfiguration (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
```

---

## Projektstruktur

```
faktura/
├── index.php              # Startseite — Länder-Demos
├── create.php             # Rechnung erstellen
├── calc.php               # Service-Kalkulator
├── invoice.php            # Anzeigen / Drucken
├── help.php / contact.php
├── demo-install.php       # 30-Tage-Paket
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Admin + Support-API
├── api/                   # Rechnung speichern, KI (öffentlich)
└── LICENSE
```

---

## Demo-Modus

- Demo-Zugangsdaten auf der Login-Seite
- SMTP aus — E-Mails in `data/email-log.json`
- KI ohne Schlüssel — lokale Vorlagen
- Beispielrechnungen auf der Startseite

### Demo-Paket erstellen

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

### Übersetzungsprüfung

```bash
node scripts/check-lang-keys.mjs
```

---

## Autor & kommerzielle Lizenz

**Ruslan Bilohash**
- Website: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- E-Mail: rbilohash@gmail.com

Für **kommerzielle Lizenz**, vollständigen Quellcode oder die **neueste Produktionsversion** kontaktieren Sie den Autor. Siehe [LICENSE](LICENSE).