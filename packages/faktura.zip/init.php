<?php
require_once __DIR__ . '/config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/includes/i18n.php';
require_once __DIR__ . '/includes/storage.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/print-designs.php';
require_once __DIR__ . '/includes/invoice-render.php';
require_once __DIR__ . '/includes/mailer.php';
require_once __DIR__ . '/includes/qr.php';
require_once __DIR__ . '/includes/ai.php';
require_once __DIR__ . '/includes/referral-links.php';
require_once __DIR__ . '/includes/service-calc.php';
fk_ai_maybe_set_provider_cookie();
fk_bootstrap_data();