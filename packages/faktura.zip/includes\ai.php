<?php

/**
 * AI-assisted email notes, subjects and invoice text (OpenAI-compatible API).
 */

/**
 * @return array<string, string>
 */
function fk_ai_lang_names(): array
{
    return [
        'en' => 'English',
        'uk' => 'Ukrainian',
        'lt' => 'Lithuanian',
        'pl' => 'Polish',
        'de' => 'German',
        'sv' => 'Swedish',
        'no' => 'Norwegian',
    ];
}

/**
 * @param array<string, mixed> $context
 * @return array{ok: bool, text: string, demo: bool, error: string}
 */
function fk_ai_compose(array $settings, string $type, array $context, string $lang, string $providerOverride = ''): array
{
    $ai = $settings['ai'] ?? [];
    if ($providerOverride !== '') {
        $ai = fk_ai_with_provider($ai, $providerOverride);
    }
    $langName = fk_ai_lang_names()[$lang] ?? 'English';

    $prompt = fk_ai_build_prompt($ai, $type, $context, $langName);
    if ($prompt === '') {
        return ['ok' => false, 'text' => '', 'demo' => false, 'error' => 'Unknown compose type'];
    }

    if (empty($ai['enabled']) || trim((string) ($ai['api_key'] ?? '')) === '') {
        $text = fk_ai_fallback($type, $context, $lang);
        return ['ok' => true, 'text' => $text, 'demo' => true, 'error' => ''];
    }

    $result = fk_ai_call_api($ai, $prompt);
    if (!$result['ok']) {
        $text = fk_ai_fallback($type, $context, $lang);
        return ['ok' => true, 'text' => $text, 'demo' => true, 'error' => $result['error']];
    }

    return ['ok' => true, 'text' => trim($result['text']), 'demo' => false, 'error' => ''];
}

/**
 * @param array<string, mixed> $ai
 * @param array<string, mixed> $context
 */
function fk_ai_build_prompt(array $ai, string $type, array $context, string $langName): string
{
    $templates = [
        'email_note' => $ai['prompt_email_note'] ?? 'Write a short polite personal note (2-3 sentences) for an invoice email to {client_name}. Invoice {invoice_no}, total {total} {currency}, due {due_date}. Company: {company}. Language: {lang}. No subject line, no greeting — note body only.',
        'email_subject' => $ai['prompt_email_subject'] ?? 'Write one concise email subject line for invoice {invoice_no} from {company} to {client_name}. Total {total} {currency}. Language: {lang}. Subject only, no quotes.',
        'invoice_notes' => $ai['prompt_invoice_notes'] ?? 'Write payment terms / notes for invoice {invoice_no}, total {total} {currency}, due {due_date}. Mention bank transfer if IBAN provided: {iban}. Language: {lang}. 1-2 sentences.',
    ];

    if (!isset($templates[$type])) {
        return '';
    }

    $replacements = [
        '{client_name}' => (string) ($context['client_name'] ?? 'Customer'),
        '{invoice_no}'  => (string) ($context['invoice_no'] ?? ''),
        '{total}'       => (string) ($context['total'] ?? ''),
        '{currency}'    => (string) ($context['currency'] ?? ''),
        '{due_date}'    => (string) ($context['due_date'] ?? ''),
        '{company}'     => (string) ($context['company'] ?? 'Faktura Creator'),
        '{iban}'        => (string) ($context['iban'] ?? ''),
        '{lang}'        => $langName,
    ];

    return str_replace(array_keys($replacements), array_values($replacements), $templates[$type]);
}

/**
 * @param array<string, mixed> $context
 */
function fk_ai_fallback(string $type, array $context, string $lang): string
{
    $client = (string) ($context['client_name'] ?? '');
    $no = (string) ($context['invoice_no'] ?? '');
    $total = (string) ($context['total'] ?? '');
    $currency = (string) ($context['currency'] ?? '');
    $due = (string) ($context['due_date'] ?? '');
    $iban = (string) ($context['iban'] ?? '');

    $fallbacks = [
        'en' => [
            'email_note' => "Thank you for your business. Please find invoice {$no} ({$total} {$currency}) attached via the link below. Payment is due by {$due}.",
            'email_subject' => "Invoice {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Payment within 14 days by bank transfer to IBAN {$iban}. Reference: {$no}."
                : "Payment within 14 days. Reference: {$no}.",
        ],
        'uk' => [
            'email_note' => "Дякуємо за співпрацю. Рахунок {$no} на суму {$total} {$currency} — посилання нижче. Термін оплати: {$due}.",
            'email_subject' => "Рахунок {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Оплата протягом 14 днів переказом на IBAN {$iban}. Призначення: {$no}."
                : "Оплата протягом 14 днів. Призначення: {$no}.",
        ],
        'no' => [
            'email_note' => "Takk for samarbeidet. Faktura {$no} ({$total} {$currency}) — lenke nedenfor. Forfall: {$due}.",
            'email_subject' => "Faktura {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Betaling innen 14 dager til IBAN {$iban}. KID/ref: {$no}."
                : "Betaling innen 14 dager. Referanse: {$no}.",
        ],
        'lt' => [
            'email_note' => "Dėkojame už bendradarbiavimą. Sąskaita {$no} ({$total} {$currency}) — nuoroda žemiau. Mokėjimo terminas: {$due}.",
            'email_subject' => "Sąskaita {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Apmokėti per 14 dienų pavedimu į IBAN {$iban}. Paskirtis: {$no}."
                : "Apmokėti per 14 dienų. Paskirtis: {$no}.",
        ],
        'pl' => [
            'email_note' => "Dziękujemy za współpracę. Faktura {$no} ({$total} {$currency}) — link poniżej. Termin płatności: {$due}.",
            'email_subject' => "Faktura {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Płatność w ciągu 14 dni przelewem na IBAN {$iban}. Tytuł: {$no}."
                : "Płatność w ciągu 14 dni. Tytuł: {$no}.",
        ],
        'de' => [
            'email_note' => "Vielen Dank für die Zusammenarbeit. Rechnung {$no} ({$total} {$currency}) — Link unten. Fällig: {$due}.",
            'email_subject' => "Rechnung {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Zahlung innerhalb von 14 Tagen per Überweisung an IBAN {$iban}. Verwendungszweck: {$no}."
                : "Zahlung innerhalb von 14 Tagen. Verwendungszweck: {$no}.",
        ],
        'sv' => [
            'email_note' => "Tack för samarbetet. Faktura {$no} ({$total} {$currency}) — länk nedan. Förfallodatum: {$due}.",
            'email_subject' => "Faktura {$no} — {$total} {$currency}",
            'invoice_notes' => $iban !== ''
                ? "Betalning inom 14 dagar till IBAN {$iban}. Referens: {$no}."
                : "Betalning inom 14 dagar. Referens: {$no}.",
        ],
    ];

    $pack = $fallbacks[$lang] ?? $fallbacks['en'];
    $text = $pack[$type] ?? $pack['email_note'];

    if ($client !== '' && $type === 'email_note') {
        $greetings = [
            'en' => "Dear {$client}, ",
            'uk' => "Шановний(-а) {$client}, ",
            'no' => "Hei {$client}, ",
            'lt' => "Gerb. {$client}, ",
            'pl' => "Szanowny(-a) {$client}, ",
            'de' => "Guten Tag {$client}, ",
            'sv' => "Hej {$client}, ",
        ];
        $text = ($greetings[$lang] ?? $greetings['en']) . $text;
    }

    return $text;
}

/**
 * @param array<string, mixed> $ai
 * @return array{ok: bool, text: string, error: string}
 */
function fk_ai_call_api(array $ai, string $prompt, int $maxTokens = 300): array
{
    $resolved = fk_ai_resolve_config($ai);
    $apiKey = trim((string) ($ai['api_key'] ?? ''));
    $model = $resolved['model'];
    $base = $resolved['api_base'];
    $endpoint = $base . '/chat/completions';

    $payload = [
        'model' => $model,
        'messages' => [
            ['role' => 'system', 'content' => 'You are a professional business assistant for invoices and client emails. Reply with plain text only, no markdown.'],
            ['role' => 'user', 'content' => $prompt],
        ],
        'temperature' => 0.6,
        'max_tokens' => max(64, min(2000, $maxTokens)),
    ];

    $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($body === false) {
        return ['ok' => false, 'text' => '', 'error' => 'JSON encode failed'];
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
        ]);
        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($errno || $raw === false) {
            return ['ok' => false, 'text' => '', 'error' => 'API request failed'];
        }
        if ($http < 200 || $http >= 300) {
            return ['ok' => false, 'text' => '', 'error' => 'API HTTP ' . $http];
        }
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\nAuthorization: Bearer {$apiKey}\r\n",
                'content' => $body,
                'timeout' => 30,
                'ignore_errors' => true,
            ],
        ]);
        $raw = @file_get_contents($endpoint, false, $ctx);
        if ($raw === false) {
            return ['ok' => false, 'text' => '', 'error' => 'API request failed'];
        }
    }

    $data = json_decode($raw ?: '', true);
    $text = trim((string) ($data['choices'][0]['message']['content'] ?? ''));
    if ($text === '') {
        return ['ok' => false, 'text' => '', 'error' => 'Empty AI response'];
    }

    return ['ok' => true, 'text' => $text, 'error' => ''];
}

/**
 * @param array<string, mixed> $context
 * @return array{ok:bool,demo:bool,subject:string,body:string,error:string}
 */
function fk_ai_compose_message_draft(array $settings, string $mode, string $draft, string $lang, array $context = []): array
{
    $draft = trim($draft);
    $mode = $mode === 'client_email' ? 'client_email' : 'owner_support';
    $adminName = trim((string) ($context['admin_name'] ?? 'Faktura admin'));
    $clientName = trim((string) ($context['client_name'] ?? 'Customer'));
    $topic = trim((string) ($context['topic'] ?? ''));

    $ai = $settings['ai'] ?? [];
    if (empty($ai['enabled']) || trim((string) ($ai['api_key'] ?? '')) === '') {
        return fk_ai_compose_message_fallback($mode, $draft, $lang, $context, true, '');
    }

    if ($mode === 'client_email') {
        $prompt = 'You help a BILOHASH Faktura Creator merchant write a professional email to their customer. '
            . 'Admin name: ' . $adminName . '. Customer: ' . $clientName . '. '
            . ($topic !== '' ? 'Topic: ' . $topic . '. ' : '')
            . 'Draft notes: "' . ($draft !== '' ? $draft : 'Follow-up about their invoice or question') . '". '
            . 'Language: ' . $lang . '. '
            . 'Return ONLY valid JSON {"subject":"...","body":"..."} — body plain text with paragraphs, no HTML, friendly business tone.';
    } else {
        $prompt = 'You help a Faktura Creator admin user write a clear support message to BILOHASH owner (Ruslan). '
            . 'Admin: ' . $adminName . '. Language: ' . $lang . '. '
            . 'Draft: "' . ($draft !== '' ? $draft : 'Need help with Faktura Creator setup') . '". '
            . 'Return ONLY valid JSON {"subject":"...","body":"..."} — concise subject, body with problem, context, and what they need.';
    }

    $result = fk_ai_call_api($ai, $prompt, 900);
    if (!$result['ok']) {
        return fk_ai_compose_message_fallback($mode, $draft, $lang, $context, false, $result['error']);
    }

    $raw = trim($result['text']);
    if (preg_match('/```(?:json)?\s*([\s\S]*?)```/i', $raw, $m)) {
        $raw = trim($m[1]);
    }
    $parsed = json_decode($raw, true);
    $subject = trim((string) ($parsed['subject'] ?? ''));
    $body = trim((string) ($parsed['body'] ?? ''));
    if ($subject === '' || $body === '') {
        return fk_ai_compose_message_fallback($mode, $draft, $lang, $context, false, 'Invalid JSON from AI');
    }

    return ['ok' => true, 'demo' => false, 'subject' => $subject, 'body' => $body, 'error' => ''];
}

/**
 * @param array<string, mixed> $context
 * @return array{ok:bool,demo:bool,subject:string,body:string,error:string}
 */
function fk_ai_compose_message_fallback(string $mode, string $draft, string $lang, array $context, bool $demo, string $error): array
{
    $adminName = trim((string) ($context['admin_name'] ?? 'Faktura admin'));
    $clientName = trim((string) ($context['client_name'] ?? 'Customer'));
    $draft = $draft !== '' ? $draft : ($mode === 'client_email' ? 'Thank you for your business.' : 'I need assistance with my Faktura Creator installation.');

    if ($mode === 'client_email') {
        return [
            'ok'      => true,
            'demo'    => $demo,
            'subject' => 'Regarding your request — ' . $clientName,
            'body'    => "Hello " . $clientName . ",\n\n" . $draft . "\n\nBest regards,\n" . $adminName,
            'error'   => $error,
        ];
    }

    return [
        'ok'      => true,
        'demo'    => $demo,
        'subject' => 'Faktura Creator support request',
        'body'    => "Hello BILOHASH team,\n\n" . $draft . "\n\n— " . $adminName,
        'error'   => $error,
    ];
}

/**
 * @param array<string, mixed> $invoice
 * @param array<string, mixed> $client
 */
function fk_ai_context_from_invoice(array $invoice, array $settings, array $client = []): array
{
    return [
        'client_name' => (string) ($client['name'] ?? $invoice['buyer']['name'] ?? ''),
        'invoice_no'  => (string) ($invoice['invoice_no'] ?? ''),
        'total'       => (string) ($invoice['totals']['total'] ?? ''),
        'currency'    => (string) ($invoice['currency'] ?? ''),
        'due_date'    => (string) ($invoice['due_date'] ?? ''),
        'company'     => (string) ($settings['company']['name'] ?? 'Faktura Creator'),
        'iban'        => (string) ($invoice['seller']['iban'] ?? $settings['company']['iban'] ?? ''),
    ];
}