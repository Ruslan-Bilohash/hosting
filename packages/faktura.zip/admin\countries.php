<?php
require_once __DIR__ . '/init.php';
$adm_title = $t['admin']['countries'] ?? 'Countries';
$adm_nav_active = 'countries';
$settings = fk_load_settings();
$adm_saved = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $posted = $_POST['countries'] ?? [];
    foreach ($settings['countries'] as $i => $country) {
        $id = $country['id'];
        if (!isset($posted[$id])) continue;
        $p = $posted[$id];
        $settings['countries'][$i]['active'] = !empty($p['active']);
        $settings['countries'][$i]['tax_mode'] = ($p['tax_mode'] ?? 'vat') === 'single' ? 'single' : 'vat';
        $settings['countries'][$i]['vat_rate'] = (float) ($p['vat_rate'] ?? 0);
        $settings['countries'][$i]['single_tax_rate'] = (float) ($p['single_tax_rate'] ?? 0);
        $settings['countries'][$i]['currency'] = trim($p['currency'] ?? 'EUR');
    }
    fk_save_settings($settings);
    $adm_saved = true;
}

require __DIR__ . '/includes/layout.php';
?>
<form method="post">
<?php foreach ($settings['countries'] ?? [] as $country): $id = $country['id']; ?>
<div class="adm-card">
    <h2><?= fk_h(fk_localized($country, 'name', $lang)) ?> (<?= fk_h($id) ?>)</h2>
    <div class="adm-grid-2">
        <div class="adm-field">
            <label><input type="checkbox" name="countries[<?= fk_h($id) ?>][active]" value="1" <?= !empty($country['active']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['active'] ?? 'Active') ?></label>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['tax_mode'] ?? 'Tax mode') ?></label>
            <select name="countries[<?= fk_h($id) ?>][tax_mode]">
                <option value="vat" <?= ($country['tax_mode'] ?? 'vat') === 'vat' ? 'selected' : '' ?>><?= fk_h($t['invoice']['tax_mode_vat'] ?? 'VAT') ?></option>
                <option value="single" <?= ($country['tax_mode'] ?? '') === 'single' ? 'selected' : '' ?>><?= fk_h($t['invoice']['tax_mode_single'] ?? 'Single tax') ?></option>
            </select>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['vat_rate'] ?? 'VAT %') ?></label>
            <input type="number" step="0.01" name="countries[<?= fk_h($id) ?>][vat_rate]" value="<?= fk_h((string)($country['vat_rate'] ?? 0)) ?>">
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['single_rate'] ?? 'Single tax %') ?></label>
            <input type="number" step="0.01" name="countries[<?= fk_h($id) ?>][single_tax_rate]" value="<?= fk_h((string)($country['single_tax_rate'] ?? 0)) ?>">
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['invoice']['currency'] ?? 'Currency') ?></label>
            <input type="text" name="countries[<?= fk_h($id) ?>][currency]" value="<?= fk_h($country['currency'] ?? '') ?>">
        </div>
    </div>
</div>
<?php endforeach; ?>
<button type="submit" class="adm-btn adm-btn-primary"><?= fk_h($t['admin']['save'] ?? 'Save') ?></button>
</form>
<?php require __DIR__ . '/includes/layout-end.php'; ?>