<?php
require_once __DIR__ . '/_bootstrap.php';

$rootIncludes = dirname(__DIR__, 3) . '/includes/ecosystem-owner-messages.php';
if (!is_file($rootIncludes)) {
    fk_json_response(['ok' => false, 'error' => 'Messaging module missing'], 500);
}
require_once $rootIncludes;
require_once dirname(__DIR__, 3) . '/includes/ecosystem-support-common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fk_json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    $payload = $_POST;
}

$subject = trim((string) ($payload['subject'] ?? ''));
$body = trim((string) ($payload['body'] ?? ''));
$category = trim((string) ($payload['category'] ?? 'support'));
$fromEmail = strtolower(trim((string) ($payload['from_email'] ?? '')));

if ($subject === '' || $body === '') {
    fk_json_response(['ok' => false, 'error' => 'subject_body_required'], 400);
}

if ($fromEmail !== '' && !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
    fk_json_response(['ok' => false, 'error' => 'invalid_email'], 400);
}

$adminUrl = ecosystem_support_admin_url();

$id = ecosystem_owner_messages_add([
    'subject'     => $subject,
    'body'        => $body,
    'category'    => $category,
    'from_user'   => (string) ($_SESSION['fk_admin_user'] ?? ''),
    'from_name'   => fk_admin_display_name(),
    'from_role'   => fk_admin_role(),
    'from_email'  => $fromEmail,
    'shop_url'    => $adminUrl,
    'lang'        => trim((string) ($payload['lang'] ?? $lang ?? 'en')),
    'ip'          => fk_admin_client_ip(),
]);

if ($id === null) {
    fk_json_response(['ok' => false, 'error' => 'save_failed'], 500);
}

fk_json_response(['ok' => true, 'id' => $id]);