<?php
require_once __DIR__ . '/init.php';
$adm_title = $t['admin']['settings'] ?? 'Settings';
$adm_nav_active = 'settings';
$settings = fk_load_settings();
$adm_saved = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    if (($_POST['action'] ?? '') === 'sync_service_preset') {
        $pid = trim($_POST['sync_preset_id'] ?? '');
        if ($pid !== '' && fk_apply_service_preset_to_settings($pid)) {
            $adm_saved = true;
            $settings = fk_load_settings();
        }
    } else {
    $settings['default_country'] = $_POST['default_country'] ?? 'en';
    $presetPick = trim($_POST['default_service_preset'] ?? '');
    if ($presetPick !== '' && fk_get_service_preset($presetPick) !== null) {
        $settings['default_service_preset'] = $presetPick;
    }
    $settings['invoice_prefix'] = trim($_POST['invoice_prefix'] ?? 'INV');
    $settings['next_number'] = max(1, (int) ($_POST['next_number'] ?? 1001));
    $settings['print_design'] = fk_normalize_print_design($_POST['print_design'] ?? 'classic-blue');
    $settings['print_format'] = fk_normalize_print_format($_POST['print_format'] ?? 'a4');
    foreach (['name','org_nr','vat_nr','address','city','postal','country','email','phone','bank','iban','bic'] as $f) {
        $settings['company'][$f] = trim($_POST['company_' . $f] ?? '');
    }
    $settings['qr'] = array_merge($settings['qr'] ?? [], [
        'enabled'              => !empty($_POST['qr_enabled']),
        'mode'                 => in_array($_POST['qr_mode'] ?? '', ['invoice_link', 'payment_url', 'custom'], true)
            ? $_POST['qr_mode'] : 'invoice_link',
        'payment_url_template' => trim($_POST['qr_payment_template'] ?? ''),
        'custom_url'           => trim($_POST['qr_custom_url'] ?? ''),
        'show_on_print'        => !empty($_POST['qr_show_print']),
        'show_url_text'        => !empty($_POST['qr_show_url']),
        'size'                 => max(80, min(200, (int) ($_POST['qr_size'] ?? 120))),
    ]);
    fk_save_settings($settings);
    $adm_saved = true;
    }
}

$servicePresets = fk_load_service_presets();
$defaultServicePreset = fk_default_service_preset_id($settings);
$co = $settings['company'] ?? [];
$qr = $settings['qr'] ?? [];
$printDesign = fk_normalize_print_design($settings['print_design'] ?? 'classic-blue');
$printFormat = fk_normalize_print_format($settings['print_format'] ?? 'a4');
$extra_css = [fk_asset('css/print-designs.css') . '?v=1'];
require __DIR__ . '/includes/layout.php';
?>
<form method="post">
<div class="adm-card">
    <h2><i class="fas fa-file-invoice" aria-hidden="true"></i> <?= fk_h($t['admin']['factura_title'] ?? 'Service calculator') ?></h2>
    <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 .75rem"><?= fk_h($t['admin']['factura_hint'] ?? 'Layout like frontend.html — company, requisites, quick services. Configure preset in Service calculator.') ?></p>
    <div class="adm-grid-2">
        <div class="adm-field">
            <label for="adm-default-preset"><?= fk_h($t['admin']['factura_default_preset'] ?? 'Default preset for service calculator') ?></label>
            <select name="default_service_preset" id="adm-default-preset">
                <?php foreach ($servicePresets as $sp): ?>
                <option value="<?= fk_h($sp['id'] ?? '') ?>" <?= ($sp['id'] ?? '') === $defaultServicePreset ? 'selected' : '' ?>>
                    <?= fk_h(fk_localized($sp, 'name', $lang)) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field" style="display:flex;flex-direction:column;justify-content:flex-end;gap:.5rem">
            <a href="<?= fk_admin_url('service-presets.php?edit=' . urlencode($defaultServicePreset)) ?>" class="adm-btn adm-btn-ghost adm-btn-sm">
                <i class="fas fa-pen"></i> <?= fk_h($t['admin']['factura_edit_preset'] ?? 'Edit company & services') ?>
            </a>
            <a href="<?= fk_h(fk_url('calc.php')) ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank" rel="noopener">
                <i class="fas fa-external-link-alt"></i> <?= fk_h($t['admin']['factura_preview'] ?? 'Open service calculator') ?>
            </a>
        </div>
    </div>
    <div class="adm-field" style="margin-top:.5rem">
        <label><?= fk_h($t['admin']['factura_sync_label'] ?? 'Sync preset seller → global company & Lithuania override') ?></label>
        <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center">
            <select name="sync_preset_id" id="adm-sync-preset-id" form="adm-sync-preset-form">
                <?php foreach ($servicePresets as $sp): ?>
                <option value="<?= fk_h($sp['id'] ?? '') ?>" <?= ($sp['id'] ?? '') === $defaultServicePreset ? 'selected' : '' ?>>
                    <?= fk_h(fk_localized($sp, 'name', $lang)) ?>
                </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" form="adm-sync-preset-form" name="action" value="sync_service_preset" class="adm-btn adm-btn-primary adm-btn-sm">
                <i class="fas fa-arrows-rotate"></i> <?= fk_h($t['admin']['factura_sync_btn'] ?? 'Sync now') ?>
            </button>
        </div>
    </div>
</div>
<div class="adm-card">
    <h2><?= fk_h($t['admin']['print_settings'] ?? 'Print layout') ?></h2>
    <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 .75rem"><?= fk_h($t['admin']['print_settings_hint'] ?? 'Default design and paper format for new invoices. Users can override on the invoice page.') ?></p>
    <div class="adm-field">
        <label><?= fk_h($t['admin']['print_design'] ?? 'Print design (12)') ?></label>
        <div class="adm-design-picker">
            <?php fk_render_design_picker('print_design', $printDesign, $lang); ?>
        </div>
    </div>
    <div class="adm-field">
        <label for="adm-print-format"><?= fk_h($t['admin']['print_format'] ?? 'Paper format') ?></label>
        <?php fk_render_format_select('print_format', $printFormat, $lang, 'adm-print-format'); ?>
    </div>
</div>
<div class="adm-card">
    <h2><?= fk_h($t['admin']['settings'] ?? 'Global') ?></h2>
    <div class="adm-grid-2">
        <div class="adm-field">
            <label><?= fk_h($t['admin']['default_country'] ?? 'Default country') ?></label>
            <select name="default_country">
                <?php foreach ($settings['countries'] ?? [] as $c): ?>
                <option value="<?= fk_h($c['id']) ?>" <?= ($settings['default_country'] ?? '') === $c['id'] ? 'selected' : '' ?>><?= fk_h(fk_localized($c, 'name', $lang)) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['invoice_prefix'] ?? 'Prefix') ?></label>
            <input type="text" name="invoice_prefix" value="<?= fk_h($settings['invoice_prefix'] ?? 'INV') ?>">
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['next_number'] ?? 'Next number') ?></label>
            <input type="number" name="next_number" value="<?= (int)($settings['next_number'] ?? 1001) ?>">
        </div>
    </div>
    <h2 style="margin-top:1.5rem"><?= fk_h($t['invoice']['seller'] ?? 'Company') ?></h2>
    <?php foreach (['name','org_nr','vat_nr','address','city','postal','country','email','phone','bank','iban','bic'] as $f): ?>
    <div class="adm-field">
        <label><?= fk_h($t['invoice'][$f] ?? $f) ?></label>
        <input type="text" name="company_<?= $f ?>" value="<?= fk_h($co[$f] ?? '') ?>">
    </div>
    <?php endforeach; ?>
    <h2 style="margin-top:1.5rem"><?= fk_h($t['admin']['qr_title'] ?? 'QR code on invoices') ?></h2>
    <p style="font-size:.85rem;color:var(--adm-muted);margin:0 0 .75rem"><?= fk_h($t['admin']['qr_hint'] ?? 'QR appears on preview and print. Modes: invoice view link, payment URL template, or custom URL.') ?></p>
    <div class="adm-field">
        <label><input type="checkbox" name="qr_enabled" value="1" <?= !empty($qr['enabled']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['qr_enabled'] ?? 'Show QR on invoices') ?></label>
    </div>
    <div class="adm-grid-2">
        <div class="adm-field">
            <label><?= fk_h($t['admin']['qr_mode'] ?? 'QR content') ?></label>
            <select name="qr_mode">
                <option value="invoice_link" <?= ($qr['mode'] ?? '') === 'invoice_link' ? 'selected' : '' ?>><?= fk_h($t['admin']['qr_mode_link'] ?? 'Invoice view link') ?></option>
                <option value="payment_url" <?= ($qr['mode'] ?? '') === 'payment_url' ? 'selected' : '' ?>><?= fk_h($t['admin']['qr_mode_payment'] ?? 'Payment URL') ?></option>
                <option value="custom" <?= ($qr['mode'] ?? '') === 'custom' ? 'selected' : '' ?>><?= fk_h($t['admin']['qr_mode_custom'] ?? 'Custom URL') ?></option>
            </select>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['qr_size'] ?? 'QR size (px)') ?></label>
            <input type="number" name="qr_size" min="80" max="200" value="<?= (int) ($qr['size'] ?? 120) ?>">
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['qr_payment_template'] ?? 'Payment URL template') ?></label>
            <input type="text" name="qr_payment_template" value="<?= fk_h($qr['payment_url_template'] ?? '') ?>" placeholder="https://vipps.no/pay?amount={amount}&ref={invoice_no}">
            <p class="adm-field-hint"><?= fk_h($t['admin']['qr_placeholders'] ?? '{amount}, {invoice_no}, {currency}, {id}, {reference}') ?></p>
        </div>
        <div class="adm-field">
            <label><?= fk_h($t['admin']['qr_custom_url'] ?? 'Custom URL') ?></label>
            <input type="url" name="qr_custom_url" value="<?= fk_h($qr['custom_url'] ?? '') ?>">
        </div>
    </div>
    <div class="adm-field">
        <label><input type="checkbox" name="qr_show_print" value="1" <?= !empty($qr['show_on_print']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['qr_show_print'] ?? 'Include on print/PDF') ?></label>
    </div>
    <div class="adm-field">
        <label><input type="checkbox" name="qr_show_url" value="1" <?= !empty($qr['show_url_text']) ? 'checked' : '' ?>> <?= fk_h($t['admin']['qr_show_url'] ?? 'Show URL text under QR') ?></label>
    </div>
    <button type="submit" class="adm-btn adm-btn-primary" style="width:auto"><?= fk_h($t['admin']['save'] ?? 'Save') ?></button>
    <a href="<?= fk_url('help.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank"><i class="fas fa-book"></i> <?= fk_h($t['admin']['qr_help_link'] ?? 'QR instructions') ?></a>
</div>
</form>
<form method="post" id="adm-sync-preset-form" style="display:none" aria-hidden="true"></form>
<script>
(function(){
    document.querySelectorAll('.fk-design-option input').forEach(function(inp){
        inp.addEventListener('change', function(){
            document.querySelectorAll('.fk-design-option').forEach(function(l){ l.classList.remove('selected'); });
            inp.closest('.fk-design-option').classList.add('selected');
        });
    });
})();
</script>
<?php require __DIR__ . '/includes/layout-end.php'; ?>