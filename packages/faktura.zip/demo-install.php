<?php
require_once __DIR__ . '/init.php';

$di = $t['demo_install'] ?? [];
$current_page = 'demo_install';
$page_title = $di['page_title'] ?? 'Download Faktura Creator — 30-day demo';
$page_desc = $di['meta_description'] ?? '';
$canonical = $site_url . '/demo-install.php' . ($lang !== 'en' ? '?lang=' . urlencode($lang) : '');

$cabinetLang = $lang === 'uk' ? 'ua' : $lang;
$cabinetFile = dirname(__DIR__) . '/includes/license-cabinet-i18n.php';
$cabinetUrl = '/ecosystem/cabinet.php?product=faktura' . ($cabinetLang !== 'en' ? '&lang=' . urlencode($cabinetLang === 'ua' ? 'uk' : $cabinetLang) : '');
if (is_file($cabinetFile)) {
    require_once $cabinetFile;
    $cabinetUrl = license_cabinet_url($cabinetLang) . (str_contains(license_cabinet_url($cabinetLang), '?') ? '&' : '?') . 'product=faktura#download';
}

$hasDemoZip = false;
$demoPkgFile = __DIR__ . '/includes/demo-package.php';
if (is_file($demoPkgFile)) {
    require_once $demoPkgFile;
    $hasDemoZip = fk_demo_package_latest_zip() !== null;
}

$cabinetLoggedIn = false;
$downloadToken = '';
$userEmail = '';
$cabinetRoot = dirname(__DIR__) . '/includes/license-cabinet.php';
if (is_file($cabinetRoot)) {
    require_once $cabinetRoot;
    license_cabinet_ensure_session();
    $cabinetLoggedIn = license_cabinet_is_logged_in();
    if ($cabinetLoggedIn) {
        $userEmail = license_cabinet_user_email();
        $downloadToken = license_cabinet_download_token_issue($userEmail);
    }
}
$downloadApi = '/api/faktura-demo-download.php';
$trialDays = defined('FK_DEMO_TRIAL_DAYS') ? (int) FK_DEMO_TRIAL_DAYS : 30;

require __DIR__ . '/includes/header.php';
?>

<section class="fk-home-section">
    <div class="fk-home-hero-inner" style="max-width:52rem;margin:0 auto">
        <p class="fk-home-badge"><i class="fas fa-box-open"></i> <?= fk_h('30-day demo') ?></p>
        <h1><?= fk_h($di['h1'] ?? 'Self-install Faktura Creator') ?></h1>
        <p class="fk-home-lead"><?= fk_h($di['subtitle'] ?? '') ?></p>
    </div>
</section>

<section class="fk-home-section">
    <div style="max-width:52rem;margin:0 auto;display:grid;gap:2rem">
        <div class="fk-card" style="padding:1.5rem;border:1px solid var(--fk-border);border-radius:1rem;background:var(--fk-surface)">
            <h2><i class="fas fa-list-ol" style="color:var(--fk-primary)"></i> <?= fk_h($di['steps_title'] ?? 'Installation steps') ?></h2>
            <ol style="margin:1rem 0;padding-left:1.25rem;line-height:1.6;color:var(--fk-muted)">
                <?php foreach ($di['steps'] ?? [] as $step): ?>
                <li style="margin-bottom:.5rem"><?= fk_h($step) ?></li>
                <?php endforeach; ?>
            </ol>
            <p class="fk-muted" style="font-size:.9rem"><?= fk_h(strtr($di['trial_note'] ?? '', ['{days}' => (string) $trialDays])) ?></p>
        </div>

        <div class="fk-card" style="padding:1.5rem;border:1px solid var(--fk-border);border-radius:1rem;background:var(--fk-surface)">
            <h2><i class="fas fa-download" style="color:var(--fk-primary)"></i> <?= fk_h($di['form_title'] ?? 'Get the package') ?></h2>
            <?php if (!$hasDemoZip): ?>
            <p class="fk-muted"><?= fk_h($di['package_missing'] ?? '') ?></p>
            <?php else: ?>
            <p class="fk-muted" style="margin-bottom:1rem"><?= fk_h($di['download_help'] ?? '') ?></p>
            <?php if (!$cabinetLoggedIn): ?>
            <p class="fk-muted" style="margin-bottom:1rem">
                <?= fk_h($di['cabinet_only_text'] ?? '') ?>
                <a href="<?= fk_h($cabinetUrl) ?>"><?= fk_h($di['cabinet_cta'] ?? 'Open customer cabinet') ?></a>
            </p>
            <?php endif; ?>
            <form id="fkDiDownloadForm" class="fk-form-stack" style="display:flex;flex-direction:column;gap:.85rem;max-width:28rem"
                  data-api="<?= fk_h($downloadApi) ?>"
                  data-logged="<?= $cabinetLoggedIn ? '1' : '0' ?>"
                  data-cabinet="<?= fk_h($cabinetUrl) ?>"
                  data-filename="<?= fk_h(function_exists('fk_demo_package_basename') ? fk_demo_package_basename() : 'faktura-demo-30d.zip') ?>">
                <input type="hidden" name="lang" value="<?= fk_h($lang) ?>">
                <input type="hidden" name="download_token" value="<?= fk_h($downloadToken) ?>">
                <label><?= fk_h($di['email'] ?? 'Email') ?>
                    <input class="fk-input" type="email" name="email" required value="<?= fk_h($userEmail) ?>" <?= $cabinetLoggedIn ? 'readonly' : '' ?>>
                </label>
                <label><?= fk_h($di['domain'] ?? 'Domain') ?>
                    <input class="fk-input" type="text" name="domain" required placeholder="example.com">
                </label>
                <label><?= fk_h($di['license_optional'] ?? 'License key (optional)') ?>
                    <input class="fk-input" type="text" name="license_key">
                </label>
                <label style="display:flex;gap:.5rem;align-items:flex-start;font-size:.9rem">
                    <input type="checkbox" name="terms" value="1" required style="margin-top:.2rem">
                    <span><?= fk_h($di['terms_label'] ?? '') ?>
                        <a href="<?= fk_h($di['terms_url'] ?? 'https://bilohash.com/ecosystem/install.php') ?>" target="_blank" rel="noopener"><?= fk_h($di['terms_link'] ?? '') ?></a>
                    </span>
                </label>
                <button type="submit" class="fk-btn fk-btn-primary"><i class="fas fa-download"></i> <?= fk_h($di['submit_download'] ?? 'Download') ?></button>
                <p id="fkDiMessage" class="fk-muted" hidden role="status"></p>
            </form>
            <?php endif; ?>
            <p style="margin-top:1.25rem">
                <a href="<?= fk_h($cabinetUrl) ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-door-open"></i> <?= fk_h($di['cabinet_cta'] ?? 'Open customer cabinet') ?></a>
            </p>
        </div>
    </div>
</section>

<?php
$extra_js = [fk_asset('js/demo-install.js')];
require __DIR__ . '/includes/footer.php';