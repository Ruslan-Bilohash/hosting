<?php
require_once __DIR__ . '/init.php';
$ta = $t['admin'] ?? [];

if (fk_admin_logged()) {
    header('Location: ' . fk_admin_url('index.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (fk_admin_login(trim($_POST['username'] ?? ''), $_POST['password'] ?? '')) {
        header('Location: ' . fk_admin_url('index.php'));
        exit;
    }
    $error = $ta['login_error'] ?? 'Invalid credentials';
}
?>
<!DOCTYPE html>
<html lang="<?= fk_h($lang_meta['html']) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= fk_h($ta['login_title'] ?? 'Admin') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= fk_h(fk_asset('css/admin.css')) ?>?v=6">
    <link rel="stylesheet" href="<?= fk_h(fk_asset('css/style.css')) ?>?v=9">
</head>
<body class="adm-body">
<div class="adm-login-wrap">
    <div class="adm-login-box">
        <div class="adm-login-lang">
            <?php
            $fk_dd_id = 'fkLangLogin';
            $fk_dd_variant = 'admin';
            $fk_dd_url_fn = 'fk_admin_lang_url';
            require dirname(__DIR__) . '/includes/lang-dropdown.php';
            ?>
        </div>
        <div class="adm-logo"><i class="fas fa-file-invoice-dollar"></i></div>
        <h1><?= fk_h($ta['login_title'] ?? 'Faktura Creator Admin') ?></h1>
        <p class="adm-sub"><?= fk_h($ta['login_sub'] ?? '') ?></p>
        <p class="adm-hint"><i class="fas fa-info-circle"></i> <?= fk_h($ta['demo_creds'] ?? 'demo / bilofaktura2026') ?></p>
        <?php if ($error): ?><div class="adm-error"><?= fk_h($error) ?></div><?php endif; ?>
        <form method="post">
            <label><i class="fas fa-user" aria-hidden="true"></i> <?= fk_h($ta['username'] ?? 'Username') ?><input type="text" name="username" required value="demo"></label>
            <label><i class="fas fa-key" aria-hidden="true"></i> <?= fk_h($ta['password'] ?? 'Password') ?><input type="password" name="password" required value="bilofaktura2026"></label>
            <button type="submit" class="adm-btn adm-btn-primary"><i class="fas fa-right-to-bracket" aria-hidden="true"></i> <?= fk_h($ta['login_btn'] ?? 'Log in') ?></button>
        </form>
        <p class="adm-back"><a href="<?= fk_url('index.php') ?>"><i class="fas fa-arrow-left" aria-hidden="true"></i> <?= fk_h($t['breadcrumb_home'] ?? 'Home') ?></a></p>
    </div>
</div>
<script src="<?= fk_h(fk_asset('js/fk-nav.js')) ?>?v=2" defer></script>
</body>
</html>