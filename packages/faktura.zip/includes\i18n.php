<?php
require_once __DIR__ . '/../config.php';

define('FK_LANG_COOKIE', 'fk_lang');
define('FK_LANG_DEFAULT', 'en');

$FK_LANGS = [
    'en' => ['label' => 'EN', 'name' => 'English', 'flag' => '🇬🇧', 'locale' => 'en-GB', 'html' => 'en'],
    'uk' => ['label' => 'UA', 'name' => 'Українська', 'flag' => '🇺🇦', 'locale' => 'uk-UA', 'html' => 'uk'],
    'lt' => ['label' => 'LT', 'name' => 'Lietuvių', 'flag' => '🇱🇹', 'locale' => 'lt-LT', 'html' => 'lt'],
    'pl' => ['label' => 'PL', 'name' => 'Polski', 'flag' => '🇵🇱', 'locale' => 'pl-PL', 'html' => 'pl'],
    'de' => ['label' => 'DE', 'name' => 'Deutsch', 'flag' => '🇩🇪', 'locale' => 'de-DE', 'html' => 'de'],
    'sv' => ['label' => 'SV', 'name' => 'Svenska', 'flag' => '🇸🇪', 'locale' => 'sv-SE', 'html' => 'sv'],
    'no' => ['label' => 'NO', 'name' => 'Norsk', 'flag' => '🇳🇴', 'locale' => 'nb-NO', 'html' => 'no'],
];

function fk_lang_cookie_path(): string
{
    global $base_path;
    $path = rtrim($base_path, '/');
    return $path !== '' ? $path : '/';
}

function fk_is_home_request(): bool
{
    $script = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');
    return $script === 'index.php';
}

function fk_set_lang_cookie(string $code): void
{
    global $FK_LANGS;
    if (!in_array($code, array_keys($FK_LANGS), true)) {
        return;
    }
    setcookie(FK_LANG_COOKIE, $code, [
        'expires'  => time() + 365 * 86400,
        'path'     => fk_lang_cookie_path(),
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
    $_COOKIE[FK_LANG_COOKIE] = $code;
}

function fk_redirect_without_lang_param(): void
{
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $parts = parse_url($uri);
    parse_str($parts['query'] ?? '', $q);
    unset($q['lang']);
    $clean = ($parts['path'] ?? '/') . ($q ? '?' . http_build_query($q) : '');
    if ($clean !== $uri) {
        header('Location: ' . $clean, true, 302);
        exit;
    }
}

function fk_detect_lang(): string
{
    global $FK_LANGS;
    $codes = array_keys($FK_LANGS);

    if (isset($_GET['lang']) && $_GET['lang'] !== '' && in_array($_GET['lang'], $codes, true)) {
        $chosen = $_GET['lang'];
        fk_set_lang_cookie($chosen);
        // Strip ?lang=en only on homepage — subpages must keep the param so English
        // still applies when the cookie has not updated yet (e.g. help.php).
        if ($chosen === FK_LANG_DEFAULT && fk_is_home_request()) {
            fk_redirect_without_lang_param();
        }
        return $chosen;
    }

    if (fk_is_home_request() && !isset($_GET['lang'])) {
        return FK_LANG_DEFAULT;
    }

    if (!empty($_COOKIE[FK_LANG_COOKIE]) && in_array($_COOKIE[FK_LANG_COOKIE], $codes, true)) {
        return $_COOKIE[FK_LANG_COOKIE];
    }

    return FK_LANG_DEFAULT;
}

$lang      = fk_detect_lang();
$lang_meta = $FK_LANGS[$lang] ?? $FK_LANGS[FK_LANG_DEFAULT];
$t_en = require __DIR__ . '/../lang/en.php';
$lang_file = __DIR__ . '/../lang/' . $lang . '.php';
if ($lang === FK_LANG_DEFAULT || !is_file($lang_file)) {
    $t = $t_en;
} else {
    $t = array_replace_recursive($t_en, require $lang_file);
}

$ecoI18n = dirname(__DIR__, 2) . '/includes/ecosystem-i18n.php';
if (is_readable($ecoI18n)) {
    require_once $ecoI18n;
    if (function_exists('bh_apply_ecosystem_translations')) {
        $t = bh_apply_ecosystem_translations($t, $lang, 'faktura');
    }
}