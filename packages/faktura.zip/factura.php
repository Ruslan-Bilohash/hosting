<?php
require_once __DIR__ . '/init.php';

$settings = fk_load_settings();
$demoInvoices = fk_get_demo_invoices();
$h = $t['home'] ?? [];

$current_page = 'factura';
$page_title = ($h['demo_title'] ?? 'Demo invoices') . ' — Faktura Creator';
$page_desc = $h['demo_text'] ?? ($t['meta']['description'] ?? '');
$canonicalQs = $lang !== 'en' ? ['lang' => $lang] : [];
$canonical = $site_url . '/factura.html' . ($canonicalQs ? '?' . http_build_query($canonicalQs) : '');

require __DIR__ . '/includes/header.php';
?>

<div class="fk-hero">
    <h1><?= fk_h($h['demo_title'] ?? 'Demo invoices') ?></h1>
    <p><?= fk_h($h['demo_text'] ?? '') ?></p>
    <div class="fk-home-cta" style="margin-top:1.25rem">
        <a href="<?= fk_h(fk_url('create.php')) ?>" class="fk-btn fk-btn-primary"><i class="fas fa-file-circle-plus"></i> <?= fk_h($h['cta_create'] ?? 'Create invoice') ?></a>
        <a href="<?= fk_h(fk_url('calc.php')) ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-calculator"></i> <?= fk_h($t['nav']['calc'] ?? 'Service calculator') ?></a>
    </div>
</div>

<?php require __DIR__ . '/includes/demo-invoices-section.php'; ?>

<?php
if (!empty($demoInvoices)) {
    $extra_js = array_merge((array)($extra_js ?? []), [fk_asset('js/fk-demo-picker.js') . '?v=1']);
}
require __DIR__ . '/includes/footer.php';