<?php
require_once __DIR__ . '/init.php';

$settings = fk_load_settings();
$presets = fk_load_service_presets();
$calcT = $t['calc'] ?? [];

$requestedPreset = trim((string) ($_GET['preset'] ?? ''));
$defaultPresetId = $requestedPreset !== '' && fk_get_service_preset($requestedPreset)
    ? $requestedPreset
    : fk_default_service_preset_id($settings);
$isFacturaEntry = isset($_SERVER['REQUEST_URI']) && preg_match('#/frontend\.html#i', (string) $_SERVER['REQUEST_URI']);
$defaultPreset = fk_get_service_preset($defaultPresetId) ?? $presets[0] ?? [];

$loadId = trim((string) ($_GET['id'] ?? ''));
$loadedCalc = $loadId !== '' ? fk_get_calc($loadId) : null;
if ($loadedCalc !== null && !empty($loadedCalc['preset_id'])) {
    $defaultPresetId = (string) $loadedCalc['preset_id'];
    $defaultPreset = fk_get_service_preset($defaultPresetId) ?? $defaultPreset;
}

$invoicePrefix = $settings['invoice_prefix'] ?? 'INV';
$invoiceNo = $invoicePrefix . '-' . date('Ym') . '-' . str_pad((string) ($settings['next_number'] ?? 1001), 3, '0', STR_PAD_LEFT);
$invoiceDate = date('Y-m-d');
$dueDate = date('Y-m-d');

if ($loadedCalc !== null) {
    $invoiceNo = (string) ($loadedCalc['invoice_no'] ?? $invoiceNo);
    $invoiceDate = (string) ($loadedCalc['invoice_date'] ?? $invoiceDate);
    $dueDate = (string) ($loadedCalc['due_date'] ?? $dueDate);
}

$savedCalcs = array_slice(fk_load_calcs(), 0, 50);
$savedForJs = array_map(static function (array $c) use ($lang, $loadId) {
    $row = [
        'id'    => $c['id'] ?? '',
        'title' => fk_calc_title($c) . ' — ' . fmt_money_label($c),
    ];
    if (($c['id'] ?? '') === $loadId) {
        $row['full'] = $c;
    }
    return $row;
}, $savedCalcs);

function fmt_money_label(array $c): string
{
    $total = fk_calc_total($c);
    $cur = '€';
    foreach (fk_load_service_presets() as $p) {
        if (($p['id'] ?? '') === ($c['preset_id'] ?? '')) {
            $cur = ($p['currency'] ?? 'EUR') === 'EUR' ? '€' : ($p['currency'] ?? 'EUR');
            break;
        }
    }
    return number_format($total, 2, '.', ' ') . ' ' . $cur;
}

$presetsJson = fk_presets_for_js($presets, $lang);
$doc = $defaultPreset['doc'] ?? [];
$seller = $defaultPreset['seller'] ?? [];

$current_page = 'calc';
$page_title = ($calcT['title'] ?? 'Service calculator') . ' — Faktura Creator';
$page_desc = $calcT['meta_desc'] ?? '';
$canonicalQs = [];
if ($lang !== 'en') {
    $canonicalQs['lang'] = $lang;
}
if ($requestedPreset !== '') {
    $canonicalQs['preset'] = $requestedPreset;
}
$canonicalPath = $isFacturaEntry ? '/frontend.html' : '/calc.php';
$canonical = $site_url . $canonicalPath . ($canonicalQs ? '?' . http_build_query($canonicalQs) : '');
$serviceCount = count($defaultPreset['services'] ?? []);
$qrSettings = $settings['qr'] ?? [];
$initialPaymentUrl = '';
if ($loadedCalc !== null) {
    $initialPaymentUrl = fk_calc_payment_url($loadedCalc, $defaultPreset, $settings);
}
$currencySymbol = fk_currency_symbol($defaultPreset['currency'] ?? 'EUR');

$extra_css = [
    fk_asset('css/service-calc.css') . '?v=4',
    fk_asset('css/print-demo.css') . '?v=1',
];
$extra_js = [fk_asset('js/service-calc.js') . '?v=3'];
$body_class = trim(($body_class ?? '') . ' fk-calc-page fk-calc-factura-layout');

require __DIR__ . '/includes/header.php';
?>

<section class="fk-calc-hero fk-no-print">
    <div class="fk-calc-hero__glow" aria-hidden="true"></div>
    <div class="fk-calc-hero__inner">
        <span class="fk-calc-badge"><i class="fas fa-bolt" aria-hidden="true"></i> <?= fk_h($calcT['badge'] ?? 'Mobile-first · Save & PDF') ?></span>
        <h1><?= fk_h($calcT['title'] ?? 'Service calculator') ?></h1>
        <p class="fk-calc-hero__lead"><?= fk_h($calcT['lead'] ?? $calcT['subtitle'] ?? '') ?></p>
        <div class="fk-calc-pills">
            <span class="fk-calc-pill"><i class="fas fa-save" aria-hidden="true"></i> <?= fk_h($calcT['pill_save'] ?? 'Save') ?></span>
            <span class="fk-calc-pill"><i class="fas fa-print" aria-hidden="true"></i> <?= fk_h($calcT['pill_print'] ?? 'Print / PDF') ?></span>
            <span class="fk-calc-pill"><i class="fas fa-mobile-alt" aria-hidden="true"></i> <?= fk_h($calcT['pill_mobile'] ?? 'Phone') ?></span>
            <span class="fk-calc-pill"><i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i> <?= fk_h($calcT['pill_presets'] ?? 'Presets') ?></span>
        </div>
        <div class="fk-calc-hero-stats">
            <div class="fk-calc-stat"><strong><?= (int) max($serviceCount, 9) ?></strong><span><?= fk_h($calcT['stat_services'] ?? 'quick services') ?></span></div>
            <div class="fk-calc-stat"><strong>30s</strong><span><?= fk_h($calcT['stat_seconds'] ?? 'to first quote') ?></span></div>
            <div class="fk-calc-stat"><strong>7</strong><span><?= fk_h($calcT['stat_langs'] ?? 'languages') ?></span></div>
        </div>
    </div>
</section>

<div class="fk-calc-wrap">
    <div class="fk-calc-toolbar fk-no-print">
        <div class="fk-field">
            <label for="fk-calc-preset"><?= fk_h($calcT['preset'] ?? 'Service preset') ?></label>
            <select id="fk-calc-preset">
                <?php foreach ($presets as $p): ?>
                <option value="<?= fk_h($p['id'] ?? '') ?>" <?= ($p['id'] ?? '') === $defaultPresetId ? 'selected' : '' ?>>
                    <?= fk_h(fk_localized($p, 'name', $lang)) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="fk-field">
            <label for="fk-calc-saved"><?= fk_h($calcT['load_saved'] ?? 'Saved calculations') ?></label>
            <select id="fk-calc-saved">
                <option value=""><?= fk_h($calcT['load_none'] ?? '— New calculation —') ?></option>
                <?php foreach ($savedCalcs as $sc): ?>
                <option value="<?= fk_h($sc['id'] ?? '') ?>" <?= ($sc['id'] ?? '') === $loadId ? 'selected' : '' ?>>
                    <?= fk_h(fk_calc_title($sc)) ?> — <?= fk_h(fmt_money_label($sc)) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="fk-field">
            <label for="fk-calc-title"><?= fk_h($calcT['calc_title'] ?? 'Title (for save)') ?></label>
            <input type="text" id="fk-calc-title" value="<?= fk_h($loadedCalc['title'] ?? '') ?>" placeholder="<?= fk_h($calcT['calc_title_ph'] ?? 'Client or project name') ?>">
        </div>
        <div class="fk-calc-toolbar-actions">
            <button type="button" class="fk-btn fk-btn-ghost" id="fk-calc-new"><i class="fas fa-file"></i> <?= fk_h($calcT['new'] ?? 'New') ?></button>
            <button type="button" class="fk-btn fk-btn-success" id="fk-calc-save"><i class="fas fa-save"></i> <?= fk_h($calcT['save'] ?? 'Save calculation') ?></button>
        </div>
    </div>

    <div id="fk-calc-alert" class="fk-alert fk-alert-ok fk-calc-alert fk-no-print" hidden role="status"></div>

    <p class="fk-calc-hint fk-no-print"><i class="fas fa-lightbulb" aria-hidden="true"></i><span><?= fk_h($calcT['hint'] ?? 'Fill in buyer details and add services. Save to open later from admin or the list above.') ?></span></p>

    <div class="fk-calc-sheet" id="fk-calc-sheet">
        <div class="fk-calc-sheet-title fk-no-print">
            <strong><?= fk_h($calcT['sheet_title'] ?? 'Service invoice calculator') ?></strong>
        </div>

        <div class="fk-calc-meta">
            <strong id="fk-doc-invoice-data"><?= fk_h($doc['invoice_data'] ?? 'Invoice data:') ?></strong>
            <label id="fk-doc-invoice-no"><?= fk_h($doc['invoice_no'] ?? 'No.:') ?></label>
            <input type="text" id="fk-calc-invoice-no" value="<?= fk_h($invoiceNo) ?>">
            <label id="fk-doc-invoice-date"><?= fk_h($doc['invoice_date'] ?? 'Date:') ?></label>
            <input type="date" id="fk-calc-invoice-date" value="<?= fk_h($invoiceDate) ?>">
            <label id="fk-doc-due-date"><?= fk_h($doc['due_date'] ?? 'Due:') ?></label>
            <input type="date" id="fk-calc-due-date" value="<?= fk_h($dueDate) ?>">
        </div>

        <div class="fk-calc-details">
            <div class="fk-calc-section">
                <h2 id="fk-doc-seller"><?= fk_h($doc['seller'] ?? 'Seller') ?></h2>
                <div class="fk-calc-seller" id="fk-calc-seller">
                    <?php if (!empty($seller['name'])): ?>
                    <strong><?= fk_h($seller['name']) ?></strong><br>
                    <?php endif; ?>
                    <?php if (!empty($seller['org_nr'])): ?>
                    <?= fk_h($doc['org_label'] ?? '') ?> <?= fk_h($seller['org_nr']) ?><br>
                    <?php endif; ?>
                    <?php if (!empty($seller['license'])): ?>
                    <?= fk_h($seller['license']) ?><br><br>
                    <?php endif; ?>
                    <?php if (!empty($seller['address'])): ?>
                    <?= fk_h($seller['address']) ?><br>
                    <?php endif; ?>
                    <?php if (!empty($seller['bank'])): ?>
                    <?= fk_h($seller['bank']) ?><br>
                    <?php endif; ?>
                    <?php if (!empty($seller['iban'])): ?>
                    <?= fk_h($seller['iban']) ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="fk-calc-section">
                <h2 id="fk-doc-buyer"><?= fk_h($doc['buyer'] ?? 'Buyer') ?></h2>
                <div class="fk-calc-buyer">
                    <?php $buyer = $loadedCalc['buyer'] ?? []; ?>
                    <input type="text" id="buyer_name" placeholder="<?= fk_h($doc['buyer_name_ph'] ?? '') ?>" value="<?= fk_h($buyer['name'] ?? '') ?>">
                    <input type="text" id="buyer_code" placeholder="<?= fk_h($doc['buyer_code_ph'] ?? '') ?>" value="<?= fk_h($buyer['code'] ?? '') ?>">
                    <textarea id="buyer_address" rows="2" placeholder="<?= fk_h($doc['buyer_address_ph'] ?? '') ?>"><?= fk_h($buyer['address'] ?? '') ?></textarea>
                    <input type="tel" id="buyer_phone" placeholder="<?= fk_h($doc['buyer_phone_ph'] ?? '') ?>" value="<?= fk_h($buyer['phone'] ?? '') ?>">
                    <input type="email" id="buyer_email" placeholder="<?= fk_h($doc['buyer_email_ph'] ?? '') ?>" value="<?= fk_h($buyer['email'] ?? '') ?>">
                </div>
            </div>
        </div>

        <div class="fk-calc-services-head">
            <h2 class="fk-calc-services-title" id="fk-doc-services"><?= fk_h($doc['services'] ?? 'Services') ?></h2>
            <div class="fk-calc-live-total fk-no-print" id="fk-calc-live-total" aria-live="polite">
                <span><?= fk_h($calcT['sticky_total'] ?? 'Total') ?>:</span>
                <strong><span id="fk-calc-live-amount">0.00</span> <span class="fk-calc-currency" id="fk-calc-currency-live"><?= fk_h($currencySymbol) ?></span></strong>
            </div>
        </div>

        <div class="fk-calc-quick fk-no-print" id="fk-calc-quick"></div>

        <div class="fk-calc-table-wrap">
        <table class="fk-calc-table">
            <thead>
                <tr>
                    <th class="fk-calc-col-nr" id="fk-doc-col-nr"><?= fk_h($doc['col_nr'] ?? 'No.') ?></th>
                    <th id="fk-doc-col-name"><?= fk_h($doc['col_name'] ?? 'Name') ?></th>
                    <th class="fk-calc-col-qty" id="fk-doc-col-qty"><?= fk_h($doc['col_qty'] ?? 'Qty') ?></th>
                    <th class="fk-calc-col-price" id="fk-doc-col-price"><?= fk_h($doc['col_price'] ?? 'Price') ?></th>
                    <th class="fk-calc-col-sum" id="fk-doc-col-sum"><?= fk_h($doc['col_sum'] ?? 'Sum') ?></th>
                    <th class="fk-calc-col-remove fk-no-print"></th>
                </tr>
            </thead>
            <tbody id="fk-calc-lines"></tbody>
        </table>
        </div>

        <button type="button" class="fk-calc-add-btn fk-no-print" id="fk-calc-add-line"><i class="fas fa-plus" aria-hidden="true"></i> <?= fk_h($calcT['add_line'] ?? 'Add service') ?></button>

        <div class="fk-calc-footer-grid">
        <div class="fk-calc-total-box">
            <strong><span id="fk-doc-total"><?= fk_h($doc['total'] ?? 'TOTAL:') ?></span> <span id="fk-calc-total">0.00</span> <span class="fk-calc-currency" id="fk-calc-currency-total"><?= fk_h($currencySymbol) ?></span></strong>
        </div>

        <div class="fk-calc-pay-panel fk-no-print" id="fk-calc-pay-panel">
            <h3 class="fk-calc-pay-title"><i class="fas fa-qrcode" aria-hidden="true"></i> <?= fk_h($calcT['payment_link_title'] ?? 'Payment link & QR') ?></h3>
            <label class="fk-calc-pay-label" for="fk-calc-payment-url"><?= fk_h($calcT['payment_url'] ?? 'Payment URL') ?></label>
            <div class="fk-calc-pay-url-row">
                <input type="url" id="fk-calc-payment-url" class="fk-calc-payment-url-input" value="<?= fk_h($loadedCalc['payment_url'] ?? $initialPaymentUrl) ?>" placeholder="<?= fk_h($calcT['payment_url_ph'] ?? 'https://vipps.no/… or Stripe') ?>">
                <button type="button" class="fk-btn fk-btn-ghost fk-calc-gen-pay" id="fk-calc-gen-payment-url" title="<?= fk_h($calcT['payment_gen'] ?? 'Generate from template') ?>">
                    <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                </button>
            </div>
            <p class="fk-calc-pay-hint"><?= fk_h($calcT['payment_url_hint'] ?? 'Configure template in Admin → Service calculator. Placeholders: {amount}, {invoice_no}, {currency}, {reference}') ?></p>
            <div class="fk-calc-qr-wrap" id="fk-calc-qr-wrap" hidden>
                <img id="fk-calc-qr-img" src="" alt="<?= fk_h($calcT['qr_scan'] ?? 'Scan to pay') ?>" width="140" height="140" loading="lazy">
                <a href="#" id="fk-calc-pay-btn" class="fk-calc-pay-btn" target="_blank" rel="noopener noreferrer">
                    <i class="fas fa-credit-card" aria-hidden="true"></i> <?= fk_h($calcT['pay_now'] ?? 'Pay now') ?>
                </a>
                <p class="fk-calc-qr-caption"><?= fk_h($calcT['qr_scan'] ?? 'Scan to pay') ?></p>
            </div>
        </div>

        <div class="fk-calc-qr-print" id="fk-calc-qr-print" hidden aria-hidden="true">
            <img id="fk-calc-qr-print-img" src="" alt="QR" width="120" height="120">
            <div class="fk-calc-qr-print-url" id="fk-calc-qr-print-url"></div>
        </div>
        </div>

        <div class="fk-calc-payment">
            <strong id="fk-doc-payment"><?= fk_h($doc['payment'] ?? 'Payment:') ?></strong>
            <span id="fk-calc-payment-text"><?= fk_h(str_replace(
                ['{iban}', '{bank}'],
                [$seller['iban'] ?? '', $seller['bank'] ?? ''],
                $doc['payment_text'] ?? ''
            )) ?></span><br>
            <strong id="fk-doc-payment-purpose"><?= fk_h($doc['payment_purpose'] ?? 'Payment reference:') ?></strong>
            <span id="fk-calc-payment-purpose"><?= fk_h(str_replace('{no}', $invoiceNo, $doc['payment_purpose_tpl'] ?? '')) ?></span>
            <input type="text" id="fk-calc-payment-purpose-input" class="fk-calc-payment-purpose-input fk-no-print" value="<?= fk_h($loadedCalc['payment_purpose'] ?? '') ?>" placeholder="<?= fk_h($calcT['payment_purpose_ph'] ?? '') ?>">
        </div>

        <div class="fk-calc-actions fk-no-print">
            <button type="button" class="fk-calc-print-btn" id="fk-calc-print">
                <i class="fas fa-print"></i> <?= fk_h($calcT['print'] ?? 'Print / Save PDF') ?>
            </button>
        </div>

        <?php fk_render_print_demo_mark(); ?>
    </div>
</div>

<div class="fk-calc-sticky fk-no-print" id="fk-calc-sticky" aria-hidden="true">
    <div class="fk-calc-sticky-total">
        <span><?= fk_h($calcT['sticky_total'] ?? 'Total') ?></span>
        <strong><span id="fk-calc-sticky-amount">0.00</span> <span class="fk-calc-currency" id="fk-calc-currency-sticky"><?= fk_h($currencySymbol) ?></span></strong>
    </div>
    <button type="button" class="fk-btn fk-btn-success" id="fk-calc-sticky-save"><i class="fas fa-save" aria-hidden="true"></i> <?= fk_h($calcT['save'] ?? 'Save') ?></button>
    <button type="button" class="fk-calc-print-btn" id="fk-calc-sticky-print" style="min-width:auto;padding:.55rem .75rem"><i class="fas fa-print" aria-hidden="true"></i></button>
</div>

<script>
window.FK_CALC = <?= json_encode([
    'lang' => $lang,
    'base_url' => fk_url('calc.php'),
    'save_url' => fk_url('api/save-calc.php'),
    'presets' => $presetsJson,
    'loaded' => $loadedCalc,
    'saved' => $savedForJs,
    'qr_size' => (int) ($qrSettings['size'] ?? 140),
    'global_payment_template' => (string) ($qrSettings['payment_url_template'] ?? ''),
    'i18n' => [
        'save' => $calcT['save'] ?? 'Save calculation',
        'saving' => $calcT['saving'] ?? 'Saving…',
        'saved' => $calcT['saved'] ?? 'Calculation saved.',
        'saved_link' => $calcT['saved_link'] ?? 'Open saved calculation',
        'save_error' => $calcT['save_error'] ?? 'Could not save.',
        'load_none' => $calcT['load_none'] ?? '— New calculation —',
        'remove_line' => $calcT['remove_line'] ?? 'Remove',
        'payment_purpose_tpl' => $doc['payment_purpose_tpl'] ?? 'Payment for invoice {no}',
        'col_nr' => $doc['col_nr'] ?? 'No.',
        'col_name' => $doc['col_name'] ?? 'Name',
        'col_qty' => $doc['col_qty'] ?? 'Qty',
        'col_price' => $doc['col_price'] ?? 'Price',
        'col_sum' => $doc['col_sum'] ?? 'Sum',
        'payment_gen' => $calcT['payment_gen'] ?? 'Generate from template',
        'pay_now' => $calcT['pay_now'] ?? 'Pay now',
        'qr_scan' => $calcT['qr_scan'] ?? 'Scan to pay',
    ],
], JSON_UNESCAPED_UNICODE) ?>;
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>