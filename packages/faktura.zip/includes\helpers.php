<?php

function fk_admin_url(string $path = ''): string
{
    return fk_url('admin/' . ltrim($path, '/'));
}

function fk_langs(): array
{
    global $FK_LANGS;
    return $FK_LANGS;
}

/**
 * Language URL for a specific page (help, contact, etc.).
 */
function fk_page_lang_url(string $page, string $code): string
{
    global $FK_LANGS;
    if (!in_array($code, array_keys($FK_LANGS), true)) {
        $code = FK_LANG_DEFAULT;
    }
    $base = fk_url($page);
    if ($code === FK_LANG_DEFAULT) {
        return $base . '?lang=en';
    }
    return $base . '?lang=' . urlencode($code);
}

function fk_lang_url(string $code, bool $absolute = false): string
{
    global $FK_LANGS;
    if (!in_array($code, array_keys($FK_LANGS), true)) {
        $code = FK_LANG_DEFAULT;
    }

    $uri = $_SERVER['REQUEST_URI'] ?? fk_url('index.php');
    $parts = parse_url($uri);
    $path = $parts['path'] ?? fk_url('index.php');
    parse_str($parts['query'] ?? '', $q);
    unset($q['lang']);
    $q['lang'] = $code;

    $result = $path . '?' . http_build_query($q);
    if ($absolute) {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        return $protocol . '://' . ($_SERVER['HTTP_HOST'] ?? FK_DOMAIN) . $result;
    }
    return $result;
}

function fk_admin_lang_url(string $code): string
{
    global $FK_LANGS;
    if (!in_array($code, array_keys($FK_LANGS), true)) {
        $code = FK_LANG_DEFAULT;
    }

    $uri = $_SERVER['REQUEST_URI'] ?? fk_admin_url('index.php');
    $parts = parse_url($uri);
    parse_str($parts['query'] ?? '', $q);
    unset($q['lang']);
    $q['lang'] = $code;
    $path = $parts['path'] ?? fk_admin_url('index.php');
    return $path . '?' . http_build_query($q);
}

function fk_localized(array $item, string $field, string $lang): string
{
    $val = $item[$field] ?? '';
    if (is_array($val)) {
        return (string) ($val[$lang] ?? $val['en'] ?? reset($val) ?: '');
    }
    return (string) $val;
}

function fk_country_by_id(array $settings, string $id): ?array
{
    foreach ($settings['countries'] ?? [] as $country) {
        if (($country['id'] ?? '') === $id && !empty($country['active'])) {
            return $country;
        }
    }
    return null;
}

function fk_active_countries(array $settings): array
{
    return array_values(array_filter(
        $settings['countries'] ?? [],
        static fn(array $c) => !empty($c['active'])
    ));
}

/**
 * @param array<int, array{qty: float, price: float}> $lines
 * @return array{subtotal: float, tax_amount: float, total: float, tax_label: string, tax_rate: float, tax_mode: string}
 */
function fk_calculate_totals(array $lines, array $country, string $lang): array
{
    $subtotal = 0.0;
    foreach ($lines as $line) {
        $qty = (float) ($line['qty'] ?? 0);
        $price = (float) ($line['price'] ?? 0);
        $subtotal += $qty * $price;
    }

    $taxMode = $country['tax_mode'] ?? 'vat';
    $taxLabel = fk_localized($country, 'tax_label', $lang);
    $rate = $taxMode === 'single'
        ? (float) ($country['single_tax_rate'] ?? 0)
        : (float) ($country['vat_rate'] ?? 0);

    if ($taxMode === 'single') {
        $taxAmount = round($subtotal * $rate / 100, 2);
        $total = round($subtotal - $taxAmount, 2);
    } else {
        $taxAmount = round($subtotal * $rate / 100, 2);
        $total = round($subtotal + $taxAmount, 2);
    }

    return [
        'subtotal'   => round($subtotal, 2),
        'tax_amount' => $taxAmount,
        'total'      => $total,
        'tax_label'  => $taxLabel,
        'tax_rate'   => $rate,
        'tax_mode'   => $taxMode,
    ];
}

function fk_format_date(string $lang): string
{
    return date($lang === 'en' ? 'Y-m-d' : 'd.m.Y');
}

function fk_h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/** @return array<string, string> demo invoice id => screenshot filename */
function fk_demo_shots_map(): array
{
    return [
        'demo-no-cleaning'   => 'demo-no-cleaning.svg',
        'demo-uk-consulting' => 'demo-uk-consulting.svg',
        'demo-lt-cleaning'   => 'demo-lt-cleaning.svg',
        'demo-ua-webdev'     => 'demo-ua-webdev.svg',
        'demo-pl-marketing'  => 'demo-pl-marketing.svg',
        'demo-de-engineering'=> 'demo-de-engineering.svg',
        'demo-sv-design'     => 'demo-sv-design.svg',
    ];
}

/** @return array<string, array{label: string, api_base: string, models: string[]}> */
function fk_ai_providers(): array
{
    return [
        'openai' => [
            'label'    => 'OpenAI',
            'api_base' => 'https://api.openai.com/v1',
            'models'   => ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1'],
        ],
        'grok' => [
            'label'    => 'xAI Grok',
            'api_base' => 'https://api.x.ai/v1',
            'models'   => ['grok-3-mini', 'grok-3', 'grok-2-latest', 'grok-beta'],
        ],
        'compatible' => [
            'label'    => 'OpenAI-compatible',
            'api_base' => 'https://api.openai.com/v1',
            'models'   => [],
        ],
    ];
}

/**
 * @param array<string, mixed> $ai
 * @return array{provider: string, api_base: string, model: string}
 */
function fk_ai_resolve_config(array $ai): array
{
    $providers = fk_ai_providers();
    $provider = (string) ($ai['provider'] ?? 'openai');
    if (!isset($providers[$provider])) {
        $provider = 'openai';
    }
    $preset = $providers[$provider];
    $apiBase = rtrim(trim((string) ($ai['api_base'] ?? '')), '/');
    if ($apiBase === '') {
        $apiBase = rtrim($preset['api_base'], '/');
    }
    $model = trim((string) ($ai['model'] ?? ''));
    if ($model === '') {
        $model = $preset['models'][0] ?? 'gpt-4o-mini';
    }
    return ['provider' => $provider, 'api_base' => $apiBase, 'model' => $model];
}

function fk_json_response(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Visible only when printing — demo watermark for PDF output. */
function fk_render_print_demo_mark(): void
{
    if (!defined('FK_DEMO_MODE') || !FK_DEMO_MODE) {
        return;
    }
    global $t;
    $cc = $t['print_demo'] ?? [];
    $label = (string) ($cc['label'] ?? 'DEMO');
    $url = fk_demo_url();
    ?>
    <div class="fk-print-demo" aria-hidden="true">
        <span class="fk-print-demo__watermark"><?= fk_h($label) ?></span>
        <span class="fk-print-demo__url"><?= fk_h($url) ?></span>
    </div>
    <?php
}