<?php
/** @var array $t @var string $lang */
$cc = $t['contact_channels'] ?? [];
$demoUrl = fk_demo_url();
?>
<aside class="fk-contact-channels" aria-label="<?= fk_h($cc['title'] ?? 'Contact us') ?>">
    <div class="fk-contact-channels-kicker"><?= fk_h($cc['kicker'] ?? 'NEXT STEP') ?></div>
    <h2 class="fk-contact-channels-title"><?= fk_h($cc['title'] ?? 'Contact us') ?></h2>
    <p class="fk-contact-channels-sub"><?= fk_h($cc['subtitle'] ?? 'Choose a convenient method') ?></p>

    <div class="fk-contact-channel-list">
        <a href="<?= fk_h($demoUrl) ?>" class="fk-contact-channel fk-contact-channel--primary" rel="related">
            <i class="fas fa-play-circle" aria-hidden="true"></i>
            <span><?= fk_h($cc['demo'] ?? 'Live demo') ?></span>
            <small><?= fk_h($demoUrl) ?></small>
        </a>
        <a href="mailto:email@bilohash.com" class="fk-contact-channel">
            <i class="fas fa-envelope" aria-hidden="true"></i>
            <span><?= fk_h($cc['email'] ?? 'Email') ?></span>
            <small>email@bilohash.com</small>
        </a>
        <a href="<?= fk_h(fk_url('help.php')) ?>" class="fk-contact-channel">
            <i class="fas fa-book-open" aria-hidden="true"></i>
            <span><?= fk_h($cc['help'] ?? 'Help & guide') ?></span>
        </a>
        <a href="<?= fk_h(fk_url('create.php')) ?>" class="fk-contact-channel">
            <i class="fas fa-file-circle-plus" aria-hidden="true"></i>
            <span><?= fk_h($cc['create'] ?? 'Create invoice') ?></span>
        </a>
        <a href="<?= fk_h(fk_url('factura.html')) ?>" class="fk-contact-channel">
            <i class="fas fa-file-invoice" aria-hidden="true"></i>
            <span><?= fk_h($cc['factura'] ?? ($t['home']['demo_title'] ?? 'Demo invoices')) ?></span>
        </a>
        <a href="<?= fk_h(fk_admin_url('login.php')) ?>" class="fk-contact-channel">
            <i class="fas fa-lock" aria-hidden="true"></i>
            <span><?= fk_h($cc['admin'] ?? 'Admin demo') ?></span>
            <small><?= fk_h($cc['admin_hint'] ?? 'demo / bilofaktura2026') ?></small>
        </a>
    </div>
</aside>