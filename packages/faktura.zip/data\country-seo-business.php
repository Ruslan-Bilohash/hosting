<?php
/**
 * Business example copy — always shown in the market's native language on country SEO pages.
 *
 * @return array<string, array{title: string, text: string, buyer: string, seller: string}>
 */
return [
    'no' => [
        'title'  => 'Eksempel: kontorrengjøring for AS',
        'seller' => 'BILOHASH Demo AS (Drammen)',
        'buyer'  => 'Nordic Office Park AS (Oslo)',
        'text'   => 'Månedlig kontorrengjøring og vinduspuss fakturert i NOK med MVA 25 %. Norske betalingsfrister, org.nr. og bankoverføring til IBAN — klar for regnskapsfører og SMB.',
    ],
    'en' => [
        'title'  => 'Example: IT consulting for UK Ltd',
        'seller' => 'BILOHASH Demo Ltd (London)',
        'buyer'  => 'TechStart Ltd',
        'text'   => 'PHP CMS integration and invoice module setup billed in GBP with VAT 20 %. UK company fields, payment terms and IBAN — ready for bookkeepers and SMEs.',
    ],
    'lt' => [
        'title'  => 'Pavyzdys: valymo paslaugos UAB',
        'seller' => 'BILOHASH Demo UAB (Vilnius)',
        'buyer'  => 'UAB Verslo centras',
        'text'   => 'Biuro valymas ir langų plovimas sąskaitoje EUR su PVM 21 %. Lietuvos įmonės laukai, mokėjimo terminai ir IBAN — buhalteriams ir MVĮ.',
    ],
    'pl' => [
        'title'  => 'Przykład: agencja marketingowa Sp. z o.o.',
        'seller' => 'BILOHASH Demo Sp. z o.o. (Warszawa)',
        'buyer'  => 'Agencja Kreatywna Sp. z o.o.',
        'text'   => 'Kampania social media i projekt landing page w PLN z VAT 23 %. Polskie pola firmy, terminy płatności i IBAN — dla księgowych i MŚP.',
    ],
    'de' => [
        'title'  => 'Beispiel: Ingenieurbüro GmbH',
        'seller' => 'BILOHASH Demo GmbH (Berlin)',
        'buyer'  => 'BauTech GmbH',
        'text'   => 'Statikprüfung und Baustellenbegehung in EUR mit USt 19 %. Deutsche Firmenfelder, Zahlungsziel und IBAN — für Buchhalter und KMU.',
    ],
    'sv' => [
        'title'  => 'Exempel: designstudio AB',
        'seller' => 'BILOHASH Demo AB (Stockholm)',
        'buyer'  => 'Nordic Brand AB',
        'text'   => 'Varumärkesidentitet och fakturamallar i SEK med moms 25 %. Svenska företagsfält, betalningsvillkor och IBAN — för revisorer och småföretag.',
    ],
    'uk' => [
        'title'  => 'Приклад: веб-студія ТОВ',
        'seller' => 'ТОВ «БІЛОХАШ Демо» (Київ)',
        'buyer'  => 'ТОВ «Клієнт Плюс»',
        'text'   => 'Розробка сайту на PHP CMS та адаптивний дизайн у UAH з ПДВ 20 %. Українські реквізити, терміни оплати та IBAN — для бухгалтерів і МСП.',
    ],
];