</main>
</div>
</div>
<script src="<?= fk_h(fk_asset('js/fk-nav.js')) ?>?v=2" defer></script>
<script src="<?= fk_h(fk_asset('js/admin-nav.js')) ?>?v=3" defer></script>
<?php if (!empty($adm_extra_js)): foreach ((array) $adm_extra_js as $js): ?>
<script src="<?= fk_h($js) ?>" defer></script>
<?php endforeach; endif; ?>
</body>
</html>