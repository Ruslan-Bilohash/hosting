<?php
require_once __DIR__ . '/init.php';
fk_admin_logout();
header('Location: ' . fk_admin_url('login.php'), true, 302);
exit;