<?php

/**
 * 12 print layouts + 4 page formats.
 */
function fk_print_designs(): array
{
    return [
        'classic-blue' => [
            'accent' => '#1e40af',
            'name' => ['en' => 'Classic Blue', 'no' => 'Klassisk blå', 'uk' => 'Класичний синій', 'lt' => 'Klasikinis mėlynas', 'de' => 'Klassisch Blau', 'pl' => 'Klasyczny niebieski', 'sv' => 'Klassisk blå'],
        ],
        'minimal-mono' => [
            'accent' => '#18181b',
            'name' => ['en' => 'Minimal Mono', 'no' => 'Minimal mono', 'uk' => 'Мінімалізм', 'lt' => 'Minimalus', 'de' => 'Minimal Mono', 'pl' => 'Minimal mono', 'sv' => 'Minimal mono'],
        ],
        'nordic-light' => [
            'accent' => '#475569',
            'name' => ['en' => 'Nordic Light', 'no' => 'Nordisk lys', 'uk' => 'Північний світлий', 'lt' => 'Šiaurės šviesus', 'de' => 'Nordisch Hell', 'pl' => 'Nordycki jasny', 'sv' => 'Nordisk ljus'],
        ],
        'corporate-navy' => [
            'accent' => '#0f172a',
            'name' => ['en' => 'Corporate Navy', 'no' => 'Corporate marine', 'uk' => 'Корпоративний navy', 'lt' => 'Korporacinis', 'de' => 'Corporate Navy', 'pl' => 'Korporacyjny granat', 'sv' => 'Corporate marin'],
        ],
        'teal-fresh' => [
            'accent' => '#0d9488',
            'name' => ['en' => 'Teal Fresh', 'no' => 'Teal frisk', 'uk' => 'Бірюзовий', 'lt' => 'Žalias mėlynas', 'de' => 'Teal Frisch', 'pl' => 'Morski świeży', 'sv' => 'Teal fräsch'],
        ],
        'forest-green' => [
            'accent' => '#166534',
            'name' => ['en' => 'Forest Green', 'no' => 'Skoggrønn', 'uk' => 'Лісовий зелений', 'lt' => 'Miško žalias', 'de' => 'Waldgrün', 'pl' => 'Leśna zieleń', 'sv' => 'Skogsgrön'],
        ],
        'wine-elegant' => [
            'accent' => '#881337',
            'name' => ['en' => 'Wine Elegant', 'no' => 'Vin elegant', 'uk' => 'Винний елегант', 'lt' => 'Vyno elegantiškas', 'de' => 'Wein Elegant', 'pl' => 'Bordowy elegancki', 'sv' => 'Vin elegant'],
        ],
        'sunset-orange' => [
            'accent' => '#c2410c',
            'name' => ['en' => 'Sunset Orange', 'no' => 'Solnedgang oransje', 'uk' => 'Помаранчевий захід', 'lt' => 'Saulėlydžio oranžinė', 'de' => 'Sonnenuntergang Orange', 'pl' => 'Pomarańczowy zachód', 'sv' => 'Solnedgång orange'],
        ],
        'violet-creative' => [
            'accent' => '#6d28d9',
            'name' => ['en' => 'Violet Creative', 'no' => 'Fiolett kreativ', 'uk' => 'Фіолетовий креатив', 'lt' => 'Violetinis', 'de' => 'Violett Kreativ', 'pl' => 'Fioletowy kreatywny', 'sv' => 'Violett kreativ'],
        ],
        'slate-pro' => [
            'accent' => '#334155',
            'name' => ['en' => 'Slate Pro', 'no' => 'Skifer pro', 'uk' => 'Сланцевий pro', 'lt' => 'Pilkas pro', 'de' => 'Schiefer Pro', 'pl' => 'Łupkowy pro', 'sv' => 'Skiffer pro'],
        ],
        'stripe-classic' => [
            'accent' => '#1d4ed8',
            'name' => ['en' => 'Stripe Classic', 'no' => 'Stripe klassisk', 'uk' => 'Смугастий класик', 'lt' => 'Juostuotas', 'de' => 'Streifen Klassisch', 'pl' => 'Paski klasyczne', 'sv' => 'Rand klassisk'],
        ],
        'formal-border' => [
            'accent' => '#1e3a5f',
            'name' => ['en' => 'Formal Border', 'no' => 'Formell ramme', 'uk' => 'Офіційна рамка', 'lt' => 'Formali rėmelis', 'de' => 'Formeller Rahmen', 'pl' => 'Formalna ramka', 'sv' => 'Formell ram'],
        ],
    ];
}

function fk_print_formats(): array
{
    return [
        'a4' => [
            'css' => 'A4',
            'width' => '210mm',
            'name' => ['en' => 'A4 (210 × 297 mm)', 'no' => 'A4 (210 × 297 mm)', 'uk' => 'A4 (210 × 297 мм)', 'lt' => 'A4 (210 × 297 mm)', 'de' => 'A4 (210 × 297 mm)', 'pl' => 'A4 (210 × 297 mm)', 'sv' => 'A4 (210 × 297 mm)'],
        ],
        'a5' => [
            'css' => 'A5',
            'width' => '148mm',
            'name' => ['en' => 'A5 (148 × 210 mm)', 'no' => 'A5 (148 × 210 mm)', 'uk' => 'A5 (148 × 210 мм)', 'lt' => 'A5 (148 × 210 mm)', 'de' => 'A5 (148 × 210 mm)', 'pl' => 'A5 (148 × 210 mm)', 'sv' => 'A5 (148 × 210 mm)'],
        ],
        'letter' => [
            'css' => 'letter',
            'width' => '8.5in',
            'name' => ['en' => 'US Letter (8.5 × 11 in)', 'no' => 'US Letter (8.5 × 11 tommer)', 'uk' => 'US Letter (8.5 × 11 дюймів)', 'lt' => 'US Letter (8.5 × 11 in)', 'de' => 'US Letter (8.5 × 11 Zoll)', 'pl' => 'US Letter (8.5 × 11 cali)', 'sv' => 'US Letter (8.5 × 11 tum)'],
        ],
        'legal' => [
            'css' => 'legal',
            'width' => '8.5in',
            'name' => ['en' => 'US Legal (8.5 × 14 in)', 'no' => 'US Legal (8.5 × 14 tommer)', 'uk' => 'US Legal (8.5 × 14 дюймів)', 'lt' => 'US Legal (8.5 × 14 in)', 'de' => 'US Legal (8.5 × 14 Zoll)', 'pl' => 'US Legal (8.5 × 14 cali)', 'sv' => 'US Legal (8.5 × 14 tum)'],
        ],
    ];
}

function fk_normalize_print_design(?string $id): string
{
    $designs = fk_print_designs();
    return isset($designs[$id]) ? $id : 'classic-blue';
}

function fk_normalize_print_format(?string $id): string
{
    $formats = fk_print_formats();
    return isset($formats[$id]) ? $id : 'a4';
}

function fk_print_design_name(string $id, string $lang): string
{
    $designs = fk_print_designs();
    $item = $designs[fk_normalize_print_design($id)] ?? [];
    return fk_localized($item, 'name', $lang);
}

function fk_print_format_name(string $id, string $lang): string
{
    $formats = fk_print_formats();
    $item = $formats[fk_normalize_print_format($id)] ?? [];
    return fk_localized($item, 'name', $lang);
}

function fk_print_classes(string $design, string $format): string
{
    return 'fk-print-sheet fk-design-' . fk_normalize_print_design($design)
        . ' fk-fmt-' . fk_normalize_print_format($format);
}

function fk_print_format_css(string $format): string
{
    $formats = fk_print_formats();
    $id = fk_normalize_print_format($format);
    return $formats[$id]['css'] ?? 'A4';
}

function fk_print_format_width(string $format): string
{
    $formats = fk_print_formats();
    $id = fk_normalize_print_format($format);
    return $formats[$id]['width'] ?? '210mm';
}

function fk_render_design_picker(string $fieldName, string $selected, string $lang): void
{
    $selected = fk_normalize_print_design($selected);
    echo '<div class="fk-design-picker" role="radiogroup">';
    foreach (fk_print_designs() as $id => $meta) {
        $sel = $id === $selected;
        $label = fk_localized($meta, 'name', $lang);
        $cls = 'fk-design-' . $id;
        echo '<label class="fk-design-option' . ($sel ? ' selected' : '') . '">';
        echo '<input type="radio" name="' . fk_h($fieldName) . '" value="' . fk_h($id) . '"' . ($sel ? ' checked' : '') . '>';
        echo '<div class="fk-design-thumb ' . fk_h($cls) . '"><div class="fk-design-thumb-inner">';
        echo '<div class="fk-design-thumb-bar"></div>';
        echo '<div class="fk-design-thumb-line"></div><div class="fk-design-thumb-line short"></div>';
        echo '</div></div><span class="fk-design-label">' . fk_h($label) . '</span></label>';
    }
    echo '</div>';
}

function fk_render_format_select(string $fieldName, string $selected, string $lang, string $id = 'fk-print-format'): void
{
    $selected = fk_normalize_print_format($selected);
    echo '<select name="' . fk_h($fieldName) . '" id="' . fk_h($id) . '" class="fk-format-select">';
    foreach (fk_print_formats() as $fid => $meta) {
        echo '<option value="' . fk_h($fid) . '"' . ($fid === $selected ? ' selected' : '') . '>';
        echo fk_h(fk_localized($meta, 'name', $lang)) . '</option>';
    }
    echo '</select>';
}