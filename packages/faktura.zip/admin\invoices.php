<?php
require_once __DIR__ . '/init.php';

$adm_title = $t['admin']['invoices'] ?? 'Saved invoices';
$adm_nav_active = 'invoices';
$adm_body_class = 'adm-page-invoices';
$adm_saved = false;
$ta = $t['admin'] ?? [];
$settings = fk_load_settings();
$countries = $settings['countries'] ?? [];
$designs = fk_print_designs();
$formats = fk_print_formats();

$countryFlags = [
    'no' => '🇳🇴', 'en' => '🇬🇧', 'uk' => '🇬🇧', 'gb' => '🇬🇧',
    'lt' => '🇱🇹', 'ua' => '🇺🇦', 'pl' => '🇵🇱', 'de' => '🇩🇪', 'se' => '🇸🇪',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && fk_admin_logged()) {
    $deleteId = trim($_POST['delete_id'] ?? '');
    $toggleId = trim($_POST['toggle_demo_id'] ?? '');
    if ($deleteId !== '' && fk_delete_invoice($deleteId)) {
        $adm_saved = true;
    } elseif ($toggleId !== '') {
        $inv = fk_get_invoice($toggleId);
        if ($inv !== null) {
            $newDemo = empty($inv['is_demo']);
            fk_update_invoice($toggleId, ['is_demo' => $newDemo]);
            $adm_saved = true;
            $adm_demo_saved = true;
        }
    }
}

$list = fk_load_invoices();
$demoCount = count(array_filter($list, static fn($r) => !empty($r['is_demo'])));
$adm_extra_js = [fk_asset('js/admin-invoices.js') . '?v=2'];

require __DIR__ . '/includes/layout.php';
?>

<div class="adm-card adm-card--flush">
    <div class="adm-doc-head">
        <div class="adm-doc-head-text">
            <h2><i class="fas fa-folder-open" aria-hidden="true"></i> <?= fk_h($adm_title) ?></h2>
            <p><?= fk_h($ta['inv_hint'] ?? 'Browse, preview, email and manage homepage demo invoices.') ?></p>
        </div>
        <a href="<?= fk_url('create.php') ?>" class="adm-btn adm-btn-ghost adm-btn-sm" target="_blank" rel="noopener">
            <i class="fas fa-plus" aria-hidden="true"></i> <?= fk_h($ta['inv_create'] ?? 'New invoice') ?>
        </a>
    </div>

    <?php if (empty($list)): ?>
    <p class="adm-empty"><i class="fas fa-inbox" aria-hidden="true"></i> <?= fk_h($ta['invoices_empty'] ?? 'No saved invoices yet.') ?></p>
    <?php else: ?>
    <div class="adm-doc-stats">
        <div class="adm-doc-stat"><i class="fas fa-file-invoice" aria-hidden="true"></i><strong><?= count($list) ?></strong><span><?= fk_h($ta['inv_count_label'] ?? 'Total') ?></span></div>
        <div class="adm-doc-stat"><i class="fas fa-home" aria-hidden="true"></i><strong><?= $demoCount ?></strong><span><?= fk_h($ta['demo_homepage'] ?? 'Homepage demo') ?></span></div>
        <div class="adm-doc-stat"><i class="fas fa-palette" aria-hidden="true"></i><strong>12</strong><span><?= fk_h($ta['print_design'] ?? 'Print designs') ?></span></div>
    </div>

    <div class="adm-doc-toolbar">
        <label class="adm-doc-search">
            <i class="fas fa-magnifying-glass" aria-hidden="true"></i>
            <input type="search" id="adm-doc-search" placeholder="<?= fk_h($ta['inv_search'] ?? 'Search by number, buyer, amount…') ?>" autocomplete="off">
        </label>
        <div class="adm-doc-filters" role="group" aria-label="<?= fk_h($ta['inv_filter_label'] ?? 'Filter') ?>">
            <button type="button" class="adm-filter-btn active" data-filter="all"><i class="fas fa-layer-group" aria-hidden="true"></i><span><?= fk_h($ta['inv_filter_all'] ?? 'All') ?></span></button>
            <button type="button" class="adm-filter-btn" data-filter="demo"><i class="fas fa-home" aria-hidden="true"></i><span><?= fk_h($ta['inv_filter_demo'] ?? 'Homepage') ?></span></button>
        </div>
        <div class="adm-doc-view-toggle" role="group" aria-label="<?= fk_h($ta['inv_view_label'] ?? 'View') ?>">
            <button type="button" class="adm-view-btn active" data-view="cards" title="<?= fk_h($ta['inv_view_cards'] ?? 'Cards') ?>"><i class="fas fa-grip" aria-hidden="true"></i></button>
            <button type="button" class="adm-view-btn" data-view="table" title="<?= fk_h($ta['inv_view_table'] ?? 'Table') ?>"><i class="fas fa-list" aria-hidden="true"></i></button>
        </div>
    </div>
    <p class="adm-doc-result" id="adm-doc-result" aria-live="polite"></p>

    <div class="adm-doc-grid" id="adm-doc-grid">
        <?php foreach ($list as $row):
            $buyerName = $row['buyer']['name'] ?? '—';
            $buyerEmail = $row['buyer']['email'] ?? '';
            $total = $row['totals']['total'] ?? 0;
            $currency = $row['currency'] ?? '';
            $viewUrl = fk_url('invoice.php?id=' . urlencode($row['id'] ?? ''));
            $printUrl = $viewUrl . (str_contains($viewUrl, '?') ? '&' : '?') . 'print=1';
            $isDemo = !empty($row['is_demo']);
            $countryId = strtolower($row['country_id'] ?? '');
            $country = null;
            foreach ($countries as $c) {
                if (($c['id'] ?? '') === $countryId) {
                    $country = $c;
                    break;
                }
            }
            $countryName = $country ? fk_localized($country, 'name', $lang) : strtoupper($countryId);
            $flag = $countryFlags[$countryId] ?? '🌐';
            $designId = $row['print_design'] ?? ($settings['print_design'] ?? 'classic-blue');
            $design = $designs[$designId] ?? $designs['classic-blue'];
            $designName = fk_localized($design, 'name', $lang);
            $accent = $design['accent'] ?? '#1e40af';
            $formatId = $row['print_format'] ?? ($settings['print_format'] ?? 'a4');
            $formatName = isset($formats[$formatId]) ? fk_localized($formats[$formatId], 'name', $lang) : strtoupper($formatId);
            $searchBlob = strtolower(implode(' ', [
                $row['invoice_no'] ?? '',
                $buyerName,
                $buyerEmail,
                $currency,
                (string) $total,
                $countryName,
                $designName,
            ]));
        ?>
        <article class="adm-doc-card" data-demo="<?= $isDemo ? '1' : '0' ?>" data-search="<?= fk_h($searchBlob) ?>">
            <div class="adm-doc-card-accent" style="background:<?= fk_h($accent) ?>"></div>
            <div class="adm-doc-card-top">
                <span class="adm-doc-card-icon" style="color:<?= fk_h($accent) ?>"><i class="fas fa-file-invoice" aria-hidden="true"></i></span>
                <div class="adm-doc-card-title">
                    <strong><?= fk_h($row['invoice_no'] ?? '') ?></strong>
                    <span class="adm-doc-card-date"><i class="fas fa-calendar-day" aria-hidden="true"></i> <?= fk_h($row['invoice_date'] ?? '') ?></span>
                </div>
                <?php if ($isDemo): ?>
                <span class="adm-badge-demo" title="<?= fk_h($ta['demo_on'] ?? 'On homepage') ?>"><i class="fas fa-home" aria-hidden="true"></i></span>
                <?php endif; ?>
            </div>
            <div class="adm-doc-card-body">
                <p class="adm-doc-buyer"><i class="fas fa-user" aria-hidden="true"></i> <?= fk_h($buyerName) ?></p>
                <?php if ($buyerEmail !== ''): ?>
                <p class="adm-doc-meta"><i class="fas fa-envelope" aria-hidden="true"></i> <?= fk_h($buyerEmail) ?></p>
                <?php endif; ?>
                <p class="adm-doc-total"><i class="fas fa-coins" aria-hidden="true"></i> <?= fk_h(fk_money((float) $total, $currency)) ?></p>
                <div class="adm-doc-tags">
                    <span class="adm-doc-tag"><span aria-hidden="true"><?= $flag ?></span> <?= fk_h($countryName) ?></span>
                    <span class="adm-doc-tag"><i class="fas fa-palette" aria-hidden="true"></i> <?= fk_h($designName) ?></span>
                    <span class="adm-doc-tag"><i class="fas fa-file" aria-hidden="true"></i> <?= fk_h($formatName) ?></span>
                </div>
            </div>
            <div class="adm-doc-card-actions">
                <a href="<?= fk_h($viewUrl) ?>" class="adm-icon-btn" target="_blank" rel="noopener" title="<?= fk_h($ta['view'] ?? 'View') ?>"><i class="fas fa-eye" aria-hidden="true"></i></a>
                <a href="<?= fk_h($printUrl) ?>" class="adm-icon-btn" target="_blank" rel="noopener" title="<?= fk_h($t['invoice']['print'] ?? 'Print') ?>"><i class="fas fa-print" aria-hidden="true"></i></a>
                <a href="<?= fk_h(fk_admin_url('send-mail.php?invoice_id=' . urlencode($row['id'] ?? ''))) ?>" class="adm-icon-btn" title="<?= fk_h($ta['send_email'] ?? 'Send') ?>"><i class="fas fa-paper-plane" aria-hidden="true"></i></a>
                <form method="post">
                    <input type="hidden" name="toggle_demo_id" value="<?= fk_h($row['id'] ?? '') ?>">
                    <button type="submit" class="adm-icon-btn" title="<?= fk_h($isDemo ? ($ta['demo_off'] ?? 'Remove') : ($ta['demo_on'] ?? 'Add')) ?>">
                        <i class="fas <?= $isDemo ? 'fa-eye-slash' : 'fa-home' ?>" aria-hidden="true"></i>
                    </button>
                </form>
                <form method="post" onsubmit="return confirm('<?= fk_h($ta['delete_confirm'] ?? 'Delete?') ?>');">
                    <input type="hidden" name="delete_id" value="<?= fk_h($row['id'] ?? '') ?>">
                    <button type="submit" class="adm-icon-btn adm-icon-btn--danger" title="<?= fk_h($ta['delete'] ?? 'Delete') ?>"><i class="fas fa-trash" aria-hidden="true"></i></button>
                </form>
            </div>
        </article>
        <?php endforeach; ?>
    </div>

    <div class="adm-doc-table-view" id="adm-doc-table" hidden>
        <div class="adm-table-wrap">
            <table class="adm-table adm-table--icons">
                <thead>
                    <tr>
                        <th><i class="fas fa-hashtag" aria-hidden="true"></i> <?= fk_h($t['invoice']['invoice_no'] ?? 'No.') ?></th>
                        <th><i class="fas fa-calendar-day" aria-hidden="true"></i> <?= fk_h($t['invoice']['invoice_date'] ?? 'Date') ?></th>
                        <th><i class="fas fa-user" aria-hidden="true"></i> <?= fk_h($t['invoice']['buyer'] ?? 'Buyer') ?></th>
                        <th><i class="fas fa-globe" aria-hidden="true"></i> <?= fk_h($ta['inv_country'] ?? 'Country') ?></th>
                        <th><i class="fas fa-coins" aria-hidden="true"></i> <?= fk_h($t['invoice']['total'] ?? 'Total') ?></th>
                        <th><i class="fas fa-palette" aria-hidden="true"></i> <?= fk_h($ta['inv_print_design'] ?? 'Design') ?></th>
                        <th><i class="fas fa-home" aria-hidden="true"></i> <?= fk_h($ta['demo_homepage'] ?? 'Demo') ?></th>
                        <th><i class="fas fa-bolt" aria-hidden="true"></i> <?= fk_h($ta['inv_actions'] ?? 'Actions') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($list as $row):
                        $buyerName = $row['buyer']['name'] ?? '—';
                        $total = $row['totals']['total'] ?? 0;
                        $currency = $row['currency'] ?? '';
                        $viewUrl = fk_url('invoice.php?id=' . urlencode($row['id'] ?? ''));
                        $isDemo = !empty($row['is_demo']);
                        $countryId = strtolower($row['country_id'] ?? '');
                        $country = null;
                        foreach ($countries as $c) {
                            if (($c['id'] ?? '') === $countryId) {
                                $country = $c;
                                break;
                            }
                        }
                        $countryName = $country ? fk_localized($country, 'name', $lang) : strtoupper($countryId);
                        $flag = $countryFlags[$countryId] ?? '🌐';
                        $designId = $row['print_design'] ?? ($settings['print_design'] ?? 'classic-blue');
                        $design = $designs[$designId] ?? $designs['classic-blue'];
                        $designName = fk_localized($design, 'name', $lang);
                        $accent = $design['accent'] ?? '#1e40af';
                        $searchBlob = strtolower(implode(' ', [$row['invoice_no'] ?? '', $buyerName, $currency, (string) $total, $countryName, $designName]));
                    ?>
                    <tr class="adm-doc-row" data-demo="<?= $isDemo ? '1' : '0' ?>" data-search="<?= fk_h($searchBlob) ?>">
                        <td><strong><?= fk_h($row['invoice_no'] ?? '') ?></strong></td>
                        <td><?= fk_h($row['invoice_date'] ?? '') ?></td>
                        <td><?= fk_h($buyerName) ?></td>
                        <td><span class="adm-doc-tag adm-doc-tag--inline"><span aria-hidden="true"><?= $flag ?></span> <?= fk_h($countryName) ?></span></td>
                        <td><strong><?= fk_h(fk_money((float) $total, $currency)) ?></strong></td>
                        <td><span class="adm-design-dot" style="background:<?= fk_h($accent) ?>"></span> <?= fk_h($designName) ?></td>
                        <td>
                            <?php if ($isDemo): ?>
                            <span class="adm-badge-demo"><i class="fas fa-home" aria-hidden="true"></i></span>
                            <?php else: ?>
                            <span class="adm-muted-dash">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="adm-actions-row adm-actions-row--tight">
                                <a href="<?= fk_h($viewUrl) ?>" class="adm-icon-btn adm-icon-btn--sm" target="_blank" rel="noopener" title="<?= fk_h($ta['view'] ?? 'View') ?>"><i class="fas fa-eye" aria-hidden="true"></i></a>
                                <a href="<?= fk_h(fk_admin_url('send-mail.php?invoice_id=' . urlencode($row['id'] ?? ''))) ?>" class="adm-icon-btn adm-icon-btn--sm" title="<?= fk_h($ta['send_email'] ?? 'Send') ?>"><i class="fas fa-paper-plane" aria-hidden="true"></i></a>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="toggle_demo_id" value="<?= fk_h($row['id'] ?? '') ?>">
                                    <button type="submit" class="adm-icon-btn adm-icon-btn--sm" title="<?= fk_h($isDemo ? ($ta['demo_off'] ?? 'Remove') : ($ta['demo_on'] ?? 'Add')) ?>"><i class="fas <?= $isDemo ? 'fa-eye-slash' : 'fa-home' ?>" aria-hidden="true"></i></button>
                                </form>
                                <form method="post" style="display:inline" onsubmit="return confirm('<?= fk_h($ta['delete_confirm'] ?? 'Delete?') ?>');">
                                    <input type="hidden" name="delete_id" value="<?= fk_h($row['id'] ?? '') ?>">
                                    <button type="submit" class="adm-icon-btn adm-icon-btn--sm adm-icon-btn--danger" title="<?= fk_h($ta['delete'] ?? 'Delete') ?>"><i class="fas fa-trash" aria-hidden="true"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/layout-end.php'; ?>