<?php
return [
    [
        'id' => 'tpl-consulting-no',
        'country_id' => 'no',
        'active' => true,
        'name' => [
            'en' => 'Consulting — Norway', 'uk' => 'Консалтинг — Норвегія', 'lt' => 'Konsultacijos — Norvegija',
            'pl' => 'Konsulting — Norwegia', 'de' => 'Beratung — Norwegen', 'sv' => 'Konsultation — Norge', 'no' => 'Konsultasjon — Norge',
        ],
        'lines' => [
            ['desc' => ['en' => 'Business consulting (hour)', 'uk' => 'Бізнес-консалтинг (год)', 'lt' => 'Verslo konsultacija (val.)', 'pl' => 'Konsulting biznesowy (godz.)', 'de' => 'Unternehmensberatung (Std.)', 'sv' => 'Affärskonsultation (tim)', 'no' => 'Forretningsrådgivning (time)'], 'qty' => 8, 'unit' => 'h', 'price' => 1450],
            ['desc' => ['en' => 'Project management', 'uk' => 'Управління проєктом', 'lt' => 'Projekto valdymas', 'pl' => 'Zarządzanie projektem', 'de' => 'Projektmanagement', 'sv' => 'Projektledning', 'no' => 'Prosjektledelse'], 'qty' => 1, 'unit' => 'pcs', 'price' => 12000],
        ],
    ],
    [
        'id' => 'tpl-web-lt',
        'country_id' => 'lt',
        'active' => true,
        'name' => [
            'en' => 'Web development — Lithuania', 'uk' => 'Веб-розробка — Литва', 'lt' => 'Interneto svetainės — Lietuva',
            'pl' => 'Tworzenie stron — Litwa', 'de' => 'Webentwicklung — Litauen', 'sv' => 'Webbutveckling — Litauen', 'no' => 'Webutvikling — Litauen',
        ],
        'lines' => [
            ['desc' => ['en' => 'PHP CMS development', 'uk' => 'Розробка PHP CMS', 'lt' => 'PHP CMS kūrimas', 'pl' => 'Rozwój PHP CMS', 'de' => 'PHP-CMS-Entwicklung', 'sv' => 'PHP CMS-utveckling', 'no' => 'PHP CMS-utvikling'], 'qty' => 40, 'unit' => 'h', 'price' => 65],
            ['desc' => ['en' => 'SEO setup', 'uk' => 'Налаштування SEO', 'lt' => 'SEO konfigūracija', 'pl' => 'Konfiguracja SEO', 'de' => 'SEO-Einrichtung', 'sv' => 'SEO-konfiguration', 'no' => 'SEO-oppsett'], 'qty' => 1, 'unit' => 'pcs', 'price' => 890],
        ],
    ],
    [
        'id' => 'tpl-products-de',
        'country_id' => 'de',
        'active' => true,
        'name' => [
            'en' => 'Product sale — Germany', 'uk' => 'Продаж товарів — Німеччина', 'lt' => 'Prekių pardavimas — Vokietija',
            'pl' => 'Sprzedaż produktów — Niemcy', 'de' => 'Warenverkauf — Deutschland', 'sv' => 'Produktförsäljning — Tyskland', 'no' => 'Produktsalg — Tyskland',
        ],
        'lines' => [
            ['desc' => ['en' => 'Software licence (annual)', 'uk' => 'Ліцензія ПЗ (річна)', 'lt' => 'Programinės įrangos licencija (metinė)', 'pl' => 'Licencja oprogramowania (roczna)', 'de' => 'Softwarelizenz (jährlich)', 'sv' => 'Programvarulicens (årlig)', 'no' => 'Programvarelisens (årlig)'], 'qty' => 1, 'unit' => 'pcs', 'price' => 2490],
            ['desc' => ['en' => 'Support package', 'uk' => 'Пакет підтримки', 'lt' => 'Palaikymo paketas', 'pl' => 'Pakiet wsparcia', 'de' => 'Support-Paket', 'sv' => 'Supportpaket', 'no' => 'Støttepakke'], 'qty' => 1, 'unit' => 'pcs', 'price' => 590],
        ],
    ],
    [
        'id' => 'tpl-services-pl',
        'country_id' => 'pl',
        'active' => true,
        'name' => [
            'en' => 'IT services — Poland', 'uk' => 'IT-послуги — Польща', 'lt' => 'IT paslaugos — Lenkija',
            'pl' => 'Usługi IT — Polska', 'de' => 'IT-Dienstleistungen — Polen', 'sv' => 'IT-tjänster — Polen', 'no' => 'IT-tjenester — Polen',
        ],
        'lines' => [
            ['desc' => ['en' => 'Server maintenance (month)', 'uk' => 'Обслуговування сервера (міс.)', 'lt' => 'Serverio priežiūra (mėn.)', 'pl' => 'Utrzymanie serwera (mies.)', 'de' => 'Serverwartung (Monat)', 'sv' => 'Serverunderhåll (mån)', 'no' => 'Servervedlikehold (mnd)'], 'qty' => 1, 'unit' => 'pcs', 'price' => 1800],
            ['desc' => ['en' => 'Security audit', 'uk' => 'Аудит безпеки', 'lt' => 'Saugumo auditas', 'pl' => 'Audyt bezpieczeństwa', 'de' => 'Sicherheitsaudit', 'sv' => 'Säkerhetsgranskning', 'no' => 'Sikkerhetsrevisjon'], 'qty' => 1, 'unit' => 'pcs', 'price' => 4500],
        ],
    ],
    [
        'id' => 'tpl-freelance-sv',
        'country_id' => 'sv',
        'active' => true,
        'name' => [
            'en' => 'Freelance design — Sweden', 'uk' => 'Фріланс-дизайн — Швеція', 'lt' => 'Laisvai samdomas dizainas — Švedija',
            'pl' => 'Freelance design — Szwecja', 'de' => 'Freelance-Design — Schweden', 'sv' => 'Frilansdesign — Sverige', 'no' => 'Frilansdesign — Sverige',
        ],
        'lines' => [
            ['desc' => ['en' => 'UI/UX design', 'uk' => 'UI/UX дизайн', 'lt' => 'UI/UX dizainas', 'pl' => 'Projekt UI/UX', 'de' => 'UI/UX-Design', 'sv' => 'UI/UX-design', 'no' => 'UI/UX-design'], 'qty' => 24, 'unit' => 'h', 'price' => 950],
        ],
    ],
    [
        'id' => 'tpl-it-ua',
        'country_id' => 'uk',
        'active' => true,
        'name' => [
            'en' => 'IT services — Ukraine', 'uk' => 'IT-послуги — Україна', 'lt' => 'IT paslaugos — Ukraina',
            'pl' => 'Usługi IT — Ukraina', 'de' => 'IT-Dienstleistungen — Ukraine', 'sv' => 'IT-tjänster — Ukraina', 'no' => 'IT-tjenester — Ukraina',
        ],
        'lines' => [
            ['desc' => ['en' => 'Website development', 'uk' => 'Розробка веб-сайту', 'lt' => 'Svetainės kūrimas', 'pl' => 'Tworzenie strony www', 'de' => 'Website-Entwicklung', 'sv' => 'Webbplatsutveckling', 'no' => 'Nettstedutvikling'], 'qty' => 1, 'unit' => 'pcs', 'price' => 45000],
            ['desc' => ['en' => 'AI chat integration', 'uk' => 'Інтеграція AI-чату', 'lt' => 'AI pokalbių integracija', 'pl' => 'Integracja czatu AI', 'de' => 'KI-Chat-Integration', 'sv' => 'AI-chattintegration', 'no' => 'AI-chat integrasjon'], 'qty' => 1, 'unit' => 'pcs', 'price' => 12000],
        ],
    ],
    [
        'id' => 'tpl-cleaning-lt',
        'country_id' => 'lt',
        'active' => true,
        'name' => [
            'en' => 'Cleaning services — Lithuania (wireframe)', 'uk' => 'Клінінг — Литва (макет)', 'lt' => 'Valymo paslaugos — Lietuva',
            'pl' => 'Usługi sprzątania — Litwa', 'de' => 'Reinigung — Litauen', 'sv' => 'Städning — Litauen', 'no' => 'Rengjøring — Litauen',
        ],
        'lines' => [
            ['desc' => ['en' => 'Office cleaning', 'uk' => 'Офісне прибирання', 'lt' => 'Valymo paslaugos biure'], 'qty' => 1, 'unit' => 'pcs', 'price' => 120],
            ['desc' => ['en' => 'Post-renovation cleaning', 'uk' => 'Післяремонтне прибирання', 'lt' => 'Valymas po remonto'], 'qty' => 1, 'unit' => 'pcs', 'price' => 250],
            ['desc' => ['en' => 'Common areas cleaning', 'uk' => 'Місця загального користування', 'lt' => 'Bendro naudojimo patalpų valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 95],
            ['desc' => ['en' => 'Window cleaning', 'uk' => 'Миття вікон', 'lt' => 'Langų valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 85],
            ['desc' => ['en' => 'Carpet & upholstery', 'uk' => 'Чищення килимів та меблів', 'lt' => 'Kilimų ir minkštų baldų valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 150],
            ['desc' => ['en' => 'Kitchen cleaning', 'uk' => 'Прибирання кухні', 'lt' => 'Virtuvės valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 110],
            ['desc' => ['en' => 'Sanitary cleaning', 'uk' => 'Санвузли', 'lt' => 'Sanitarinių patalpų valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 90],
            ['desc' => ['en' => 'Outdoor area cleaning', 'uk' => 'Прибирання території', 'lt' => 'Teritorijos valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 130],
            ['desc' => ['en' => 'Deep cleaning', 'uk' => 'Генеральне прибирання', 'lt' => 'Generalinis valymas'], 'qty' => 1, 'unit' => 'pcs', 'price' => 180],
        ],
    ],
    [
        'id' => 'tpl-intl-en',
        'country_id' => 'en',
        'active' => true,
        'name' => [
            'en' => 'International services — UK', 'uk' => 'Міжнародні послуги — UK', 'lt' => 'Tarptautinės paslaugos — JK',
            'pl' => 'Usługi międzynarodowe — UK', 'de' => 'Internationale Dienstleistungen — UK', 'sv' => 'Internationella tjänster — UK', 'no' => 'Internasjonale tjenester — UK',
        ],
        'lines' => [
            ['desc' => ['en' => 'SaaS subscription (month)', 'uk' => 'SaaS підписка (міс.)', 'lt' => 'SaaS prenumerata (mėn.)', 'pl' => 'Subskrypcja SaaS (mies.)', 'de' => 'SaaS-Abonnement (Monat)', 'sv' => 'SaaS-prenumeration (mån)', 'no' => 'SaaS-abonnement (mnd)'], 'qty' => 1, 'unit' => 'pcs', 'price' => 199],
            ['desc' => ['en' => 'Onboarding & training', 'uk' => 'Онбординг та навчання', 'lt' => 'Įvedimas ir mokymai', 'pl' => 'Wdrożenie i szkolenie', 'de' => 'Onboarding & Schulung', 'sv' => 'Onboarding & utbildning', 'no' => 'Onboarding og opplæring'], 'qty' => 4, 'unit' => 'h', 'price' => 85],
        ],
    ],
];