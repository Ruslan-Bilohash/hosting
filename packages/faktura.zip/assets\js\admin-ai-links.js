(function () {
    'use strict';

    function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text);
        }
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'absolute';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try {
            document.execCommand('copy');
        } finally {
            document.body.removeChild(ta);
        }
        return Promise.resolve();
    }

    function flashBtn(btn) {
        var icon = btn.querySelector('i');
        if (!icon) return;
        var prev = icon.className;
        icon.className = 'fas fa-check';
        btn.classList.add('adm-btn--copied');
        setTimeout(function () {
            icon.className = prev;
            btn.classList.remove('adm-btn--copied');
        }, 1400);
    }

    document.querySelectorAll('.fk-copy-ai-link').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var url = btn.getAttribute('data-copy') || '';
            if (!url) return;
            copyText(url).then(function () { flashBtn(btn); });
        });
    });

    var copyAll = document.getElementById('fk-copy-all-ai-links');
    if (copyAll) {
        copyAll.addEventListener('click', function () {
            var lines = [];
            document.querySelectorAll('.adm-ai-link-input').forEach(function (inp) {
                if (inp.value) lines.push(inp.value);
            });
            if (lines.length === 0) return;
            copyText(lines.join('\n')).then(function () { flashBtn(copyAll); });
        });
    }
})();