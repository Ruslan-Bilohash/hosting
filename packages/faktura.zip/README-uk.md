# Faktura Creator

**PHP-адмінпанель для бухгалтерів і власників бізнесу** — клієнти, ПДВ/MVA для 7 країн, шаблони рахунків, SMTP, AI-нотатки, QR-оплата та підтримка екосистеми BILOHASH. Портфоліо-проєкт [Ruslan Bilohash](https://bilohash.com/).

**Версія (цей repo):** 1.0.0 · **Мови readme:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-з%20коробки-purple)

---

## Важливо — лише демо-репозиторій

> **На GitHub завантажено лише демо / портфоліо-приклад Faktura Creator.**
> Це **не** повна комерційна версія і **не** обовʼязково останній реліз.
>
> **Останню повну версію**, оновлення та комерційну підтримку можна **придбати у автора**:
> - Живе демо: https://bilohash.com/faktura/
> - 30-денне самовстановлення: https://bilohash.com/faktura/demo-install.php
> - Підписка: https://bilohash.com/ecosystem/join.php
> - Контакт: **rbilohash@gmail.com**

**Комерційне використання без письмової згоди автора заборонено.** Див. [LICENSE](LICENSE).

---

## Живе демо

| Ресурс | URL |
|--------|-----|
| **Головна** | https://bilohash.com/faktura/ |
| **Створити рахунок** | https://bilohash.com/faktura/create.php |
| **Калькулятор послуг** | https://bilohash.com/faktura/calc.php |
| **Адмін-панель** | https://bilohash.com/faktura/admin/ |
| **Довідка та відео** | https://bilohash.com/faktura/help.php |
| **Завантаження демо 30 днів** | https://bilohash.com/faktura/demo-install.php |
| **Кабінет BILOHASH** | https://bilohash.com/ecosystem/cabinet.php |

**Вхід в адмінку (демо):** `demo` / `bilofaktura2026`

---

## AI з коробки

Faktura Creator має **вбудовану AI-допомогу** (OpenAI / xAI Grok — API-ключ у адмінці):

| Область | Що робить AI |
|---------|----------------|
| **Нотатки email** | Особиста нотатка при надсиланні рахунків клієнтам |
| **Тема листа** | Стислі теми для invoice email |
| **Нотатки рахунку** | Умови оплати та текст про банківський переказ |
| **Підтримка** | Чернетки звернень у екосистему та листів клієнтам |

У демо-режимі **без API-ключа** — багатомовні шаблони для ознайомлення.

---

## Можливості

### Публічний фронтенд
- Мобільний конструктор рахунків з пресетами ПДВ/MVA за країною
- **7 ринків:** UK, Норвегія, Литва, Польща, Німеччина, Швеція, Україна
- **12 макетів друку** — A4, Letter, Legal; перегляд і друк/PDF у браузері
- Калькулятор послуг з пресетами (клінінг, консалтинг тощо)
- Збереження рахунків і розрахунків; посилання на перегляд
- QR на рахунках — шаблон URL оплати або своє посилання
- Демо-рахунки на головній для кожної країни
- Довідка зі скриншотами та відео-секцією
- Мови: **EN, UA, LT, PL, DE, SV, NO** (`?lang=` + cookie)
- Контакт і смуга екосистеми BILOHASH

### Адмін-панель
- **Dashboard** — клієнти, рахунки, демо на головній, таблиця ПДВ
- **Клієнти** — база для рахунків у 2 кліки
- **Рахунки** — пошук, друк, email, демо на головній
- **Розрахунки** — збережені кошториси послуг
- **Пресети калькулятора** — шаблони та URL оплати
- **Надіслати email** — SMTP з AI-нотатками
- **Налаштування** — компанія, нумерація, QR
- **Країни та податки** — ПДВ / єдина ставка
- **Шаблони** — типові позиції рядків
- **SMTP** — хост, порт, TLS (демо пише в `email-log.json`)
- **AI** — провайдер, модель, промпти, реферальні посилання
- **Підтримка та листи** — inbox BILOHASH, чат з власником, чернетки клієнтам
- Багатомовна адмінка

### Екосистема BILOHASH
- **ZIP на 30 днів** — завантаження з кабінету після підписки
- **Листування з підтримкою** — розмови з BILOHASH з адмінки
- **Підписка** — 49 kr/міс (1 CMS) або 249 kr/міс (усі скрипти на 1 домені)

---

## Стек

- PHP 8+ (без фреймворків)
- JSON (`data/*.json`, PHP-seed у `data/`)
- i18n (`lang/*.php` — overlay для `uk`, `no`)
- Apache `.htaccess`, canonical, hreflang
- Font Awesome 6, vanilla CSS/JS
- OpenAI-сумісний API (OpenAI, xAI Grok)

---

## Вимоги

- PHP 8.0+
- Apache з `mod_rewrite` (або nginx-аналог)
- Запис у каталог `data/`
- SMTP (опційно — демо логує email локально)

---

## Встановлення

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Скопіюйте `faktura/` у web root (наприклад `/faktura/`).
2. Права на запис для `data/`:
   ```bash
   chmod 755 data
   ```
3. Відкрийте `https://ваш-домен/faktura/` — демо-дані з seed.
4. Адмінка: `https://ваш-домен/faktura/admin/` — змініть логін перед продакшеном.

### Самовстановлення (30 днів)

1. Оформіть підписку на https://bilohash.com/ecosystem/join.php
2. Увійдіть у [кабінет](https://bilohash.com/ecosystem/cabinet.php) і завантажте demo ZIP
3. Завантажте на хостинг (наприклад `/public_html/faktura/`)
4. Інструкція: https://bilohash.com/faktura/demo-install.php

### Локальний сервер

```bash
cd faktura
php -S localhost:8080
```

### Конфігурація (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
```

---

## Структура проєкту

```
faktura/
├── index.php              # Головна — демо за країнами
├── create.php             # Створення рахунку
├── calc.php               # Калькулятор послуг
├── invoice.php            # Перегляд / друк
├── help.php / contact.php
├── demo-install.php       # Завантаження пакета 30 днів
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Адмінка + support API
├── api/                   # save invoice, AI (публічні)
└── LICENSE
```

---

## Демо-режим

- Демо-логін на сторінці входу
- SMTP вимкнено — листи в `data/email-log.json`
- AI без ключа — локальні шаблони
- Зразкові рахунки на головній

### Збірка demo-пакета

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

### Перевірка перекладів

```bash
node scripts/check-lang-keys.mjs
```

---

## Автор і комерційна ліцензія

**Ruslan Bilohash**
- Сайт: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- Email: rbilohash@gmail.com

Для **комерційної ліцензії**, повного коду або **останньої версії** — звертайтесь до автора. [LICENSE](LICENSE).