(function () {
    'use strict';

    const wrap = document.getElementById('adm-preset-services');
    const addBtn = document.getElementById('adm-svc-add');
    if (!wrap || !addBtn) return;

    function nextIndex() {
        return wrap.querySelectorAll('.adm-preset-service-row').length;
    }

    function bindRemove(row) {
        row.querySelector('.adm-svc-remove')?.addEventListener('click', () => {
            if (wrap.querySelectorAll('.adm-preset-service-row').length <= 1) {
                row.querySelectorAll('input').forEach((inp) => { inp.value = inp.type === 'number' ? '0' : ''; });
                return;
            }
            row.remove();
        });
    }

    wrap.querySelectorAll('.adm-preset-service-row').forEach(bindRemove);

    addBtn.addEventListener('click', () => {
        const i = nextIndex();
        const row = document.createElement('div');
        row.className = 'adm-preset-service-row';
        row.innerHTML = `
            <input type="text" name="services[${i}][name]" placeholder="Service name">
            <input type="number" name="services[${i}][qty]" value="1" min="0.01" step="0.01">
            <input type="number" name="services[${i}][price]" value="0" min="0" step="0.01">
            <button type="button" class="adm-btn adm-btn-danger adm-btn-sm adm-svc-remove" aria-label="Remove"><i class="fas fa-trash"></i></button>
        `;
        wrap.appendChild(row);
        bindRemove(row);
        row.querySelector('input')?.focus();
    });
})();