# Faktura Creator

**Panel administracyjny PHP dla księgowych i właścicieli firm** — klienci, VAT dla 7 krajów, szablony faktur, SMTP, notatki AI, płatności QR i wsparcie ekosystemu BILOHASH. Projekt portfolio — [Ruslan Bilohash](https://bilohash.com/).

**Wersja (to repo):** 1.0.0 · **Języki readme:** [English](README.md) · [Norsk](README-no.md) · [Svenska](README-sv.md) · [Lietuvių](README-lt.md) · [Polski](README-pl.md) · [Deutsch](README-de.md) · [Українська](README-uk.md)

![PHP](https://img.shields.io/badge/PHP-8%2B-777BB4?logo=php&logoColor=white)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![i18n](https://img.shields.io/badge/languages-EN%20%7C%20UA%20%7C%20LT%20%7C%20PL%20%7C%20DE%20%7C%20SV%20%7C%20NO-green)
![AI](https://img.shields.io/badge/AI-wbudowane-purple)

---

## Ważne — tylko repozytorium demo

> **To repozytorium GitHub zawiera demo / przykład portfolio Faktura Creator.**
> **Nie** jest to pełny produkt komercyjny i **nie** musi być najnowszą wersją.
>
> **Najnowsza pełna wersja**, aktualizacje i wsparcie komercyjne są dostępne **tylko u autora**:
> - Demo na żywo: https://bilohash.com/faktura/
> - Samodzielna instalacja 30 dni: https://bilohash.com/faktura/demo-install.php
> - Subskrypcja: https://bilohash.com/ecosystem/join.php
> - Kontakt: **rbilohash@gmail.com**

**Użycie komercyjne bez pisemnej zgody autora jest zabronione.** Zob. [LICENSE](LICENSE).

---

## Demo na żywo

| Zasób | URL |
|-------|-----|
| **Strona główna** | https://bilohash.com/faktura/ |
| **Utwórz fakturę** | https://bilohash.com/faktura/create.php |
| **Kalkulator usług** | https://bilohash.com/faktura/calc.php |
| **Panel admin** | https://bilohash.com/faktura/admin/ |
| **Pomoc i wideo** | https://bilohash.com/faktura/help.php |
| **Pobranie demo 30 dni** | https://bilohash.com/faktura/demo-install.php |
| **Panel klienta BILOHASH** | https://bilohash.com/ecosystem/cabinet.php |

**Logowanie admin (demo):** `demo` / `bilofaktura2026`

---

## AI od razu po instalacji

Faktura Creator ma **wbudowaną pomoc AI** (OpenAI / xAI Grok — klucz API w panelu admin):

| Obszar | Co robi AI |
|--------|------------|
| **Notatki e-mail** | Osobista notatka przy wysyłce faktur |
| **Temat e-mail** | Zwięzłe tematy wiadomości z fakturą |
| **Notatki faktury** | Warunki płatności i tekst przelewu |
| **Wsparcie** | Szkice zgłoszeń do ekosystemu i maili do klientów |

Tryb demo działa **bez klucza API** — wielojęzyczne szablony.

---

## Funkcje

### Frontend publiczny
- Tworzenie faktur mobile-first z presetami VAT wg kraju
- **7 rynków:** UK, Norwegia, Litwa, Polska, Niemcy, Szwecja, Ukraina
- **12 layoutów druku** — A4, Letter, Legal; podgląd i druk/PDF
- Kalkulator usług z presetami
- Zapisane faktury i kalkulacje; linki do udostępnienia
- QR na fakturach — szablon URL płatności lub własny link
- Demo faktur na stronie głównej dla każdego kraju
- Strona pomocy ze zrzutami ekranu i wideo
- Języki: **EN, UA, LT, PL, DE, SV, NO** (`?lang=` + cookie)
- Kontakt i pasek ekosystemu BILOHASH

### Panel administracyjny
- **Dashboard** — klienci, faktury, demo na stronie głównej, tabela VAT
- **Klienci** — baza do faktury w 2 kliknięcia
- **Faktury** — wyszukiwanie, druk, e-mail, demo na stronie głównej
- **Kalkulacje** — zapisane wyceny usług
- **Presety usług** — szablony kalkulatora i URL płatności
- **Wyślij e-mail** — SMTP z notatkami AI
- **Ustawienia** — firma, numeracja, QR
- **Kraje i podatki** — VAT / stawka jednolita
- **Szablony** — domyślne pozycje
- **SMTP** — host, port, TLS (demo zapisuje do `email-log.json`)
- **AI** — dostawca, model, prompty, linki referral
- **Wsparcie i poczta** — skrzynka BILOHASH, czat z właścicielem, szkice do klientów
- Wielojęzyczny admin

### Ekosystem BILOHASH
- **ZIP 30 dni** — pobranie z panelu klienta po subskrypcji
- **Wiadomości wsparcia** — wątki z BILOHASH z admina
- **Subskrypcja** — 49 kr/mies. (1 CMS) lub 249 kr/mies. (wszystkie skrypty na 1 domenie)

---

## Stos technologiczny

- PHP 8+ (bez frameworka)
- Magazyn JSON (`data/*.json`)
- Modułowy i18n (`lang/*.php`)
- Apache `.htaccess`, kanoniczne URL, hreflang
- Font Awesome 6, vanilla CSS i JS
- API zgodne z OpenAI (OpenAI, xAI Grok)

---

## Wymagania

- PHP 8.0 lub nowsze
- Apache z `mod_rewrite`
- Zapisywalny katalog `data/`
- SMTP (opcjonalnie — demo loguje e-mail lokalnie)

---

## Instalacja

```bash
git clone https://github.com/Ruslan-Bilohash/faktura.git faktura
```

1. Skopiuj `faktura/` do web root (np. `/faktura/`).
2. Uprawnienia zapisu dla `data/`:
   ```bash
   chmod 755 data
   ```
3. Otwórz `https://twoja-domena.pl/faktura/`.
4. Admin: `https://twoja-domena.pl/faktura/admin/` — zmień dane logowania przed produkcją.

### Samodzielna instalacja (30 dni)

1. Subskrybuj https://bilohash.com/ecosystem/join.php
2. Zaloguj się do [panelu klienta](https://bilohash.com/ecosystem/cabinet.php) i pobierz demo ZIP
3. Wgraj na hosting
4. Instrukcja: https://bilohash.com/faktura/demo-install.php

### Lokalny serwer PHP

```bash
cd faktura
php -S localhost:8080
```

### Konfiguracja (`config.php`)

```php
define('FK_BASE_PATH', '/faktura');
define('FK_SITE_NAME', 'Faktura Creator');
define('FK_DEMO_MODE', true);
```

---

## Struktura projektu

```
faktura/
├── index.php              # Strona główna — demo wg krajów
├── create.php             # Tworzenie faktury
├── calc.php               # Kalkulator usług
├── invoice.php            # Podgląd / druk
├── help.php / contact.php
├── demo-install.php       # Pakiet 30 dni
├── lang/                  # EN, UA, LT, PL, DE, SV, NO
├── includes/              # Header, storage, mailer, AI, QR
├── data/                  # settings, clients, invoices (JSON)
├── admin/                 # Admin + support API
├── api/                   # zapis faktury, AI (publiczne)
└── LICENSE
```

---

## Tryb demo

- Dane demo na stronie logowania
- SMTP wyłączone — maile w `data/email-log.json`
- AI bez klucza — lokalne szablony
- Przykładowe faktury na stronie głównej

### Budowa pakietu demo

```powershell
powershell -NoProfile -File scripts/pack-demo.ps1
```

### Sprawdzenie tłumaczeń

```bash
node scripts/check-lang-keys.mjs
```

---

## Autor i licencja komercyjna

**Ruslan Bilohash**
- Strona: https://bilohash.com/
- GitHub: https://github.com/Ruslan-Bilohash/
- E-mail: rbilohash@gmail.com

W sprawie **licencji komercyjnej**, pełnego kodu lub **najnowszej wersji produkcyjnej** skontaktuj się z autorem. Zob. [LICENSE](LICENSE).