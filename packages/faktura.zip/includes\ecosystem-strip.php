<?php
if (empty($t['ecosystem']['items'])) {
    return;
}
$eco = $t['ecosystem'];
?>
<section class="fk-ecosystem" id="ecosystem">
    <div class="fk-ecosystem-inner">
        <div class="fk-ecosystem-head">
            <h2><?= fk_h($eco['title']) ?></h2>
            <p><?= fk_h($eco['subtitle']) ?></p>
        </div>
        <div class="fk-ecosystem-grid">
            <?php foreach ($eco['items'] as $item): ?>
            <article class="fk-ecosystem-card">
                <div class="fk-ecosystem-icon" aria-hidden="true">
                    <?php if (($item['icon'] ?? '') === 'wordpress'): ?>
                    <i class="fab fa-wordpress"></i>
                    <?php else: ?>
                    <i class="fas fa-<?= fk_h($item['icon']) ?>"></i>
                    <?php endif; ?>
                </div>
                <h3><?= fk_h($item['name']) ?></h3>
                <p><?= fk_h($item['desc']) ?></p>
                <div class="fk-ecosystem-links">
                    <a href="<?= fk_h($item['url']) ?>" class="fk-btn fk-btn-outline fk-btn-sm" rel="related"><?= fk_h($eco['product_btn']) ?></a>
                    <a href="<?= fk_h($item['demo']) ?>" class="fk-btn fk-btn-primary fk-btn-sm" rel="related"><?= fk_h($eco['demo_btn']) ?></a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        <p class="fk-ecosystem-join">
            <a href="https://bilohash.com/ecosystem/join.php"><?= fk_h($eco['strip_label'] ?? 'BILOHASH ecosystem') ?> →</a>
        </p>
    </div>
</section>