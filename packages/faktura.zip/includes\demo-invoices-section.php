<?php
/** @var array $demoInvoices @var array $h @var array $t @var string $lang */
?>
<section class="fk-home-section" id="demo-invoices">
    <h2><?= fk_h($h['demo_title'] ?? 'Demo invoices') ?></h2>
    <p class="fk-home-text"><?= fk_h($h['demo_text'] ?? '') ?></p>
    <?php if (empty($demoInvoices)): ?>
    <div class="fk-card">
        <p class="fk-home-empty"><?= fk_h($h['demo_empty'] ?? 'No demo invoices yet. Mark invoices as demo in Admin → Saved invoices.') ?></p>
        <a href="<?= fk_h(fk_admin_url('invoices.php')) ?>" class="fk-btn fk-btn-ghost fk-btn-sm"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?> →</a>
    </div>
    <?php else:
        $demoShots = fk_demo_shots_map();
        $firstDemo = $demoInvoices[0];
        $firstId = $firstDemo['id'] ?? '';
        $firstView = fk_url('invoice.php?id=' . urlencode($firstId));
    ?>
    <div class="fk-demo-picker">
        <label class="fk-field-label" for="fk-demo-select"><?= fk_h($h['demo_select'] ?? 'Choose demo invoice') ?></label>
        <select id="fk-demo-select" class="fk-select fk-demo-select">
            <?php foreach ($demoInvoices as $i => $demo):
                $label = fk_demo_invoice_label($demo, $lang);
                $total = (float) ($demo['totals']['total'] ?? 0);
                $currency = $demo['currency'] ?? '';
                $design = fk_normalize_print_design($demo['print_design'] ?? 'classic-blue');
                $demoId = $demo['id'] ?? '';
                $shot = $demoShots[$demoId] ?? '';
            ?>
            <option value="<?= fk_h($demoId) ?>"
                    data-view="<?= fk_h(fk_url('invoice.php?id=' . urlencode($demoId))) ?>"
                    data-shot="<?= fk_h($shot ? fk_asset('images/demo/' . $shot) : '') ?>"
                    data-label="<?= fk_h($label) ?>"
                    data-meta="<?= fk_h(fk_money($total, $currency) . ' · ' . fk_print_design_name($design, $lang)) ?>"
                    <?= $i === 0 ? 'selected' : '' ?>>
                <?= fk_h(($demo['invoice_no'] ?? '') . ' — ' . $label) ?>
            </option>
            <?php endforeach; ?>
        </select>

        <div class="fk-demo-preview-wrap">
            <div class="fk-demo-preview-shot">
                <?php
                $firstShot = $demoShots[$firstId] ?? '';
                if ($firstShot):
                ?>
                <img id="fk-demo-shot" src="<?= fk_h(fk_asset('images/demo/' . $firstShot)) ?>" alt="<?= fk_h(fk_demo_invoice_label($firstDemo, $lang)) ?>" width="400" height="520" loading="eager">
                <?php endif; ?>
            </div>
            <div class="fk-demo-preview-panel">
                <p class="fk-demo-preview-meta" id="fk-demo-meta"><?= fk_h(fk_money((float)($firstDemo['totals']['total'] ?? 0), $firstDemo['currency'] ?? '') . ' · ' . fk_print_design_name(fk_normalize_print_design($firstDemo['print_design'] ?? 'classic-blue'), $lang)) ?></p>
                <div class="fk-demo-preview-actions">
                    <a href="<?= fk_h($firstView) ?>" id="fk-demo-view" class="fk-btn fk-btn-primary"><i class="fas fa-eye"></i> <?= fk_h($h['demo_view'] ?? 'View & print') ?></a>
                    <a href="<?= fk_h(fk_url('help.php#video')) ?>" class="fk-btn fk-btn-ghost"><i class="fas fa-play-circle"></i> <?= fk_h($h['demo_video'] ?? 'Video guide') ?></a>
                </div>
                <p class="fk-demo-preview-hint"><?= fk_h($h['demo_hint'] ?? 'Screenshots of real print layouts — open full invoice for PDF print and QR.') ?></p>
            </div>
        </div>

        <div class="fk-demo-thumb-row" role="list" aria-label="<?= fk_h($h['demo_title'] ?? 'Demo invoices') ?>">
            <?php foreach ($demoInvoices as $demo):
                $demoId = $demo['id'] ?? '';
                $shot = $demoShots[$demoId] ?? '';
                if (!$shot) continue;
            ?>
            <button type="button" class="fk-demo-thumb" role="listitem" data-demo-id="<?= fk_h($demoId) ?>" title="<?= fk_h(fk_demo_invoice_label($demo, $lang)) ?>">
                <img src="<?= fk_h(fk_asset('images/demo/' . $shot)) ?>" alt="" width="80" height="104" loading="lazy">
            </button>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</section>