<?php
return [
    [
        'id' => 'cli-nordic-office',
        'name' => 'Nordic Office Park AS',
        'email' => 'regnskap@nordicoffice.example',
        'org_nr' => '912 345 678',
        'vat_nr' => '',
        'address' => 'Dronning Eufemias gate 8',
        'city' => 'Oslo',
        'postal' => '0191',
        'country' => 'Norway',
        'phone' => '+47 22 00 00 00',
        'notes' => 'Monthly cleaning contract',
    ],
    [
        'id' => 'cli-techstart',
        'name' => 'TechStart Ltd',
        'email' => 'billing@techstart.example',
        'org_nr' => '12345678',
        'vat_nr' => 'GB999888777',
        'address' => '45 Silicon Roundabout',
        'city' => 'London',
        'postal' => 'EC2A 3LT',
        'country' => 'United Kingdom',
        'phone' => '+44 20 7946 0000',
        'notes' => 'IT consulting',
    ],
];