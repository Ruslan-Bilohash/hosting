(function () {
    'use strict';

    var search = document.getElementById('adm-clients-search');
    var resultEl = document.getElementById('adm-clients-result');
    if (!search) return;

    var rows = Array.prototype.slice.call(document.querySelectorAll('.adm-client-row'));
    var cards = Array.prototype.slice.call(document.querySelectorAll('.adm-client-card'));
    var total = rows.length || cards.length;

    function matchItem(el) {
        var q = search.value.trim().toLowerCase();
        if (q === '') return true;
        return (el.getAttribute('data-search') || '').indexOf(q) !== -1;
    }

    function applyFilters() {
        var visible = 0;
        rows.forEach(function (row) {
            var show = matchItem(row);
            row.hidden = !show;
            if (show) visible++;
        });
        cards.forEach(function (card) {
            var show = matchItem(card);
            card.hidden = !show;
            if (rows.length === 0 && show) visible++;
        });
        if (resultEl && total > 0) {
            resultEl.textContent = visible + ' / ' + total;
        }
    }

    search.addEventListener('input', applyFilters);
    applyFilters();
})();