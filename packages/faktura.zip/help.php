<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/includes/help-content.php';

$hl = fk_help_lang($lang);
$h = fk_help_content($hl);
$settings = fk_load_settings();
$sub = $settings['subscription'] ?? [];
$subKey = 'note_' . ($hl === 'uk' ? 'uk' : ($hl === 'no' ? 'no' : 'en'));
$subNote = $sub[$subKey] ?? ($sub['note_en'] ?? '');

$current_page = 'help';
$page_title = $h['title'] . ' — Faktura Creator';
$page_desc = $h['intro'];

require __DIR__ . '/includes/header.php';

$langLinks = [];
foreach (fk_langs() as $code => $info) {
    $langLinks[$code] = [
        'label' => $info['label'],
        'url'   => fk_page_lang_url('help.php', $code),
    ];
}

$menu = $h['menu'] ?? [];
?>

<div class="fk-hero">
    <h1><?= fk_h($h['title']) ?></h1>
    <p><?= fk_h($h['intro']) ?></p>
    <p class="fk-help-langline">
        <?= fk_h($t['help']['langs'] ?? 'Instructions in 7 languages') ?> —
        <?php foreach ($langLinks as $code => $info): ?>
        <a href="<?= fk_h($info['url']) ?>"<?= $lang === $code ? ' class="active"' : '' ?>><?= fk_h($info['label']) ?></a><?= $code !== 'no' ? ' ·' : '' ?>
        <?php endforeach; ?>
    </p>
</div>

<div class="fk-help-layout">
    <details class="fk-help-menu" open>
        <summary class="fk-help-menu-title"><?= fk_h($h['menu_title'] ?? 'Contents') ?></summary>
        <nav aria-label="<?= fk_h($h['menu_title'] ?? 'Help menu') ?>">
            <ul>
                <?php foreach ($menu as $item): ?>
                <li><a href="<?= fk_h($item['href']) ?>"><i class="fas <?= fk_h($item['icon'] ?? 'fa-circle') ?>" aria-hidden="true"></i><span class="fk-menu-label"><?= fk_h($item['label']) ?></span></a></li>
                <?php endforeach; ?>
            </ul>
        </nav>
    </details>

    <div class="fk-help-content">
        <section class="fk-card fk-help-section" id="video">
            <h2><i class="fas fa-play-circle" aria-hidden="true"></i> <?= fk_h($h['video_title'] ?? 'Video guide') ?></h2>
            <p class="fk-help-lead"><?= fk_h($h['video_intro'] ?? '') ?></p>
            <div class="fk-video-steps">
                <?php foreach (($h['video_steps'] ?? []) as $vs): ?>
                <article class="fk-video-step">
                    <div class="fk-video-step-head">
                        <span class="fk-video-step-n"><?= fk_h($vs['n'] ?? '') ?></span>
                        <strong><?= fk_h($vs['t'] ?? '') ?></strong>
                    </div>
                    <?php if (!empty($vs['img'])): ?>
                    <a href="<?= fk_h($vs['link'] ?? '#') ?>" class="fk-video-shot" target="_blank" rel="noopener">
                        <img src="<?= fk_h($vs['img']) ?>" alt="<?= fk_h($vs['t'] ?? '') ?>" width="400" height="260" loading="lazy">
                    </a>
                    <?php endif; ?>
                    <p><?= fk_h($vs['d'] ?? '') ?></p>
                    <?php if (!empty($vs['link']) && !empty($vs['link_label'])): ?>
                    <a href="<?= fk_h($vs['link']) ?>" class="fk-btn fk-btn-ghost fk-btn-sm" target="_blank" rel="noopener"><?= fk_h($vs['link_label']) ?> →</a>
                    <?php endif; ?>
                </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="fk-card fk-help-section" id="countries">
            <h2><i class="fas fa-globe-europe" aria-hidden="true"></i> <?= fk_h($h['countries_title'] ?? '7 countries') ?></h2>
            <p class="fk-help-lead"><?= fk_h($h['countries_intro'] ?? '') ?></p>
            <div class="fk-country-demo-grid">
                <?php foreach (($h['country_demos'] ?? []) as $cd): ?>
                <a href="<?= fk_h($cd['link']) ?>" class="fk-country-demo-card" target="_blank" rel="noopener">
                    <?php if (!empty($cd['img'])): ?>
                    <img src="<?= fk_h($cd['img']) ?>" alt="" width="120" height="156" loading="lazy">
                    <?php endif; ?>
                    <span class="fk-country-demo-flag" aria-hidden="true"><?= $cd['flag'] ?></span>
                    <strong><?= fk_h($cd['no']) ?></strong>
                    <span class="fk-menu-desc"><?= fk_h($cd['label']) ?></span>
                    <em><?= fk_h($cd['currency']) ?> · <?= fk_h((string) $cd['rate']) ?>%</em>
                </a>
                <?php endforeach; ?>
            </div>
            <a href="<?= fk_h(fk_url('index.php#demo-invoices')) ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:1rem"><?= fk_h($t['home']['demo_title'] ?? 'Demo invoices') ?> →</a>
        </section>

        <section class="fk-card fk-help-section" id="steps">
            <h2><?= fk_h($t['help']['steps'] ?? 'Steps') ?></h2>
            <ol class="fk-help-steps">
                <?php foreach ($h['steps'] as $step): ?>
                <li><strong><?= fk_h($step['t']) ?></strong><span class="fk-menu-desc"><?= fk_h($step['d']) ?></span></li>
                <?php endforeach; ?>
            </ol>
        </section>

        <section class="fk-help-section" id="features">
            <h2 class="fk-section-heading"><?= fk_h($h['admin_features_title'] ?? 'Admin features') ?></h2>
            <div class="fk-grid fk-grid--2">
                <?php foreach (($h['admin_features'] ?? []) as $feat): ?>
                <div class="fk-card">
                    <h3><i class="fas <?= fk_h($feat['icon'] ?? 'fa-star') ?>" aria-hidden="true"></i> <?= fk_h($feat['t']) ?></h3>
                    <p class="fk-menu-desc"><?= fk_h($feat['d']) ?></p>
                    <?php if (!empty($feat['link'])): ?>
                    <a href="<?= fk_h($feat['link']) ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:.65rem" target="_blank" rel="noopener"><?= fk_h($feat['link_label'] ?? 'Open') ?> →</a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="fk-help-section" id="clients">
            <div class="fk-grid fk-grid--2">
                <div class="fk-card">
                    <h2><i class="fas fa-users" aria-hidden="true"></i> <?= fk_h($h['clients_title']) ?></h2>
                    <p class="fk-help-muted"><?= fk_h($h['clients_text']) ?></p>
                    <a href="<?= fk_admin_url('clients.php') ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:.75rem"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?> → <?= fk_h($t['admin']['clients'] ?? 'Clients') ?></a>
                </div>
                <div class="fk-card" id="ai">
                    <h2><i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i> <?= fk_h($h['ai_title']) ?></h2>
                    <p class="fk-help-muted"><?= fk_h($h['ai_text']) ?></p>
                    <a href="<?= fk_admin_url('ai.php') ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:.75rem"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?> → <?= fk_h($t['admin']['ai_nav'] ?? 'AI') ?></a>
                </div>
                <div class="fk-card" id="qr">
                    <h2><i class="fas fa-qrcode" aria-hidden="true"></i> <?= fk_h($h['qr_title']) ?></h2>
                    <p class="fk-help-muted"><?= fk_h($h['qr_text']) ?></p>
                    <a href="<?= fk_admin_url('settings.php') ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:.75rem"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?> → <?= fk_h($t['admin']['settings'] ?? 'Settings') ?></a>
                </div>
                <div class="fk-card" id="email">
                    <h2><i class="fas fa-envelope" aria-hidden="true"></i> <?= fk_h($h['email_title']) ?></h2>
                    <p class="fk-help-muted"><?= fk_h($h['email_text']) ?></p>
                    <a href="<?= fk_admin_url('send-mail.php') ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:.75rem"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?> → <?= fk_h($t['admin']['send_email'] ?? 'Send email') ?></a>
                </div>
            </div>
        </section>

        <section class="fk-card fk-help-section" id="devices">
            <h2><?= fk_h($h['devices_title']) ?></h2>
            <p class="fk-help-muted"><?= fk_h($h['devices_intro']) ?></p>
            <div class="fk-device-grid">
                <?php foreach ($h['devices'] as $d): ?>
                <div class="fk-device-card">
                    <i class="fas <?= fk_h($d['icon']) ?>" aria-hidden="true"></i>
                    <strong><?= fk_h($d['t']) ?></strong>
                    <p><?= fk_h($d['d']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="fk-help-section" id="smtp">
            <div class="fk-grid fk-grid--2">
                <div class="fk-card">
                    <h2><?= fk_h($h['smtp_title']) ?></h2>
                    <p class="fk-help-muted"><?= fk_h($h['smtp_text']) ?></p>
                    <a href="<?= fk_admin_url('smtp.php') ?>" class="fk-btn fk-btn-ghost fk-btn-sm" style="margin-top:.75rem"><?= fk_h($t['nav']['admin'] ?? 'Admin') ?> → SMTP</a>
                </div>
                <div class="fk-card" id="subscription">
                    <h2><?= fk_h($h['sub_title']) ?></h2>
                    <p class="fk-help-muted"><?= fk_h($h['sub_text']) ?></p>
                    <?php if ($subNote): ?><p style="font-size:.85rem;margin-top:.5rem"><?= fk_h($subNote) ?></p><?php endif; ?>
                    <a href="<?= fk_h($sub['join_url'] ?? 'https://bilohash.com/ecosystem/join.php') ?>" class="fk-btn fk-btn-primary fk-btn-sm" style="margin-top:.75rem" target="_blank" rel="noopener">BILOHASH ecosystem</a>
                </div>
            </div>
        </section>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>